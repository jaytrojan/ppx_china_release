// Example2.c : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#ifdef WIN32
#include <conio.h>
#endif

#include "host_definitions.h"
#include "driver_ext.h"
#include "host_services.h"
#include "driver_util.h"
#include "sensor_handling.h"
#include "sensor_stats.h"


//**************************************************************
//* example chip program                                    *
//**************************************************************
int main(int argc, char *argv[])
{
   I2C_HANDLE_T i2c_handle;
   I2C_HANDLE_T eeprom_i2c_handle;
   IRQ_HANDLE_T irq_handle;
   DI_INSTANCE_T * instance;
   u8 product_id;
   u8 revision_id;
   u16 rom_version;
   u16 ram_version;
   bool eeprom_present;
   DI_ERROR_T error_info;
   SENSOR_CONFIG sensor_config;
   u32 sensor_data_received;
   u32 prev_received = 0;
   bool executing;
   bool sensing;
   int i;
   //int port = 5;                                                     // change this to match your COM port number
   char *port = "\\\\.\\COM5";
   u32 output_timeout;

   info_log("U718x Sensor Output Logger v1.1\n\n");

   //**************************************************************
   //* set up I2C and Data Ready IRQ                              *
   //*                                                            *
   //* In this example, we assume we've already written functions *
   //* i2c_setup() and irq_setup() to interface our test platform *
   //* I2C and IRQ drivers to chip's Platform-intependent      *
   //* services.                                                  *
   //**************************************************************
   i2c_handle = i2c_setup(0x28, port);                   // handle for chip I2C access
   if (!i2c_init(i2c_handle))
   {
      error_log("I2C init error\n");
      return 1;
   }
   eeprom_i2c_handle = i2c_setup(0x50, port);
   if (!i2c_init(eeprom_i2c_handle))
   {
      error_log("I2C init error\n");
      return 1;
   }
   if (!i2c_handle || !eeprom_i2c_handle)
   {
      error_log("I2C setup error\n");
      return 1;
   }

   irq_handle = irq_setup(5, port);                      // the SPI /SS line on the Aardvark
   if (!irq_handle)
   {
      error_log("IRQ setup error\n");
      return 1;
   }


   //**************************************************************
   //* initialize chip                                            *
   //**************************************************************
   instance = di_init(i2c_handle, irq_handle, TRUE);                // reset chip
   if (!instance)
   {
      info_log("Driver setup error\n");
      return 1;
   }

   di_control_logging(instance, FALSE, FALSE, TRUE, FALSE);

   // make sure we can communicate with it
   if (!di_detect_chip(instance, NULL, NULL, NULL, NULL, NULL))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d detecting chip\n", error_info.driver_error);
      return 1;
   }
   // start chip firmware running
   if (!di_run_request(instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error starting: %d\n", error_info.driver_error);
      return 1;
   }

   // start the algorithm running
   if (!di_normal_exec_request(instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error running: %d\n", error_info.driver_error);
      return 1;
   }

   if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d detecting u718x\n", error_info.driver_error);
      return 1;
   }
   info_log("U718x detected.  Product id: u71%02X, revision id: %u, rom version: %u, ram version: %u, eeprom present: %u\n",
             product_id, revision_id, rom_version, ram_version, eeprom_present);

   info_log("\nWaiting for initialization complete...\n");
   output_timeout = time_ms() + 2000;
   instance->meta_events[DME_INITIALIZED] = 0;
   do
   {
      if (!di_task_loop(instance, NULL))
      {
         display_error_info(instance);
         break;
      }
      if (instance->meta_events[DME_INITIALIZED] || instance->meta_events_wakeup[DME_INITIALIZED])
      {
         info_log("Initialized event received; device is ready\n");
         break;
      }
   }
   while (time_ms() < output_timeout);
   if (!instance->meta_events[DME_INITIALIZED] && !instance->meta_events_wakeup[DME_INITIALIZED])
      info_log("Timeout!\n");
   di_pause_task_loop(instance);

   // find out what sensors are there
   if (!di_query_features(instance))
   {
      error_log("error retrieving sensor list\n");
      return 1;
   }

   // display info about the sensor drivers
   info_log("\nInformation about detected sensors:\n");
   if (!display_driver_info(instance))
   {
      error_log("error displaying driver info\n");
      return 1;
   }

   // set up the sample rates for all sensors
   sensor_config.change_sensitivity = 0;
   sensor_config.dynamic_range = 0;
   sensor_config.max_report_latency = 0;
   sensor_config.sample_rate = 100;
   if (!di_configure_sensor(instance, DST_ACCELEROMETER, &sensor_config))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d setting Accel rate\n", error_info.driver_error);
      return 1;
   }

   sensor_config.sample_rate = 200;
   if (!di_configure_sensor(instance, DST_GYROSCOPE, &sensor_config))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d setting Gyro rate\n", error_info.driver_error);
      return 1;
   }

   sensor_config.sample_rate = 30;
   if (!di_configure_sensor(instance, DST_GEOMAGNETIC_FIELD, &sensor_config))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d setting Magnetometer rate\n", error_info.driver_error);
      return 1;
   }

   sensor_config.sample_rate = 100;
   if (!di_configure_sensor(instance, DST_ROTATION_VECTOR, &sensor_config))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d setting Quaternion rate\n", error_info.driver_error);
      return 1;
   }

   // tell driver to call us when data arrives
   if (!di_register(instance, data_callback, (void *)instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error registering data callback: %d\n", error_info.driver_error);
      return 1;
   }

   time_delay_ms(400);

   // confirm all is well
   if (!di_query_status(instance, &executing, &sensing))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error reading status: %d\n", error_info.driver_error);
      return 1;
   }
   info_log("executing: %d, sensing: %d\n", executing, sensing);

   // init statistics
   reset_stats();

   // update the scale factors now that it is running
   if (!di_query_features(instance))
   {
      error_log("error detecting sensors\n");
      return 1;
   }

   // display actual sample rates implemented by the drivers
   info_log("\nActual sensor settings:\n");
   if (!display_actual_rates(instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error reading status: %d\n", error_info.driver_error);
      return 1;
   }

   if (!di_query_sensor_status(instance))
   {
      error_log("error querying sensor status bits\n");
      return 1;
   }
   else
   {
      info_log("\nSensor status bits:\n");
      display_sensor_status_bytes(instance, TRUE);
   }

   // select a sensor as the source of host interrupts
   if (!di_configure_interrupts(instance, TRUE, 0))
   {
      di_get_last_error(instance, &error_info);
      error_log("Error enabling sensor: %d\n", error_info.driver_error);
      return 1;
   }

   info_log("\nRunning:\n");
   //**************************************************************
   //* process sensor data (first 100 samples)                    *
   //**************************************************************
   for (i = 0; i < 100;)
   {
      if (!di_task_loop(instance, NULL))
      {
         display_error_info(instance);
      }
      else if ((sensor_data_received = get_sensor_data_received_count()) != prev_received)
      {
         prev_received = sensor_data_received;
         i++;                                                        // one sample received
      }
#ifdef WIN32
      if (_kbhit())
      {
         char sel = _getch();
         di_pause_task_loop(instance);
         if (sel == ' ')
         {
            // display actual sample rates implemented by the drivers
            info_log("\nDetermine actual rates for sensors:\n");
            if (!display_actual_rates(instance))
            {
            }
         }
         else
         {
            info_log("Cancelled\n");
            break;
         }
      }
#endif
   }

   info_log("\nSummary:\n");
   calc_periodic_stats(instance);
   display_periodic_stats(instance, TRUE);

   info_log("\nDone.\n");

   di_deregister(instance);
   di_standby_request(instance);
   di_shutdown_request(instance);
   di_deinit(instance);

   return 0;
}

