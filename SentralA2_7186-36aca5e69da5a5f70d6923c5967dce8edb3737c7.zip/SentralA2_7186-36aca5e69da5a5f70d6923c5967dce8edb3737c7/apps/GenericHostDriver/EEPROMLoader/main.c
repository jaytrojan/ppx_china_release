#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "driver_ext.h"
#include "host_services.h"
#include "host_definitions.h"
#include "driver_util.h"
#include "main.h"

#if !defined(VERSION)
#define VERSION 4
#endif

void print_signon(void)
{
   info_log("U718x EEPROMLoader v1.1.%d, %s, %s\n\n", VERSION, __DATE__, __TIME__);
}

void print_usage(char *app)
{
   info_log("Usage: %s {-e} {-r} {-x} {-v} {-a} {-llog} {-ffile} {-Uid}\n", app);
   info_log("-e     erase EEPROM\n");
   info_log("-r     upload to RAM instead of EEPROM\n");
   info_log("-x     force ROMVerExp to 0 (any ROM)\n");
   info_log("-v     set verbose output\n");
   info_log("-a     append to log\n");
   info_log("-llog  log output to file 'log'\n");
   info_log("-ffile set the 718x firmware filename here\n");
   info_log("-Uid   select I2C interface with unique ID = id\n");
}

int main(int argc, char *argv[])
{
   I2C_HANDLE_T i2c_handle = NULL;
   I2C_HANDLE_T eeprom_i2c_handle = NULL;
   IRQ_HANDLE_T irq_handle = NULL;
   DI_INSTANCE_T *instance = NULL;
   DI_ERROR_T error_info;
   u8 product_id;
   u8 revision_id;
   u16 rom_version;
   u16 ram_version;
   bool eeprom_present;
   bool append_log = FALSE;
   int i;
   bool verbose = FALSE;
   bool erase = FALSE;
   bool upload_ram = FALSE;
   bool force_anyrom = FALSE;
   char log_file[1024] = "";
   char firmware[1024] = "";
   char *unique_id = NULL;
   struct tm *ltime;
   time_t now;

   // process command line
   if (argc > 1)
   {
      for (i = 1; i < argc; i++)
      {
         if ((argv[i][0] == '-') || (argv[i][0] == '/'))
         {
            switch (argv[i][1])
            {
               case 'e':
                  erase = TRUE;
                  break;
               case 'x':
                  force_anyrom = TRUE;
                  break;
               case 'r':
                  upload_ram = TRUE;
                  break;
               case 'v':
                  verbose = TRUE;
                  break;
               case 'a':
                  append_log = TRUE;
                  info_log("will append to log\n");
                  break;
               case 'l':
                  strcpy(log_file, &argv[i][2]);
                  info_log("using log file: %s\n", log_file);
                  break;
               case 'f':
                  strcpy(firmware, &argv[i][2]);
                  info_log("using firmware file: %s\n", firmware);
                  break;
               case 'U':
                  unique_id = _strdup(&argv[i][2]);
                  break;
               case 'h':
               case '?':
                  print_signon();
                  print_usage(argv[0]);
                  return 0;
            }
         }
      }
   }

   if (0) // !erase && (strlen(firmware) == 0))
   {
      print_signon();
      print_usage(argv[0]);
      error_log("\nno filename specified for upload\n");
      return -1;
   }


   // log to file if requested
   if (log_file[0] != '\0')
      debug_set_log_file(log_file, append_log);

   // log the name of the test
   print_signon();

   // display test start date / time
   time(&now);
   ltime = localtime(&now);
   info_log("current date and time: %s\n", asctime(ltime));

   /**************************************************************
   * set up I2C and Data Ready IRQ                               *
   ***************************************************************/
   i2c_handle = i2c_setup(0x28, unique_id);                   // handle for 718x I2C access
   if (!i2c_init(i2c_handle))
   {
      error_log("I2C init error\n");
      goto error_exit;
   }
   eeprom_i2c_handle = i2c_setup(0x50, unique_id);
   if (!i2c_init(eeprom_i2c_handle))
   {
      error_log("I2C init error\n");
      goto error_exit;
   }
   if (!i2c_handle || !eeprom_i2c_handle)
   {
      error_log("I2C setup error\n");
      goto error_exit;
   }

   irq_handle = irq_setup(5, unique_id);                      // the SPI /SS line on the Aardvark
   if (!irq_handle)
   {
      error_log("IRQ setup error\n");
      goto error_exit;
   }

   /**************************************************************
   * initialize 718x                                          *
   ***************************************************************/
   instance = di_init(i2c_handle, irq_handle, TRUE);
   if (!instance)
   {
      error_log("Driver setup error\n");
      goto error_exit;
   }

   if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
   {
      di_get_last_error(instance, &error_info);
      error_log("Error %d detecting u718x\n", error_info.driver_error);
      goto error_exit;
   }

   info_log("U718x detected.  Product id: u71%02X, revision id: %u, rom version: %u, ram version: %u, eeprom present: %u\n",
             product_id, revision_id, rom_version, ram_version, eeprom_present);

   /**************************************************************
   * load firmware                                               *
   ***************************************************************/
   if (erase)
   {
      info_log("erasing EEPROM...");
      if (!di_erase_eeprom(instance, eeprom_i2c_handle))
      {
         error_log("failed!\n");
         goto error_exit;
      }
      else
         info_log("erase complete\n");
   }

   if (strlen(firmware))
   {
      if (!upload_ram)
      {
         info_log("Uploading to EEPROM...\n");
         if (!di_upload_eeprom(instance, eeprom_i2c_handle, firmware, force_anyrom, NULL))
         {
            di_get_last_error(instance, &error_info);
            error_log("Error uploading firmware: %d\n", error_info.driver_error);
            goto error_exit;
         }
      }
      else
      {
         info_log("Uploading to RAM...\n");
         if (!di_upload_firmware(instance, firmware, force_anyrom, NULL))
         {
            di_get_last_error(instance, &error_info);
            error_log("Error uploading firmware: %d\n", error_info.driver_error);
            goto error_exit;
         }
      }
   }

   // start 718x firmware running
   if (!di_run_request(instance))
   {
      di_get_last_error(instance, &error_info);
      error_log("Error starting: %d\n", error_info.driver_error);
   }

   // now that we're running, we can check the ram version
   if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
   {
      di_get_last_error(instance, &error_info);
      error_log("Error %d detecting 718x\n", error_info.driver_error);
      goto error_exit;
   }
   info_log("RAM version is now: %u\n", ram_version);

   error_exit:
   if (instance)
   {
      di_deregister(instance);
      di_standby_request(instance);
      di_shutdown_request(instance);
      di_deinit(instance);
   }
   debug_set_log_file(NULL, FALSE);
   return 0;
}


