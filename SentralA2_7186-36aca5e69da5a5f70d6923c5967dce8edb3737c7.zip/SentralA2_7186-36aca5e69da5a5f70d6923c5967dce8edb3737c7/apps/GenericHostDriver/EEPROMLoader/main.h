#ifndef _MAIN_H_
#define _MAIN_H_

#include "types.h"
#include "host_services.h"
#include "driver_ext.h"

#define EEPROM_FILE        "EEPROM.FW"   // file to load to EEPROM if in force-upload

//typedef uint32_t bool;
#define TRUE 1
#define FALSE 0

#endif

