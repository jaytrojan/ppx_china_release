#include "test_common.h"
#ifndef WIN32
#include <unistd.h>
#else
#include <conio.h>
#endif
/**
* \brief EEPROM Upload Tests (not needed for BST but useful for
* EM testing)
* Upload EEPROM (valid image, EEPROMNoExec bit set in header)
* Confirm EEPROMDetected, EEUploadDone, Idle bits are correct in
* Chip Status
*/
TEST_START(1_1)
{
   RegHostStatus hs;
   RegChipStatus cs;

   if (config.eeprom_present)
   {
      TEST_ASSERT(di_upload_eeprom(di, eeprom_i2c_handle, EEPROM_NOEXEC_FILE, 0, NULL));
      TEST_ASSERT(di_reg_read(di, SR_HOST_STATUS, &hs.reg, 1));
      TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1));
      TEST_ASSERT(hs.bits.CPUReset);
      TEST_ASSERT(cs.bits.EEUploadDone       &&
                  !cs.bits.EEUploadError  &&
                  !cs.bits.NoEEPROM);
      return TEST_PASSED;
   }
   else
   {
      info_log("EEPROM not present; test skipped\n");
      return TEST_SKIPPED;
   }
}
TEST_END


/**
 * \brief Upload EEPROM (valid image, EEPROMNoExec bit clear in
 * header) Confirm EEPROMDetected, EEUploadDone, Idle bits are
 * correct in Chip Status
 */
TEST_START(1_2)
{
   RegHostStatus hs;
   RegChipStatus cs;

   if (config.eeprom_present)
   {
      TEST_ASSERT(di_upload_eeprom(di, eeprom_i2c_handle, EEPROM_EXEC_FILE, 0, NULL));
      TEST_ASSERT(di_reg_read(di, SR_HOST_STATUS, &hs.reg, 1));
      TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1));
      TEST_ASSERT(hs.bits.CPUReset);
      TEST_ASSERT(cs.bits.EEUploadDone       &&
                  !cs.bits.EEUploadError  &&
                  !cs.bits.NoEEPROM);
      return TEST_PASSED;
   }
   else
   {
      info_log("EEPROM not present; test skipped\n");
      return TEST_SKIPPED;
   }
}
TEST_END


/**
 * \brief Upload EEPROM (test I2CClockSpeed header values?)
 */
TEST_START(1_3)
{
   RegChipStatus cs;
   u32 start;
   u32 normal_delta;
   u32 fast_delta;

   if (config.eeprom_present)
   {
      info_log("Uploading to EEPROM at default 400KHz...\n");
      TEST_ASSERT(di_upload_eeprom(di, eeprom_i2c_handle, EEPROM_NORMAL_FILE, 0, NULL));

      // time the reset process; this is when chip actually reads from the EEPROM
      start = time_ms();
      TEST_ASSERT(di_reset_chip(di, FALSE));
      normal_delta = time_ms() - start;

      TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1));

      TEST_ASSERT(cs.bits.EEUploadDone &&
                  !cs.bits.EEUploadError &&
                  !cs.bits.NoEEPROM);

      info_log("U718x Status: 0x%02X\n", cs.reg);

      info_log("Uploading to EEPROM at fast 1000KHz...\n");
      TEST_ASSERT(di_upload_eeprom(di, eeprom_i2c_handle, EEPROM_FAST_FILE, 0, NULL));

      start = time_ms();
      TEST_ASSERT(di_reset_chip(di, FALSE));
      fast_delta = time_ms() - start;

      TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1));

      TEST_ASSERT(cs.bits.EEUploadDone &&
                  !cs.bits.EEUploadError &&
                  !cs.bits.NoEEPROM);

      info_log("U718x Status: 0x%02X\n", cs.reg);

      info_log("fast delta t = %u ms; normal delta t = %u ms\n", fast_delta, normal_delta);
      TEST_ASSERT(!config.ignore_sample_rates && (fast_delta <= (normal_delta / 1.8)));
      return TEST_PASSED;
   }
   else
   {
      info_log("EEPROM not present; test skipped\n");
      return TEST_SKIPPED;
   }
}
TEST_END


/**
 * \brief Upload EEPROM (test ROMVerExp header values?)
 */
TEST_START(1_4)
{
   u8 version[4];
   u8 rev;
   char *test_file;

   if (config.eeprom_present)
   {
      TEST_ASSERT(i2c_blocking_read(di->i2c_handle, SR_ROM_VERSION, version, 4));
      TEST_ASSERT(i2c_blocking_read(di->i2c_handle, SR_REVISION_ID, &rev, 1));

      di->rom_version = ((u16)version[0]) | (((u16)version[1]) << 8);
      di->ram_version = ((u16)version[2]) | (((u16)version[3]) << 8);
      di->revision_id = rev;

      // pick a file that targets a different ROM
      if (di->revision_id == 1)
         test_file = EEPROM_DI02_SPECIFIC_FILE;
      else
         test_file = EEPROM_DI01_SPECIFIC_FILE;

      info_log("Uploading to EEPROM...\n");
      TEST_ASSERT(di_upload_eeprom(di, eeprom_i2c_handle, test_file, config.force_anyrom, NULL));

      // check results
      TEST_ASSERT(i2c_blocking_read(di->i2c_handle, SR_CHIP_STATUS, &di->error.chip_status.reg, 1));
      info_log("U718x Status: 0x%02X\n", di->error.chip_status.reg);

      TEST_ASSERT(di->error.chip_status.bits.FirmwareHalted &&
                  !di->error.chip_status.bits.EEUploadDone &&
                  !di->error.chip_status.bits.EEPROMDetected &&
                  !di->error.chip_status.bits.EEUploadError &&
                  di->error.chip_status.bits.NoEEPROM);
      return TEST_PASSED;
   }
   else
   {
      info_log("EEPROM not present; test skipped\n");
      return TEST_SKIPPED;
   }
}
TEST_END


/**
 *  \brief Upload EEPROM (invalid image)
 *  Confirm EEPROMDetected, EEUploadError bits are correct in
 *  Chip Status
 */
TEST_START(1_5)
{
   RegChipStatus cs;
   if (config.eeprom_present)
   {

      info_log("Uploading to EEPROM...\n");
      TEST_ASSERT(di_upload_eeprom(di, eeprom_i2c_handle, EEPROM_INVALID_FILE, 0, NULL));
      TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1));
      info_log("U718x Status: 0x%02X\n", cs.reg);
      TEST_ASSERT(cs.bits.EEUploadDone && cs.bits.EEUploadError && !cs.bits.NoEEPROM);

      return TEST_PASSED;
   }
   else
   {
      info_log("EEPROM not present; test skipped\n");
      return TEST_SKIPPED;
   }
}
TEST_END
//---------------------------------------------------------------------------------------
/**
 *  \brief Test to enable all sensors at maximum rate
 */
TEST_START(1_6)
{
   DI_SENSOR_TYPE_T sensor;
   DI_SENSOR_TYPE_T tmp_sens;
   /*FILE *p_file_out;
   int size;
   //int i;
   char ch[]={1,2,3,4,5,6,7,8,9,10};*/
   u32 tm_beg;
   u32 tm_now;
   u32 tm_dif;
   u32 smpl_rcv;
   u32 smpl_rcv_sum;
   u32 smpl_rcv_sum_zero_cnt;
   u32 acel_same_cnt = 0;
   u32 acel_dif_cnt = 0;
   DI_3AXIS_INT_DATA_T *axes3;
   DI_3AXIS_INT_DATA_T last_axes3;
   char *last_3axes_same;
   bool first_run = TRUE;
   int enSens[255] = {
      0,                                                             // DST_NOP = 0,
      1,                                                             //DST_ACCELEROMETER
      1,                                                             // DST_GEOMAGNETIC_FIELD = 2,
      1,                                                             //DST_ORIENTATION = 3,
      1,                                                             //DST_GYROSCOPE = 4,
      1,                                                             //DST_LIGHT = 5,
      1,                                                             //DST_PRESSURE = 6,
      1,                                                             //DST_TEMPERATURE = 7,                                           // not used
      1,                                                             //DST_PROXIMITY = 8,
      1,                                                             //DST_GRAVITY = 9,
      1,                                                             //DST_LINEAR_ACCELERATION = 10,
      1,                                                             //DST_ROTATION_VECTOR = 11,
      1,                                                             //DST_RELATIVE_HUMIDITY = 12,
      1,                                                             //DST_AMBIENT_TEMPERATURE = 13,
      1,                                                             //DST_MAGNETIC_FIELD_UNCALIBRATED = 14,
      1,                                                             //DST_GAME_ROTATION_VECTOR = 15,
      1,                                                             //DST_GYROSCOPE_UNCALIBRATED = 16,
      1,                                                             //DST_SIGNIFICANT_MOTION = 17,
      1,                                                             //DST_STEP_DETECTOR = 18,
      1,                                                             //DST_STEP_COUNTER = 19,
      1,                                                             //DST_GEOMAGNETIC_ROTATION_VECTOR = 20,
      1,                                                             //DST_HEART_RATE = 21,
                                                                     // future Android L product only:
      1,                                                             //DST_TILT_DETECTOR = 22,
      0,                                                             //DST_WAKE_GESTURE = 23,
      1,                                                             //DST_GLANCE_GESTURE = 24,
      1,                                                             //DST_PICKUP_GESTURE = 25,
      1,                                                             // 26
      1,                                                             // 27
      1,                                                             // 28
      1,                                                             //DST_JERK_EXAMPLE = 29,
      1,                                                             //DST_CAL_STATUS = 30,
      1,                                                             //DST_ACTIVITY = 31,
   };


#define LOG_EVERY_MS 1000
#define USE_RATE_HZ 200

   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);

   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   // enable all sensors
   for (sensor = DST_FIRST; sensor <= di_max_sensor_id(di); sensor++)
   {
      //SENSOR_INFORMATION info;
      if (!di_has_sensor(di, sensor))
      {
         continue;
      }

      if (di->hi_id == HIID_KITKAT)
         tmp_sens = (int)sensor;
      else
         tmp_sens = (sensor < di_wake_sensor_start(di)) ? (int)sensor : (int)(sensor - di_wake_sensor_start(di));
      if (enSens[tmp_sens] == 0)
      {
         continue;
      }
      TEST_ASSERT(di_configure_rate(di, sensor, USE_RATE_HZ, 0));
   }
   // wait sensors get initialized
   time_delay_ms(TEST_RUN_DELAY);
   // read sensor actual configuration (rate and dynamic range)
   TEST_ASSERT(di_query_features(di));
   // print all sensors rate
   for (sensor = DST_FIRST; sensor <= di_max_sensor_id(di); sensor++)
   {
      info_log("Sensor %d ", sensor);
      info_log("%s : ", di_query_sensor_name(di, sensor));

      if (!di_has_sensor(di, sensor))
      {
         info_log("NA\n");
      }
      else
      {
         info_log("act rate: %d\n", di->sensor_info[sensor].actual_rate);
      }
   }

   display_error_info(di);
   /*p_file_out=fopen("test.bin","wb");
   if (!p_file_out)
   {
      printf("Unable to open file!");
      return 1;
   }*/
   tm_beg = time_ms();
   smpl_rcv_sum = 0;
   smpl_rcv_sum_zero_cnt = 0;
   memset(&last_axes3, 0, sizeof(last_axes3));

   while (TRUE)
   {

      read_FIFO(1, FALSE, &smpl_rcv);
      smpl_rcv_sum += smpl_rcv;

      tm_now = time_ms();
      tm_dif = tm_now - tm_beg;
      if (tm_dif > LOG_EVERY_MS)
      {
         tm_beg += LOG_EVERY_MS;
         info_log("Fifo Ovf: W/NW: %u/%u  Error: %u/%u invalid smpls: %u smplRec: %u zeroSum: %u\n",
                  di->meta_events_wakeup[DME_FIFO_OVERFLOW], di->meta_events[DME_FIFO_OVERFLOW],
                  di->meta_events_wakeup[DME_ERROR], di->meta_events[DME_ERROR],
                  di->total_invalid_samples_received, smpl_rcv_sum,
                  smpl_rcv_sum_zero_cnt);
         axes3 = &di->last_sample.accel;
         if (last_axes3.x == axes3->x &&
             last_axes3.y == axes3->y &&
             last_axes3.z == axes3->z)
         {
            acel_same_cnt++;
            last_3axes_same = "Same";
         }
         else
         {
            acel_dif_cnt++;
            last_3axes_same = "Differ";
         }
         last_axes3 = *axes3;
         info_log("Last Accel: x:%d y:%d z:%d (%s) total same/diff :%u / %u (samples recv: %u)\n",
                  axes3->x, axes3->y, axes3->z, last_3axes_same, acel_same_cnt, acel_dif_cnt,
                  di->sensor_info[DST_ACCELEROMETER].samples_received);

         if (smpl_rcv_sum == 0)
         {
            display_error_info(di);
            smpl_rcv_sum_zero_cnt++;

         }
         if (smpl_rcv_sum_zero_cnt >= 3)
         {
            break;
         }
         smpl_rcv_sum = 0;
         first_run = FALSE;
      }
#ifdef WIN32
      if (_kbhit())
      {
         char sel = _getch();
         if (sel == 'x')
         {
            TEST_ASSERT(acel_same_cnt < (acel_dif_cnt * 0.1))
            TEST_ASSERT(smpl_rcv_sum_zero_cnt == 0);
            break;
         }
      }
#endif
   }

   /*size = 3;
   fwrite(&size, sizeof(size), 1, p_file_out);
   fwrite(ch, size, 1, p_file_out);
   size = 5;
   fwrite(&size, sizeof(size), 1, p_file_out);
   fwrite(ch, size, 1, p_file_out);

   fclose(p_file_out);*/
   return 0;




}
TEST_END
