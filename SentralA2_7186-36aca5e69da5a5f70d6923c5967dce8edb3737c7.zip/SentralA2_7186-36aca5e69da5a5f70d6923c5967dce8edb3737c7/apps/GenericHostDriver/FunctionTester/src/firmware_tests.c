/**
 * \file    firmware_tests.c
 *
 * \brief   firmware tests
 *
 * \copyright (C) 2013-2014 EM Microelectronic
 *
 */
#include "test_common.h"
#include "test_x.h"

#define TEST_DESC(id,name,desc)  { do_test_##id, name, desc, 1 }
static struct test_desc tests[] =
{
   TEST_DESC(1_1, "1.1",   "Valid EEPROM Load, noexec set"),
   TEST_DESC(1_2, "1.2",   "Valid EEPROM Load, noexec clr"),
   TEST_DESC(1_3, "1.3",   "EEPROM Load, I2CClockSpeed"),
   TEST_DESC(1_4, "1.4",   "EEPROM Load, ROMVerExp"),
   TEST_DESC(1_5, "1.5",   "EEPROM Load, invalid image"),
   TEST_DESC(1_6, "1.6",   "Test All Sensors At maximum Speed"),

   TEST_DESC(2_1, "2.1",   "RAM Load, Valid image"),
   TEST_DESC(2_2, "2.2",   "RAM Load, Invalid image"),

   TEST_DESC(5_1, "5.1",   "Host Interrupt Enable Bit Functions"),
   TEST_DESC(5_2, "5.2",   "Reset Register Triggers Reset Interrupt"),

   TEST_DESC(6_1, "6.1",   "Sensor Presence Detection"),
   TEST_DESC(6_2, "6.2",   "Missing Sensor Detection"),
   TEST_DESC(6_3, "6.3",   "Mismatched Sensor Detection"),

   TEST_DESC(7_1, "7.1",   "Parameter Read/Validate"),
   TEST_DESC(7_2, "7.2",   "Parameter Write/Read/Validate"),
   TEST_DESC(7_3, "7.3",   "Parameter Transfer Performance & Reliability"),
   TEST_DESC(7_4, "7.4",   "Short Parameter Transfers"),

   //TEST_DESC(8_1, "8.1",   "vbe ad hoc test - todo remove ultimately"),
   TEST_DESC(8_2, "8.2",   "Bytes Remaining Register"),
   TEST_DESC(8_3, "8.3",   "Abort Transfer Bit"),
   TEST_DESC(8_4, "8.4",   "Update Transfer Count Bit"),
   TEST_DESC(8_5_0, "8.5.0",   "Host FIFO Control: watermark test"),
   TEST_DESC(8_5_1, "8.5.1",   "Host FIFO Control: Expect No interrupts"),
   TEST_DESC(8_5_2, "8.5.2",   "Host FIFO Control"),
   TEST_DESC(8_5_3, "8.5.3",   "Host FIFO Control: Expect Interrupts"),
   TEST_DESC(8_7, "8.7",   "Max Report Latency"),
   TEST_DESC(8_8, "8.8",   "Pause and resume transfer"),
   TEST_DESC(8_9, "8.9",   "FIFO Overflow"),
   TEST_DESC(8_10, "8.10", "Sample Parsing"),
   TEST_DESC(8_11, "8.11", "FIFO Flush"),

   TEST_DESC(9_1, "9.1",   "Data Available Bits"),
   TEST_DESC(9_2, "9.2",   "Data Lost Bits"),
   TEST_DESC(9_3, "9.3",   "Power Mode Bits"),
   TEST_DESC(9_4, "9.4",   "Sensor Data Scaling"),
   TEST_DESC(9_5, "9.5",   "Sample Rate Control"),
   TEST_DESC(9_5_CAL, "9.5.cal",   "Sample Rate Control DST_CAL_STATUS"),
   TEST_DESC(9_5_JERK, "9.5.jerk",   "Sample Rate Control DST_JERK_EXAMPLE"),
   TEST_DESC(9_5_SPD, "9.5.spd",   "Sample Rate Control DST_SPEED == JERK_EXAMPLE"),
   TEST_DESC(9_6, "9.6",   "Sample Rate Setting Reliability"),
   TEST_DESC(9_8, "9.8",   "Sensor Configuration Dynamic Range"),

   TEST_DESC(10_1, "10.1", "Flush Complete Meta Event"),
   TEST_DESC(10_2, "10.2", "Sample Rate Changed Meta Event"),
   TEST_DESC(10_3, "10.3", "Power Mode Changed Meta Event"),
   TEST_DESC(10_6, "10.6", "Sensor Error Meta Event"),
   TEST_DESC(10_7, "10.7", "FIFO Overflow Meta Event"),
   TEST_DESC(10_8, "10.8", "Dynamic Range Changed Meta Event"),
   TEST_DESC(10_9, "10.9", "FIFO Watermark Meta Event"),

   TEST_DESC(12_1, "12.1", "Pass Through"),
   TEST_DESC(12_2, "12.2", "SCL Low Cycles"),
   TEST_DESC(12_3, "12.3", "Resume After Pass Through"),

   TEST_DESC(13_1, "13.1", "Firmware Version"),

   TEST_DESC(15_1, "15.1", "Data Repetition"),
   TEST_DESC(15_2, "15.2", "Data Loss"),
   TEST_DESC(15_3, "15.3", "Data Cross-Sensor Synchronization"),

   TEST_DESC(UC_1, "UC.1", "Sensor Independence"),
};

#define NUM_TESTS    ARRAY_SIZE(tests)

/*
3. System Power Consumption
This means measuring power of U718x + attached sensors but no other parts (not the host AP).
3.1.  when in initialize mode (no sensors on)
3.2.  with accel only on, min and max rates
3.3.  with gyro only on, min and max rates
3.4.  with mag only on, min and max rates
3.5.  with all sensors on, min and max rates

4. State Transitions (can potentiality be verified with current measurements and timestamp checking)
4.1.  System can transition from hardware-standby to normal operation (no sensors enabled)
4.2.  System can transition from hardware-standby to normal operation (multiple sensors enabled)
4.3.  System can transition from normal operation (no sensors enabled) to normal operation (one plus sensors enabled)
4.4.  System can transition from normal operation (multiple sensors) to normal operation (no sensors) multiple times.
4.5.  Host Interface Control Register Algorithm Standby Request enable and status bits work properly
set up sensors; assert this bit; confirm status reflects it; confirm sensors are shutdown to save power

5.3.  Cause a watchdog timeout by going into pass through mode with the algorithm running

8. FIFO Transfer Mechanism
8.1.  Host Status Register (no-metal-change mode)
set up accel; let data accumulate; update transfer count; read blocks of data smaller than 50 bytes (so read often enough to keep the FIFO mostly empty) and confirm the Previous X value is correct
8.8.  Pause and Resume
set up accel (or known test pattern generator); confirm we can start a transfer, switch to reading other registers, then go back and pick up data transfer where we left off

9.6.  Sensor Configuration Actual Sample Rate return values close to measured sample rates
9.7.  Sensor Configuration Change Sensitivity (later)
9.8.  Sensor Configuration Dynamic Range (later)
9.9.  Host Interface Control Register NED bit works properly; ideally done with device in various orientations (later)

10.4. Error
10.5. Host IRQ Timestamp
10.8. Dynamic Range Changed

11.   Still Mode handling (ALL TBD; these sub items are all old)
11.1. Disabling individual sensors works properly when in still mode
11.2. Disabling individual sensors works properly when not in still mode
11.3. Still mode exits when enabling a sensor
11.4. Still mode with gyro enhancement does turn off gyro
11.5. When system is not moved, system detects stillness and powers down sensors (is this part of BSX?  Or does our framework have to do this?)

12.1 general operation of pass through (enter, communicate with EEPROM, exit)
12.2 SCLLowCycles + SensorToHostEn works (test using oscilloscope and sensor that is known to stretch the clock)? this always passes

13.2. Orientation Matrices are handled correctly
13.3. Config Data Structure
fw file structure  verify signature, RAM version, CDS version, host irq pin, GPIO pull selection, device name

14.   StuffELF
The StuffELF utility is used manually, by the build system, and by the web configuration websites.  Some features are tested by executing tests 1-5.
14.1. Host Interrupt Pin
14.2. Sensor GPIO Pins (for each sensor)
14.3. Sensor Slave Addresses (for each sensor)
14.4. Sensor Ranges (for each sensor)

16.   Regression Tests
16.1. TBD
*/

int get_num_tests(void)
{
   return NUM_TESTS;
}

void set_all_tests_loop(int loops)
{
   int i;
   for (i = 0; i < NUM_TESTS; i++) {
      tests[i].loop_count = loops;
   }
}

struct test_desc *find_test(const char *name)
{
   int i;
   for (i = 0; i < NUM_TESTS; i++) {
      struct test_desc *test = &tests[i];
      if (strcasecmp(test->name, name) == 0)
         return test;
   }

   return NULL;
}

struct test_desc *get_test(int index)
{
   if (index >= 0 && index < NUM_TESTS)
      return &tests[index];

   return NULL;
}

static void print_tests(int status)
{
   int i;
   for (i = 0; i < NUM_TESTS; i++) {
      struct test_desc *test = get_test(i);
      if (test->result != status)
         continue;
      info_log("\tTest %s: %s\n", test->name, test->desc);
   }
}

const char *result_to_string(int result)
{
   const char *s = "ERROR";
   switch (result) {
      case TEST_PASSED:
         s = "PASS";
         break;
      case TEST_FAILED:
         s = "FAIL";
         break;
      case TEST_ABORTED:
         s = "ABORT";
         break;
      case TEST_SKIPPED:
         s = "SKIPPED";
         break;
      case TEST_NOT_IMPLEMENTED:
         s = "NOT IMPLEMENTED";
         break;
      default:
         ;
   }

   return s;
}


int test_run_all(DI_INSTANCE_T *instance)
{
   int i;
   int passed = 0, failed = 0, skipped = 0, aborted = 0, noimpl = 0;
   const char *s;
   u32 tm_beg_test_ms;                                               // begin time for all tests
   u32 tm_beg_ms;                                                    // begin time for each test
   u32 tm_end_ms;                                                    // end time
   u32 tm_dif_ms;                                                    // difference time
// temporary string buffer size
#define TMP_STR_SZ 200
   char tmp_str[TMP_STR_SZ];                                         // temporary string buffer

   di = instance;

   info_log("Starting %d tests\n", NUM_TESTS);
   tm_beg_test_ms = time_ms();

   TEST_ASSERT((eeprom_i2c_handle = i2c_setup(0x50, 0)) > 0);
   TEST_ASSERT(i2c_init(eeprom_i2c_handle));

   for (i = 0; i < NUM_TESTS; i++)
   {
      int j;
      int tpassed = 0, tfailed = 0, taborted = 0, tskipped = 0;
      struct test_desc *test = get_test(i);

      if (!test)
      {continue;
      }

      info_log("\nStarting test %d/%d: %s: %s...\n", i + 1, NUM_TESTS, test->name, test->desc);
      tm_beg_ms = time_ms();
      if (test->loop_count == 0) {
         //info_log("skipping test %s\n", test->name);
         test->result = TEST_SKIPPED;
      }
      else
      {
         if (config.reset_each_test && !di_reset_chip(di, TRUE)) {
            error_log("FAILED TO RESET CHIP");
            return TEST_FAILED;
         }
         // defualt logging setup
         di->quiet_loading = FALSE;
         di->quiet_meta_events = FALSE;
         di->quiet_timestamp_errors = FALSE;
         di->quiet_gap_errors = FALSE;
         di->dump_raw_data = FALSE;

         for (j = 0; j < test->loop_count; j++) {
            info_log("=== Test: %s loop %d/%d =============================================\n",
                     test->name, j + 1, test->loop_count);
            fflush(stdout);
            test->result = test->handler(j == 0);
            display_error_info(di);

            switch (test->result) {
               case TEST_PASSED:
                  tpassed++;
                  break;
               case TEST_FAILED:
                  tfailed++;
                  j = test->loop_count;                              // no point in looping over failed tests
                  break;
               case TEST_ABORTED:
                  taborted++;
                  j = test->loop_count;                              // no point in looping over aborted tests
                  break;
               case TEST_SKIPPED:
                  tskipped++;
                  j = test->loop_count;                              // no point in looping over skipped tests
                  break;
               case TEST_NOT_IMPLEMENTED:
                  j = test->loop_count;                              // no point in looping over unimplemented tests
                  break;
               default:
                  error_log("Unhandled result: %d\n", test->result);
            }

            test->iterations++;
         }

         if (config.shutdown_sensors_each_test && !di_shutdown_request(di)) {
            error_log("FAILED TO SHUTDOWN CHIP");
            return TEST_FAILED;
         }
      }

      //if(test->iterations > 0) printCommunicationInfo(di);
      tm_end_ms = time_ms();
      tm_dif_ms = tm_end_ms - tm_beg_ms;
      if (test->iterations > 1)
      {
         test->result = (tpassed == test->loop_count) ? TEST_PASSED : TEST_FAILED;
      }
      s = result_to_string(test->result);
      time_to_str(tmp_str, TMP_STR_SZ, tm_dif_ms);
      info_log("%s: Test %s Run Time: %s", s, test->name, tmp_str);
      if (test->iterations > 1)
      {
         info_log(" (%d/%d Loops) -- %dP %dF %dS %dA   -- %s\n",
                  test->iterations, test->loop_count,
                  tpassed, tfailed, tskipped, taborted,
                  test->desc);
      }
      else
      {
         info_log(" -- %s\n", test->desc);
      }

      passed  += (test->result == TEST_PASSED) ? 1 : 0;
      failed  += (test->result == TEST_FAILED) ? 1 : 0;
      aborted += (test->result == TEST_ABORTED) ? 1 : 0;
      skipped += (test->result == TEST_SKIPPED) ? 1 : 0;
      noimpl  += (test->result == TEST_NOT_IMPLEMENTED) ? 1 : 0;
   }

   if (noimpl > 0) {
      info_log("NOT IMPLEMENTED TESTS:\n");
      print_tests(TEST_NOT_IMPLEMENTED);
      info_log("\n\n");
   }
   if (skipped > 0) {
      info_log("SKIPPED TESTS:\n");
      print_tests(TEST_SKIPPED);
      info_log("\n\n");
   }
   if (aborted > 0) {
      info_log("ABORTED TESTS:\n");
      print_tests(TEST_ABORTED);
      info_log("\n\n");
   }
   if (passed > 0) {
      info_log("PASSED TESTS:\n");
      print_tests(TEST_PASSED);
      info_log("\n\n");
   }
   if (failed > 0) {
      info_log("FAILED TESTS:\n");
      print_tests(TEST_FAILED);
      info_log("\n\n");
   }
   info_log("\n\nRESULTS:\n\t%d PASSED\n\t%d FAILED\n\t%d SKIPPED\n\t%d ABORTED\n\t%d NOT IMPLEMENTED\n\n",
            passed, failed, skipped, aborted, noimpl);

   tm_end_ms = time_ms();
   tm_dif_ms = tm_end_ms - tm_beg_test_ms;
   time_to_str(tmp_str, TMP_STR_SZ, tm_dif_ms);
   info_log("all tests run time: %s\n", tmp_str);

   return(failed > 0) ? TEST_FAILED : TEST_PASSED;
}

