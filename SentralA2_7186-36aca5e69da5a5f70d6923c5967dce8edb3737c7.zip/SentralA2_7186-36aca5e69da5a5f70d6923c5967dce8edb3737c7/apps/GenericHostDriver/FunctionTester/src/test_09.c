#include "test_common.h"

/***************************************************************************************
 * 9. Sensor Operation
 **************************************************************************************/
/**
 * PRIORITY 2
 * Sensor Status Data Available bits work
 * disable all sensors; clear out FIFO; ensure all Data
 * Available bits are clear; enable each sensor one at a time;
 * ensure Data Available becomes true
 */

// enable sensor, check if data available bit is set
// disable sensor, clears FIFO data and check if data available bit is cleared
// s: sensor to test
// use_discard: how to clear FIFO datat  TRUE = for flush(discard)
//                                       FALSE = read them
void t_9_1_chk_sensor(DI_SENSOR_TYPE_T s, bool use_discard)
{
   SENSOR_INFORMATION si;

   u16 rt;                                                           // set rate
   int i;
   if (!di_has_sensor(di, s))
   {
      return;
   }
   info_log("=== test sensor %d: %s\n", s, di_query_sensor_name(di, s));
   di_query_sensor_info(di, s, &si);
   rt = si.max_rate > 200 ? 200 : si.max_rate;
   set_and_chk_rate(s, rt, NULL, TRUE);
   chk_sens_stat_data_avail_param(s, TRUE);
   TAFR(try_with_time_limit(chk_sens_stat_data_avail, 1000, 50), "expecting data available bit but not received it\n");
   time_delay_ms(1000);                                              // wait for everything to start up
   for (i = 1; i <= di_max_sensor_id(di); i++)
   {
      if ((i == s) ||
          !di_has_sensor(di, (DI_SENSOR_TYPE_T)(i)))
      {
         continue;
      }
      chk_sens_stat_data_avail_param((DI_SENSOR_TYPE_T)(i), FALSE);
      TAFR(try_with_time_limit(chk_sens_stat_data_avail, 100, 5), "expecting no data available bit of other sensor but received it\n");
   }
   set_and_chk_rate(s, 0, NULL, TRUE);
   time_delay_ms(1000);                                              // wait for everything to shut down
                                                                     //read_FIFO(1,1,NULL);
   if (use_discard)
   {
      // PETE: fixed... warn_log("We know that flush(discard) does not clear 'data_available' flag properly - it shall be fixed in 718x\n");
      flushBothFifoAndCheckEmpty();
   }
   else
   {
      fifo_discard_by_read_fifo_data();
   }
   chk_sens_stat_data_avail_param(s, FALSE);
   TAFR(try_with_time_limit(chk_sens_stat_data_avail, 50, 10), "expecting no data available bit of turned off sensor but received it\n");
}

TEST_START(9_1)
{
   int i;
   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   read_out_while_intr(300, NULL, 9);

   for (i = 0; i < g_all_std_sens_sz; i++)
   {
      t_9_1_chk_sensor(all_std_sens[i], FALSE);
   }
   if (di->hi_id != HIID_KITKAT)
   {
      for (i = 0; i < g_all_std_sens_sz; i++)
      {
         t_9_1_chk_sensor(all_std_sens[i] | di_wake_sensor_start(di), FALSE);
      }
   }

   t_9_1_chk_sensor(DST_ACCELEROMETER, TRUE);
}
TEST_END

//-----------------------------------------------------------------------------
/**
 * PRIORITY 2
 * \brief Sensor Status Data Lost bits work
 * enable all sensors; wait enough time for FIFO to overflow;
 * ensure all expected sensors� Data Lost bits are set (on
 * change sensors should work too, as when they are enabled they
 * are required to output a single sample; one shot [Significant
 * Motion] will need to be triggered by operator at the start)
 */

// check "data lost" bit of all sensors in list
// as: available sensros - will use as->cu list
// exp: expected value of "data lost" bit
void chk_all_data_lost_bits(available_sensors_t *as, bool exp)
{
   int i;
   TAR(di_query_sensor_status(di));
   info_log("Sensor status bits:\n");
   display_sensor_status_bytes(di, TRUE);

   for (i = 0; i < as->cu; i++)
   {
      DI_SENSOR_TYPE_T s = as->su[i];
      SENSOR_STATUS sensor_status;
      TAR(di_read_sensor_status(di, s, &sensor_status));
      info_log("checking sensor %d % 27s: data lost: exp: %d got %d\n",
               s, di_query_sensor_name(di, s), exp, sensor_status.data_lost);
      TAFR(sensor_status.data_lost == exp, "Expecting data lost bit == %u", exp);
   }
}

TEST_START(9_2)
{
   u32 limit_time_ms;                                                // wait time to over flow fifo
   u16 lim_w;                                                        // estimate of maximum message to fill FIFO W
   u16 lim_nw;                                                       // estimate of maximum message to fill FIFO NW
   int i;                                                            // tmp counter
   u32 sum_rate;                                                     // sum of all sensors rate
   available_sensors_t as;                                           //available sensors

   default_rates();
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   read_out_while_intr(300, NULL, 9);

   get_3axis_fifo_events(di, &lim_w, &lim_nw);

   avail_sens_list(g_all_std_sens_sz, all_std_sens, &as);

   set_list_sensors_rate(as.cu, as.su, 500); // U16_MAX);

   if (di->hi_id != HIID_KITKAT)
   {
      TAFR(chk_val_with_margin(lim_w, lim_nw, 0.5, 1),
           "This test is written for roughly same size of W and NW FIFOs, if this is not case this test need little bit more work on wait time calculation\n");
   }

   // sum rate to better estimate necessary wait time
   sum_rate = 0;
   for (i = 0; i < as.c; i++)
   {
      DI_SENSOR_TYPE_T s = as.s[i];
      sum_rate += di->sensor_info[s].actual_rate;
   }

   // read all status once to clear out all bits
   TAR(di_query_sensor_status(di));

   // calculate time it will take to get FIFO 100% full
   limit_time_ms = (u32)(1000.0 * (double)(lim_nw) / (double)(sum_rate));
   limit_time_ms *= 2;                                               // *2 to add some time margin to ensure data_lost will happen

   info_log("wait %u ms to over-flow fifo\n", limit_time_ms);
   time_delay_ms(limit_time_ms);

   // turn off all sensors
   set_list_sensors_rate(as.cu, as.su, 0);
   fifo_discard_by_read_fifo_data();

   // all sensors should have lost data
   chk_all_data_lost_bits(&as, 1);

   // bits shall be cleared after previous read <<-- only by reading sensor status bits -- flushing FIFO DOES NOT clear these bits!
   chk_all_data_lost_bits(&as, 0);
}
TEST_END

/**
 * PRIORITY 2
 * \brief Sensor Status Power Mode bits work
 * disable all base sensors; ensure power mode bits indicate
 * they are off; enable them all; ensure they are now
 * registering as powered up in active mode
 */
TEST_START(9_3)
{
   DI_SENSOR_TYPE_T sensors_to_test[] = { DST_ACCELEROMETER, DST_GYROSCOPE, DST_GEOMAGNETIC_FIELD};
   DI_SENSOR_TYPE_T available_sensors[255];
// const u8 num_of_sensors_to_test = sizeof(sensors_to_test) / sizeof(DI_SENSOR_TYPE_T);
   u8 num_of_sensors_available;
   SENSOR_POWER_MODE pwrMode;
   const u32 MAX_WAIT_TM_MS = 1000;
   u32 startTime;
   int i;

   default_rates();
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(1000, FALSE));

   // check if sensors available in setup
   num_of_sensors_available = 0;
   info_log("Sensors to test:\n");
   for (i = 0; i < sizeof(sensors_to_test) / sizeof(DI_SENSOR_TYPE_T); i++)
   {
      if (di_has_sensor(di, sensors_to_test[i]))
      {
         available_sensors[num_of_sensors_available++] = sensors_to_test[i];
         info_log("%u (%s), ", sensors_to_test[i], di_query_sensor_name(di, sensors_to_test[i]));
      }
   }
   info_log("\n");
   // check that available sensors are on
   for (i = 0; i < num_of_sensors_available; i++)
   {
      TEST_ASSERT(getSensorPwrMode(di, available_sensors[i], &pwrMode));
      TEST_ASSERT(testSensorPwrModeOn(pwrMode));
   }
   // disable available sensors (set rate = 0 Hz)
   for (i = 0; i < num_of_sensors_available; i++)
   {
      TEST_ASSERT(di_configure_rate(di, available_sensors[i], 0, 0));
   }
   // check that available sensors are off
   startTime = time_ms();
   for (i = 0; i < num_of_sensors_available; i++)
   {
      while (1)
      {
         TEST_ASSERT(getSensorPwrMode(di, available_sensors[i], &pwrMode));
         if (testSensorPwrModeOff(pwrMode))
            break;
         if (MAX_WAIT_TM_MS < (time_ms() - startTime))
            break;
      }
      if (!testSensorPwrModeOff(pwrMode))
      {
         error_log("sensor %u (%s) is not powered off\n", available_sensors[i], di_query_sensor_name(di, available_sensors[i]));
      }
      TEST_ASSERT(testSensorPwrModeOff(pwrMode));
   }
   // enable available sensors (set rate = 50 Hz)
   for (i = 0; i < num_of_sensors_available; i++)
   {
      TEST_ASSERT(di_configure_rate(di, available_sensors[i], 50, 0));
   }
   // check that available sensors are back on
   startTime = time_ms();
   for (i = 0; i < num_of_sensors_available; i++)
   {
      while (1)
      {
         TEST_ASSERT(getSensorPwrMode(di, available_sensors[i], &pwrMode));
         if (testSensorPwrModeOn(pwrMode))
            break;
         if (MAX_WAIT_TM_MS < (time_ms() - startTime))
            break;
      }
      if (!testSensorPwrModeOn(pwrMode))
      {
         error_log("sensor %u (%s) is not powered on\n", available_sensors[i], di_query_sensor_name(di, available_sensors[i]));
      }
      TEST_ASSERT(testSensorPwrModeOn(pwrMode));
   }
   return TEST_PASSED;
}
TEST_END

/**
 * PRIORITY 2
 * \brief Sensor output data is scaled properly
 * or is the data already scaled correctly by BSX?
 */
TEST_START(9_4)
{
   return TEST_NOT_IMPLEMENTED;
}
TEST_END

// maximum number of sensors to be tested in 9_5 test
// make it always odd number - higher half is used for wakeup version of each sensor
#define TEST_9_5_MAX_SENSORS 8





// check sensor rate since last reset_stats();
// also computes error from expected sensor rate
// s: sensor
// ser: sensor expected rate
bool checkSensorRate(DI_SENSOR_TYPE_T s, u16 ser)
{
   double measured_rate;
   double rate_error_f, rate_error_m1_f;
   u16 rate_error, rate_error_m1;
   u16 ser_m1;
   measured_rate = (double)get_measured_sample_rate_float(s);

   // Sensor Rates can be truncated. Possible values go from ser to ser + 1.

   if (ser == 0)
   {
      if (measured_rate < 0.001)
         rate_error = 0;
      else
         rate_error = 100;
   }
   else if ((measured_rate < (ser + 1)) &&
            (measured_rate > ser))
   {
      // Measured rate is within the actual set rate possible values. No way to know error.
      rate_error_f = 0;
      rate_error = 0;
   }
   else
   {
      rate_error_f = ((((double)ser) - (measured_rate)) * 100) / (double)ser;
      rate_error = (u16)(abs((int)rate_error_f));

      ser_m1 = ser + 1;
      rate_error_m1_f = ((((double)(ser_m1)) - (measured_rate)) * 100) / (double)(ser_m1);
      rate_error_m1 = (u16)(abs((int)rate_error_m1_f));

      if (fabs(rate_error_m1_f) < fabs(rate_error_f))
      {
         info_log("used higher rate %u instead of %u; rate_error_m1_f %0.1f, rate_error_f %0.1f\n", ser_m1, ser, rate_error_m1_f, rate_error_f);
         rate_error_f = rate_error_m1_f;
         rate_error = rate_error_m1;
      }
   }

   if (rate_error > config.accel_rate_tol_percent)                   // TODO set it for correct sensor...
   {
      error_log("Rate check ERROR: %s: measured %0.1f, expected %d to %d, deviation %d %%\n", di_query_sensor_name(di, s), measured_rate, ser, ser + 1, rate_error);
      return FALSE;
   }
   else
   {
      info_log("Rate check OK: %s: measured %0.1f, expected %d to %d, deviation %d %% \n", di_query_sensor_name(di, s), measured_rate, ser, ser + 1, rate_error);
   }
   return TRUE;
}

// test sensor rate according to smaples number gathered in TEST_9_5_TIME (measured by PC time)
// len: length of following arrays
// s: array of sensors ID
// sr: array of respective sensros rates
// returns: TEST_FAILED/PASSED
int test_rate_according_to_pc_timer(
   int len,
   DI_SENSOR_TYPE_T *s,
   u16 *sr)
{
   u16 qsr[TEST_9_5_MAX_SENSORS];                                    // Queried (actually returned) Sensor A Rate (using di_query_sensor_config)
   int i;
   bool ret = TRUE;
   bool retAct;
   u16 test_duration = TEST_9_5_TIME;

   TEST_ASSERTF(((len >= 1) || (len <= TEST_9_5_MAX_SENSORS)), "Not implemented for more than %d tests", TEST_9_5_MAX_SENSORS);

   for (i = 0; i < len; i++)
   {
      if ((s[i] == DST_NOP) || (!di_has_sensor(di, s[i])))
      {
         TEST_ASSERTF(0, "Sensor %d (%s) was not found - skipping this sensor test", s[i], di_query_sensor_name(di, s[i]));
      }

      set_and_chk_rate(s[i], sr[i], &(qsr[i]), TRUE);
      //time_delay_ms(1000);
      if (qsr[i] && (qsr[i] <= 5)) // slow rate, so test longer
         test_duration = TEST_9_5_TIME * (6 - qsr[i]);
      //test_duration -= 1000;
   }

   info_log("running for %u seconds...\n", test_duration / 1000);
   fifo_discard();
   reset_stats();
   restart_stats_time();
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(test_duration, FALSE));
   calc_periodic_stats(di);
   info_log("SENSOR DATA:\n");
   display_periodic_stats(di, FALSE);

   for (i = 0; i < len; i++)
   {
      if ((s[i] == DST_NOP) || (!di_has_sensor(di, s[i])))
         continue;
      retAct = checkSensorRate(s[i], qsr[i]);
      TAFR(retAct, "check sensor rate failed");
      ret &= retAct;
   }
   if (ret)
   {
      return TEST_PASSED;
   }
   else
   {
      display_full_status();
      return TEST_FAILED;
   }
}

// decide if iteration is over
// respects if iterating up or down
// compenstate double precission error
// act: actual iteration position
// end: end iteration position
// stp: iteration stp (can be negative)
bool isIteratorOver(double act, double end, double stp)
{
   if ((stp >= 0) && (act > (end - 0.1)))                            // -0.1 to count with double imprecision
   {
      return TRUE;
   }
   if ((stp <= 0) && (act < (end + 0.1)))                            // +0.1 to count with double imprecision
   {
      return TRUE;
   }
   return FALSE;
}

// sweep through selected rates in selected sensors and test if rates within limit
// len: number of sensors (array len)
// s: array with sensor types
// beg: array with beginning rate for each sensor
// end: array with end rate for each sensor
// stp: step in rate to do for each sensor
//      testing of correct sensor rate ends when last sensor reaches it's end rate
// return: number of failed configurations
int sweepSensorsRate(int len, DI_SENSOR_TYPE_T *s, double *beg, double *end, double *stp)
{
   bool all_steps_done = FALSE;
   int errors = 0;
   int i;
   u16 usedRate[TEST_9_5_MAX_SENSORS];

   APR(((len >= 1) && (len <= TEST_9_5_MAX_SENSORS)), -1, "Implemented for more <1,%d> sensors but requested %d", TEST_9_5_MAX_SENSORS, len)

   while (1)
   {
      for (i = 0; i < len; i++)
      {
         usedRate[i] = (u16)(beg[i]); // --> don't round + 0.5);
      }
      if (TEST_PASSED != test_rate_according_to_pc_timer(len, s, usedRate))
      {
         errors++;
      }
      all_steps_done = TRUE;
      for (i = 0; i < len; i++)
      {
         if ((s[i] == DST_NOP) || (!di_has_sensor(di, s[i])))
            continue;
         if (!isIteratorOver(beg[i], end[i], stp[i]))
         {
            all_steps_done = FALSE;
            if (beg[i] == 1)
               beg[i] = stp[i]; // don't add to 1; results in 13 Hz instead of 12, or 101 instead of 100
            else
               beg[i] += stp[i];
         }
      }
      if (all_steps_done)
      {
         return errors;
      }
   }
}

typedef struct test_9_5_sensorsAndParams
{
   int useSensorsCount;
   DI_SENSOR_TYPE_T useSensors[TEST_9_5_MAX_SENSORS];
   SENSOR_INFORMATION sInf[TEST_9_5_MAX_SENSORS];
} test_9_5_sensorsAndParams_t;

int t_9_5_turn_off_all_sensors(test_9_5_sensorsAndParams_t *cfg)
{
   u16 qsr;                                                          // querried sensor rate
   int i;
   // turn off all sensors
   for (i = 0; i < cfg->useSensorsCount; i++)                        // turn off not tested sensors
   {
      set_and_chk_rate(cfg->useSensors[i], 0, &qsr, TRUE);
      APR(qsr == 0, -1, "didn't manage to turn off sensor %d!", cfg->useSensors[i])
   }
   return 0;
}

// Wrapper which prepare rates to go through in selected sensors
// and then call function to actually do sweeps through <min,max> rate in selected sensors
// cfg: struct containing array of available sensors with their configuration
// len: number of sensors used
// cfgIdx: array of indexes to cfg - selects which sensors will be used
// slowToFast: configuration array of sweep direction for each sensor 1= slow to fast/ 0=fast to slow
// steps: how many steps to do between minimum to maximum rate (eg 3 would test "min, middle and max" rate)
//        steps has to be minimum 2 - we swwep min then max - otherwise it does not make sense
// return: 0=ok, else error
int sweepFollowingSensors(test_9_5_sensorsAndParams_t *cfg,
                          int len, u8 *cfgIdx, bool *slowToFast, int steps)
{
   int i;
   DI_SENSOR_TYPE_T s[TEST_9_5_MAX_SENSORS];
   double beg[TEST_9_5_MAX_SENSORS];
   double end[TEST_9_5_MAX_SENSORS];
   double stp[TEST_9_5_MAX_SENSORS];
   int valid_sensors;

   APR(((len >= 1) && (len <= TEST_9_5_MAX_SENSORS)), -1, "Implemented for <1,%d> sensors but requested %d", TEST_9_5_MAX_SENSORS, len)
   APR(steps >= 2, -1, "Steps has to be minimum 2 (min,max) but requested %d", steps)
   // turn off all sensors
   t_9_5_turn_off_all_sensors(cfg);

   // configure sweep [beg,end,step] for each sensor
   valid_sensors = 0;
   for (i = 0; i < len; i++)
   {
      if ((cfg->useSensors[cfgIdx[i]] == DST_NOP) || (!di_has_sensor(di, cfg->useSensors[cfgIdx[i]])))
      {
         warn_log("Can not run this part of independent sensor rate setting test because: sensor %d is missing or is NOP\n", cfg->useSensors[cfgIdx[i]]);
         continue;
      }
      APR(cfgIdx[i] < cfg->useSensorsCount, -1,
          "Sensor index (%d) over sensor count (%d)", cfgIdx[i], cfg->useSensorsCount)
      s[valid_sensors] = cfg->useSensors[cfgIdx[i]];
      beg[valid_sensors] = cfg->sInf[cfgIdx[i]].min_rate;
      end[valid_sensors] = cfg->sInf[cfgIdx[i]].max_rate;
      stp[valid_sensors] = (end[valid_sensors]/* - beg[valid_sensors]*/) / (steps - 1); // use power of two rates
      if (!slowToFast[i])
      {
         double tmp;
         stp[valid_sensors] = -stp[valid_sensors];
         tmp = beg[valid_sensors];
         beg[valid_sensors] = end[valid_sensors];
         end[valid_sensors] = tmp;
      }
      valid_sensors++;
   }
   if(!valid_sensors) return 0; // unable to run, return OK.
   return sweepSensorsRate(valid_sensors, s, beg, end, stp);
}


/**
 * PRIORITY 1
 * \brief Sensor Configuration Sample Rate settings can be
 * changed on the fly and result in actual changes to
 * sample rates
 */
#define TEST_9_5_MORE_COMBINATIONS 1
TEST_START(9_5)
{
   test_9_5_sensorsAndParams_t t95conf;
   // note for parameter "useSensors" expecting that
   //  - first 2 positions are present on android K system
   //  - next 2 positions are Wakeup verions of first sensors for android L (if not used define DST_NOP )
   int i;
   int j;
   int fusion_sensor_idx = -1;
   u16 qsr;                                                          // queried sensor rate

   u8 idx[TEST_9_5_MAX_SENSORS];
   bool slowToFast[TEST_9_5_MAX_SENSORS];
#if(TEST_9_5_MORE_COMBINATIONS==1)
   int steps = 3;
#else
   int steps = 2;
#endif

   DI_SENSOR_TYPE_T s[TEST_9_5_MAX_SENSORS];
   u16 sr[TEST_9_5_MAX_SENSORS];

   for (i = 0; i < TEST_9_5_MAX_SENSORS; i++)
   {
      slowToFast[i] = TRUE;
   }
   accel_rate = 10;
   gyro_rate = 0;
   mag_rate = 0;
   quat_rate = 0;
   set_latencies(0, 0, 0, 0);
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   fifo_discard();


   t95conf.useSensorsCount = TEST_9_5_MAX_SENSORS;
   t95conf.useSensors[0] = DST_ACCELEROMETER;                        // accelerometer is present always
   t95conf.useSensors[1] = DST_GEOMAGNETIC_FIELD;
   t95conf.useSensors[2] = DST_GYROSCOPE;
   t95conf.useSensors[3] = DST_NOP;
   t95conf.useSensors[4] = DST_ACCELEROMETER + di_wake_sensor_start(di); // accelerometer is present always
   t95conf.useSensors[5] = DST_GEOMAGNETIC_FIELD + di_wake_sensor_start(di);
   t95conf.useSensors[6] = DST_GYROSCOPE + di_wake_sensor_start(di);
   t95conf.useSensors[7] = DST_NOP + di_wake_sensor_start(di);

   // also try to use one fusion sensor, as it can interact with sensor rates of the physical sensors (the fusion library can override the physical rates, but the host side rates should not change)
   i = 3;
   fusion_sensor_idx = -1;
   if (di_has_sensor(di, DST_ORIENTATION))
   {
      t95conf.useSensors[i] = DST_ORIENTATION;
      t95conf.useSensors[i + TEST_9_5_MAX_SENSORS / 2] = DST_ORIENTATION | di_wake_sensor_start(di);
      fusion_sensor_idx = i;
      i++;
   }
#if 1
   else if (di_has_sensor(di, DST_ROTATION_VECTOR))
   {
      t95conf.useSensors[i] = DST_ROTATION_VECTOR;
      t95conf.useSensors[i + TEST_9_5_MAX_SENSORS / 2] = DST_ROTATION_VECTOR | di_wake_sensor_start(di);
      fusion_sensor_idx = i;
      i++;
   }
   else if (di_has_sensor(di, DST_GAME_ROTATION_VECTOR))
   {
      t95conf.useSensors[i] = DST_GAME_ROTATION_VECTOR;
      t95conf.useSensors[i + TEST_9_5_MAX_SENSORS / 2] = DST_GAME_ROTATION_VECTOR | di_wake_sensor_start(di);
      fusion_sensor_idx = i;
      i++;
   }
   else if (di_has_sensor(di, DST_GEOMAGNETIC_ROTATION_VECTOR))
   {
      t95conf.useSensors[i] = DST_GEOMAGNETIC_ROTATION_VECTOR;
      t95conf.useSensors[i + TEST_9_5_MAX_SENSORS / 2] = DST_GEOMAGNETIC_ROTATION_VECTOR | di_wake_sensor_start(di);
      fusion_sensor_idx = i;
      i++;
   }
#endif

   if (di->hi_id == HIID_KITKAT)
   {
      t95conf.useSensorsCount = TEST_9_5_MAX_SENSORS / 2;
   }
   else
   {
      t95conf.useSensorsCount = TEST_9_5_MAX_SENSORS;
   }
   // todo error_info remove
   //display_error_info(di);
   for (i = 0; i < t95conf.useSensorsCount; i++)
   {
      u16 over_max_rate;
      if ((t95conf.useSensors[i] == DST_NOP) || (!di_has_sensor(di, t95conf.useSensors[i])))
      {
         t95conf.useSensors[i] = DST_NOP;                            // Ensure sensor is disabled for future runs.
         continue;
      }
      info_log("====== sensor %s\n", di_query_sensor_name(di, t95conf.useSensors[i]));
      TAR(di_query_sensor_info(di, t95conf.useSensors[i], &(t95conf.sInf[i])));

      // use function to correct BSX max algo limit rate
      t95conf.sInf[i].max_rate = get_max_sensor_rate(t95conf.useSensors[i]);

      info_log("=== Checking that max rate %d can be set\n", t95conf.sInf[i].max_rate);
      set_and_chk_rate(t95conf.useSensors[i], t95conf.sInf[i].max_rate, &qsr, TRUE);

      over_max_rate = t95conf.sInf[i].max_rate * 3;
      info_log("=== Checking that value over max rate %d cannot be set\n", over_max_rate);
      set_and_chk_rate(t95conf.useSensors[i], over_max_rate, &qsr, FALSE);
      TAFR((qsr >= t95conf.sInf[i].max_rate) && (qsr <= (2 * t95conf.sInf[i].max_rate)),
           "Rate out of limit expecting <%d,%d> got %d",
           t95conf.sInf[i].max_rate, 2 * t95conf.sInf[i].max_rate, qsr);
      if (di->hi_id != HIID_KITKAT)
      {
         // time_delay_ms(500); //vbe todo shall not be need
         info_log("=== Checking that min rate %d can be set\n", t95conf.sInf[i].min_rate);
         set_and_chk_rate(t95conf.useSensors[i], t95conf.sInf[i].min_rate, &qsr, TRUE);

         if (t95conf.sInf[i].min_rate > 1)
         {
            // time_delay_ms(500); //vbe todo shall not be need
            info_log("=== Checking that value lower than min rate %d cannot be set\n", t95conf.sInf[i].min_rate);
            set_and_chk_rate(t95conf.useSensors[i], t95conf.sInf[i].min_rate - 1, &qsr, FALSE);
            TAFR((qsr >= t95conf.sInf[i].min_rate) && (qsr <= (2 * t95conf.sInf[i].min_rate)),
                 "Rate out of limit expecting <%d,%d> got %d",
                 t95conf.sInf[i].min_rate, 2 * t95conf.sInf[i].min_rate, qsr);
            TAR(qsr == t95conf.sInf[i].min_rate);
         }
      }
   }
   if (di->hi_id == HIID_KITKAT)
   {
      for (i = 0; i < t95conf.useSensorsCount; i++)
      {
         t95conf.sInf[i].min_rate = 10;                              // todo - how to determnie actual minimum rate?
      }
   }

   // todo remove debug one sensor
   // t_9_5_turn_off_all_sensors(&t95conf);
   // s[0]=DST_ACCELEROMETER;
   // sr[0]=1;
   // TAR(TEST_PASSED == test_rate_according_to_pc_timer(1,s,sr));
   // display_error_info(di);
   // s[0]=DST_ACCELEROMETER;
   // sr[0]=100;
   // TAR(TEST_PASSED == test_rate_according_to_pc_timer(1,s,sr));
   // display_error_info(di);
   // return TEST_FAILED;


   // note there is test for W+NW at the end which is more extensive - but keep this test for android K
#if 1
   if (t95conf.useSensorsCount == (1 + TEST_9_5_MAX_SENSORS / 2) ||  // only one sensor
       TEST_9_5_MORE_COMBINATIONS == 1
      )
   {
      info_log("=== sweep and check rate separately for each used sensor\n");
      for (i = 0; i < t95conf.useSensorsCount; i++)
      {
         if ((t95conf.useSensors[i] == DST_NOP) || (!di_has_sensor(di, t95conf.useSensors[i])))
         {
            continue;
         }
         idx[0] = (u8)i;
         TAR(0 == sweepFollowingSensors(&t95conf, 1, idx, slowToFast, steps));
      }
   }
#endif
   if (t95conf.useSensorsCount > (1 + TEST_9_5_MAX_SENSORS / 2))     // more than one sensor
   {
#if(TEST_9_5_MORE_COMBINATIONS == 1)
      info_log("=== sweep and check rate for 2 NW sensors (rate slow to fast)\n");
      idx[0] = 0;
      slowToFast[0] = TRUE;
      idx[1] = 1;
      slowToFast[1] = TRUE;
      TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));
#endif
      info_log("=== sweep and check rate for 2 NW sensors (rate opposite)\n");
      idx[0] = 0;
      slowToFast[0] = TRUE;
      idx[1] = 1;
      slowToFast[1] = FALSE;
      TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));


      if (fusion_sensor_idx != -1)
      {
         info_log("=== check that disabling fusion sensor won't disable physical sensor \n");
         s[0] = DST_ACCELEROMETER;
         s[1] = t95conf.useSensors[fusion_sensor_idx];
         sr[0] = 20;
         sr[1] = 0;
         TAR(TEST_PASSED == test_rate_according_to_pc_timer(2, s, sr));

         info_log("=== check that disabling physical sensor won't disable fusion sensor \n");
         s[0] = t95conf.useSensors[fusion_sensor_idx];
         s[1] = DST_ACCELEROMETER;
         sr[0] = 20;
         sr[1] = 0;
         TAR(TEST_PASSED == test_rate_according_to_pc_timer(2, s, sr));
      }
   }

   if (di->hi_id == HIID_KITKAT)
      return g_current_test_retval;

#if(TEST_9_5_MORE_COMBINATIONS==1)
   info_log("=== sweep and check rate for W/NW same sensors (opposite RATE)\n");
   idx[0] = 0;
   slowToFast[0] = TRUE;
   idx[1] = TEST_9_5_MAX_SENSORS / 2;
   slowToFast[1] = FALSE;
   TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));

   info_log("=== sweep and check rate for W/NW same sensors\n");
   idx[0] = 0;
   slowToFast[0] = TRUE;
   idx[1] = TEST_9_5_MAX_SENSORS / 2;
   slowToFast[1] = TRUE;
   TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));

   if (t95conf.useSensorsCount > (1 + TEST_9_5_MAX_SENSORS / 2))     // more than one sensor
   {
      info_log("=== sweep and check rate for 2 W sensors (opposite rate)\n");
      idx[0] = TEST_9_5_MAX_SENSORS / 2;
      idx[1] = 1 + TEST_9_5_MAX_SENSORS / 2;
      slowToFast[0] = TRUE;
      slowToFast[1] = FALSE;
      TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));

      info_log("=== sweep and check rate for 2 W sensors\n");
      idx[0] = TEST_9_5_MAX_SENSORS / 2;
      idx[1] = 1 + TEST_9_5_MAX_SENSORS / 2;
      slowToFast[0] = TRUE;
      slowToFast[1] = TRUE;
      TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));

      info_log("=== sweep and check rate for W/NW different sensors\n");
      idx[0] = 0;
      slowToFast[0] = TRUE;
      idx[1] = 1 + TEST_9_5_MAX_SENSORS / 2;
      slowToFast[1] = TRUE;
      TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));

      info_log("=== sweep and check rate for W/NW different sensors (opposite rate)\n");
      idx[0] = 0;
      slowToFast[0] = TRUE;
      idx[1] = 1 + TEST_9_5_MAX_SENSORS / 2;
      slowToFast[1] = FALSE;
      TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));

      info_log("=== sweep and check rate for all sensors\n");
      j = 0;
      for (i = 0; i < t95conf.useSensorsCount; i++)
      {
         if (t95conf.useSensors[i] == DST_NOP)
         {
            continue;
         }
         idx[j] = i;
         slowToFast[j] = TRUE;
         j++;
      }
      TAR(0 == sweepFollowingSensors(&t95conf, j, idx, slowToFast, steps));
   }
#endif
   info_log("=== sweep and check rate for all sensors (opposite rate)\n");
   j = 0;
   for (i = 0; i < (t95conf.useSensorsCount / 2); i++)
   {
      if (t95conf.useSensors[i] == DST_NOP)
      {
         break;
      }
      if ((i % 2) == 0)
      {                                                              // W set after NW
         idx[j] = i;
         idx[j + 1] = i + TEST_9_5_MAX_SENSORS / 2;
      }
      else
      {                                                              // NW set after W
         idx[j] = i + TEST_9_5_MAX_SENSORS / 2;
         idx[j + 1] = i;

      }
      slowToFast[j] = TRUE;
      slowToFast[j + 1] = FALSE;
      j += 2;
   }
   TAR(0 == sweepFollowingSensors(&t95conf, j, idx, slowToFast, steps));

   info_log("=== check that disabling NW doesn't disable W \n");
   //info_log("set_and_chk_rate()\n");
   set_and_chk_rate(DST_ACCELEROMETER, 20, &qsr, TRUE);
   //time_delay_ms(1000);
   s[0] = DST_ACCELEROMETER | di_wake_sensor_start(di);
   sr[0] = 20;
   s[1] = DST_ACCELEROMETER;
   sr[1] = 0;
   //info_log("test_rate_according_to_pc_timer()\n");
   TAR(TEST_PASSED == test_rate_according_to_pc_timer(2, s, sr));

   info_log("=== check that disabling W doesn't disable NW \n");
   //info_log("set_and_chk_rate()\n");
   set_and_chk_rate(DST_ACCELEROMETER | di_wake_sensor_start(di), 20, &qsr, TRUE);
   //time_delay_ms(1000);
   s[0] = DST_ACCELEROMETER;
   sr[0] = 20;
   s[1] = DST_ACCELEROMETER | di_wake_sensor_start(di);
   sr[1] = 0;
   //info_log("test_rate_according_to_pc_timer()\n");
   TAR(TEST_PASSED == test_rate_according_to_pc_timer(2, s, sr))

   return g_current_test_retval;
}
TEST_END

int comm_9_5_cal_and_jerk(bool first_loop, test_9_5_sensorsAndParams_t *t95conf)
{
   int i;
   u8 idx[TEST_9_5_MAX_SENSORS];
   bool slowToFast[TEST_9_5_MAX_SENSORS];
   int steps = 3;

   fifo_discard();
   t95conf->useSensorsCount = 2;

   for (i = 0; i < t95conf->useSensorsCount; i++)
   {
      info_log("====== sensor %s\n", di_query_sensor_name(di, t95conf->useSensors[i]));

      // use function to correct BSX max algo limit rate
      t95conf->sInf[i].max_rate = get_max_sensor_rate(t95conf->useSensors[i]);
      t95conf->sInf[i].min_rate = 1;
   }

   info_log("=== sweep and check rate for 2 NW sensors (rate opposite)\n");
   idx[0] = 0; slowToFast[0] = TRUE;
   idx[1] = 1; slowToFast[1] = FALSE;
   TAR(0 == sweepFollowingSensors(t95conf, 2, idx, slowToFast, steps));
   return 0;
}

TEST_START(9_5_CAL)
{
   test_9_5_sensorsAndParams_t t95conf =
   {  TEST_9_5_MAX_SENSORS,
      {  DST_CAL_STATUS,                                             // accelerometer is present always
         DST_ORIENTATION,
         DST_NOP,
         DST_NOP,
         DST_CAL_STATUS | di_wake_sensor_start(di),
         DST_ORIENTATION | di_wake_sensor_start(di),
         DST_NOP,
         DST_NOP
      }
   };

   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }

   if (di->hi_id == HIID_LOLLIPOP_EX)
   {
      printf("Updating cal status sensor id\n");
      t95conf.useSensors[0] = 62;
      t95conf.useSensors[4] = 62  | di_wake_sensor_start(di);
   }

   comm_9_5_cal_and_jerk(first_loop, &t95conf);
}
TEST_END

TEST_START(9_5_JERK)
{
   test_9_5_sensorsAndParams_t t95conf =
   {  TEST_9_5_MAX_SENSORS,
      {  DST_JERK_EXAMPLE,
         DST_ACCELEROMETER,
         DST_NOP,
         DST_NOP,
         DST_JERK_EXAMPLE | di_wake_sensor_start(di),
         DST_ACCELEROMETER | di_wake_sensor_start(di),
         DST_NOP,
         DST_NOP
      }
   };

   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }


   comm_9_5_cal_and_jerk(first_loop, &t95conf);
}
TEST_END

TEST_START(9_5_SPD)
{
   test_9_5_sensorsAndParams_t t95conf =
   {  TEST_9_5_MAX_SENSORS,
      {  DST_ACCELEROMETER,
         DST_JERK_EXAMPLE,
         DST_NOP,
         DST_NOP,
         DST_ACCELEROMETER | di_wake_sensor_start(di),
         DST_JERK_EXAMPLE | di_wake_sensor_start(di),
         DST_NOP,
         DST_NOP
      }
   };
   //int i;
   u8 idx[TEST_9_5_MAX_SENSORS];
   bool slowToFast[TEST_9_5_MAX_SENSORS];
   int steps = 3;

   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   fifo_discard();
   t95conf.useSensorsCount = 2;


   info_log("====== sensor %s\n", di_query_sensor_name(di, t95conf.useSensors[0]));
   t95conf.sInf[0].max_rate = get_max_sensor_rate(t95conf.useSensors[0]);
   t95conf.sInf[0].min_rate = 1;

   info_log("====== sensor %s\n", di_query_sensor_name(di, t95conf.useSensors[1]));
   t95conf.sInf[1].max_rate = get_max_sensor_rate(t95conf.useSensors[1]);
   t95conf.sInf[1].min_rate = 64;

   info_log("=== sweep and check rate for 2 NW sensors (rate opposite)\n");
   idx[0] = 0;
   slowToFast[0] = TRUE;
   idx[1] = 1;
   slowToFast[1] = FALSE;
   TAR(0 == sweepFollowingSensors(&t95conf, 2, idx, slowToFast, steps));
}
TEST_END

// Sample Rate Setting Reliability
TEST_START(9_6)
{
#define NUM_9_6_SENSORS 6
   DI_SENSOR_TYPE_T desired_sensors[NUM_9_6_SENSORS] = {DST_ACCELEROMETER, DST_GEOMAGNETIC_FIELD, DST_GYROSCOPE, DST_ROTATION_VECTOR, DST_GAME_ROTATION_VECTOR, DST_GEOMAGNETIC_ROTATION_VECTOR};
   DI_SENSOR_TYPE_T test_sensors[NUM_9_6_SENSORS];
   SENSOR_CONFIG conf;
   SENSOR_CONFIG read_conf;
   int num_sensors = 0;
   int i;
   int j;
   int k;
   u16 measured_rate;
   u16 requested_rate;
   u16 test_rate;
   u16 rate_low_bounds;
   u16 rate_high_bounds;

   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);

   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   fifo_discard();

   for (i = 0; i < NUM_9_6_SENSORS; i++)
   {
      if (di_has_sensor(di, desired_sensors[i]))
      {
         test_sensors[num_sensors++] = desired_sensors[i];
         if (i >= 3)
            break; // we only need one fusion sensor
      }
   }

   memset(&conf, 0, sizeof(conf));

   for (j = 0; j < num_sensors; j++)
   {
      if (test_sensors[j] == DST_GEOMAGNETIC_FIELD)
         test_rate = 25;
      else
         test_rate = 50;
      conf.sample_rate = test_rate;
      info_log("set sensor %u (%s) to rate %u\n", test_sensors[j], di_query_sensor_name(di, test_sensors[j]), conf.sample_rate);
      TEST_ASSERT(di_configure_sensor(di, test_sensors[j], &conf));
   }
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(2000, FALSE)); // discard previous data, but do so unobtrusively -- read from FIFO only
   for (j = 0; j < num_sensors; j++)
   {
      TEST_ASSERT(di_query_sensor_config(di, test_sensors[j], &read_conf));
      if (!read_conf.dynamic_range)
         info_log("no dynamic range!\n");
   }
   reset_stats(); // ignore counts from previous rate setting
   restart_stats_time();

   for (i = 0; i < 256; i++)
   {
      info_log("Step %u\n", i);
      for (j = 0; j < num_sensors; j++)
      {
         if (test_sensors[j] == DST_GEOMAGNETIC_FIELD)
            test_rate = 25;
         else
            test_rate = 50;
         conf.sample_rate = (i & (1 << j)) ? test_rate : 0; // if bit set in i, turn corresponding sensor on, else turn it off
         
         if ((i == 0) || (conf.sample_rate != di->sensor_info[test_sensors[j]].rate)) // only set on first loop or if the rate if it has changed
         {
            info_log("set sensor %u (%s) to rate %u\n", test_sensors[j], di_query_sensor_name(di, test_sensors[j]), conf.sample_rate);
            TEST_ASSERT(di_configure_sensor(di, test_sensors[j], &conf));
         }
      }
      reset_stats(); // ignore counts from previous rate setting
      restart_stats_time();
      TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(1000, FALSE)); // discard previous data, but do so unobtrusively -- read from FIFO only
      calc_periodic_stats(di);
      restart_stats_time(); // restart time interval measurement as soon as possible, so time of sensor data accumulation is not underestimated
      info_log("turn on data:\n");
      display_periodic_stats(di, FALSE);
      reset_stats(); // ignore counts from previous rate setting
      TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(1000, FALSE)); // now measure for real
      calc_periodic_stats(di);
      restart_stats_time();
      info_log("running data:\n");
      display_periodic_stats(di, FALSE);
      for (k = 0; k < num_sensors; k++)
      {
         measured_rate = get_measured_sample_rate(test_sensors[k]);
         requested_rate = di->sensor_info[test_sensors[k]].rate;
         if (di->alg_id == AID_SPACE_POINT)
         {
            rate_low_bounds = requested_rate - 5;
            rate_high_bounds = requested_rate * 2; // Android limit is up to 2x faster than request
         }
         else
         {
            rate_low_bounds = requested_rate - 5;  // BSX constrains rates
            rate_high_bounds = requested_rate + 5;
         }

         if ((measured_rate != 0) != (requested_rate != 0)) // off vs. on is different
         {
            TEST_ASSERTF(FALSE, "sensor %u (%s): requested rate %u but measured rate %u!\n", test_sensors[k], di_query_sensor_name(di, test_sensors[k]), measured_rate, requested_rate);
         }
         else if (requested_rate)
         {
            TEST_ASSERT((int)measured_rate >= (int)rate_low_bounds);
            TEST_ASSERT((int)measured_rate <= (int)rate_high_bounds);
         }
      }
   }

   return g_current_test_retval;
}
TEST_END




// Sensor Configuration Dynamic Range
TEST_START(9_8)
{
   SENSOR_INFORMATION sensor_info;
   SENSOR_CONFIG sensor_config;
   u16 dynamRange;
   bool executing, sensing;

   u32 metaEventDynamicRangeCount;
   u32 metaEventDynamicRangeCount2;
   u32 metaEventDynamicRangeCountChg;
   u32 i;

   default_rates();
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   // confirm all is well
   if (!di_query_status(di, &executing, &sensing))
   {
      error_log("error reading status\n");
   }
   info_log("executing: %d, sensing: %d\n", executing, sensing);
   TEST_ASSERT(executing == 1);
   TEST_ASSERT(sensing == 1);
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(1000, FALSE));

   // Enable "Dynamich Range Change Event"
   //for (i = DME_FLUSH_COMPLETE; i < DME_NUM_META_EVENTS; i++)
   i = DME_DYNAMIC_RANGE_CHANGED;
   {
      if (!di_enable_meta_event_ex(di, (DI_META_EVENT_T)i, TRUE, TRUE, FALSE))
      {
         error_log("error enabling %s meta event\n", di_query_meta_event_name((DI_META_EVENT_T)i));
         return TEST_FAILED;
      }
      else
      {
         info_log("Enabled meta event: %s\n", di_query_meta_event_name((DI_META_EVENT_T)i));
      }
   }

   test_read_out_pending_data(5000, FALSE);

   // remember Dynamic Range Chnage Event number
   metaEventDynamicRangeCount = di->meta_events[DME_DYNAMIC_RANGE_CHANGED];

   // Chnge dynamic range of accelereometer sensor
   //for (i = DST_FIRST; i < DST_WAKEUP; i++)
   i = DST_ACCELEROMETER;
   {
      if (!di_has_sensor(di, i))
      {
         if (di->sensor_info[i].status.device_id_error
             || di->sensor_info[i].status.i2c_nack)
         {
            error_log("% 2u, %27s, Device ID Error=%u, I2C NACK=%u\n", i, di_query_sensor_name(di, (DI_SENSOR_TYPE_T)i), di->sensor_info[i].status.device_id_error, di->sensor_info[i].status.i2c_nack);
            return TEST_FAILED;
         }
         if (i == DST_ACCELEROMETER)
         {
            error_log("Accelereometer was not found, test for changing range expects accelerometer present in system");
         }
      }

      info_log("% 2u, %27s: ", i, di_query_sensor_name(di, (DI_SENSOR_TYPE_T)i));
      di_query_sensor_info(di, (DI_SENSOR_TYPE_T)i, &sensor_info);
      info_log("max rng %u, resolution: %u", sensor_info.max_range, sensor_info.resolution);

      di_query_sensor_config(di, i, &sensor_config);
      info_log(", dynam rng: %u", sensor_config.dynamic_range);

      sensor_config.sample_rate = 10;
      sensor_config.max_report_latency = 0;
      sensor_config.change_sensitivity = 0;
      dynamRange  = sensor_config.dynamic_range
                    = sensor_config.dynamic_range * 2;
      if (!di_configure_sensor(di, i, &sensor_config))
      {
         error_log("error configuring sensor\n");
      }
      else
      {
         info_log(", set: smpl rate:%u, latncy:%u dynam rng: %u", sensor_config.sample_rate, sensor_config.max_report_latency, sensor_config.dynamic_range);
      }
      time_delay_ms(500);

      di_query_sensor_config(di, i, &sensor_config);
      info_log("; new dynam rng: %u\n", sensor_config.dynamic_range);

      TEST_ASSERTF(sensor_config.dynamic_range >= dynamRange,
                   "Requested dynam rate % 5u < sensor returned dynam range % 5u",
                   dynamRange, sensor_config.dynamic_range);
   }

   test_read_out_pending_data(5000, FALSE);

   // Check if Dynamic Range Chnage Event was generated exactly once
   metaEventDynamicRangeCount2 = di->meta_events[DME_DYNAMIC_RANGE_CHANGED];
   metaEventDynamicRangeCountChg = metaEventDynamicRangeCount2 - metaEventDynamicRangeCount;
   info_log("Dynam range changed %d times\n", metaEventDynamicRangeCountChg);
   if (metaEventDynamicRangeCountChg == 1)
   {
      info_log("Dynam range changed exactly once as expected\n");
   }
   else if (metaEventDynamicRangeCountChg > 1)
   {
      warn_log("Dynam range changed more than once\n");
   }
   else
   {
      error_log("Dynam range hasn't changed (one change expected)\n");
      return TEST_FAILED;
   }
   return TEST_PASSED;
}
TEST_END
