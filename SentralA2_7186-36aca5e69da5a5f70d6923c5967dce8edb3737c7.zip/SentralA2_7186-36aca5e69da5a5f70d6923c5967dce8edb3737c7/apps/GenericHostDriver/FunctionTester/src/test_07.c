#include "test_common.h"

/***************************************************************************************
 * 7. Parameter Transfer Mechanism
 **************************************************************************************/
/**
 *  Confirm can read all supported pages, and contents read are valid
 */
#define TEST_7_BUF_SIZE 32
TEST_START(7_1)
{
   int i;
   u8 obuf[TEST_7_BUF_SIZE];
   u8 buf[TEST_7_BUF_SIZE];
   const u8 page_max_param[PP_MAX_PAGE + 1] = {0, SYSP_MAX_PARAMETER, 0, SP_MAX_PARAMETER};
   AlgIDValues alg_id;


   set_rates(50, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

   alg_id = di_get_algorithm_id(di);

   for (i = PP_SYSTEM; i <= PP_MAX_PAGE; i++)
   {
      int j;
      for (j = 1; j <= page_max_param[i]; j++)
      {
         int changed = 0;
         int m;

         info_log("reading page %u param %u: ", i, j);

         memset(obuf, 0, TEST_7_BUF_SIZE);
         TEST_ASSERT(di_save_parameter(di, i, j, obuf, PARAM_SAVE_SIZE)); // can read valid page and parameter
         for (m = 0; m < TEST_7_BUF_SIZE; m++)
         {
            obuf[m] ^= 0x5A;                                         // definitely modify the buffer contents
         }

         memset(buf, 0x5A, TEST_7_BUF_SIZE);
         TEST_ASSERT(di_save_parameter(di, i, j, buf, PARAM_SAVE_SIZE)); // can read valid page and parameter
         /* ensure only the requested number changed */
         for (m = 0; m < TEST_7_BUF_SIZE; m++)
         {
            changed += (buf[m] != obuf[m]);
         }
         info_log("%d changed  \r", changed);

         TEST_ASSERT(changed == PARAM_SAVE_SIZE);                    // size of 0 means maximum size of 16
         /* TODO: how to determine "valid"? */
      }
   }

   info_log("\n");
#if defined(TEST_INVALID_PARAMETER_IO)
   TEST_ASSERT(!di_save_parameter(di, PP_MAX_PAGE + 1, 1, buf, PARAM_SAVE_SIZE)); // cannot read above max page
   if (alg_id == AID_BSX)
   {
      TEST_ASSERT(!di_save_parameter(di, PP_ALGORITHM, 125, buf, PARAM_SAVE_SIZE)); // cannot read unsupported param
   }
   else
   {
      TEST_ASSERT(!di_save_parameter(di, PP_ALGORITHM, 126, buf, PARAM_SAVE_SIZE)); // cannot read unsupported param
   }
   TEST_ASSERT(!di_save_parameter(di, PP_SYSTEM, 1, buf, 17));       // cannot read above max size
#endif
   return TEST_PASSED;
}
TEST_END

/**
 * PRIORITY 1
 * Confirm can write all supported pages, and what we read back is correct
 */
TEST_START(7_2)
{
   return TEST_NOT_IMPLEMENTED;
}
TEST_END


/**
 * PRIORITY 2
 *  Parameter transfer performance / reliability test � using System Page Echo Test
 *  Parameter, transfer 1000+ times in both directions as fast as possible and confirm
 *  validity of data
 */
TEST_START(7_3)
{
   int i;
   u8 buf[TEST_7_BUF_SIZE];
   u8 orig[TEST_7_BUF_SIZE];
   u32 start;
   u32 write_start;
   u32 write_total = 0;
   u32 read_start;
   u32 read_total = 0;

   set_rates(50, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

   memset(orig, 0, TEST_7_BUF_SIZE);
   memset(buf, 0xff, TEST_7_BUF_SIZE);
   TEST_ASSERT(di_save_parameter(di, PP_SYSTEM, SYSP_META_EVENT_CONTROL, orig, sizeof(META_EVENT_CONTROL_PARAM))); // save original copy
   start = time_ms();
   for (i = 0; i <= TEST_7_NUM_PARAMS; i++)
   {
      read_start = time_us();
      TEST_ASSERT(di_save_parameter(di, PP_SYSTEM, SYSP_META_EVENT_CONTROL, buf, sizeof(META_EVENT_CONTROL_PARAM))); // can read valid page and parameter
      read_total += time_us() - read_start;
      write_start = time_us();
      TEST_ASSERT(di_load_parameter(di, PP_SYSTEM, SYSP_META_EVENT_CONTROL, buf, sizeof(META_EVENT_CONTROL_PARAM))); // can write valid page and parameter
      write_total += time_us() - write_start;
   }
   info_log("average time to save and load a parameter: %u ms\n", (time_ms() - start) / TEST_7_NUM_PARAMS);
   info_log("average time to save parameter: %u us\n", read_total / TEST_7_NUM_PARAMS);
   info_log("average time to load parameter: %u us\n", write_total / TEST_7_NUM_PARAMS);
   TEST_ASSERT(memcmp(buf, orig, sizeof(META_EVENT_CONTROL_PARAM)) == 0);
   return TEST_PASSED;
}
TEST_END


/**
 * PRIORITY 2
 *  Confirm requesting a shorter transfer than default (most significant nibble of Parameter
 *  Page Select) works
 */
TEST_START(7_4)
{
   int i;
   bool use_alt;
   bool skip;
   u8 buf[TEST_7_BUF_SIZE];
   const u8 page_max_param[PP_MAX_PAGE + 1] = {0, SYSP_MAX_PARAMETER, 0, SP_MAX_PARAMETER};

   set_rates(50, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

   for (i = PP_SYSTEM; i <= PP_MAX_PAGE; i++)
   {
      int j;
      for (j = 1; j <= page_max_param[i]; j++)
      {
         int changed = 0;
         int k;
         TEST_ASSERT(di_save_parameter(di, i, j, buf, PARAM_SAVE_SIZE)); // can read valid page and parameter

         use_alt = FALSE;
         skip = FALSE;
         for (k = 0; k < PARAM_SAVE_SIZE; k++)
         {
            if (buf[k] == 0xA5)
               use_alt = TRUE;
            else if (buf[k] == 0x5A)
               skip = TRUE;
         }
         if (use_alt && skip)
         {
            info_log("skipping page %u param %u\n", i, j);
            continue;
         }

         for (k = 1; k < 16; k++)
         {
            int m;

            //info_log("reading page %u param %u size %u: ", i, j, (k & 0xF));
            memset(buf, use_alt ? 0x5A : 0xA5, sizeof(buf));

            TEST_ASSERT(di_save_parameter(di, i, j, buf, k));        // can read valid page and parameter

            /* ensure only the requested number changed */
            for (m = 0, changed = 0; m < TEST_7_BUF_SIZE; m++)
            {
               changed += (buf[m] != (use_alt ? 0x5A : 0xA5));
            }
            //info_log("%d changed\n", changed);
            TEST_ASSERT(changed == k);                               // size of 0 means maximum size of 16
         }
      }
   }

   info_log("\n");
   return TEST_PASSED;
}
TEST_END
