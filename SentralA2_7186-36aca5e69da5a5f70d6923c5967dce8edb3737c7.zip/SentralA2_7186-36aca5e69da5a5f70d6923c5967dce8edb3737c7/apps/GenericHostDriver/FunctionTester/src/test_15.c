#include "test_common.h"

/***************************************************************************************
 * 15. Bosch Data Quality Tests
 **************************************************************************************/
/**
 * PRIORITY 2
 * \brief Bosch Data Quality Tests: Data repetition
 * for accel, gyro, and mag, before data goes through BSX,
 * confirm data is not repeated or sent in the wrong order;
 * while doing so, periodically switch modes (which modes?);
 */
#define NUM_ED_HIST 4
typedef struct test_15_1_stats
{
   bool high_speed;
   u32 t_prev_prev;
   u32 t_prev;
   u32 requested_rate;
   u32 samples_per_timestamp;
   u32 start_timestamp;
   u32 last_timestamp;
   u32 num_samples;
   u32 num_unique_timestamps;
   u32 num_duplicates;
   u32 num_missing;
   u32 out_of_order;
   float measured_rate;
   u32 expected_timestamp;
   u32 expected_delta;
   u32 ed_hist[NUM_ED_HIST];
   u32 ed_count;
   u32 ed_index;
   u32 expected_tolerance;
   u32 spt_histogram[20];
   u32 bsx_period;
}
test_15_1_stats;


typedef struct test_15_1
{
   char             *name;
   AlgIDValues    algo_id;
   test_15_1_stats  stats;
} test_15_1;


test_15_1 accel_test;                                                // BSX_A
test_15_1 gyro_test;                                                 // BSX_C
test_15_1 mag_test;                                                  // BSX_B




void analyze_bsx(test_15_1 *test, u32 t)
{
   test_15_1_stats *stats = &test->stats;
   bool print_errors = TRUE; 
   bool print_all = FALSE;
   bool is_mag = (strncmp(test->name, "BSX_B", 5) == 0);

   stats->num_samples++;
   stats->samples_per_timestamp++;
   if (!stats->start_timestamp)
      stats->start_timestamp = t;
   if (t > stats->last_timestamp)
      stats->last_timestamp = t;
   if (t < stats->t_prev)
   {
      stats->out_of_order++;
      //info_log("ooo %u %s: %u\n", data->sensor, stats->name, t);
   }
   if (t != stats->t_prev)
   {
      if (stats->samples_per_timestamp > 19)
         stats->samples_per_timestamp = 19;
      stats->spt_histogram[stats->samples_per_timestamp]++;          // create history of how many duplicates we get
      stats->samples_per_timestamp = 0;
      stats->num_unique_timestamps++;
      /*
      per Cloud at Bosch / Shanghai, we don't need to compare the data -- timestamp is enough
      if ((data->x == stats->data.x) && (data->y == stats->data.y) && (data->z == stats->data.z))
      {
         stats->num_duplicates++;
         info_log("dup %u: %u\n", data->sensor, t);
      }
      */
      if (!stats->high_speed &&
               stats->expected_timestamp &&
               (t > (stats->expected_timestamp + stats->expected_tolerance)))
      {
         stats->num_missing++;
         if (print_errors)
            info_log("mis %s: %u; exp %u, tol %u, exp delta %u, act delta %u; cur ts %u, prev %u, prevprev %u\n", 
            test->name, t, stats->expected_timestamp, stats->expected_tolerance, stats->expected_delta, t - stats->t_prev,
               t, stats->t_prev, stats->t_prev_prev);
      }
      if (stats->t_prev && (t > stats->t_prev))                      // calculate long term average expected period
      {
         int i;
         u32 sum;
         u32 prev_exp;

         if (print_all)
            info_log("nrm %s: %u; exp %u, tol %u, exp delta %u, act delta %u; cur ts %u, prev %u, prevprev %u\n", 
            test->name, t, stats->expected_timestamp, stats->expected_tolerance, stats->expected_delta, t - stats->t_prev,
               t, stats->t_prev, stats->t_prev_prev);

         stats->ed_hist[stats->ed_index] = t - stats->t_prev;
         stats->ed_count++;
         if (stats->ed_count > NUM_ED_HIST)
            stats->ed_count = NUM_ED_HIST;
         if (++stats->ed_index >= NUM_ED_HIST)
            stats->ed_index = 0;

         sum = 0;
         for (i = 0; i < stats->ed_count; i++)
            sum += stats->ed_hist[i]; 
         prev_exp = stats->expected_delta;
         stats->expected_delta = sum / stats->ed_count;

         if (stats->expected_delta > stats->bsx_period)
         {
            if (stats->bsx_period)
               stats->expected_delta = (stats->expected_delta / stats->bsx_period) * stats->bsx_period;
            if (!stats->high_speed)
            {
               if (stats->expected_delta < stats->bsx_period)
                  stats->expected_delta = stats->bsx_period;
            }
         }

         if (stats->expected_delta < prev_exp) // don't let it decrease
            stats->expected_delta = prev_exp;

         stats->expected_tolerance = stats->expected_delta / 2;
         if ((stats->expected_tolerance < stats->bsx_period) && (stats->expected_delta > stats->bsx_period))
            stats->expected_tolerance = stats->bsx_period;
         stats->expected_timestamp = t + stats->expected_delta;
      }
   }
   else
   {
         if (stats->expected_timestamp)
         {
            stats->num_duplicates++;
            if (print_errors && !is_mag)
               info_log("dup %s: %u; exp %u, exp delta %u, act delta %u; cur ts %u, prev %u, prevprev %u\n", 
               test->name, t, stats->expected_timestamp, stats->expected_delta, t - stats->t_prev,
               t, stats->t_prev, stats->t_prev_prev);
         }
         if (stats->high_speed)                                       // if sensor sample rate greater than BSX rate, then we must have a new timestamp every call
         {
            stats->num_missing++;
            if (print_errors)
               info_log("mis %s: %u; exp %u, tol %u, exp delta %u, act delta %u; cur ts %u, prev %u, prevprev %u\n", 
               test->name, t, stats->expected_timestamp, stats->expected_tolerance, stats->expected_delta, t - stats->t_prev,
               t, stats->t_prev, stats->t_prev_prev);
         }
   }
   stats->t_prev_prev = stats->t_prev;
   stats->t_prev = t;
}


bool test_15_1_data_callback(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *data, void *user_param)
{
   if (accel_test.algo_id == AID_BSX && sensor == DST_RAW_DEBUG_OUTPUT_ACCEL)
      analyze_bsx(&accel_test, data->raw_accel.t);
   else if (mag_test.algo_id == AID_BSX && sensor == DST_RAW_DEBUG_OUTPUT_MAG)
      analyze_bsx(&mag_test, data->raw_mag.t);
   else if (gyro_test.algo_id == AID_BSX && sensor == DST_RAW_DEBUG_OUTPUT_GYRO)
      analyze_bsx(&gyro_test, data->raw_gyro.t);
   else if (accel_test.algo_id == AID_SPACE_POINT && sensor == DST_ACCELEROMETER)
      analyze_bsx(&accel_test, data->accel.t);
   else if (mag_test.algo_id == AID_SPACE_POINT && sensor == DST_GEOMAGNETIC_FIELD)
      analyze_bsx(&mag_test, data->mag.t);
   else if (gyro_test.algo_id == AID_SPACE_POINT && sensor == DST_GYROSCOPE)
      analyze_bsx(&gyro_test, data->gyro.t);

   return TRUE;
}


void reset_15_1_stats(u16 rate)
{
   memset(&accel_test.stats, 0, sizeof(test_15_1_stats));
   memset(&gyro_test.stats, 0, sizeof(test_15_1_stats));
   memset(&mag_test.stats, 0, sizeof(test_15_1_stats));
   if (rate)
      mag_test.stats.expected_delta = gyro_test.stats.expected_delta = accel_test.stats.expected_delta = 1000000 / rate;
}

TEST_START(15_1)
{
   float accel_rate_error;
   float gyro_rate_error;
   float mag_rate_error;
   u16 sensor_rates[4] = {200, 50, 16, 5};
   int i;
   int j;
   SENSOR_CONFIG sensor_config;
   enum AlgID  algo_id;
   u16 bsx_rate = 0;

   // set up accel and start gathering data
   di_control_logging(di, FALSE, TRUE, TRUE, FALSE);
   default_rates();
   raw_data_enabled = TRUE;                                          // use BSX data if available; test_start_chip_running() will decide if it is possible

   reset_15_1_stats(config.accel_norm_rate);

   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   algo_id = di_get_algorithm_id(di);

   info_log("algo id: %s\n", algo_id == AID_BSX ? "BSX" : "SpacePoint");

   memset(&sensor_config, 0, sizeof(sensor_config));

   if (algo_id == AID_BSX)
   {
      accel_test.name = "BSX_A: Accel";
      mag_test.name = "BSX_B: Mag";
      gyro_test.name = "BSX_C: Gyro";
   }
   else
   {
      accel_test.name = "SpacePoint Accel";
      mag_test.name = "SpacePoint Mag";
      gyro_test.name = "SpacePoint Gyro";
   }

   accel_test.algo_id = mag_test.algo_id = gyro_test.algo_id = algo_id;

   // read out some data to start
   TEST_ASSERT(di_register(di, test_15_1_data_callback, (void *)di));

   info_log("----> read and discard initial measurements (allow for sensors to turn on and reach proper sample rate <----\n");
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(1000, FALSE));

   for (i = 0; i < ARRAY_SIZE(sensor_rates); i++)
   {
      reset_15_1_stats(sensor_rates[i]);

      info_log("\nrequesting sample rate: %u\n", sensor_rates[i]);
      sensor_config.sample_rate = sensor_rates[i];
      if (di_has_sensor(di, DST_ACCELEROMETER))
         TEST_ASSERT(di_configure_sensor(di, DST_ACCELEROMETER, &sensor_config));
      if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
         TEST_ASSERT(di_configure_sensor(di, DST_GEOMAGNETIC_FIELD, &sensor_config));
      if (di_has_sensor(di, DST_GYROSCOPE))
         TEST_ASSERT(di_configure_sensor(di, DST_GYROSCOPE, &sensor_config));

      time_delay_ms(250);

      if (algo_id == AID_BSX)
      {
         PHYS_SENSOR_STATUS phys_sensor_status;

         u8 buf[2];

         TEST_ASSERT(di_save_parameter(di, PP_SYSTEM, SYSP_PHYS_SENS_STATUS, (u8 *)&phys_sensor_status, sizeof(phys_sensor_status)));

         TEST_ASSERT(di_save_parameter(di, PP_ALGORITHM, BAP_OPR_MODE, buf, 2));
         info_log("BSX update rate: %u\nBSX operating mode index: %u\n\n", buf[0], buf[1]);
         bsx_rate = buf[0];
         gyro_test.stats.bsx_period = mag_test.stats.bsx_period = accel_test.stats.bsx_period = bsx_rate ? (1000000 / bsx_rate) : 0;
         // limit measurement rate to bsx rate, since that's the output rate for BSX_A/B/C
         // also test differently when sensor is faster than BSX
         accel_test.stats.high_speed = FALSE;
         mag_test.stats.high_speed = FALSE;
         gyro_test.stats.high_speed = FALSE;

         if (phys_sensor_status.AccelRate >= bsx_rate)
         {
            accel_test.stats.high_speed = TRUE;
            phys_sensor_status.AccelRate = bsx_rate;
         }

         if (phys_sensor_status.MagRate >= bsx_rate)
         {
            mag_test.stats.high_speed = TRUE;
            phys_sensor_status.MagRate = bsx_rate;
         }

         if (phys_sensor_status.GyroRate >= bsx_rate)
         {
            gyro_test.stats.high_speed = TRUE;
            phys_sensor_status.GyroRate = bsx_rate;
         }

         accel_test.stats.requested_rate = phys_sensor_status.AccelRate;
         mag_test.stats.requested_rate = phys_sensor_status.MagRate;
         gyro_test.stats.requested_rate = phys_sensor_status.GyroRate;
      }
      else
      {
         if (di_has_sensor(di, DST_ACCELEROMETER))
         {
            TEST_ASSERT(di_query_sensor_config(di, DST_ACCELEROMETER, &sensor_config));
            accel_test.stats.requested_rate = sensor_config.sample_rate;
         }
         if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
         {
            TEST_ASSERT(di_query_sensor_config(di, DST_GEOMAGNETIC_FIELD, &sensor_config));
            mag_test.stats.requested_rate = sensor_config.sample_rate;
         }
         if (di_has_sensor(di, DST_GYROSCOPE))
         {
            TEST_ASSERT(di_query_sensor_config(di, DST_GYROSCOPE, &sensor_config));
            gyro_test.stats.requested_rate = sensor_config.sample_rate;
         }
      }

      if (di_has_sensor(di, DST_ACCELEROMETER))
         info_log("actual accel rate=%u\n", accel_test.stats.requested_rate);
      if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
         info_log("actual mag rate=%u\n", mag_test.stats.requested_rate);
      if (di_has_sensor(di, DST_GYROSCOPE))
         info_log("actual gyro rate=%u\n", gyro_test.stats.requested_rate);

      // now read it all out, and confirm the expected pattern
      TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_15_1_RUN_TIME / 4, FALSE));

      if (di_has_sensor(di, DST_ACCELEROMETER))
      {
         test_15_1_stats *stats = &accel_test.stats;

         if (stats->last_timestamp != stats->start_timestamp)
            stats->measured_rate = (float)((stats->num_unique_timestamps * 1000000.0) / (stats->last_timestamp - stats->start_timestamp));
         accel_rate_error = calc_rate_error((float)stats->requested_rate, stats->measured_rate);
         info_log("accel rate: %3.3f, rate error: %3.3f%%, samples: %u, num dups: %u, out of order: %u, missing: %u, unique ts: %u, multiplier: %3.3f, delta_t: %u\n",
                  stats->measured_rate, accel_rate_error, stats->num_samples, stats->num_duplicates, stats->out_of_order, stats->num_missing, stats->num_unique_timestamps,
                  (stats->num_unique_timestamps ? ((1.0 * stats->num_samples) / stats->num_unique_timestamps) : 0.0), stats->last_timestamp - stats->start_timestamp);

         TEST_CHECK((stats->num_duplicates <= TEST_15_1_ACCEL_DUPS) && (stats->out_of_order == 0));
         TEST_CHECK(accel_rate_error < config.accel_rate_tol_percent);

         info_log("accel spt_histogram: ");
         for (j = 0; j < 20; j++)
            info_log("%u, ", accel_test.stats.spt_histogram[j]);
         info_log("\n");
      }

      if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
      {
         test_15_1_stats *stats = &mag_test.stats;
         u32 allowed_dups;
         if (bsx_rate)
         {
            allowed_dups = TEST_15_1_MAG_DUPS + (stats->num_samples * (bsx_rate - stats->requested_rate)) / bsx_rate;
            info_log("expdelta:%u bsx_period:%u\n", stats->expected_delta, stats->bsx_period);
         }
         else
            allowed_dups = 0;

         if (stats->last_timestamp != stats->start_timestamp)
            stats->measured_rate = (float)((stats->num_unique_timestamps * 1000000.0) / (stats->last_timestamp - stats->start_timestamp));
         mag_rate_error = calc_rate_error((float)stats->requested_rate, stats->measured_rate);
         info_log("mag rate: %3.3f, rate error: %3.3f%%, samples: %u, num dups: %u, allowed:%u, out of order: %u, missing: %u, unique ts: %u, multiplier: %3.3f, delta_t: %u\n",
                  stats->measured_rate, mag_rate_error, stats->num_samples, stats->num_duplicates, allowed_dups, stats->out_of_order, stats->num_missing, stats->num_unique_timestamps,
                  (stats->num_unique_timestamps ? ((1.0 * stats->num_samples) / stats->num_unique_timestamps) : 0.0), stats->last_timestamp - stats->start_timestamp);

         TEST_CHECK((stats->num_duplicates <= allowed_dups) && (stats->out_of_order == 0));
         TEST_CHECK(mag_rate_error < config.mag_rate_tol_percent);

         info_log("mag spt_histogram: ");
         for (j = 0; j < 20; j++)
            info_log("%u, ", mag_test.stats.spt_histogram[j]);
         info_log("\n");
      }

      if (di_has_sensor(di, DST_GYROSCOPE))
      {
         test_15_1_stats *stats = &gyro_test.stats;

         if (stats->last_timestamp != stats->start_timestamp)
            stats->measured_rate = (float)((stats->num_unique_timestamps * 1000000.0) / (stats->last_timestamp - stats->start_timestamp));
         gyro_rate_error = calc_rate_error((float)stats->requested_rate, stats->measured_rate);
         info_log("gyro rate: %3.3f, rate error: %3.3f%%, samples: %u, num dups: %u, out of order: %u, missing: %u, unique ts: %u, multiplier: %3.3f, delta_t: %u\n",
                  stats->measured_rate, gyro_rate_error, stats->num_samples, stats->num_duplicates, stats->out_of_order, stats->num_missing, stats->num_unique_timestamps,
                  (stats->num_unique_timestamps ? ((1.0 * stats->num_samples) / stats->num_unique_timestamps) : 0.0), stats->last_timestamp - stats->start_timestamp);

         TEST_CHECK((stats->num_duplicates <= TEST_15_1_GYRO_DUPS) && (stats->out_of_order == 0));
         TEST_CHECK(gyro_rate_error < config.gyro_rate_tol_percent);

         info_log("gyro spt_histogram: ");
         for (j = 0; j < 20; j++)
            info_log("%u, ", gyro_test.stats.spt_histogram[j]);
         info_log("\n");
      }
   }

   di_control_logging(di, FALSE, FALSE, FALSE, FALSE);
   info_log("\n");

}
TEST_END


/**
 * PRIORITY 2
 * \brief Bosch Data Quality Tests: Data loss
 * set up sensors to generate data; retrieve data such that some
 * buffering is happening but is not allowed to overflow; ensure
 * no samples lost
 */
TEST_START(15_2)
{
   PHYS_SENSOR_STATUS phys_sensor_status;
   FIFO_CONTROL_PARAM fifo_control_param;

   // set up accel and start gathering data
   di_control_logging(di, FALSE, TRUE, FALSE, FALSE);
   set_rates(50, 50, 50, 0);
   set_latencies(65535, 65535, 65535, 65535);
   raw_data_enabled = TRUE;

   reset_15_1_stats(config.accel_fast_rate);

   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   TEST_ASSERT(di_register(di, test_15_1_data_callback, (void *)di));
   TEST_ASSERT(di_save_parameter(di, PP_SYSTEM, SYSP_FIFO_CONTROL, (u8 *)&fifo_control_param, sizeof(fifo_control_param)));
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERT(di_configure_interrupts_ex(di, TRUE, TRUE, fifo_control_param.fifo_size / 2, fifo_control_param.fifo_size / 2));
   }
   else
   {
      TEST_ASSERT(di_configure_interrupts(di, TRUE, fifo_control_param.fifo_size / 2));
   }

   TEST_ASSERT(di_save_parameter(di, PP_SYSTEM, SYSP_PHYS_SENS_STATUS, (u8 *)&phys_sensor_status, sizeof(phys_sensor_status)));
   if (di_has_sensor(di, DST_ACCELEROMETER))
      info_log("physical accel rate=%u\n", phys_sensor_status.AccelRate);
   if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
      info_log("physical mag rate=%u\n", phys_sensor_status.MagRate);
   if (di_has_sensor(di, DST_GYROSCOPE))
      info_log("physical gyro rate=%u\n", phys_sensor_status.GyroRate);

   reset_15_1_stats(config.accel_fast_rate);


   if (di_get_algorithm_id(di) == AID_BSX)
   {
      u16 bsx_rate = 0;
      u8 buf[2];
      // limit measurement rate to bsx rate, since that's the output rate for BSX_A/B/C
      // also test differently when sensor is faster than BSX
      TEST_ASSERT(di_save_parameter(di, PP_ALGORITHM, BAP_OPR_MODE, buf, 2));
      info_log("BSX update rate: %u\nBSX operating mode index: %u\n\n", buf[0], buf[1]);
      bsx_rate = buf[0];
      gyro_test.stats.bsx_period = mag_test.stats.bsx_period = accel_test.stats.bsx_period = bsx_rate ? (1000000 / bsx_rate) : 0;
      accel_test.stats.high_speed = FALSE;
      mag_test.stats.high_speed = FALSE;
      gyro_test.stats.high_speed = FALSE;

      if (phys_sensor_status.AccelRate >= bsx_rate)
      {
         accel_test.stats.high_speed = TRUE;
         phys_sensor_status.AccelRate = bsx_rate;
      }

      if (phys_sensor_status.MagRate >= bsx_rate)
      {
         mag_test.stats.high_speed = TRUE;
         phys_sensor_status.MagRate = bsx_rate;
      }

      if (phys_sensor_status.GyroRate >= bsx_rate)
      {
         gyro_test.stats.high_speed = TRUE;
         phys_sensor_status.GyroRate = bsx_rate;
      }
   }

   if (di_get_algorithm_id(di) == AID_BSX)
   {
      accel_test.name = "BSX_A: Accel";
      mag_test.name = "BSX_B: Mag";
      gyro_test.name = "BSX_C: Gyro";
   }
   else
   {
      accel_test.name = "SpacePoint Accel";
      mag_test.name = "SpacePoint Mag";
      gyro_test.name = "SpacePoint Gyro";
   }

   // read out some data to start
   info_log("----> read and discard initial measurements (allow for sensors to turn on and reach proper sample rate <----\n");
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_15_2_DISCARD_TIME, FALSE));

   accel_test.stats.num_missing = accel_test.stats.out_of_order = accel_test.stats.num_duplicates = accel_test.stats.num_unique_timestamps = 0;
   mag_test.stats.num_missing = mag_test.stats.out_of_order = mag_test.stats.num_duplicates = mag_test.stats.num_unique_timestamps = 0;
   gyro_test.stats.num_missing = gyro_test.stats.out_of_order = gyro_test.stats.num_duplicates = gyro_test.stats.num_unique_timestamps = 0;

   // now read it all out, and confirm the expected pattern
   info_log("\nStart monitoring...\n");
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_15_2_RUN_TIME, FALSE));

   if (di_has_sensor(di, DST_ACCELEROMETER))
   {
      info_log("accel: num missing: %u, num dups: %u, out of order: %u, unique ts: %u\n",
               accel_test.stats.num_missing, accel_test.stats.num_duplicates, accel_test.stats.out_of_order, accel_test.stats.num_unique_timestamps);
   }

   if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
   {
      info_log("mag: num missing: %u, num dups: %u, out of order: %u, unique ts: %u\n",
               mag_test.stats.num_missing, mag_test.stats.num_duplicates, mag_test.stats.out_of_order, mag_test.stats.num_unique_timestamps);
   }

   if (di_has_sensor(di, DST_GYROSCOPE))
   {
      info_log("gyro: num missing: %u, num dups: %u, out of order: %u, unique ts: %u\n",
               gyro_test.stats.num_missing, gyro_test.stats.num_duplicates, gyro_test.stats.out_of_order, gyro_test.stats.num_unique_timestamps);
   }

   di_control_logging(di, FALSE, FALSE, FALSE, FALSE);

   TEST_ASSERT((accel_test.stats.num_missing == 0) && (accel_test.stats.out_of_order == 0));
   TEST_ASSERT((mag_test.stats.num_missing == 0) && (mag_test.stats.out_of_order == 0));
   TEST_ASSERT((gyro_test.stats.num_missing == 0) && (gyro_test.stats.out_of_order == 0));

   return TEST_PASSED;
}
TEST_END


/**
 * PRIORITY 2
 * \brief Data synchronization
 * set up sensors to generate data; ensure timestamps of each
 * sensor are consistent with each other (time-aligned within
 * x%); confirm data rates are as expected
 */
TEST_START(15_3)
{
   return TEST_NOT_IMPLEMENTED;
}
TEST_END

