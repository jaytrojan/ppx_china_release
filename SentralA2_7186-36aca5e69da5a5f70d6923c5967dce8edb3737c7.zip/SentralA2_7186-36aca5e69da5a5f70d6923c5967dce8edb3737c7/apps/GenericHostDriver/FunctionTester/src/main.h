#ifndef _MAIN_H_
#define _MAIN_H_

#include "types.h"
#include "host_services.h"
#include "driver_ext.h"

// test application configuration flags
#define CONFIG_FILE_REQUIRED              // don't run if we can't find the config file
#define SENSORS_PRESENT_SIZE 32

#define TRUE 1
#define FALSE 0

#endif

