#include "test_common.h"
//#define USE_JOSHS_TESTS

/**
 * \brief Test 8.1
 */
TEST_START(8_1)
{
#ifdef VBE_DBG
   //SENSOR_INFORMATION sensor_info;
   //SENSOR_CONFIG sensor_config;
   bool executing, sensing;

   //default_rates();
   accel_rate = 0;
   gyro_rate = 0;
   mag_rate = 0;
   quat_rate = 0;

   accel_latency = 0;
   gyro_latency = 0;
   mag_latency = 0;
   quat_latency = 0;

   //di->dump_raw_data = 1;
   //set_logging_level(4);

   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }

   // DST_ACCELEROMETER DST_GYROSCOPE DST_GEOMAGNETIC_FIELD
   // DST_WAKEUP_ACCELEROMETER
   // DST_WAKEUP_GEOMAGNETIC_FIELD
   // DST_WAKEUP_GYROSCOPE
   accel_rate = 10;
   accel_latency = 1000;
   if (di->hi_id != HIID_KITKAT)
   {
      di_configure_rate(di, DST_ACCELEROMETER | di_wake_sensor_start(di), accel_rate, accel_latency);
   }

   accel_rate = 10;
   accel_latency = 900;
   di_configure_rate(di, DST_ACCELEROMETER, accel_rate, accel_latency);

   TEST_ASSERT(di_enable_meta_event(di, DME_FLUSH_COMPLETE, TRUE, FALSE));
   TEST_ASSERT(di_configure_interrupts_ex(di, TRUE, TRUE, 5000, 5000));

   // confirm all is well
   if (!di_query_status(di, &executing, &sensing))
   {
      error_log("error reading status\n");
   }
   info_log("executing: %d, sensing: %d\n", executing, sensing);
   TEST_ASSERT(executing == 1);
   TEST_ASSERT(sensing == 1);

   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(1000, FALSE));
   time_delay_ms(400);
   printf("flush beg");
   di_fifo_flush(di, 0x33);
   printf("flush end");
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(1000, FALSE));
   return TEST_PASSED;
#else
   return TEST_NOT_IMPLEMENTED;
#endif //VBE_DBG
}
TEST_END


/***************************************************************************************
 * 8. FIFO Transfer Mechanism
 **************************************************************************************/
/**
 * PRIORITY 1
 * \brief Bytes Remaining
 * set up accel; let data accumulate for time sufficient to
 * reach 80% full; update transfer count; ensure count
 * matches expected amount of data accumulation; disable
 * accel; read out all data; update transfer count and
 * ensure it is at 0
 */

/**
 * \brief display bytes remaining
 */
void read_known_and_print()
{
   u32 last_byte_xfer;
   last_byte_xfer = di->total_bytes_transferred;
   di_read_fifo_known_bytes_remaining(di);
   last_byte_xfer = di->total_bytes_transferred - last_byte_xfer;
   info_log("bytes read from FIFO: %u\n", last_byte_xfer);
}

/**
 * \brief perform test 8.2 for a specific set of sensors
 * \param s_sz - number of sensors in the set
 * \param s - array of sensor IDs
 * \return int - status
 */
int t_8_2_for_sensor(int s_sz, DI_SENSOR_TYPE_T *s)
{
   int i;
   u16 max_events;                                                   // max accel events in FIFO (note: it is estimate, it counts in timestamp
                                                                     //   LSW but not timestamp MSW so in fact there will fit less accel event
                                                                     //   into real FIFO)
   double fifo_to_fill = 0.8;                                        // FIFO to fill (eg. 0.8 = 80%)
   u32 extra_events_to_generate = 10;                                // extra events to generate for check that bytes_reamaining is increased
   u32 extra_events_generated;                                       // extra events actually generated
   u16 exp_evnts;                                                    // expected events to receive
   u32 exp_bytes;                                                    // expected bytes to receive
   u32 exp_bytes_fast;                                               // expected bytes to receive
   u32 wait_time;                                                    // wait time to wait for data to be generated to fill FIFO
   u16 count;                                                        // received count of remaninig bytes
   u16 count_evnts;                                                  // computed received events from received remaining bytes
   u16 count2;                                                       // received count of next remaninig bytes
   s32 count_diff;                                                   // difference between count2 and count
   u32 fifo_bytes_remaining_bck;                                     // FIFO bytes remaining backup value
   u32 partial_read_bytes;                                           // partial bytes read
   s32 delta;                                                        // delta between expected events and received events
   FIFO_CONTROL_PARAM fifo_control_param;
   unsigned int use_rate;                                            // rate to be use for Accel sensor
   u32 use_event_size = ACCEL_EVENT_FIFO_REAL_SIZE;                  // events size to be used for computation of expected events
   u32 use_fifo_size;                                                // u718x FIFO size
   u32 last_time_ms;                                                 // last time in ms
   u32 diff_time_ms;                                                 // difference time in ms
   u32 diff_time_ms_fast;                                            // difference time in ms
   u16 queried_rate;

   //use_rate = config.accel_norm_rate;
   use_rate = config.accel_fast_rate;

   info_log("=== test 8.2 - loop ======================================================\n");
   // note sensor_info.fifo_max doea not take into account timestamps - therefore we count expected events ourselves
   TEST_ASSERT(di_save_parameter(di, PP_SYSTEM, SYSP_FIFO_CONTROL, (u8 *)&fifo_control_param, sizeof(fifo_control_param)));
   info_log("fifo: watermark: %d size W/NW: %u/%u B\n",
            fifo_control_param.watermark, fifo_control_param.fifo_size,
            fifo_control_param.nonwakeup_fifo_size);

   use_fifo_size = fifo_control_param.fifo_size;
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERTF(fifo_control_param.fifo_size == fifo_control_param.nonwakeup_fifo_size,
                   "This test was designed with presumption that wakeup and non wakeup size are roughly equal")
   }
   max_events = (use_fifo_size / use_event_size);
   info_log("max events to populate full W or NW FIFO: %u\n", max_events);
   exp_evnts =  (u32)(max_events * fifo_to_fill);
   info_log("expected accel events: %d (to populate %0.1f %% of FIFO)\n", exp_evnts, fifo_to_fill * 100);

   for (i = 0; i < s_sz; i++)
   {
      TEST_ASSERT(set_and_chk_rate(s[i], use_rate, &queried_rate, TRUE));
   }

   if (queried_rate)
      wait_time = 1000 * exp_evnts / queried_rate;
   else
      wait_time = 0;

   exp_evnts *= s_sz;                                                // expecting sensors on same rate

   // clear the fifo
   info_log("Read out FIFO\n");
   read_FIFO(20, TRUE, NULL);                                        // for accel.fast we do not use read whie interrupt as it is always

   info_log("wait %u ms (to fill %0.1f %% of FIFO)\n", wait_time, fifo_to_fill * 100);
   time_delay_ms(wait_time);

   info_log("=== Check that bytes generated match expectation\n");

   read_bytes_remaining();
   info_log("bytes to read in current transaction: %u\n", di->fifo_bytes_remaining);

   // update transfer count and check the results
   TEST_ASSERT(di_update_transfer_count(di, &count));
   last_time_ms = time_ms();
   info_log("total bytes to read: %u\n", count);
   count_evnts = count / use_event_size;                             // convert bytes remaining to number of accel samples
   info_log("total events ~%u\n", count_evnts);
   delta = (s32)(exp_evnts)-(s32)(count_evnts);
   info_log("approximation of expected_events - received_events: %d\n", delta);
   TAFR(chk_s_val_with_margin(0, delta, 0, exp_evnts * TEST_8_2_ACCURACY_THRESHOLD / 100),
        "too big difference between expedcted and received events\n");

   info_log("=== Check that after generating more events - bytes are increased\n");

   info_log("wait for %u accel events\n", extra_events_to_generate);
   if (queried_rate)
      time_delay_ms(extra_events_to_generate * 1000 / queried_rate);

   info_log("disabling accel:\n");
   diff_time_ms_fast = time_ms() - last_time_ms;

   for (i = 0; i < s_sz; i++)
   {
      TEST_ASSERT(set_and_chk_rate(s[i], 0, NULL, TRUE));
   }
   // Turning off rates can take some time, we could have been generating up untill the function returned / loop exited.:
   // Note: this value should be slightly high. Also, if multiple sensors are turned off, this will be incorrect.
   diff_time_ms = time_ms() - last_time_ms;

   extra_events_generated = (u32)(queried_rate * diff_time_ms / 1000.0);
   exp_bytes = use_event_size * extra_events_generated * s_sz;

   extra_events_generated = (u32)(queried_rate * diff_time_ms_fast / 1000.0);
   exp_bytes_fast = use_event_size * extra_events_generated * s_sz;

   TEST_ASSERT(di_update_transfer_count(di, &count2));
   info_log("total bytes to read after wait: %u\n", count2);
   info_log("bytes before wait: %u < bytes after wait: %u\n", count, count2);
   count_diff = count2 - count;
   info_log("bytes increased: %d\n", count_diff);

   TAFR(chk_dual_val_with_margin_lr(exp_bytes_fast, exp_bytes, count_diff, 0.2, 0, 0.3, use_event_size * 8 * s_sz),
        "expecting <%d> more bytes to read after wait\n",
        exp_bytes);

   info_log("=== Check that after FIFO reading - bytes are decreased\n");

   read_known_and_print();

   try_with_time_limit(check_int_pin_1, 100, 30);

   read_bytes_remaining();
   info_log("bytes remaining (note bytes that has been read before was already in buffer, so not counted in FIFO): %u\n", di->fifo_bytes_remaining);

   TEST_ASSERT(di_update_transfer_count(di, &count));
   info_log("bytes updated (note intermediate buffer will consume ~100 B): %u\n", count);

   TAFR(di->fifo_bytes_remaining >= count, "Some bytes may have been read to intermediate buffer thus count may be <0,100>B lower\n");

   fifo_bytes_remaining_bck = di->fifo_bytes_remaining;
   di->fifo_bytes_remaining = partial_read_bytes = 300;
   read_known_and_print();

   TEST_ASSERT(di_update_transfer_count(di, &count2));
   info_log("bytes updated: %u\n", count2);
   count_diff = count - count2;
   info_log("Bytes diff: %d ", count_diff);
   TAFR(chk_val_with_margin(partial_read_bytes, count_diff, 0, 200), // was 110 -- why?
        "Expecting %d less bytes to read after data were read out\n", count_diff);

   info_log("=== Check that reading whole FIFO - bytes == 0\n");

   // read out all data - do not use standard reading function as they would
   //   update di->fifo_bytes_remaining and it would be wrong
   di->fifo_bytes_remaining = fifo_bytes_remaining_bck - partial_read_bytes;
   read_known_and_print();

   // update count again and ensure is zero
   TEST_ASSERT(di_update_transfer_count(di, &count));
   info_log("count %u\n", count);
   TEST_ASSERT(count == 0);
   TEST_ASSERT(check_FIFO_consistency() == TEST_PASSED);
   return g_current_test_retval;
}


/**
 * \brief test 8.2
 */
TEST_START(8_2)
{
   // set up accel and start gathering data
   DI_SENSOR_TYPE_T s[2];
   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }

   s[0] = DST_ACCELEROMETER;
   t_8_2_for_sensor(1, s);

   if (di->hi_id == HIID_KITKAT)
   {
      return g_current_test_retval;
   }

   s[0] = DST_ACCELEROMETER | di_wake_sensor_start(di);
   t_8_2_for_sensor(1, s);

   s[1] = DST_ACCELEROMETER;
   t_8_2_for_sensor(2, s);

   return g_current_test_retval;

}
TEST_END


/**
 * PRIORITY 2
 * \brief Host Interface Control Register Abort Transfer bit
 * works properly set up accel
 * read some but not all of the FIFO; abort the transfer; the
 * next read from the FIFO should contain data subsequent to
 * last read data; anything that was placed in the output
 * registers but not known to have been really read by host will
 * be lost; we need a test mode that generates a predictable
 * pattern of sensor samples and contents; each sensor should be
 * able to do this, and have a unique but predictable pattern of
 * sample data
 */

// global structure for test 8.3 parameters - may be accessed by all test 8.3 functions
typedef struct test_8_3_global_data
{
   u32 last_smpl_cnt;                                                // last accel sample index
   u32 last_batch_smpl_cnt_dif;                                      // last batch accel samples count
   u32 last_w_smpl_cnt;                                              // last wakeup accel sample index
   u32 last_batch_w_smpl_cnt_dif;                                    // last batch wakeup accel samples count
   u32 exp_batch_smpl_cnt;                                           // epxected batch sample count
   u32 exp_min_B_disc;                                               // expected minimum bytes discarded
   u32 exp_max_B_disc;                                               // expected maximum bytes discarded
   double period_ms;                                                 // accel period in ms
   double period_us;                                                 // accel period in us
   u32 exp_min_acel_evnt_disc;                                       // expected minimum accel events discarde
   u32 exp_max_acel_evnt_disc;                                       // expected maximum accel events discarded
   u32 exp_min_time_gap_us;                                          // expected minimum time gap in us
   u32 exp_max_time_gap_us;                                          // expected maximum time gap in us
   u32 del_tm_ms;                                                    // delay time in ms
   u32 lat_tm_ms;                                                    // latency time in ms
   u32 minimum_required_latency_ms;                                  // minimum required batch latency in ms
   u16 qsr;                                                          // accel queried sample rate
   u16 ql;                                                           // accel queried latency
   u16 w_qsr;                                                        // wakeup accel queried sample rate
   u16 approx_bytes_to_be_generated;                                 // requested bytes to be generated (approximate)
   u16 host_int_wait_ms;                                             // host interface interrupt change wait time ms
   u16 host_int_poll_ms;                                             // host interface interrupt poll period ms
}
test_8_3_global_data_t;

test_8_3_global_data_t g_8_3;


/**
 * \brief initialize test 8.3 parameters
 */
void init_test_8_3()
{
   g_8_3.minimum_required_latency_ms = 300;
   g_8_3.host_int_wait_ms = 200;
   g_8_3.host_int_poll_ms = 50;
   g_8_3.last_smpl_cnt = 0;
   g_8_3.last_batch_smpl_cnt_dif = 0;
   g_8_3.last_w_smpl_cnt = 0;
   g_8_3.last_batch_w_smpl_cnt_dif = 0;
   g_8_3.exp_min_B_disc = 50;
   g_8_3.exp_max_B_disc = 100;
   g_8_3.period_ms = 0;
   g_8_3.period_us = 0;
   g_8_3.qsr = 0;
   g_8_3.w_qsr = 0;
}


/**
 * \brief counts expected number of discarded events and expected time gap
 *        uses exp_min_B_disc, exp_max_B_disc
 */
void count_exp_events_disc()
{
   u32 sz_of_lsw_and_acel = ACCEL_EVENT_FIFO_REAL_SIZE;
   g_8_3.exp_min_acel_evnt_disc = g_8_3.exp_min_B_disc / sz_of_lsw_and_acel;
   g_8_3.exp_min_acel_evnt_disc = (u32)(g_8_3.exp_min_acel_evnt_disc * 0.5); // bug cushion - due to MSW etc...
   g_8_3.exp_min_time_gap_us = (u32)(g_8_3.exp_min_acel_evnt_disc * g_8_3.period_us);

   g_8_3.exp_max_acel_evnt_disc = g_8_3.exp_max_B_disc / sz_of_lsw_and_acel;
   g_8_3.exp_max_acel_evnt_disc = (u32)(g_8_3.exp_max_acel_evnt_disc * 1.2) + 1; // 20% +1 event safety cushion
   g_8_3.exp_max_time_gap_us = (u32)((g_8_3.exp_max_acel_evnt_disc + 1) * g_8_3.period_us);
}


/**
** \brief  print accel event samples received (index and difference from last batch)
 */
void prn_accel_smpl_dif()
{
   g_8_3.last_batch_smpl_cnt_dif   = di->sensor_info[DST_ACCELEROMETER].samples_received - g_8_3.last_smpl_cnt;
   info_log("=======   Accel samples received: %u diff: %u\n",
            di->sensor_info[DST_ACCELEROMETER].samples_received,
            g_8_3.last_batch_smpl_cnt_dif);
   g_8_3.last_smpl_cnt   = di->sensor_info[DST_ACCELEROMETER].samples_received;
   if (di->hi_id != HIID_KITKAT)
   {
      g_8_3.last_batch_w_smpl_cnt_dif = di->sensor_info[DST_ACCELEROMETER | di_wake_sensor_start(di)].samples_received - g_8_3.last_w_smpl_cnt;
      info_log("======= W Accel samples received: %u diff: %u\n",
               di->sensor_info[DST_ACCELEROMETER | di_wake_sensor_start(di)].samples_received,
               g_8_3.last_batch_w_smpl_cnt_dif);
      g_8_3.last_w_smpl_cnt = di->sensor_info[DST_ACCELEROMETER | di_wake_sensor_start(di)].samples_received;
   }
   else
   {
      g_8_3.last_batch_w_smpl_cnt_dif = 0;
      g_8_3.last_w_smpl_cnt = 0;
   }
}


/**
 * \brief convert decode status to a string
 * \return const char* - the string
 */
const char *get_str_event_decode_status()
{
   switch (di->event_decode_status)
   {
      case DI_PROC_ONE__OK:
         return "properly ended";
      case DI_PROC_ONE__NOP:
         return "padding 00";
      case DI_PROC_ONE__UNKNOWN_EVENT:
         return "unknown event detected";
      case DI_PROC_ONE__EVENT_NOT_COMPLETE:
         return "event not complete";
      default:
         return "unknown state";
   }
}


/**
 * \brief wait for defined latency,
 *        check host interrupt pin is asserted
 *        read bytes in FIFO
 */
void t_8_3_wait_and_read_bytes_remaining()
{
   info_log("Wait %d [ms] to put in FIFO more than %d samples and trigger latency %d\n",
            g_8_3.del_tm_ms, g_8_3.exp_batch_smpl_cnt, g_8_3.ql);
   time_delay_ms(g_8_3.del_tm_ms);

   TAFR(try_with_time_limit(check_int_pin_1, g_8_3.host_int_wait_ms, g_8_3.host_int_poll_ms),
        "Expecting host interrupt, but no host interrupt detected!\n");

   read_bytes_remaining();
   info_log("fifo bytes remaining: %u\n", di->fifo_bytes_remaining);
}


/**
 * \brief prepare test
 *        1. discard old data
 *        2. generates 1st batch
 *        3. waits for next data and check host interrupt and bytes remaining
 * \return int - TEST_PASSED/FAILED
 */
int t_8_3_prepare_data()
{
   int i;
   bool done;
   test_read_out_pending_data(500, FALSE);
   TEST_ASSERTF(try_with_time_limit(check_int_pin_0, g_8_3.host_int_wait_ms, g_8_3.host_int_poll_ms),
                "Expecting cleared host interrupt pin, but active host interrupt detected!\n");
   // reset relevant counters
   di->total_timegaps = 0;
   di->sensor_info[DST_ACCELEROMETER].timestamp_gaps = 0;
   if (di->hi_id != HIID_KITKAT)
      di->sensor_info[DST_ACCELEROMETER | di_wake_sensor_start(di)].timestamp_gaps = 0;
   di->total_timeslips = 0;
   di->total_timedups = 0;
   di->total_invalid_samples_received = 0;
   // read first batch
   for (i = 0; i < 1; i++)
   {
      TEST_ASSERT(di_read_fifo(di, &done, g_8_3.lat_tm_ms * 2, 0));
      /* for debugging, display info so we can try to figure out why we're not getting data
      if (!done)
      {
         display_actual_rates(di);
         di_query_sensor_status(di);
         display_sensor_status_bytes(di, TRUE);
         display_error_info(di);
      }*/
      TEST_ASSERTF(done, "Data not received");
      prn_accel_smpl_dif();
   }
   // read batch that will be tested
   t_8_3_wait_and_read_bytes_remaining();
   return TEST_PASSED;
}


/**
 * \brief read required number of data optionally check if gap
 *        (and other properties) as expected
 * \param rd_bytes - number of bytes to read
 * \param check_gap_sensor - sensor [DST_ACCEL,
 *                           DST_WAKEUP_ACCEL] whose data shall
 *                           generate time gap
 * \return int - TEST_PASSED/FAILED
 */
int t_8_3_read_data(u32 rd_bytes, DI_SENSOR_TYPE_T check_gap_sensor)
{
   info_log("reading: %u of %u bytes\n", rd_bytes, di->fifo_bytes_remaining);
   TEST_ASSERTF(rd_bytes <= di->sensor_buf_size, "Trying to read more bytes than is size of buffer");
   TEST_ASSERTF(rd_bytes <= di->fifo_bytes_remaining, "Trying to read more bytes then are available in u718x");
   TAFR(i2c_blocking_read(di->i2c_handle, 0x00, di->sensor_buf, rd_bytes),
        "read %d B failed\n", rd_bytes);
   di->sensor_buf_idx = 0;
   di->sensor_buf_valid_data_size = rd_bytes;
   process_fifo_chunk(di);
   info_log("Event decoding status %s\n", get_str_event_decode_status());
   prn_accel_smpl_dif();
   if (check_gap_sensor != DST_NOP)
   {
      TEST_ASSERT(di->total_invalid_samples_received == 0);
   }
   return TEST_PASSED;
}


/**
 * \brief check that host interrupt pin deasserted, and bytes_remaining cleared
 *        call t_8_3_wait_and_read_bytes_remaining
 * \return int - TEST_PASSED/FAILED
 */
int t_8_3_abort_xfer_and_prepare_next_data()
{
   info_log("issuing abort transfer...");
   prn_num_sep(time_ms(), 9);
   info_log("[ms]\n");
   TEST_ASSERTF(di_abort_transfer(di), "error aborting FIFO transfer\n");

   TEST_ASSERTF(TRUE == try_with_time_limit(check_int_pin_0, g_8_3.host_int_wait_ms, g_8_3.host_int_poll_ms),
                "Expecting cleared host interrupt, but active host interrupt detected!\n");

   read_bytes_remaining();
   info_log("fifo bytes remaining: %u tm:", di->fifo_bytes_remaining);
   prn_num_sep(time_ms(), 9);
   info_log("[ms]\n");
   TEST_ASSERTF(di->fifo_bytes_remaining == 0, "Expecting cleared bytes_remaining but got %u\n"
                "   NOTE: this error may be due to too short latency - next packet is generated before bytes_remaining is read\n"
                "       try increase latency parameter g_8_3.minimum_required_latency_ms (this will prolong the test time)\n"
                , di->fifo_bytes_remaining);

   t_8_3_wait_and_read_bytes_remaining();
   return TEST_PASSED;
}


/**
 * \brief main test 8.3 loop
 *        - reads some bytes
 *        - call abort_transfer + check host interrupt deasserted
 *        - reads next batch and checks next data are correct
 * \param sens_gap - sensor whose data shall contain time gap
 * \param bytes_mul - determines data to read before
 *        abort_transfer see bytes_add
 * \param bytes_add - determines data to read before
 *        abort_transfer; formula is: batch_data_number *
 *        bytes_mul + bytes_add
 */
void t_8_3_main_loop(DI_SENSOR_TYPE_T sens_gap, double bytes_mul, u32 bytes_add)
{
   info_log("===========================================================================\n");
   info_log("=== Read (%u B + ~%u) = ~%u of ~%u B\n",
            bytes_add, (u32)(g_8_3.approx_bytes_to_be_generated * bytes_mul),
            bytes_add + (u32)(g_8_3.approx_bytes_to_be_generated * bytes_mul),
            g_8_3.approx_bytes_to_be_generated);
   do
   {
      if (TEST_PASSED != t_8_3_prepare_data())
         break;
      if (TEST_PASSED != t_8_3_read_data((u32)(di->fifo_bytes_remaining * bytes_mul) + bytes_add, DST_NOP))
         break;
      if (TEST_PASSED != t_8_3_abort_xfer_and_prepare_next_data())
         break;
      if (TEST_PASSED != t_8_3_read_data(di->fifo_bytes_remaining, sens_gap))
         break;
   }
   while (FALSE);
}


/**
 * \brief set accel rate and latency according tu number of
 *        bytes that shall be generated in one batch; NOTE
 *        wakeup_accel must be set separately - rest of tests
 *        expects same rate for W and NW
 *        approx_bytes_to_be_generated: approximate number od
 *        bytes that will be generated in one batch; NOTE if
 *        "approx_bytes_to_be_generated" is too low the latency
 *        may be also too low and checking that interrupt is
 *        deasserted may fail. If so you need to set more data
 *        expected
 * \param approx_bytes_to_be_generated -
 */
void t_8_3_set_accel_rate_and_lat(u16 approx_bytes_to_be_generated)
{
   u16 try_rate[] = {config.accel_fast_rate, config.accel_norm_rate, 20, 10, 1};
   int i;

   // first try faster rate - if latency for requesterd bytes would be too small (less than 100ms)
   //    then switch for normal frequency;
   //    If latency is too small some IO reading (eg checking that bytes_remaining==0 host_interrupt=0)
   //      might not get in time and test might fail unjustly
   for (i = 0; i < (sizeof(try_rate) / sizeof(u16)); i++)
   {
      set_and_chk_rate(DST_ACCELEROMETER, try_rate[i], &g_8_3.qsr, TRUE);
      g_8_3.period_ms = 1e3 / g_8_3.qsr;
      g_8_3.period_us = g_8_3.period_ms * 1e3;
      count_exp_events_disc();

      g_8_3.approx_bytes_to_be_generated = approx_bytes_to_be_generated;
      g_8_3.exp_batch_smpl_cnt = approx_bytes_to_be_generated / ACCEL_EVENT_FIFO_REAL_SIZE;
      g_8_3.lat_tm_ms = (u32)(g_8_3.exp_batch_smpl_cnt * g_8_3.period_ms);
      if (g_8_3.lat_tm_ms > g_8_3.minimum_required_latency_ms)
         break;                                                      // requre at least x ms
   }
   set_and_chk_lat(DST_ACCELEROMETER, g_8_3.lat_tm_ms, &(g_8_3.ql), TRUE);
   g_8_3.del_tm_ms = (u32)(g_8_3.lat_tm_ms * 1.00);
   info_log("approx B %u, approx batch smpls: %u, latency set: %u [ms]\n",
            g_8_3.approx_bytes_to_be_generated, g_8_3.exp_batch_smpl_cnt,
            g_8_3.del_tm_ms);
}


// detailed test tries more partial reading but takes longer time
#define TEST_8_3_DETAILED ALL_TESTS_DETAILED

/**
 * \brief test 8.3
 */
TEST_START(8_3)
{
   u16 ql;                                                           // quieried latency
   DI_SENSOR_TYPE_T sens_gap;                                        // sensor which shall contains gap
   u16 approx_bytes[] = {80, 400};                                   // bytes to be generated in one batch (50-100 bytes is discarded by abort_transaction
                                                                     //   command - rest is returned in next batch)
   double bytes_mul_andr_l[] = {0, 0.5};                             // multiplicator - controlls bytes to be partially read before
                                                                     //   abort_transfer - see t_8_3_main_loop(bytes_mul)
   u32 i = 0;
   u32 j = 0;

   // set up accel and start gathering data
   set_rates(config.accel_fast_rate, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }

   init_test_8_3();

   for (j = 0; j < sizeof(approx_bytes) / sizeof(u16); j++)
   {                                                                 // loop to iterate through different batch sizes
      t_8_3_set_accel_rate_and_lat(approx_bytes[j]);
      // try to partially read different FIFO sizes before abort_transfer is called
      if (TEST_8_3_DETAILED == 1)
      {
         for (i = 0; i < 60; i++)
         {
            t_8_3_main_loop(DST_ACCELEROMETER, 0, i);
         }
      }
      else
      {
         u32 test[] = {0, 1, 25, 50, 51};
         for (i = 0; i < sizeof(test) / sizeof(u32); i++)
         {
            t_8_3_main_loop(DST_ACCELEROMETER, 0, test[i]);
         }
      }
   }

   if (di->hi_id == HIID_KITKAT)
   {
      return g_current_test_retval;
   }

   t_8_3_set_accel_rate_and_lat(400);
   // enble WAKEUP_ACCEL at same rate as non wakeup
   set_and_chk_rate(DST_ACCELEROMETER | di_wake_sensor_start(di), g_8_3.qsr, &g_8_3.w_qsr, TRUE);
   TEST_ASSERT(g_8_3.qsr == g_8_3.w_qsr);
   set_and_chk_lat(DST_ACCELEROMETER | di_wake_sensor_start(di), g_8_3.lat_tm_ms, &ql, TRUE);
   TEST_ASSERT(g_8_3.ql == ql);
   g_8_3.approx_bytes_to_be_generated *= 2;

   for (j = 0; j < sizeof(bytes_mul_andr_l) / sizeof(double); j++)
   {                                                                 // loop to start read from beginning and from half of FIFO size (ro read W/NW sensor data)
      sens_gap = (bytes_mul_andr_l[j] >= 0.499) ? DST_ACCELEROMETER : (DST_ACCELEROMETER | di_wake_sensor_start(di));
      // try to partially read different FIFO sizes before abort_transfer is called
      if (TEST_8_3_DETAILED == 1)
      {
         for (i = 0; i < 60; i++)
         {
            t_8_3_main_loop(sens_gap, bytes_mul_andr_l[j], i);
         }
      }
      else
      {
         u32 test[] = {0, 1, 25, 50, 51};
         for (i = 0; i < sizeof(test) / sizeof(u32); i++)
         {
            t_8_3_main_loop(sens_gap, bytes_mul_andr_l[j], test[i]);
         }
      }
   }

   return g_current_test_retval;
}
TEST_END


/**
 * PRIORITY 2
 * \brief Host Interface Control Register Update Transfer Count
 * bit works properly
 * set up accel; alternately read Bytes Remaining register and
 * write the Update Transfer Count bit, at a rate such that a
 * predicable increase in Bytes Remaining is seen (e.g., 100 Hz
 * sample rate; cycle every 100ms; should see ~10 more samples
 * each time); make sure it does increase and never decreases;
 * after the FIFO is full, the Bytes Remaining should remain at
 * the maximum
 */
TEST_START(8_4)
{
   FIFO_CONTROL_PARAM fifo_control_param;
   SENSOR_INFORMATION sensor_info;
   u16 count = 0;
   u16 prev_count = 0;
   u32 limit_time_ms;
   u16 limit;
   u32 i;
   bool fifo_full = FALSE;

   // set up accel and start gathering data
   set_rates(config.accel_fast_rate, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   TEST_ASSERT(di_save_parameter(di, PP_SYSTEM, SYSP_FIFO_CONTROL, (u8 *)&fifo_control_param, sizeof(fifo_control_param)));

   info_log("fifo configuration: watermark: %d size: %d\n",
            fifo_control_param.watermark, fifo_control_param.fifo_size);

   TEST_ASSERT(di_query_sensor_info(di, DST_ACCELEROMETER, &sensor_info));
   TEST_ASSERT((fifo_control_param.fifo_size - (sensor_info.event_size * sensor_info.fifo_max)) <= sensor_info.event_size);
   TEST_ASSERT(fifo_control_param.fifo_size > 50);
   limit = sensor_info.fifo_max / 50;
   limit_time_ms = 1000 * limit / config.accel_fast_rate;

   info_log("limit: %d limit_ms:%d\n", limit, limit_time_ms);

   for (i = 0; i < TEST_8_4_RUN_TIME_1 / limit_time_ms; i++)         // read for a lot longer than it should take to fill it
   {
      time_delay_ms(limit_time_ms);
      // update transfer count and check the results
      TEST_ASSERT(di_update_transfer_count(di, &count));
      info_log("%d: count: %d d-count:%d fifo_size: %d max-sensor-size:%d\n", i, count, ((int)count - (int)prev_count), fifo_control_param.fifo_size, DI_MAX_SENSOR_SIZE);
      if (count > (fifo_control_param.fifo_size - DI_MAX_SENSOR_SIZE)) // detect fullness
         fifo_full = TRUE;
      if (!fifo_full)
      {
         TEST_ASSERTF(((count + DISCARD_COUNT) >= prev_count), "count: %d prev:%d", count, prev_count); // it should always grow until full
      }
      else
      {
         TEST_ASSERT(count > (fifo_control_param.fifo_size - DI_MAX_SENSOR_SIZE - DISCARD_COUNT)); // once full it can bounce up and down by DISCARD_COUNT
      }
      prev_count = count;
   }

   return TEST_PASSED;
}
TEST_END



#if defined(USE_JOSHS_TESTS) // use Josh's version

/**
 * PRIORITY 1
 * \brief Host FIFO Control
 * set up accel; repeat for 0%, 25%, 50%, 75%, and 100%
 * watermark values: wait for interrupt, read Bytes
 * Remaining, confirm proper value, empty FIFO
 */

/**
 * \brief poll for irq.
 * \return int - number of actual elapsed irqs, or 0 if timeout occurred
*/
int irq_wait(int timeout_ms)
{
   int irq = di->interrupt;

   timeout_ms += time_ms();

   /* poll directly for an IRQ */
   while ((irq == di->interrupt) && (time_ms() < timeout_ms))
      di_irq_check(di);

   return (di->interrupt - irq);
}


/**
 * \brief configure rate and latency, wait for it to change,
 *        return actual values
 * \param sensor - sensor to configure
 * \param rate - rate to set
 * \param actual_rate - actual rate set
 * \param latency - latency to set
 * \param actual_latency - actual latency set
 * \return bool - TRUE if successful
 */
bool configure_sensor_rate(DI_SENSOR_TYPE_T sensor, u16 rate, u16 *actual_rate, u16 latency, u16 *actual_latency)
{
   SENSOR_CONFIG config;
   SENSOR_INFORMATION info;
   int i;
   int wait_ms = 100;
   int max_wait_ms = 5000;

   BOOL_ASSERT(di_query_sensor_info(di, sensor, &info));
   BOOL_ASSERT(di_query_sensor_config(di, sensor, &config));
   config.sample_rate = rate;
   config.max_report_latency = latency;

   if (rate > info.max_rate)
      rate = info.max_rate;                                          // cannot expect it to go higher than it is able

   BOOL_ASSERT(di_configure_sensor(di, sensor, &config));

   if (!actual_rate || !actual_latency)
      return TRUE;

   *actual_rate = *actual_latency = 0;

   for (i = 0; i < max_wait_ms; i += wait_ms)
   {
      time_delay_ms(wait_ms);

      if (!di_query_sensor_config(di, sensor, &config))
         continue;

      if ((config.sample_rate < rate) || (config.max_report_latency < latency))
         continue;

      *actual_rate = config.sample_rate;
      *actual_latency = config.max_report_latency;

      return TRUE;
   }
   info_log("configure_sensor_rate failed: sensor %u, requested rate %u, actual %u; requested latency %u, actual %u\n",
            sensor, rate, config.sample_rate, latency, config.max_report_latency);
   return FALSE;
}


/**
 * \brief configure interrupts
 * \param nonwakeup_int_enable - true to enable int
 * \param wakeup_int_enable - true to enable int
 * \param nonwakeup_fifo_watermark - watermark value
 * \param wakeup_fifo_watermark - watermark value
 * \return bool - TRUE if succeeds
 */
bool configure_interrupts(bool nonwakeup_int_enable, bool wakeup_int_enable, u16 nonwakeup_fifo_watermark, u16 wakeup_fifo_watermark)
{
#if !defined(DI_SLIM)
   if (di->android_l)
   {
      return di_configure_interrupts_ex(di, nonwakeup_int_enable, wakeup_int_enable, nonwakeup_fifo_watermark, wakeup_fifo_watermark);
   }
#endif

   return di_configure_interrupts(di, wakeup_int_enable, wakeup_fifo_watermark);
}


/**
 * \brief
 * \param sensor -
 * \param delay -
 * \param nonwake_int_enabled -
 * \param wake_int_enabled -
 * \param nonwake_fifo_size -
 * \param wake_fifo_size -
 * \return bool -
 */
bool test_8_5_has_irq(DI_SENSOR_TYPE_T sensor, int delay, bool nonwake_int_enabled, bool wake_int_enabled, int nonwake_fifo_size, int wake_fifo_size)
{
   int dirq = 0;
   int t;
   RegIntStatus is;
   const char *sensor_name = di_query_sensor_name(sensor);

   info_log("\nSENSOR %s: %s %s wake_wm:%d nonwake_wm:%d\n",
            sensor_name,
            ((wake_int_enabled) ? "wake_irq_en" : "wake_irq_dis"),
            ((nonwake_int_enabled) ? "nonwake_irq_en" : "nonwake_irq_dis"),
            wake_fifo_size,
            nonwake_fifo_size);

   if (!di_configure_interrupts_ex(di, nonwake_int_enabled, wake_int_enabled, nonwake_fifo_size, wake_fifo_size))
      return FALSE;

   time_delay_ms(1000);
   t = time_ms();

   info_log("waiting %d ms\n", delay);
   dirq = irq_wait(delay);

   TEST_CHECK(di_reg_read(di, SR_INT_STATUS, &is.reg, 1));
   info_log("IRQ status: %s %s %s %s %s %s %s\n",
            ((is.bits.HostInterrupt) ? "HostInterrupt" : ""),
            ((is.bits.WakeupWatermark) ? "WakeupWatermark" : ""),
            ((is.bits.WakeupLatency) ? "WakeupLatency" : ""),
            ((is.bits.WakeupImmediate) ? "WakeupImmediate" : ""),
            ((is.bits.NonWakeupWatermark) ? "NonWakeupWatermark" : ""),
            ((is.bits.NonWakeupLatency) ? "NonWakeupLatency" : ""),
            ((is.bits.NonWakeupImmediate) ? "NonWakeupImmediate" : ""));

   if (dirq > 0)
   {
      info_log("received %d interrupts\n", dirq);
      for (t = 0; t < DME_NUM_META_EVENTS; t++)
         di->meta_events[t] = di->meta_events_wakeup[t] = 0;
      for (t = 0; t < DST_NUM_SENSOR_TYPES; t++)
         di->sensor_info[t].samples_received = 0;
      test_read_out_pending_data(1000, FALSE);
      printCommunicationInfo(di);
      return TRUE;
   }

   info_log("no irqs received\n");
   return FALSE;
}


/**
 * \brief test 8.5.0
 */
TEST_START(8_5_0)
{
   DI_SENSOR_TYPE_T  sensors[4] = {
      DST_ACCELEROMETER,
      DST_WAKEUP_GYROSCOPE,
      DST_GYROSCOPE,
      DST_WAKEUP_ACCELEROMETER
   };
   u16 rate = 100;
   int expected_period_ms = 0;
   int test_delay = 2000;
   u16 sensor_rate = 0, sensor_latency = 0;
   int i;
   int int_on = 1;
   int int_off = 0;
   int wm_on = 1;
   int wm_off = 0;
   int num_sensors = ARRAY_SIZE(sensors);
   SENSOR_INFORMATION info;

   set_rates(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

   if (di->hi_id == HIID_KITKAT)
   {
      if (!di_has_sensor(di, DST_GYROSCOPE))
      {
         if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
         {
            if (di_has_sensor(di, DST_GRAVITY))
            {
               sensors[1] = DST_GRAVITY;
            }
            else if (di_has_sensor(di, DST_LINEAR_ACCELERATION))
            {
               sensors[1] = DST_LINEAR_ACCELERATION;
            }
            else
            {
               TEST_ASSERTF(FALSE, "Can't find enough good sensors to test.\n");
            }
            sensors[2] = DST_GEOMAGNETIC_FIELD;
         }
         else
         {
            num_sensors = 2;
            if (di_has_sensor(di, DST_GRAVITY))
            {
               sensors[1] = DST_GRAVITY;
            }
            else if (di_has_sensor(di, DST_LINEAR_ACCELERATION))
            {
               sensors[1] = DST_LINEAR_ACCELERATION;
            }
            else
            {
               TEST_ASSERTF(FALSE, "Can't find enough good sensors to test.\n");
            }
         }
      }
   }
   else
   {
      if (!di_has_sensor(di, DST_GYROSCOPE))
      {
         if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
         {
            sensors[1] = DST_WAKEUP_GEOMAGNETIC_FIELD;
            sensors[2] = DST_GEOMAGNETIC_FIELD;
         }
         else
         {
            num_sensors = 2;
            sensors[1] = DST_WAKEUP_ACCELEROMETER;
         }
      }
   }

   for (i = 0; i < num_sensors; i++)
   {
      DI_SENSOR_TYPE_T  sensor  = sensors[i];

      info_log("\n%u. Configuring %s\n", i + 1, di_query_sensor_name(sensor));
      TEST_ASSERT(di_query_sensor_info(di, sensor, &info));
      TEST_ASSERT(configure_sensor_rate(sensor, rate, &sensor_rate, 65535, &sensor_latency));

      time_delay_ms(2000);

      expected_period_ms = 1000 / sensor_rate;
      wm_on = (info.event_size + 3) * (test_delay / expected_period_ms);

      /*                                               NWI      WI         NWF      WF */
      if ((di->hi_id != HIID_KITKAT) && (sensor & di_wake_sensor_start(di)))
      {
         /* all should pass, wake sensor, with wake int enabled */
         TEST_CHECK(test_8_5_has_irq(sensor, test_delay,  int_off, int_on,    wm_off,  wm_on));
         TEST_CHECK(test_8_5_has_irq(sensor, test_delay,  int_off, int_on,    wm_on,   wm_on));
         TEST_CHECK(test_8_5_has_irq(sensor, test_delay,  int_on,  int_on,    wm_off,  wm_on));
         TEST_CHECK(test_8_5_has_irq(sensor, test_delay,  int_on,  int_on,    wm_on,   wm_on));

         /* all should fail, wake sensor, with watermark off (due to high latency) */
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_off,   int_on,  wm_off,  wm_off));
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_off,   int_on,  wm_on,   wm_off));
         /* all should fail, wake sensor, with nonwake int enabled */
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_on,    int_off, wm_on,   wm_off));
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_on,    int_off, wm_off,  wm_on));
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_on,    int_off, wm_on,   wm_on));
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_on,    int_off, wm_off,  wm_off));
      }
      else
      {
         /* all should pass, nonwake sensor, with nonwake int enabled */
         TEST_CHECK(test_8_5_has_irq(sensor, test_delay,  int_on,    int_off, wm_on,   wm_off));
         TEST_CHECK(test_8_5_has_irq(sensor, test_delay,  int_on,    int_off, wm_on,   wm_on));
         TEST_CHECK(test_8_5_has_irq(sensor, test_delay,  int_on,    int_on,  wm_on,   wm_off));
         TEST_CHECK(test_8_5_has_irq(sensor, test_delay,  int_on,    int_on,  wm_on,   wm_on));

         /* all should fail, nonwake sensor, with watermark off (due to high latency) */
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_on,  int_off,   wm_off,  wm_off));
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_on,  int_off,   wm_off,  wm_on));
         /* all should fail, nonwake sensor, with wake int enabled */
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_off, int_on,    wm_on,   wm_off));
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_off, int_on,    wm_off,  wm_on));
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_off, int_on,    wm_on,   wm_on));
         TEST_CHECK(!test_8_5_has_irq(sensor, test_delay, int_off, int_on,    wm_off,  wm_off));
      }

      TEST_ASSERT(configure_sensor_rate(sensor, 0, 0, 0, 0));
      fifo_discard();
   }

}
TEST_END


/**
 * \brief set up accel Non Wake Up sensor; Don't forget to set
 * sensor's latency to long time; set up gyro W sensor; Don't
 * forget to set sensor's latency to long time; set page 1 -
 * system:FIFO Control:FIFO NW Watermark to 0; set page 1 -
 * system:FIFO Control:FIFO W Watermark to 0; run for enough
 * time to fill both FIFOs and check that interrupt is not
 * generated, FLUSH both FIFOs and check it was full
 */
TEST_START(8_5_1)
{
   SENSOR_INFORMATION   info;
   SENSOR_STATUS        status;
   RegIntStatus         irq_status = {0};
   int irq_start;
   int fifo_max = 0;
   int run_time = 0;
   int rate = 200;
   int other_sensor_rate = 0;
   int other_sensor_latency = 0;
   DI_SENSOR_TYPE_T  accel = DST_ACCELEROMETER;
   DI_SENSOR_TYPE_T  other_sensor  = DST_NOP;
   DI_META_EVENT_T evt;
   const char        *accel_name = "", *other_sensor_name = "";

   set_rates(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

#if !defined(DI_SLIM)
   if (di->android_l)
   {
      if (di_has_sensor(di, DST_WAKEUP_GYROSCOPE))
      {
         other_sensor = DST_WAKEUP_GYROSCOPE;
      }
      else if (di_has_sensor(di, DST_WAKEUP_GEOMAGNETIC_FIELD))
      {
         other_sensor = DST_WAKEUP_GEOMAGNETIC_FIELD;
      }
      else if (di_has_sensor(di, DST_WAKEUP_ACCELEROMETER))
      {
         other_sensor = DST_WAKEUP_ACCELEROMETER;
      }
   }
#endif

   // disable all possible meta events, and remove everything from the FIFO
   time_delay_ms(1000);
   for (evt = DME_FLUSH_COMPLETE; evt < DME_NUM_META_EVENTS; evt++)
   {
      if (di->android_l)
      {
         TAR(di_enable_meta_event_ex(di, evt, FALSE, FALSE, FALSE));
         TAR(di_enable_meta_event_ex(di, evt, FALSE, FALSE, TRUE));
      }
      else
      {
         TAR(di_enable_meta_event(di, evt, FALSE, FALSE));
      }
   }
   fifo_discard();

   accel_name = di_query_sensor_name(accel);
   TEST_ASSERT(configure_sensor_rate(accel, rate, &accel_rate, 65535, &accel_latency));
   info_log("%s: rate (actual/requested)=%d/%dHz latency=%dms\n", accel_name, accel_rate, config.accel_fast_rate, accel_latency);

   if (other_sensor != DST_NOP)
   {
      other_sensor_name  = di_query_sensor_name(other_sensor);
      TEST_ASSERT(configure_sensor_rate(other_sensor, rate, &other_sensor_rate, 65535, &other_sensor_latency));
      info_log("%s : rate (actual/requested)=%d/%dHz latency=%dms\n", other_sensor_name, other_sensor_rate, config.gyro_fast_rate, other_sensor_latency);
   }

   // choose the slowest rate for run-time calculation
   rate = accel_rate;
   if (rate > other_sensor_rate)
      rate = other_sensor_rate;

   info_log("configuring interrupts enabled, watermark 0\n");
   configure_interrupts(TRUE, TRUE, 0, 0);

   // choose the largest fifo for run-time calculation
   TEST_ASSERT(di_query_sensor_info(di, accel, &info));
   info_log("%s fifo_max: %d samples\n", accel_name, info.fifo_max);
   fifo_max = info.fifo_max;

   TEST_ASSERT(di_query_sensor_info(di, other_sensor, &info));
   info_log("%s fifo_max: %d samples\n", other_sensor_name, info.fifo_max);
   if (fifo_max < info.fifo_max)
      fifo_max = info.fifo_max;

   info_log("calculating runtime using: fifo_max: %d samples rate: %d Hz\n", fifo_max, rate);
   // ensure run time exceeds fifo size
   run_time = (1000 * fifo_max /*samples*/) /  rate /*samples/sec*/;

   // ensure a known-good state beforehand
   TEST_ASSERT(di_query_sensor_status(di));
   TEST_ASSERT(di_read_sensor_status(di, accel, &status));
   TEST_ASSERT(status.data_lost == 0);                               /* should have no lost data */
   TEST_ASSERT(di_read_sensor_status(di, other_sensor, &status));
   TEST_ASSERT(status.data_lost == 0);                               /* should have no lost data */
   fifo_discard();

   irq_start = di->interrupt;
   info_log("reading data for %d ms...\n", run_time);
   di->total_bytes_transferred = 0;
   time_delay_ms(run_time);

   info_log("ensuring no interrupts asserted\n");
   TEST_ASSERT(di_reg_read(di, SR_INT_STATUS, &irq_status.reg, 1));
   TEST_ASSERTF(irq_status.reg == 0, "irq status %02X, expected 0", irq_status.reg);

   TEST_ASSERT(di_query_sensor_status(di));

   info_log("ensuring %s status: data_available==1 and data_lost==1\n", accel_name);
   TEST_ASSERT(di_read_sensor_status(di, accel, &status));
   TEST_ASSERT(status.data_available == 1   &&                       /* should have data available */
               status.i2c_nack == 0         &&
               status.device_id_error == 0  &&
               status.transient_error == 0  &&
               status.data_lost == 1);                               /* should have lost data */

   info_log("ensuring %s status: data_available==1 and data_lost==1\n", other_sensor_name);
   TEST_ASSERT(di_read_sensor_status(di, other_sensor, &status));
   TEST_ASSERT(status.data_available == 1   &&                       /* should have data available */
               status.i2c_nack == 0         &&
               status.device_id_error == 0  &&
               status.transient_error == 0  &&
               status.data_lost == 1);                               /* should have lost data */

   fifo_discard();
}
TEST_END


/**
 * \brief set FIFO W sensors to fill the FIFO faster (not only
 * absolutely but also in percent of FIFO W) set FIFO NW
 * Watermark consequently to [25%,50%;75%;100%;100%+1B]; wait
 * for interrupt, read reg 0X36: INT STATUS and check bits are
 * as expected; read FIFO; parse data and ensure it is
 * completely valid (no invalid Sensor ID bytes); ensure that
 * accel data length fits to current watermark;
 * - do above test paragraph analogically for W FIFO watermark with same percentage
 * range
 */
TEST_START(8_5_2)
{
   DI_SENSOR_TYPE_T  accel = DST_ACCELEROMETER, other_sensor = DST_NOP;
   SENSOR_INFORMATION accel_info, other_sensor_info;
   DI_META_EVENT_T evt;
   int rate_div = 2;
   int max_rate = 200;
   int other_sensor_rate = 0;
   int other_sensor_latency = 0;
   u32 accel_max_fifo_size;
   u32 other_sensor_max_fifo_size;
   u16 percent;
   int i;
   const char *accel_name = "", *other_sensor_name =  "";

   set_rates(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

   // disable all possible meta events, and remove everything from the FIFO
   time_delay_ms(1000);
   for (evt = DME_FLUSH_COMPLETE; evt < DME_NUM_META_EVENTS; evt++)
   {
      if (di->android_l)
      {
         TAR(di_enable_meta_event_ex(di, evt, FALSE, FALSE, FALSE));
         TAR(di_enable_meta_event_ex(di, evt, FALSE, FALSE, TRUE));
      }
      else
      {
         TAR(di_enable_meta_event(di, evt, FALSE, FALSE));
      }
   }
   di_control_logging(di, TRUE, FALSE, TRUE, FALSE);

#if !defined(DI_SLIM)
   if (di->android_l)
   {
      if (di_has_sensor(di, DST_WAKEUP_GYROSCOPE))
      {
         other_sensor = DST_WAKEUP_GYROSCOPE;
      }
      else if (di_has_sensor(di, DST_WAKEUP_GEOMAGNETIC_FIELD))
      {
         other_sensor = DST_WAKEUP_GEOMAGNETIC_FIELD;
      }
      else if (di_has_sensor(di, DST_WAKEUP_ACCELEROMETER))
      {
         other_sensor = DST_WAKEUP_ACCELEROMETER;
      }
   }
#endif

   do
   {
      accel_name = di_query_sensor_name(accel);
      TEST_ASSERT(configure_sensor_rate(accel, max_rate / rate_div, &accel_rate, 65535, &accel_latency));
      info_log("%s: rate (actual/requested)=%d/%dHz latency=%dms\n", accel_name, accel_rate, config.accel_fast_rate, accel_latency);

      if (other_sensor != DST_NOP)
      {
         other_sensor_name  = di_query_sensor_name(other_sensor);
         TEST_ASSERT(configure_sensor_rate(other_sensor, max_rate / rate_div, &other_sensor_rate, 65535, &other_sensor_latency));
         info_log("%s : rate (actual/requested)=%d/%dHz latency=%dms\n", other_sensor_name, other_sensor_rate, config.gyro_fast_rate, other_sensor_latency);
      }

      rate_div--;

      //display_actual_rates(di);
      //display_sensor_status_bytes(di, FALSE);

      TEST_ASSERT(di_query_sensor_info(di, accel, &accel_info));
      if (other_sensor != DST_NOP)
      {
         TEST_ASSERT(di_query_sensor_info(di, other_sensor, &other_sensor_info));
      }

      accel_max_fifo_size = accel_info.fifo_max * accel_info.event_size;
      other_sensor_max_fifo_size = other_sensor_info.fifo_max * other_sensor_info.event_size;

      info_log("accel at %u Hz; other_sensor at %d Hz\n", accel_rate, other_sensor_rate);

      // test a series of watermark levels
      for (percent = 25; percent <= 100; percent += 25)
      {
         u16 accel_limit = 0, other_sensor_limit = 0, limit = 0;
         u16 accel_byte_limit = 0, other_sensor_byte_limit = 0, byte_limit = 0;
         u32 accel_time_ms = 0, other_sensor_time_ms = 0, total_time_ms = 0;
         int delta;
         u32 accel_samples_start = 0, other_sensor_samples_start = 0;
         u16 wake_fifo_size = 0, nonwake_fifo_size = 0;

         if (other_sensor == DST_NOP)
         {
            accel_byte_limit = accel_max_fifo_size * percent / 100;
            accel_limit = accel_byte_limit / (accel_info.event_size + 3); // need to include timestamps
            accel_time_ms = 1000 * accel_limit / accel_rate;
            total_time_ms = accel_time_ms;
            wake_fifo_size = accel_byte_limit;
         }
         else
         {
            /* accel is a function of other_sensor wakeup */
            other_sensor_byte_limit = other_sensor_max_fifo_size * percent / 100;
            other_sensor_limit = other_sensor_byte_limit / (other_sensor_info.event_size + 3);
            other_sensor_time_ms = 1000 * other_sensor_limit / other_sensor_rate;
            wake_fifo_size = other_sensor_byte_limit;

            accel_time_ms = other_sensor_time_ms;
            accel_limit = accel_time_ms * accel_rate / 1000;

            accel_byte_limit = accel_limit * (accel_info.event_size + 3);
            nonwake_fifo_size = accel_byte_limit;

            total_time_ms = other_sensor_time_ms;
         }

         limit = accel_limit + other_sensor_limit;
         byte_limit = accel_byte_limit + other_sensor_byte_limit;

         info_log("@%d%% %s: expect %d/%d samples (%d bytes) in %d ms, %s: expect %d/%d samples (%d bytes) in %dms, TOTAL: expect %d samples (%d bytes) in %dms\n",
                  percent, accel_name, accel_limit, accel_info.fifo_max, accel_byte_limit, accel_time_ms,
                  other_sensor_name,  other_sensor_limit,  other_sensor_info.fifo_max, other_sensor_byte_limit, other_sensor_time_ms,
                  limit, byte_limit, total_time_ms);
         info_log("wake_fifo_size: %d bytes nonwake_fifo_size: %d bytes\n", wake_fifo_size, nonwake_fifo_size);
         configure_interrupts(TRUE, TRUE, nonwake_fifo_size, wake_fifo_size);

         TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_8_5_RUN_TIME, FALSE));
         fifo_discard();

#if !defined(DI_SLIM)
         accel_samples_start = di->sensor_info[accel].samples_received;
         other_sensor_samples_start = di->sensor_info[other_sensor].samples_received;
#endif

         di->total_bytes_transferred = 0;
         for (i = 0; i < 50; i++)
         {
            if (!di->total_bytes_transferred)
            {
               TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_8_5_RUN_TIME, TRUE)); // stop on first complete FIFO transfer
            }
            else
               break;
         }

#if !defined(DI_SLIM)
         info_log("@%u%% fill (received/expected): bytes: %u/%u, accel samples: %d/%u, other_sensor samples: %d/%u\n", percent,
                  di->total_bytes_transferred, byte_limit,
                  di->sensor_info[accel].samples_received - accel_samples_start, accel_limit,
                  di->sensor_info[other_sensor].samples_received - other_sensor_samples_start, other_sensor_limit);
#endif

         if (di->total_bytes_transferred < byte_limit)
            delta = byte_limit - di->total_bytes_transferred;
         else
            delta = di->total_bytes_transferred - byte_limit;

         TEST_ASSERT(delta < (byte_limit * TEST_8_5_ACCURACY_THRESHOLD / 100));

         // read out all data
         TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_8_5_RUN_TIME, FALSE));
      }

   }
   while (rate_div);

}
TEST_END


/**
 * \brief set up accel Non Wake Up sensor;
 *        set up gyro Wake Up sensor;
 *        set page 1 system:FIFO Control:FIFO NW Watermark to 85%
 *        set page 1 system:FIFO Control:FIFO W Watermark to 85%
 *        wait for interrupt, read reg 0X36: INT STATUS and check bits are as expected; read
 *        Bytes Remaining, confirm proper value, read FIFO; parse data and ensure it is
 *        completely valid (no invalid Sensor ID bytes);
 *        wait for short time and ensure there is no 2 nd interrupt generated (as both FIFOs were
 *        read during first interrupt)
 *
 */
bool test_8_5_3_callback(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *data, void *user_param)
{
#if 0
   if( (sensor > DST_NUM_SENSOR_TYPES) || (sensor == DST_ACCELEROMETER) || (sensor == DST_WAKEUP_GYROSCOPE) )
   return TRUE;

   info_log("%s\n", di_query_sensor_name(sensor));
#endif
   return TRUE;
}

/**
 * \brief
 */
TEST_START(8_5_3)
{
   SENSOR_INFORMATION   info;
   int rate = 200;
   int other_sensor_rate = 0;
   int other_sensor_latency = 0;
   int dirq = 0;
   DI_SENSOR_TYPE_T  accel = DST_ACCELEROMETER;
   DI_SENSOR_TYPE_T  other_sensor  = DST_NOP;
   const char        *accel_name = "", *other_sensor_name = "";
   int nonwakeup_watermark = 0, wakeup_watermark = 0;
   int nonwakeup_max = 0, wakeup_max = 0;
   int accel_bytes = 0, other_sensor_bytes = 0;
// int loops=10;
   int i;
   int expected_bytes = 0;
   int expected_time_ms = 0;
   float watermark_percent = 0.65;
   float tolerance = 0.20;
   int time_start;
   int dt = 0;

   set_rates(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

   TEST_ASSERT(di_register(di, test_8_5_3_callback, (void *)di));

#if !defined(DI_SLIM)
   /* for this test, other_sensor only enabled on android 5. otherwise test operates just on accel (which is a 'wakeup' sensor in Android 4) */
   if (di->android_l)
   {
      if (di_has_sensor(di, DST_WAKEUP_GYROSCOPE))
      {
         other_sensor = DST_WAKEUP_GYROSCOPE;
      }
      else if (di_has_sensor(di, DST_WAKEUP_GEOMAGNETIC_FIELD))
      {
         other_sensor = DST_WAKEUP_GEOMAGNETIC_FIELD;
      }
      else if (di_has_sensor(di, DST_WAKEUP_ACCELEROMETER))
      {
         other_sensor = DST_WAKEUP_ACCELEROMETER;
      }
   }
#endif

   accel_name = di_query_sensor_name(accel);
   TEST_ASSERT(configure_sensor_rate(accel, rate, &accel_rate, 65535, &accel_latency));
   info_log("%s: rate (actual/requested)=%d/%dHz latency=%dms\n", accel_name, accel_rate, rate, accel_latency);

   if (other_sensor != DST_NOP)
   {
      other_sensor_name  = di_query_sensor_name(other_sensor);
      TEST_ASSERT(configure_sensor_rate(other_sensor, rate, &other_sensor_rate, 65535, &other_sensor_latency));
      info_log("%s : rate (actual/requested)=%d/%dHz latency=%dms\n", other_sensor_name, other_sensor_rate, rate, other_sensor_latency);
   }

   TEST_ASSERT(di_query_sensor_info(di, accel, &info));
   accel_bytes = info.event_size + 3;                                // PETE: need to count the timestamp!
   wakeup_max = info.fifo_max * accel_bytes;
   wakeup_watermark = wakeup_max * watermark_percent;
   expected_bytes = wakeup_watermark;
   expected_time_ms = (1000 * wakeup_watermark) / accel_bytes / accel_rate;

   if (other_sensor != DST_NOP)
   {
      TEST_ASSERT(di_query_sensor_info(di, other_sensor, &info));
      nonwakeup_watermark = wakeup_watermark;
      nonwakeup_max       = wakeup_max;

      other_sensor_bytes = info.event_size + 3;
      wakeup_max = info.fifo_max * other_sensor_bytes;
      wakeup_watermark = wakeup_max * watermark_percent;
      expected_time_ms = (1000 * wakeup_watermark) / other_sensor_bytes / other_sensor_rate;
      expected_bytes += wakeup_watermark;
   }

   info_log("fifo watermark: nonwakeup:%d/%d  wakeup:%d/%d\n",
            nonwakeup_watermark, nonwakeup_max, wakeup_watermark, wakeup_max);

   info_log("expect bytes %d in %d ms\n", expected_bytes, expected_time_ms);

   // TODO: if nonwakeup IRQ is disabled, no interrupts are received, test fails
   configure_interrupts(FALSE, TRUE, nonwakeup_watermark, wakeup_watermark);

   test_read_out_pending_data((u32)(expected_time_ms * 1.25), TRUE);

   for (i = 0; i < 3; i++)
   {
      info_log("starting wait\n");
      time_start = time_ms();

      dirq = irq_wait((int)(expected_time_ms));

      TEST_ASSERTF((dirq > 0), "no irqs received within %dms, expected >0\n", time_ms() - time_start);

      dt = time_ms() - time_start;
      info_log("received %d irqs\n", dirq);
      TEST_CHECKF((dt < (expected_time_ms * (1.0 + tolerance))) && (dt > (expected_time_ms * (1.0 - tolerance))), "irqs received in %dms, expected %dms\n", dt, expected_time_ms);

      {
         RegIntStatus is;
         TEST_CHECK(di_reg_read(di, SR_INT_STATUS, &is.reg, 1));
         info_log("IRQ status: %s %s %s %s %s %s %s\n",
                  ((is.bits.HostInterrupt) ? "HostInterrupt" : ""),
                  ((is.bits.WakeupWatermark) ? "WakeupWatermark" : ""),
                  ((is.bits.WakeupLatency) ? "WakeupLatency" : ""),
                  ((is.bits.WakeupImmediate) ? "WakeupImmediate" : ""),
                  ((is.bits.NonWakeupWatermark) ? "NonWakeupWatermark" : ""),
                  ((is.bits.NonWakeupLatency) ? "NonWakeupLatency" : ""),
                  ((is.bits.NonWakeupImmediate) ? "NonWakeupImmediate" : ""));
      }

      test_read_out_pending_data(TEST_8_5_RUN_TIME, TRUE);
   }

   info_log("ensuring no followup interrupt for %d ms\n", expected_time_ms / 4);
   dirq = irq_wait(expected_time_ms / 4);

   TEST_ASSERTF(dirq == 0, "received %d followup interrupts, expected 0", dirq);
}
TEST_END

#else // Vit's tests

//------------------------------------------------------------------------------------------------
// test 8.5 (8_5)

// set minimum time to fill FIFO. Shorter time allow faster test. On the other hand
// some host configuration would take too long communication overhead and
// in such a case test likely fail because it expect that all is done on time
// it is recommended to set it 800 ms or try even 1000 if you receive errors where more data
// are received than expected
#define REQUIRED_MINIMUM_TEST_TIME_ms 700


/**
 * \brief test all combination of water-marks (2^2) and (*) interrupts enable (2^2)
 * \param sc - sensor configuration
 * \param p - test configuration
 */
void test_all_comb_of_wm_and_intr(fifo_test_sensor_config *sc, fifo_test_config *p)
{
   int intr;
   int wm;

   float fifo_ratio;

   // increase FIFO fill percentage or decrease sensor rate in order to achieve test time
   // higher than REQUIRED_MINIMUM_TEST_TIME_ms in order to have enough time for all
   // test overhead (otherwise 718x may be too fast and generate expected interrupt twice
   // which would lead to [false] error reported by test)
   fifo_ratio = get_size_ratio_for_min_time(*sc, REQUIRED_MINIMUM_TEST_TIME_ms);
   if (fifo_ratio > (float)0.8)
   {
      fifo_ratio = (float)0.8;
      dec_rate_till_min_time_met(fifo_ratio, sc, REQUIRED_MINIMUM_TEST_TIME_ms);
   }
   for (intr = 0; intr < (sc->sz * 2); intr++)
   {
      //info_log("test_all_comb_of_wm_and_intr: intr = %d\n", intr);
      for (wm = 0; wm < (sc->sz * 2); wm++)
      {
         //info_log("test_all_comb_of_wm_and_intr: wm = %d\n", wm);
         p->intrpt[0] = (intr & 1) == 1;
         p->wm_perc[0] = (float)((wm & 1) * fifo_ratio);
         if (di->hi_id != HIID_KITKAT)
         {
            p->intrpt[1] = (intr & 2) == 2;
            p->wm_perc[1] = (float)(((wm >> 1) & 1) * fifo_ratio);
         }
         else
         {
            p->intrpt[1] = 0;
            p->wm_perc[1] = 0;
         }
         chk_water_mark(p, sc);
      }
   }
}

/**
 * \brief test 8.5.0
 */
TEST_START(8_5_0)
{
   fifo_test_sensor_config sc;
   u16 max_rt;
   fifo_test_config p;
   int i;

   fifo_test_init(first_loop, &sc, &p, &max_rt);

   p.force_wait_max_time_ms = FALSE;
   for (i = 1; i < sc.sz * 2; i++)
   {
      //info_log("8.5.0 i = %d\n", i);
      sc.rt[0] = (i & 1) * max_rt;
      if (di->hi_id != HIID_KITKAT)
         sc.rt[1] = ((i >> 1) & 1) * max_rt;
      else
         sc.rt[1] = 0;
      test_all_comb_of_wm_and_intr(&sc, &p);
   }
}
TEST_END


/**
 * \brief test 8.5.1 set up accel Non Wake Up sensor; Don't forget to set sensor's latency to long time;
 *                   set up gyro W sensor; Don't forget to set sensor's latency to long time;
 *                   set page 1  system:FIFO Control:FIFO NW Watermark to 0;
 *                   set page 1  system:FIFO Control:FIFO W Watermark to 0;
 *                   run for enough time to fill both FIFOs and check that interrupt is not generated, FLUSH
 *                   both FIFOs and check it was full
 */
TEST_START(8_5_1)
{
   fifo_test_sensor_config sc;
   u16 max_rt;
   fifo_test_config p;

   fifo_test_init(first_loop, &sc, &p, &max_rt);

   // time is counter from watermark and sensor rate
   // force time to ensure fifo overflows, and no interrupt is generated
   // when watermark is set = 0
   p.force_wait_max_time_ms = TRUE;
   sc.rt[0] = max_rt;
   sc.rt[1] = max_rt;
   p.intrpt[0] = 1;                                                  // NW/K
   p.intrpt[1] = 1;                                                  // W
   p.wm_perc[0] = 0;
   p.wm_perc[1] = 0;
   chk_water_mark(&p, &sc);
}
TEST_END


/**
 * \brief set FIFO W sensors to fill the FIFO faster (not only
 *        absolutely but also in percent of FIFO W); set FIFO NW
 *        Watermark consequently to [25%,50%;75%;100%;100%+1B];
 *        (do not set W watermark) wait for interrupt, read reg
 *        0X36: INT STATUS and check bits are as expected -
 *        faster did not generate interrupt, but slower did;
 *        read FIFO; parse data and ensure it is completely
 *        valid (no invalid Sensor ID bytes); ensure that accel
 *        data length fits to current watermark;
 *        - do above test paragraph analogically for W FIFO watermark with same percentage
 *        range
 *
 *        for android K only check that it works for watermarks [25,50,75,100]%.
 */
TEST_START(8_5_2)
{
   fifo_test_sensor_config sc;
   u16 max_rt;
   fifo_test_config p;
   int percent;
   int i;

   fifo_test_init(first_loop, &sc, &p, &max_rt);

   if (di->hi_id == HIID_KITKAT)
   {
      p.intrpt[0] = 1;
      sc.rt[1] = 0;
      sc.s[1] = 0;
      sc.sz = 1;

      for (percent = 25; percent <= 100; percent += 25)
      {
         sc.rt[0] = max_rt;
         p.wm_perc[0] = (float)(percent / 100.0);
         dec_rate_till_min_time_met(p.wm_perc[0], &sc, REQUIRED_MINIMUM_TEST_TIME_ms);
         chk_water_mark(&p, &sc);
      }

      p.wm_perc[0] = (float)(0.99);
      chk_water_mark(&p, &sc);
      return g_current_test_retval;
   }

   for (i = 0; i < 2; i++)
   {                                                                 // in 1st round NW is faster than W  and the faster NW has interrupt disabled
                                                                     // in 2nd round W  is faster than NW and the faster  W has interrupt disabled
      int fast, slow;                                                // 0= NW, 1=W
      fast = i;
      slow = (i + 1) % 2;
      for (percent = 25; percent <= 100; percent += 25)
      {
         sc.rt[fast] = max_rt;
         sc.rt[slow] = max_rt;
         // turn off faster sensor interrupt and check that it is not generated
         p.intrpt[fast] = 0;
         p.intrpt[slow] = 1;
         p.wm_perc[slow] = (float)(percent / 100.0);
         p.wm_perc[fast] = p.wm_perc[slow] / 2;
         dec_rate_till_min_time_met(p.wm_perc[fast], &sc, REQUIRED_MINIMUM_TEST_TIME_ms);

         info_log("## 8.5.2 A: %u, %u\n", i, percent);
         chk_water_mark(&p, &sc);

         // turn off faster sensor watermark and check that it is not generated
         p.intrpt[fast] = 1;
         p.intrpt[slow] = 1;
         p.wm_perc[slow] = (float)(percent / 100.0);
         p.wm_perc[fast] = 0;
         info_log("## 8.5.2 B: %u, %u\n", i, percent);
         chk_water_mark(&p, &sc);
      }
   }
}
TEST_END


/**
 * \brief set up accel Non Wake Up sensor;
 *        set up gyro Wake Up sensor;
 *        set page 1  system:FIFO Control:FIFO NW Watermark to 65%
 *        set page 1  system:FIFO Control:FIFO W Watermark to 65%
 *        wait for interrupt, read reg 0X36: INT STATUS and check bits are as expected; read
 *        Bytes Remaining, confirm proper value, read FIFO; parse data and ensure it is
 *        completely valid (no invalid Sensor ID bytes);
 *        wait for short time and ensure there is no 2 nd interrupt generated (as both FIFOs were
 *        read during first interrupt)
 *        NOTE: if % is set too high, we overflow and the counts are not accurate.
 *
 */
TEST_START(8_5_3)
{
   fifo_test_sensor_config sc;
   u16 max_rt;
   fifo_test_config p;

   fifo_test_init(first_loop, &sc, &p, &max_rt);
   TEST_ASSERT(di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, TRUE, FALSE, FALSE));
   if (di->hi_id != HIID_KITKAT)
      TEST_ASSERT(di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, TRUE, FALSE, TRUE));
   di_control_logging(di, FALSE, FALSE, FALSE, FALSE);

   sc.rt[0] = max_rt;
   p.intrpt[0] = 1;
   p.wm_perc[0] = (float)0.65;

   if (di->hi_id != HIID_KITKAT)
   {
      sc.rt[1] = max_rt;
      p.intrpt[1] = 1;
      p.wm_perc[1] = 0.65F;
   }
   else
   {
      sc.rt[1] = 0;
      p.intrpt[1] = 0;
      p.wm_perc[1] = 0.0F;
   }
   chk_water_mark(&p, &sc);
}
TEST_END
#endif

//-----------------------------------------------------------------------------
/**
 * \brief Sensor Configuration Max Report Latency
 * configure base sensors at differing rates; separately for
 * each base sensor, set max report latency to a multiple of the
 * sensor�s sample period, then measure interrupt rate (with
 * proper data retrieval from FIFO at each interrupt) � confirm
 * the interrupt rate is as expected, and the expected number of
 * samples from each sensor are read; set all sensors to 0
 * report latency, and ensure each one generates an interrupt at
 * the expected rate (keep the FIFO empty)
 */

typedef struct test_8_7_sensor_entry
{
   DI_SENSOR_TYPE_T     sensor;                                      // sensor ID
   u16                  set_rate;                                    // rate which we will try to set
   u16                  lat_in_periods;                              // latency in number of periods (derived from actual_rates)
                                                                     // following will be computed automatically
   u16                  actual_rate;                                 // actual rates - after trying to set set_rate
   double               actual_per_ms;                               // actual period in ms
   u16                  lat_in_ms;                                   // latency in miliseconds
   u16                  exp_smpls_min;                               // expected min samples in each interrupt
   u16                  exp_smpls_max;                               // expected max samples in each interrupt
   u16                  exp_smpls_in_run;                            // expected samples in one full test loop
   u32                  total_smpls_rcv;                             // total samples received
   u32                  total_smpls_rcv_at_start;                    // total samples received at start of test
   u32                  last_smpls_rcv;                              // samples received in last FIFO read

   bool                 sample_exist;                                // sample exists (in current data transfer)?
   u32                  first_sample_tm_ms;                          // u718x time of first sample received
   u32                  exp_interrupt_tm_ms;                         // expected time of interrupt from this sensor
} test_8_7_sensor_entry_t;

int g_8_7_sz;                                                        // use sensors size
test_8_7_sensor_entry_t g_8_7_us[3];                                 // use sensors


// compute array g_8_7_us[i].exp_interrupt_tm_ms where is expected interrupt
//   for each sensor based on when sample was received
// NOTE: function t_8_7_clean_irq_tm_expected_for_current_xfer() shall be called before parsing data
bool test_8_7_sample_callback(DI_INSTANCE_T *di2, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *data, void *user_param)
{
   int i;
   int fifo;
   data_callback(di2, sensor, data, user_param);
   fifo = is_wakeup_event(di, sensor) ? 1 : 0;
   for (i = 0; i < g_8_7_sz; i++)
   {
      if ((g_8_7_us[i].sensor == sensor) && (g_8_7_us[i].sample_exist == FALSE))
      {
         g_8_7_us[i].sample_exist = TRUE;
         g_8_7_us[i].first_sample_tm_ms = di2->cur_timestamp[fifo] / 1000;
         g_8_7_us[i].exp_interrupt_tm_ms = g_8_7_us[i].first_sample_tm_ms + g_8_7_us[i].lat_in_ms;
      }
   }
   return TRUE;
}


// clear IRQ times expected for one transfer
void t_8_7_clean_irq_tm_expected_for_current_xfer()
{
   int i;
   for (i = 0; i < g_8_7_sz; i++)
   {
      g_8_7_us[i].sample_exist = FALSE;
      g_8_7_us[i].first_sample_tm_ms = 0;
      g_8_7_us[i].exp_interrupt_tm_ms = U32_MAX;
   }
}


// find minimum IRQ time from each sensor
u32 t_8_7_get_expected_interrupt_time_stamp()
{
   int i;
   u32 min_time = U32_MAX;
   for (i = 0; i < g_8_7_sz; i++)
   {
      if (g_8_7_us[i].sample_exist)
      {
         STORE_MIN(min_time, g_8_7_us[i].exp_interrupt_tm_ms);
      }
   }
   return min_time;
}


// Main checking loop
// It will set sensors rate and latency and check
// - that number of sensor's event meet expectation
// - number of host IRQ meet expectations
// - sensor period is as set (no event is missing)
// - time between host IRQ meet expactatyion
//   - it checks u718x timestamp
//   - and real PC time
void do_test_8_7_sensor_entry()
{
   //double maxi_time_error_perc = 10;  // maximum allowed error in latency time [%] eg 10 means 10% error allowed
// PETE: widen timing allowances -- hardware is not that accurate under all conditions
   u32 max_lat_tm_ms_jitter = 50;                                    // max latency time allowed jitter
   double max_lat_tm_error_mult = 0.25;                              // emax latency time error multiplication g 0.1=10%
   double ok_tm_dif_mul = 0.25;                                      // allowed time difference multiplicator (eg 0.10 means +-10%)
   double ok_tm_dif_u718x_system_mul = 0.25;                         // allowed time difference multiplicator for internal u718x time(eg 0.10 means +-10%)
   u32 tm_beg;                                                       // time begin
   u32 tm_wanted;                                                    // run time wanted
   u32 irq_wanted;                                                   // IRQ wanted
   u32 tm_end;                                                       // time end
   u32 tm_last_xfer;                                                 // time of last transfer (note tm_end may be not multiple of final latency, this time is more precise run time for received data)
   u32 tm_now;                                                       // time now
   double min_lat_in_ms = U16_MAX;                                   // minimum latency in ms
   double min_period_in_ms = U16_MAX;                                // minimum period in ms
   double min_comb_tm_ms;                                            // minimum IRQ time when combining minimum latency and period
                                                                     //double max_lat_in_ms = 0;          // maximum latency in ms
   double max_period_in_ms = 0;                                      // maximum period in ms
   int irq_tm;                                                       // IRQ time
   int irq_tm_prev = 0;                                              // Previous IRQ time
   int irq_tm_dif;                                                   // IRQ time differnece
   u32 u718x_act_host_irq_us;                                        // IRQ u718x time
   u32 u718x_prev_host_irq_us = 0;                                   // previous IRQ senrtal time
   u32 u718x_dif_host_irq_us;                                        // IRQ differential u718x time
   u32 u718x_exp_host_irq_ms;                                        // IRQ u718x time expected
   u32 irq_count = 0;                                                // irq count
   u32 irq_count_exp_min;                                            // irq count expected
   u32 irq_count_exp_max;                                            // irq count expected
   int i;
   double tst_min_lat;                                               // test min latency time [ms]
   double tst_max_lat;                                               // test max latency time [ms]

   int sz = g_8_7_sz;                                                // sensor size
   test_8_7_sensor_entry_t *ua = g_8_7_us;                           // used sensors
   int j;

   HOST_IRQ_TS_PARAM host_irq;

   info_log("===\nTesting:\n");
   for (i = 0; i < sz; i++)
   {
      info_log("sensor %d rate: %d Hz latency: %d periods\n", ua[i].sensor, ua[i].set_rate, ua[i].lat_in_periods);
      set_and_chk_rate(ua[i].sensor, ua[i].set_rate, &(ua[i].actual_rate), TRUE);
      ua[i].actual_per_ms = 1000.0 / (ua[i].actual_rate + 0.5);      // round up (actual rate reported is truncated)
      ua[i].lat_in_ms = (u16)(ua[i].lat_in_periods * ua[i].actual_per_ms);
      set_and_chk_lat(ua[i].sensor, ua[i].lat_in_ms, NULL, TRUE);
      ua[i].total_smpls_rcv = di->sensor_info[ua[i].sensor].samples_received;
      ua[i].total_smpls_rcv_at_start = ua[i].total_smpls_rcv;
      STORE_MIN(min_lat_in_ms, ua[i].lat_in_ms);
      //STORE_MAX(max_lat_in_ms,ua[i].lat_in_ms);
      STORE_MIN(min_period_in_ms, ua[i].actual_per_ms)
      STORE_MAX(max_period_in_ms, ua[i].actual_per_ms);
   }
   // todo min/max latency shall be more precise when latency is counted from last host IRQ
   //  - currently latency is counted for first sample which is dependent on actual data
   if (sz == 1)
   {
      min_comb_tm_ms = MAX(min_lat_in_ms, min_period_in_ms);         // if only one sensor then it can not be faster than sensor sample period
   }
   else
   {
      min_comb_tm_ms = min_lat_in_ms;                                // if more sensor is used and they run at differet freq, then sensor sample period might be hidden
   }
   min_comb_tm_ms *= (1 - max_lat_tm_error_mult);
   tst_min_lat = (min_comb_tm_ms > max_lat_tm_ms_jitter) ? (min_comb_tm_ms - max_lat_tm_ms_jitter) : 1;
   tst_max_lat = (max_period_in_ms + min_lat_in_ms) * (1 + max_lat_tm_error_mult) + max_lat_tm_ms_jitter;

   for (i = 0; i < sz; i++)
   {
      ua[i].exp_smpls_min = (u16)(tst_min_lat / (ua[i].actual_per_ms * (1 + ok_tm_dif_mul)));
      if (ua[i].lat_in_periods == 0)                                 // if immediate then expect at most 1 sample
      {
         ua[i].exp_smpls_max = 1;
      }
      else
      {                                                              // note it seems that latency is count from 1st data - thus +1
         ua[i].exp_smpls_max = (u16)(tst_max_lat / (ua[i].actual_per_ms * (1 - ok_tm_dif_mul))) + 1;
      }
   }
   if (sz == 1)
   {
      if (ua[0].exp_smpls_min == 0)
      {
         ua[0].exp_smpls_min = 1;                                    // if only 1 sensor is enabled then at least 1 sample must be present
      }
   }

   time_delay_ms(50);
   fifo_discard();
   //di_control_logging(di, TRUE, FALSE, FALSE, FALSE);
   //set_logging_level(LL_INSANE);

   irq_wanted = 5;                                                   // test 5 host IRQ
   tm_wanted = (u32)(tst_max_lat * (irq_wanted + 0.8));
   if (tm_wanted > 5000)                                             // if test time would be longer than 4s
   {
      irq_wanted = 4;                                                // test 4 host IRQ
      tm_wanted = (u32)(tst_max_lat * (irq_wanted + 0.8));
   }
   irq_count_exp_min = (u32)(tm_wanted / (tst_max_lat * (1 + ok_tm_dif_mul)));
   irq_count_exp_max = (u32)(tm_wanted / (tst_min_lat * (1 - ok_tm_dif_mul)));

   tm_beg = time_ms();
   tm_end = tm_beg + tm_wanted;

   while (1)
   {
      int irq_cnt = di->interrupt;                                   // last irq counter
      int irq_dif;                                                   // irq difference

      // poll directly for an IRQ
      while (1)
      {
         tm_now = time_ms();
         if ((tm_now > tm_end) ||                                    // time is up
             (irq_count == irq_wanted))                              // all requested IRQ received - it will speed up test
         {
            goto t_8_7_break_outer_loop;
         }

         di_irq_check(di);                                           // check interrupt (interrupt shall increment di->interrupt)
         if (irq_cnt != di->interrupt)                               // interrupt detected
         {
            tm_last_xfer = time_ms();
            break;
         }
      }

      irq_dif = di->interrupt - irq_cnt;
      info_log("irq %u: \n", irq_count);
      TAFR(irq_dif == 1, "expecting exactly one interrupt");

      // compute time difference from last interrupt
      irq_tm = di->host_int_timestamp;
      irq_tm_dif = irq_tm - irq_tm_prev;

      t_8_7_clean_irq_tm_expected_for_current_xfer();

      // poll this *before* we read data from the FIFO -- we already know the interrupt has been asserted, so the timestamp
      // will be accurate now -- but if we read it after reading the data, it may already be updated for the next transfer
      if (di->hi_id == HIID_KITKAT)
      {
         di_save_parameter(di, PP_SYSTEM, SYSP_HOST_IRQ_TIMESTAMP, (u8 *)&host_irq, sizeof(HOST_IRQ_TS_PARAM));
         u718x_act_host_irq_us = (u32)(((u64)host_irq.host_irq_timestamp)  * SENSOR_SCALE_TIME_NUM) / SENSOR_SCALE_TIME_DEN;
      }
      TAFR(TEST_PASSED == test_read_out_pending_data(0, FALSE), "reading FIFO failed\n");
      if (di->hi_id != HIID_KITKAT)
      {
         u718x_act_host_irq_us = di->host_irq_timestamp;
      }
      u718x_dif_host_irq_us = u718x_act_host_irq_us - u718x_prev_host_irq_us;
      u718x_exp_host_irq_ms = t_8_7_get_expected_interrupt_time_stamp();
      for (j = 0; j < g_8_7_sz; j++)
      {
         info_log("%u: %s, timestamp ms: %u, expected timestamp ms: %u\n", j, g_8_7_us[j].sample_exist ? "Y" : "N", g_8_7_us[j].first_sample_tm_ms, g_8_7_us[j].exp_interrupt_tm_ms);
      }

      if (irq_tm_prev != 0)                                          // not a first run
      {
         u32 diff = 0;

         if (u718x_exp_host_irq_ms >= (u718x_prev_host_irq_us / 1000))
         {
            diff = u718x_exp_host_irq_ms - (u718x_prev_host_irq_us / 1000);
         }
         info_log("actual host irq ms %u, prev host irq ms %u, diff %u\n", u718x_act_host_irq_us / 1000, (u718x_prev_host_irq_us / 1000), u718x_dif_host_irq_us / 1000);
         info_log("expected host irq ms %u, prev host irq ms %u, diff %u\n", u718x_exp_host_irq_ms, (u718x_prev_host_irq_us / 1000), diff);

         // this needs actual FIFO - if FIFO content is not correct this test is also not correct
         info_log("irq dif time u718x (first_sample + latency)[ms]: ");
         chk_val_with_margin(u718x_dif_host_irq_us / 1000,
                             diff,
                             0, (u32)(ok_tm_dif_u718x_system_mul * u718x_dif_host_irq_us / 1000.0) + 1);
         // this test has broader limits than previous, but does not depend on FIFO content
         info_log("irq dif time u718x (raw estimation)[ms]: ");
         chk_val_min_max(u718x_dif_host_irq_us / 1000, (u32)tst_min_lat, (u32)tst_max_lat);
         // this checks actual time measured by PC, but using broadest allowed error
         info_log("irq diff time pc [ms]: ");
         chk_val_min_max(irq_tm_dif, (u32)(tst_min_lat * (1 - ok_tm_dif_mul)), (u32)(tst_max_lat * (1 + ok_tm_dif_mul)));
      }
      else
      {
         info_log("actual host irq ms %u\n", u718x_act_host_irq_us / 1000);
      }
      irq_tm_prev = irq_tm;
      u718x_prev_host_irq_us = u718x_act_host_irq_us;

      for (i = 0; i < sz; i++)
      {
         ua[i].last_smpls_rcv = di->sensor_info[ua[i].sensor].samples_received - ua[i].total_smpls_rcv;
         ua[i].total_smpls_rcv = di->sensor_info[ua[i].sensor].samples_received;
         info_log("sensor %d smpls: ", ua[i].sensor);
         chk_val_min_max(ua[i].last_smpls_rcv, ua[i].exp_smpls_min, ua[i].exp_smpls_max);
      }
      irq_count++;
   }
   t_8_7_break_outer_loop:
   if (irq_count == 0)
   {
      TAFR(FALSE, "irq_count == 0 - this test shall receive at least 3 interrupts");
   }
   else
   {
      info_log("time [ms] wanted: %u run time: %u test time: %u\n",
               tm_wanted, tm_last_xfer - tm_beg, tm_now - tm_beg);
      info_log("Check IRQ count: ");
      chk_val_min_max(irq_count, irq_count_exp_min, irq_count_exp_max);

      // compute expected sample for each sensor according to real run time (from start ot last data transfer)
      for (i = 0; i < sz; i++)
      {
         u32 tm_actual_run_time = (tm_last_xfer - tm_beg);
         ua[i].exp_smpls_in_run = (u16)(tm_actual_run_time / ua[i].actual_per_ms);
      }

      for (i = 0; i < sz; i++)
      {
         u32 recv_smpls;
         info_log("sensor %d\n", ua[i].sensor);
         // check that number of samples matches run time
         recv_smpls = di->sensor_info[ua[i].sensor].samples_received - ua[i].total_smpls_rcv_at_start;
         info_log("Received samples:");
         chk_val_with_margin(ua[i].exp_smpls_in_run,
                             recv_smpls,
                             ok_tm_dif_mul, 2);
         // check that sensor
         info_log("Checking min period %u[us]; [ms]:", di->sensor_info[ua[i].sensor].timestamp_min_delta);
         chk_val_with_margin((u32)(ua[i].actual_per_ms),
                             di->sensor_info[ua[i].sensor].timestamp_min_delta / 1000,
                             ok_tm_dif_mul, 5);
         info_log("Checking max period %u[us]; [ms]:", di->sensor_info[ua[i].sensor].timestamp_max_delta);
         chk_val_with_margin((u32)(ua[i].actual_per_ms),
                             di->sensor_info[ua[i].sensor].timestamp_max_delta / 1000,
                             ok_tm_dif_mul, 5);
      }
   }

   // turn off sensors
   for (i = 0; i < sz; i++)
   {
      set_and_chk_rate(ua[i].sensor, 0, &(ua[i].actual_rate), TRUE);
   }

}


// return true if sensor is available and prefered
bool is_sensor_test_required(DI_SENSOR_TYPE_T sensor)
{
   bool prefered_sensor_available = FALSE;
   switch (sensor)
   {
      // only use game rotation if standard rotation isn't available
      case DST_GAME_ROTATION_VECTOR:
         prefered_sensor_available = di_has_sensor(di, DST_ROTATION_VECTOR);
         break;
         // only use geo rotation if standard rotation isn't available and game rotation isn't available
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         prefered_sensor_available =  di_has_sensor(di, DST_ROTATION_VECTOR) || di_has_sensor(di, DST_GAME_ROTATION_VECTOR);
         break;
      default:
         break;
   }

   return di_has_sensor(di, sensor) && !prefered_sensor_available;
}


// convert sample period to frequency
//  and latency tu number of smaple periods
// sz: size of arrays
// per: periods in [ms] which will be converted to freq [Hz] and stored to "us[].set_rate"
// lat: latency in [ms] which will be converted tu number of smaple periods and stored to
//      us[i].lat_in_periods
// us: used sensor array to be initialized with "per" and "lat"
void t_8_7_per_lat_2_rate_lat_cnt(int sz, double *per, double *lat, test_8_7_sensor_entry_t *us)
{
   int i;
   for (i = 0; i < sz; i++)
   {
      us[i].set_rate = (u16)(1000 / per[i]);
      us[i].lat_in_periods = (u16)(lat[i] / per[i]);
   }
}


// check taht none of used sensors (g_8_7_us) is DST_NOP
// return FALSE if any sensor in used sensors is DST_NOP
bool chk_use_sens_not_dst_nop()
{
   int i;
   bool ret = TRUE;
   for (i = 0; i < g_8_7_sz; i++)
   {
      if (g_8_7_us[i].sensor == DST_NOP)
      {
         warn_log("can not run test with sensor %d - cos sensor is missing\n", g_8_7_us[i].sensor);
         ret = FALSE;
      }
   }
   return ret;
}

// set 1 for longer test, set 0 for shorter test
#define T_8_7_DETAILED ALL_TESTS_DETAILED

TEST_START(8_7)
{
   int i;
   DI_SENSOR_TYPE_T try_sensors[] = {
      DST_ACCELEROMETER,
      DST_GEOMAGNETIC_FIELD,
      DST_GYROSCOPE,
      DST_ROTATION_VECTOR,
      DST_GAME_ROTATION_VECTOR,
      DST_GEOMAGNETIC_ROTATION_VECTOR
      // DST_GYROSCOPE_UNCALIBRATED,
      // DST_ORIENTATION,
      // DST_GRAVITY,
      // DST_LINEAR_ACCELERATION,
      // DST_MAGNETIC_FIELD_UNCALIBRATED,
      // DST_SIGNIFICANT_MOTION,
      // DST_STEP_DETECTOR,
      // DST_STEP_COUNTER
   };
   available_sensors_t as;                                           // available sensors
   test_8_7_sensor_entry_t *us = g_8_7_us;                           // use sensors

   double per[3];                                                    // periods [ms]
   double lat[3];                                                    // latency [ms]
   int loop_cnt;

   // set up accel and start gathering data
   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);

   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   TEST_ASSERT(di_register(di, test_8_7_sample_callback, (void *)di));

   for (i = 0; i < ARRAY_SIZE(try_sensors); i++)
   {
      if (!is_sensor_test_required(try_sensors[i]))
      {
         try_sensors[i] = DST_NOP;
      }
   }
   avail_sens_list(ARRAY_SIZE(try_sensors), try_sensors, &as);

   // test each sensor individually
   g_8_7_sz = 1;
   for (i = 0; i < as.c; i++)
   {
      int j;

      us[0].sensor = as.s[i];
      us[0].set_rate = 10;

      for (j = 0; j < 3; j++)
      {
         us[0].lat_in_periods = (j + 2) * 5;
         do_test_8_7_sensor_entry();
      }
   }

   // test each sensor individually
   g_8_7_sz = 1;
   for (i = 0; i < as.cw; i++)
   {
      int j;

      us[0].sensor = as.sw[i];
      us[0].set_rate = 10;

      for (j = 0; j < 3; j++)
      {
         us[0].lat_in_periods = (j + 2) * 5;
         do_test_8_7_sensor_entry();
      }
   }

   g_8_7_sz = 2;
   loop_cnt = 0;
   while (1)
   {
      switch (loop_cnt)
      {
         case 0:                                                     // NW
            us[0].sensor = as.s[0];
            us[1].sensor = as.s[1];
            break;
         case 1:                                                     // W
            if (di->hi_id == HIID_KITKAT)
            {
               goto t_8_7_test_outter_loop_break;
            }
            us[0].sensor = as.sw[0];
            us[1].sensor = as.sw[1];
            break;
         case 2:                                                     // mix same W/NW
            us[0].sensor = as.s[0];
            us[1].sensor = as.sw[0];
            break;
         case 3:                                                     // mix different W/NW
            us[0].sensor = as.s[0];
            us[1].sensor = as.sw[1];
            break;
         default:
            goto t_8_7_test_outter_loop_break;
      }
      loop_cnt++;

      if (!chk_use_sens_not_dst_nop())
      {
         continue;
      }

      if (T_8_7_DETAILED == 1)
      {
         info_log("=== test 2 sensors for long latency (100 periods)\n");
         g_8_7_sz = 2;

         us[0].set_rate = 10;
         us[0].lat_in_periods = 100;

         us[1].set_rate = 10;
         us[1].lat_in_periods = 100;
         do_test_8_7_sensor_entry();
      }

      info_log("=== test 2 sensors for latency of 10 periods\n");

      per[0] = 100;
      lat[0] = 1000;
      per[1] = 100;
      lat[1] = 1000;
      t_8_7_per_lat_2_rate_lat_cnt(2, per, lat, us);
      do_test_8_7_sensor_entry();

      info_log("=== test 2 sensors for latency: 1000/300 ms (1000/300!=integer)\n");
      g_8_7_sz = 2;
      per[0] = 100;
      lat[0] = 1000;
      per[1] = 300;
      lat[1] = 300;
      t_8_7_per_lat_2_rate_lat_cnt(2, per, lat, us);
      do_test_8_7_sensor_entry();

      // note case:
      // A: P=30 L=30
      // B: P=100 L=100 we expect that latency for B will not be rest
      //  but in current implementation it starts to count latency for each sensor
      //  when first sample occurs - thus this test would fail as it expects that
      // each sensor keeps it's own latency which is not true
   }
   t_8_7_test_outter_loop_break:;

}
TEST_END


//-----------------------------------------------------------------------------
// Pause and resume
// set up accel (or known test pattern generator); confirm we can start a transfer, switch to
// reading other registers, then go back and pick up data transfer where we left off; Per section 5.3
// of the U7183 KitKat Host Interface document, read less than the Bytes Remaining value (START
// -> read data -> STOP), but remember the number of bytes read so far. then read a different
// register (e.g., Error Register 0x50), then read rest of Bytes Remaining, starting at register
// (bytes_read_so_far MOD 50). Do this for all combinations of both FIFOs (W/NW).

typedef struct t_8_8_stat_struct
{
   u32 bytes_available;                                              // bytes available in FIFO
   u32 bytes_already_read;                                           // bytes already read from FIFO (in current transfer)
} t_8_8_stat;

t_8_8_stat t_8_8;

// wait for data, and read FIFO data size
// max_wait_ms: max time to be waited for data
bool wait_and_get_bytes_remaining(u32 max_wait_ms)
{
   bool ret;
   ret = try_with_time_limit(check_IntStat_HostIntr_1, max_wait_ms, 10);
   if (!ret)
   {
      info_log("did not get host interrupt in max wait time %u [ms]\n", max_wait_ms);
      return ret;
   }
   ret = read_bytes_remaining();
   t_8_8.bytes_available = di->fifo_bytes_remaining;
   t_8_8.bytes_already_read = 0;
   info_log("Bytes available: %u\n", t_8_8.bytes_available);
   return ret;
}


// read requested number of bytes from FIFO
//  is capable of continue on address not modulo 50
// bytes_to_read: bytes to be read now
// return TRUE if data was read
bool read_fifo_known_bytes_remaining(u32 bytes_to_read)
{
   u32 bytes_available;
   u8 start;

   bytes_available = t_8_8.bytes_available - t_8_8.bytes_already_read;

   info_log("read_fifo_known_bytes_remaining: trying to read %u B (available: %u B [= %u - %u])\n"
            , bytes_to_read, bytes_available, t_8_8.bytes_available, t_8_8.bytes_already_read);

   if (t_8_8.bytes_available < t_8_8.bytes_already_read)
   {TAFR(FALSE, "already read more (%u) than available (%u)\n", t_8_8.bytes_already_read, t_8_8.bytes_available);
      return FALSE;
   }

   start = SR_BUFFER_OUT_START + (t_8_8.bytes_already_read % 50);

   if (bytes_to_read > bytes_available)
   {
      info_log("Warning trying to read %u B which is more than available (%d)\n", bytes_to_read, bytes_available);
   }
   if (bytes_to_read > di->sensor_buf_size)
   {
      TAFR(FALSE, "trying to read %u bytes but buffer size is only %u\n", bytes_to_read, di->sensor_buf_size);
      return FALSE;
   }

#ifdef VBE_DBG_FIFO_READ
   info_log("vbe read fifo start: % 3u, read len: %u\n", start, bytes_to_read);
#endif

   if (!i2c_blocking_read(di->i2c_handle, start, di->sensor_buf, bytes_to_read))
   {
      TAFR(FALSE, "Error calling i2c_blocking_read\n");
      return FALSE;
   }
   di->sensor_buf_idx = 0;
   di->sensor_buf_valid_data_size = bytes_to_read;
   process_fifo_chunk(di);

   di->fifo_bytes_remaining -= bytes_to_read;
   di->fifo_bytes_so_far += bytes_to_read;
   di->total_bytes_transferred += bytes_to_read;
   t_8_8.bytes_already_read += bytes_to_read;

   if (di->fifo_bytes_remaining == 0)
   {
      di->total_host_transfers++;
   }
   return TRUE;
}


// reset internal data statistics, wait for data, and read FIFO data size
// return TRUE if host interrupt received, else FALSE
bool t_8_8_prepare_data(u32 lat_ms)
{
   int i;
   bool ret;
   // Reset intenral stats clears out the scale_factor for *all* sensor drivers. Bcakup and restore here.
   DI_SENSOR_INFO_T sensor_info[sizeof(di->sensor_info) / sizeof(di->sensor_info[0])];

   memcpy(sensor_info, di->sensor_info, sizeof(sensor_info));

   reset_internal_stats(di);

   // restore scale factor
   for (i = 0; i < sizeof(di->sensor_info) / sizeof(di->sensor_info[0]); i++)
   {
      di->sensor_info[i].scale_factor = sensor_info[i].scale_factor;
      di->sensor_info[i].timestamp_prev = sensor_info[i].timestamp_prev;
   }

   info_log("=== Wait %u ms (to meet sensor latency time)\n", lat_ms);
   time_delay_ms(lat_ms - 100);
   ret = wait_and_get_bytes_remaining(lat_ms);
   TEST_ASSERTF(ret, "Did not get interrupt!\n");
   return ret;
}


// read consecutively data form FIFO
// sz: size of elements in parts
// parts: array of bytest to be consecutively read from FIFO
// return TRUE if data was read
bool t_8_8_read_parts(int sz, u32 *parts)
{
   int i;
   bool ret = TRUE;
   for (i = 0; i < sz; i++)
   {
      ret &= read_fifo_known_bytes_remaining(parts[i]);

      info_log("Trying to read other registers (chip status, host stauts, e.r.r.o.r register)\n");
      TEST_ASSERTF(read_chip_error_registers(di), "Reading error registers failed\n")
   }

   ret &= read_fifo_known_bytes_remaining(t_8_8.bytes_available - t_8_8.bytes_already_read);

   check_FIFO_consistency();

   return ret;
}


// set 1 for testing more options (slwer ~2 min )
// set 0 for testing less option (faster 15 sec)
#define TEST_8_8_DETAILED ALL_TESTS_DETAILED

TEST_START(8_8)
{
   u32 lat_ms = 300;                                                 // latency in ms
   u32 parts[2];                                                     // bytes to be consecutively read
   int i;                                                            // counter
   u32 bck_bytes_avail;                                              // backup bytes available
   u32 half;                                                         // half of FIFO (shall be bnoubndary W/NW FIFO)
   u32 nw;                                                           // 10% in second FIFO (NW one)
   u32 use_rate = config.accel_fast_rate;

   gtp.prn_host_intr = 0;
   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   di->total_timedups = di->total_timegaps = di->total_timeslips = di->total_invalid_samples_received = 0;
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }

   TEST_ASSERT(set_and_chk_rate(DST_ACCELEROMETER, use_rate, NULL, TRUE));
   TEST_ASSERT(set_and_chk_lat(DST_ACCELEROMETER, lat_ms, NULL, TRUE));
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERT(set_and_chk_rate(DST_ACCELEROMETER | di_wake_sensor_start(di), use_rate, NULL, TRUE));
      TEST_ASSERT(set_and_chk_lat(DST_ACCELEROMETER | di_wake_sensor_start(di), lat_ms, NULL, TRUE));
   }

   info_log("Read out FIFO\n");
   read_FIFO(10, FALSE, NULL);                                       // for accel.fast we do not use read whie interrupt as it is always

   // test 2 consecutive partial reading modulo 50
   t_8_8_prepare_data(lat_ms);
   bck_bytes_avail = t_8_8.bytes_available;
   TEST_ASSERTF(bck_bytes_avail >= 550, "Expecting at least 550 B in FIFO. If less please increase latency time 'lat_ms'\n");
   half = (u32)(bck_bytes_avail * 0.5);                              // half of FIFO (shall be bnoubndary W/NW FIFO)
   nw = (u32)(bck_bytes_avail * 0.6);                                // 10% in second FIFO (NW one)
   parts[0] = 250;
   parts[1] = 250;
   t_8_8_read_parts(2, parts);

   // test 2 consecutive partial reading not modulo 50
   t_8_8_prepare_data(lat_ms);
   parts[0] = 249;
   parts[1] = 252;
   t_8_8_read_parts(2, parts);

   // test different sizes for 1st partial reading
   if (TEST_8_8_DETAILED == 1)
   {
      for (i = 1; i <= 250; i++)
      {
         t_8_8_prepare_data(lat_ms);
         parts[0] = i;
         t_8_8_read_parts(1, parts);
      }
   }
   else
   {
      u32 use_parts[] = {1, 25, 49, 50, 51, 75, 99, 100, 101, 125, 149, 150, 151, 175, 199, 200, 201, 225, 249, 250};
      for (i = 0; i < (sizeof(use_parts) / sizeof(u32)); i++)
      {
         t_8_8_prepare_data(lat_ms);
         parts[0] = use_parts[i];
         t_8_8_read_parts(1, parts);
      }
   }

   if (di->hi_id == HIID_KITKAT)
   {
      return g_current_test_retval;
   }

   // test different sizes for 1st partial reading - for W/NW FIFO boundary and for NW FIFO
   if (TEST_8_8_DETAILED == 1)
   {
      // note it would be hard to exactly detect where non_wakeup (2nd) FIFO buffer starts
      // so we will test all 50 positions, in 60% of data (W/NW shall be ~50/50%)
      for (i = 1; i <= 50; i++)
      {
         t_8_8_prepare_data(lat_ms);
         parts[0] = (u32)(i + nw);
         t_8_8_read_parts(1, parts);
      }

      // note it would be hard to exactly detect W/NW boundary is it shall be close to 50/50
      // therefore we do 50%-25
      for (i = 1; i <= 50; i++)
      {
         t_8_8_prepare_data(lat_ms);
         parts[0] = (u32)(i + half - 25);
         t_8_8_read_parts(1, parts);
      }
   }
   else
   {
      u32 use_parts[] = {half - 25, half - 2, half - 1, half, half + 1, half + 2, half + 25,
         nw, nw + 10, nw + 25, nw + 33, nw + 50};
      for (i = 0; i < (sizeof(use_parts) / sizeof(u32)); i++)
      {
         t_8_8_prepare_data(lat_ms);
         parts[0] = use_parts[i];
         t_8_8_read_parts(1, parts);
      }
   }

}
TEST_END


//-----------------------------------------------------------------------------
/**
 * test 8.9
 * PRIORITY 2
 * \brief FIFO Overflow
 * set up accel; read some data and capture last valid
 * timestamp; allow to overflow for a measured amount of time
 * that we can estimate the number of lost samples from; resume
 * reading from FIFO, and confirm we see a little old data, a
 * gap in data (large step in timestamps of expected duration),
 * an overflow meta event, a new timestamp, then more recent
 * data in correct time order
 */

// accelerometer sensor allowed rate error (eg 0.2 = +-20%)
#define ACCEL_RATE_ERROR 0.2

typedef struct test_8_9_sensor_param
{
   DI_SENSOR_TYPE_T s;                                               // sensor ID
   u16 reqRate;                                                      // requested rate
   u16 realRate;                                                     // real sensor rate
   u32 expPeriod_us;                                                 // expected period [us] (counted from real rate)
   u32 maxPeriod_us;                                                 // maximal tolerated period [us]
   s32 minPeriod_us;                                                 // minimal tolerated period [us]
   u16 limit_fifo_events;                                            // fifo events that would overflow fifo (we count timestamp+sensor data as one event cos they come together most often)
   u16 fifo_over_flow_time_ms;                                       // time to fill full FIFO with sensor data (expecting each sensor data precede with timestamp)

   u32 lt;                                                           // last time-stamp
   u32 vmax[2];                                                      // max period [0] = befor overfolow event [1] = after OF event
   s32 vmin[2];                                                      // min period [0] = befor overfolow event [1] = after OF event
   s32 cnt[2];                                                       // sensor events counter [0] = befor overfolow event [1] = after OF event
} test_8_9_sensor_param_t;

test_8_9_sensor_param_t g_8_9_acel;                                  // accelerometer sensor
test_8_9_sensor_param_t g_8_9_acelw;                                 // wakeup accelereometer sensor

u32 g_OF = 0;                                                        // overflow counter
u32 g_OF_w = 0;                                                      // overflow wakeup counter
bool g_OF_now;                                                       // just happened of
bool g_OF_now_w;                                                     // just happened of wakeup
u32 g_ofp = 0;                                                       // over flow period
bool g_ofp_written = FALSE;                                          // over flow period already written?
u32 g_ofp_w = 0;                                                     // over flow period wakeup
bool g_ofp_written_w = FALSE;                                        // over flow period wakeup already written?

// reset sensor data statistic
// s: sensor struct
void t_8_9_g_var_rst_sensor(test_8_9_sensor_param_t *s)
{
   s->lt = 0;
   s->vmax[0] = s->vmax[1] = 0;
   s->vmin[0] = s->vmin[1] = S32_MAX;
   s->cnt[0] = s->cnt[1] = 0;
}


// reset test 8.9 data - shall be called before test run
void t_8_9_g_var_rst()
{
   t_8_9_g_var_rst_sensor(&g_8_9_acel);
   t_8_9_g_var_rst_sensor(&g_8_9_acelw);
   g_OF = 0;
   g_OF_w = 0;
   g_OF_now = FALSE;
   g_OF_now_w = FALSE;
   g_ofp = 0;
   g_ofp_w = 0;
   g_ofp_written = FALSE;
   g_ofp_written_w = FALSE;
   di->total_timeslips = 0;
   di->total_timegaps = 0;
}


// display 8.9 test measured sensor related results
// s: sensor struct
// expected_ovf_per_us: expected Over-Flow period [us]
void t_8_9_g_disp_sens(test_8_9_sensor_param_t *s, u32 expected_ovf_per_us)
{
   if (s == NULL)
   {
      return;
   }
   info_log("prev max period [us]    : %u\n", s->vmax[0]);
   info_log("prev min period [us]    : %d\n", s->vmin[0]);
   info_log("prev accel events       : %u\n", s->cnt[0]);
   info_log("after max period [us]   : %u\n", s->vmax[1]);
   info_log("after min period [us]   : %d\n", s->vmin[1]);
   info_log("after accel events      : %u\n", s->cnt[1]);
   info_log("expected OF period [us] : %u\n", expected_ovf_per_us);
}


// display 8.9 test measured fifo overflow times
void t_8_9_g_disp_ovf()
{
   info_log("found over flow events  : %u\n", g_OF);
   info_log("found over flow events w: %u\n", g_OF_w);
   info_log("over flow period [us]   : %u\n", g_ofp);
   info_log("over flow period [us]  w: %u\n", g_ofp_w);
   info_log("timegaps                : %u\n", di->total_timegaps);
   info_log("timeslips               : %u\n", di->total_timeslips);
}


// data call back - called for each parsed data
// computes max/min rate before and after overflow
// counts sensor data messages
// counts overflow meta events
// return TRUE only
bool test_8_9_data_callback(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *data, void *user_param)
{
   u32 t;                                                            // time
   s32 t_df;                                                         // time diff
   int idx;                                                          // min/max index
   test_8_9_sensor_param_t *as;                                      //actual sensor
   as = NULL;
   if (sensor == DST_ACCELEROMETER)
   {
      as = &g_8_9_acel;
      idx = g_OF > 0 ? 1 : 0;
   }
   if ((di->hi_id != HIID_KITKAT) && (sensor == (DST_ACCELEROMETER | di_wake_sensor_start(di))))
   {
      as = &g_8_9_acelw;
      idx = g_OF_w > 0 ? 1 : 0;
   }
   if (as != NULL)
   {
      t = data->accel.t;
      t_df = t - as->lt;
      if (as->lt != 0)                                               // not a 1st sensor data
      {
         as->cnt[idx]++;
         if (g_OF_now)
         {
            g_OF_now = FALSE;
            if (!g_ofp_written) {
               g_ofp = t_df;
               g_ofp_written = TRUE;
            }
         }
         else if (g_OF_now_w)
         {
            g_OF_now_w = FALSE;
            if (!g_ofp_written_w) {
               g_ofp_w = t_df;
               g_ofp_written_w = TRUE;
            }
         }
         else
         {
            if (as->vmax[idx] < (u32)t_df)
               as->vmax[idx] = t_df;
            if (as->vmin[idx] > t_df)
               as->vmin[idx] = t_df;
         }
      }
      as->lt = t;
   }
   // 1st shall appear non wakeup, 2nd wakeup
   else if (sensor == DST_META_EVENT)
   {
      if (data->meta.event_id == DME_FIFO_OVERFLOW)
      {
         g_OF++;
         g_OF_now = TRUE;
      }
   }
   else if (sensor == DST_WAKEUP_META_EVENT)
   {
      if (data->meta.event_id == DME_FIFO_OVERFLOW)
      {
         g_OF_w++;
         g_OF_now_w = TRUE;
      }
   }
   return TRUE;
}


// set sensor rate and computes overflow time for actual sensor rate
// sp: sensor Parmeters
// return TRUE if ok, else FALSE
bool set_8_9_sensor(test_8_9_sensor_param_t *sp)
{
   // SENSOR_INFORMATION sensor_info;
   bool ret = TRUE;


   if (sp == NULL)
   {                                                                 // do not configure not used sensor
      return TRUE;
   }

   ret &= set_and_chk_rate(sp->s, sp->reqRate, &(sp->realRate), TRUE);
   sp->expPeriod_us = (u32)(1.0e6 / sp->realRate);
   sp->maxPeriod_us = (u32)(sp->expPeriod_us * (1.0 + ACCEL_RATE_ERROR));
   sp->minPeriod_us = (s32)(sp->expPeriod_us * (1.0 - ACCEL_RATE_ERROR));

   {
      u16 nw_size;
      u16 w_size;
      get_3axis_fifo_events(di, &w_size, &nw_size);
      sp->limit_fifo_events = is_wakeup_sensor(di, sp->s) ? w_size : nw_size;
   }
   // calculate time it will take to get FIFO 100% full
   sp->fifo_over_flow_time_ms = 1000 * sp->limit_fifo_events / sp->realRate;
   info_log("fifo max %s sensor events: %d\n", di_query_sensor_name(di, sp->s), sp->limit_fifo_events);
   return ret;
}


// structure used to hold time parameters used for expected overflow time gap
typedef struct test_8_9_gap_time
{
   s32 ms;                                                           // time in [ms]
   u32 us;                                                           // time in [us]
   u32 max_us;                                                       // max tolerated gap time in [us]
   u32 min_us;                                                       // min tolerated gap time in [us]
} test_8_9_gap_time_t;


// count overflow gap times
// gt: gap time struct - shall contain initialized "ms"
void count_gap_time_us(test_8_9_gap_time_t *gt)
{
   gt->us = gt->ms * 1000;
   gt->max_us = (u32)(2   * gt->us);
   gt->min_us = (u32)(0.5 * gt->us);
}


// Check sensor rates
// sp: sensor struct
// returns TERST_PASSED or TEST_FAIL
int checkResultRate(test_8_9_sensor_param_t *sp)
{
   int i;
   if (sp == NULL)
   {                                                                 // do not check sensor rate for not used sensor
      return TEST_PASSED;
   }
   for (i = 0; i < 2; i++)
   {
      TEST_ASSERTF(sp->vmax[i] < sp->maxPeriod_us,
                   "expected period < %u [us] but got %u [us]",
                   sp->maxPeriod_us, sp->vmax[i]);
      TEST_ASSERTF(sp->vmin[i] > sp->minPeriod_us,
                   "expected period > %u [us] but got %u [us]",
                   sp->minPeriod_us, sp->vmin[i]);
   }
   return TEST_PASSED;
}


// check overflow gap time
// sp: sensor struct
// exp_gap_tm: expected gap time struct
// returns TERST_PASSED or TEST_FAIL
int checkGapTime(test_8_9_sensor_param_t *sp, test_8_9_gap_time_t *exp_gap_tm)
{
   u32 exp_ofp;                                                      // expected over flow period
   if (sp == NULL)
   {
      return TEST_PASSED;
   }
   exp_ofp = (is_wakeup_sensor(di, sp->s)) ? g_ofp_w : g_ofp;
   TEST_ASSERTF((exp_ofp > exp_gap_tm->min_us) && (exp_ofp < exp_gap_tm->max_us),
                "expected gap time to be <%u,%u> [us] but got %u [us]",
                exp_gap_tm->min_us, exp_gap_tm->max_us, exp_ofp);
   return TEST_PASSED;
}


// counts number of expected overflow events
// sp: sensor struct
// exp_OF: expected non wakeup overflows (will add 1 if sp is non wakeup)
// exp_OF_w: expected wakeup overflows (will add 1 if sp is wakeup)
void count_exp_OF(test_8_9_sensor_param_t *sp, u32 *exp_OF, u32 *exp_OF_w)
{  if (sp != NULL)
   {
      if (is_wakeup_sensor(di, sp->s))
      {
         (*exp_OF_w)++;
      }
      else
      {
         (*exp_OF)++;
      }
   }
}


// Do complete check of all relevant parameters after test it will check
// sensor rate correctness
// over flow gap
//   - time correctness
//   - event number
// sp : sensor struct
// sp2: sensor struct (use NULL if not used)
// exp_gap_tm: expcted over flow gap time
// exp_gap_tm2: expcted over flow gap time for another sensor (expecting different gaps for W/NW FIFO)
// returns TERST_PASSED or TEST_FAIL
int checkResult2(test_8_9_sensor_param_t *sp, test_8_9_sensor_param_t *sp2,
                 test_8_9_gap_time_t *exp_gap_tm, test_8_9_gap_time_t *exp_gap_tm2)
{
   u32 exp_OF = 0;
   u32 exp_OF_max = 0;
   u32 exp_OF_w = 0;
   u32 exp_OF_max_w = 0;
#define ALLOWED_EXTRA_OVF 3

   TEST_ASSERT(TEST_PASSED == checkResultRate(sp));
   TEST_ASSERT(TEST_PASSED == checkResultRate(sp2));

   count_exp_OF(sp, &exp_OF, &exp_OF_w);
   count_exp_OF(sp2, &exp_OF, &exp_OF_w);
   if (exp_OF > 0)
      exp_OF_max = exp_OF + ALLOWED_EXTRA_OVF;
   if (exp_OF_w > 0)
      exp_OF_max_w = exp_OF_w + ALLOWED_EXTRA_OVF;
   TEST_ASSERTF((g_OF >= exp_OF) && (g_OF <= exp_OF_max),
                "expected <%d,%d> overflow event but detected %d", exp_OF, exp_OF_max, g_OF);
   TEST_ASSERTF((g_OF_w >= exp_OF_w) & (g_OF_w <= exp_OF_max_w),
                "expected <%d,%d> overflow wakeup event but detected %d", exp_OF_w, exp_OF_max_w, g_OF);

   TEST_ASSERT(TEST_PASSED == checkGapTime(sp, exp_gap_tm));
   TEST_ASSERT(TEST_PASSED == checkGapTime(sp2, exp_gap_tm2));

   TEST_ASSERT(di->total_timegaps >= 1);
   TEST_ASSERT(di->total_timeslips == 0);

   return TEST_PASSED;
}


// sp: sensor parameters structure of sensor to be tested
// sp2: sensor parameters structure of sensor to be tested (can be NULL)
// ofm: fifo Over Flow Multiplicator (eg. 0.2 let fifo overflow by approx 20%)
//     note -values can be used to not let FIFO over-flow
int test_8_9_sensor2(test_8_9_sensor_param_t *sp, test_8_9_sensor_param_t *sp2, double ofm)
{
   test_8_9_gap_time_t exp_gap_tm[2];                                // expected gap time
   u32 wait_time_ms;


   info_log("=== test 8_9 for sensor %s, overflow %d%%", di_query_sensor_name(di, sp->s), (int)(ofm * 100));
   if (sp2 != NULL)
   {
      info_log(" + sensor %s\n", di_query_sensor_name(di, sp2->s));
   }
   info_log("\n");

   t_8_9_g_var_rst();
   set_8_9_sensor(sp);
   set_8_9_sensor(sp2);

   // read out some data to start
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_8_9_RUN_TIME, FALSE));

   TEST_ASSERTF(g_OF == 0, "Expecting no overflow event yet but got %d OF events", g_OF);
   TEST_ASSERTF(g_OF_w == 0, "Expecting no overflow wakeup event yet but got %d OF events", g_OF_w);

   // allow it to overflow (by not calling di_task_loop())
   // this should have caused a time gap but no slip (retrogression)
   exp_gap_tm[0].ms = (s32)(sp->fifo_over_flow_time_ms * ofm);
   count_gap_time_us(&(exp_gap_tm[0]));
   wait_time_ms = sp->fifo_over_flow_time_ms + exp_gap_tm[0].ms;
   if (sp2 != NULL)
   {
      exp_gap_tm[1].ms = wait_time_ms - sp2->fifo_over_flow_time_ms;
      count_gap_time_us(&(exp_gap_tm[1]));
   }

   info_log("wait and let buffer fill for %0.1f [s]\n", wait_time_ms / 1.0e3);
   time_delay_ms(wait_time_ms);

   // now read it all out, and confirm the expected pattern
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(sp->fifo_over_flow_time_ms, FALSE));

   t_8_9_g_disp_ovf();
   t_8_9_g_disp_sens(sp, exp_gap_tm[0].us);
   t_8_9_g_disp_sens(sp2, exp_gap_tm[1].us);

   return checkResult2(sp, sp2, &(exp_gap_tm[0]), &(exp_gap_tm[1]));
}


TEST_START(8_9)
{
   u16 retRate;

   // set up accel and start gathering data
   set_rates(0 /*config.accel_fast_rate*/, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   g_8_9_acel.s        = DST_ACCELEROMETER;
   g_8_9_acel.reqRate  = config.accel_fast_rate;
   if (di->hi_id != HIID_KITKAT)
   {
      g_8_9_acelw.s       = (DST_ACCELEROMETER | di_wake_sensor_start(di));
      g_8_9_acelw.reqRate = config.accel_fast_rate;
   }


   TEST_ASSERT(di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, TRUE, TRUE, FALSE));
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_8_9_RUN_TIME, FALSE));
   t_8_9_g_var_rst();
   TEST_ASSERT(di_register(di, test_8_9_data_callback, (void *)di));

   test_8_9_sensor2(&g_8_9_acel, NULL, 0.20);
   set_and_chk_rate(g_8_9_acel.s, 0, &(retRate), TRUE);
   if (di->hi_id == HIID_KITKAT)
   {
      set_and_chk_rate(g_8_9_acel.s, 0, &(retRate), TRUE);
      return g_current_test_retval;
   }
   test_8_9_sensor2(&g_8_9_acelw, NULL, 0.20);

   test_8_9_sensor2(&g_8_9_acel, &g_8_9_acelw, 0.20);

   set_and_chk_rate(g_8_9_acel.s, 0, &(retRate), TRUE);
   set_and_chk_rate(g_8_9_acelw.s, 0, &(retRate), TRUE);

   return g_current_test_retval;
}
TEST_END


//-----------------------------------------------------------------------------
/**
 * PRIORITY 1
 * \brief Sample Parsing
 * set up all sensors in test pattern mode at maximum sample
 * rates; run for a long period of time, and ensure no samples
 * are lost or corrupted
 */
TEST_START(8_10)
{
   u32 start;
   DI_SENSOR_TYPE_T s;
   int num = 0;
#if 0
   u8 buf[256];
   PHYS_SENSOR_STATUS phys_sensor_status;
#endif

   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);

   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   // turn on test pattern output
   // removed from firmware due to size... TEST_ASSERT(di_set_host_test_mode(di, TRUE));
   info_log("disable sensor framework meta events (cause time slip errors)\n");
   di_enable_meta_event_ex(di, DME_SENSOR_FRAMEWORK, FALSE, FALSE, FALSE);
   di_enable_meta_event_ex(di, DME_SENSOR_FRAMEWORK, FALSE, FALSE, TRUE);

   // set up all supported sensors
   for (s = DST_FIRST; s <= di_max_sensor_id(di); s++)
   {
      if (di_has_sensor(di, s))
      {
         info_log("turning on %s\n", di_query_sensor_name(di, s));
         TEST_ASSERT(di_configure_rate(di, s, 100, 100));            // moderate rates on all sensors
         num++;
      }
   }

   for (s = DST_FIRST; s <= di_max_sensor_id(di); s++)
   {
      if (di_has_sensor(di, s))
      {
         SENSOR_CONFIG sconf;
         // Read out set config, this needs to happen
         // after configure_Rate completes to ensure that the dynamic range value is non-zero, allowing the sample rate to be correct.
         di_query_sensor_config(di, s, &sconf);
      }
   }

   // read out all data
   start = time_ms();

#if 0
   display_error_info(di);
   display_driver_info(di);
   display_actual_rates(di);
   di_query_sensor_status(di);
   display_sensor_status_bytes(di, FALSE);
   if (!di_save_parameter(di, PP_SYSTEM, SYSP_PHYS_SENS_STATUS, (u8 *)&phys_sensor_status, sizeof(phys_sensor_status)))
   error_log("error requesting physical sensor status\n");
   else
   {
      info_log("\nPhysical sensor info:\nPhysical sensor, rate, range, IRQ en, power mode\n");
      info_log("          Accel, % 4u, % 5u, % 6u, %u\n", phys_sensor_status.AccelRate, phys_sensor_status.AccelRange, phys_sensor_status.AccelIRQ, phys_sensor_status.AccelPowerMode);
      info_log("           Gyro, % 4u, % 5u, % 6u, %u\n", phys_sensor_status.GyroRate, phys_sensor_status.GyroRange, phys_sensor_status.GyroIRQ, phys_sensor_status.GyroPowerMode);
      info_log("            Mag, % 4u, % 5u, % 6u, %u\n\n", phys_sensor_status.MagRate, phys_sensor_status.MagRange, phys_sensor_status.MagIRQ, phys_sensor_status.MagPowerMode);
   }
   if (!di_save_parameter(di, PP_ALGORITHM, BAP_WORKING_MODE_EN, buf, 2))
   error_log("error requesting working mode en\n");
   else
   info_log("\nBSX working mode en: 0x%04X\n", buf[0] + 256 * buf[1]);

   if (!di_save_parameter(di, PP_ALGORITHM, BAP_OPR_MODE, buf, 2))
   error_log("error requesting operating mode\n");
   else
   info_log("BSX update rate: %u\nBSX operating mode index: %u\n", buf[0], buf[1]);
#endif

   di->total_samples_received = 0;
   di->total_invalid_samples_received = 0;
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_8_10_DISCARD_TIME, FALSE));

   // it is normal for the generic host driver's timestamp analysis to see some slips and gaps as the
   // data starts arriving, so ignore them up to here
   di->total_timeslips = 0;
   di->total_timegaps = 0;

   info_log("running for %u seconds...\n", TEST_8_10_RUN_TIME / 1000);
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_8_10_RUN_TIME, FALSE));

   // TODO: intercept data samples and compare to test pattern

   TEST_ASSERT(di->total_samples_received != 0);                     // todo: check vs. expected count
   TEST_ASSERT(di->total_invalid_samples_received == 0);
   TEST_ASSERT(di->total_timeslips == 0);
   TEST_ASSERT(di->total_timegaps == 0);

   return TEST_PASSED;
}
TEST_END


//-----------------------------------------------------------------------------
/**
 * test 8.11
 * PRIORITY 1
 * \brief FIFO Flush
 */
typedef struct t_8_11_data
{
   DI_SENSOR_TYPE_T prev_sens;                                       // previous sensor
   u16 NW_after_W;                                                   // NW event received after W event counter
   u16 W_after_NW;                                                   // W event received after NW event counter
   u32 last_W_time_us;                                               // last Wakeup time [us]
   u32 last_time_us;                                                 // last Non-Wakeup time [us]
   u32 meta_flush_W_time_us;                                         // time of last meta event - Fifo flush [us]
   u32 meta_flush_NW_time_us;                                        // time of last meta event - Fifo flush [us]
   u32 eventsCount[255];                                             // events counter for each sensor
} t_8_11_data_t;
#define META_EVENT_NO_SOONER_THAN_X_US 6000

t_8_11_data_t g_8_11_d;                                              // globa test 8.11 data


// reset test 8.11 data
void t_8_11_data_reset()
{
   int test;
   info_log("reset test 8.9 data\n");
   g_8_11_d.prev_sens = DST_NOP;
   g_8_11_d.NW_after_W = 0;
   g_8_11_d.W_after_NW = 0;
   g_8_11_d.meta_flush_W_time_us = 0;
   g_8_11_d.meta_flush_NW_time_us = 0;
   g_8_11_d.last_W_time_us = META_EVENT_NO_SOONER_THAN_X_US + 1000;
   g_8_11_d.last_time_us = META_EVENT_NO_SOONER_THAN_X_US + 1000;

   test = sizeof(g_8_11_d.eventsCount);
   memset(g_8_11_d.eventsCount, 0, test);
}


// data call back - called for each parsed data
// log transition W->NW (expected) and NW->W (not expected) events
// save last W event befor NW
// count events per sensor
// return TRUE only
bool t_8_11_data_callback(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *data, void *user_param)
{
   DI_META_EVENT_INT_DATA_T *me;
   data_callback(instance, sensor, data, user_param);
   //info_log("vbe: sensor %s\n",di_query_sensor_name(sensor));
   if (sensor <= di_max_sensor_id(instance))
   {
      g_8_11_d.eventsCount[sensor]++;
   }
   if (g_8_11_d.prev_sens != DST_NOP)
   {
      me = (DI_META_EVENT_INT_DATA_T *)(&(di->cur_sample));

      if (is_wakeup_event(di, sensor))
      {
         g_8_11_d.last_W_time_us = di->cur_timestamp[1];
         if (sensor == DST_WAKEUP_META_EVENT)
         {
            if (me->event_id == DME_FLUSH_COMPLETE)
            {
               g_8_11_d.meta_flush_W_time_us = g_8_11_d.last_W_time_us;
            }
         }

         if (!is_wakeup_event(di, g_8_11_d.prev_sens))
         {
            g_8_11_d.W_after_NW++;
         }
      }
      if (!is_wakeup_event(di, sensor))
      {
         g_8_11_d.last_time_us = di->cur_timestamp[0];
         if (sensor == DST_META_EVENT)
         {
            if (me->event_id == DME_FLUSH_COMPLETE)
            {
               g_8_11_d.meta_flush_NW_time_us = g_8_11_d.last_time_us;
            }
         }
         if (is_wakeup_event(di, g_8_11_d.prev_sens))
         {
            g_8_11_d.NW_after_W++;
         }
      }
   }
   g_8_11_d.prev_sens = sensor;
   return TRUE;
}


// max used sensors in test 8.11
#define T_8_11_MAX_USED_SENSORS 8
typedef struct t_8_11_use_sens
{
   int sz;                                                           // size of sensors
   DI_SENSOR_TYPE_T s[T_8_11_MAX_USED_SENSORS];                      // sensor
   int exp_evns[T_8_11_MAX_USED_SENSORS];                            // expected events count
   int time_delay_ms;                                                // time delay [ms]

} t_8_11_use_sens_t;


// display sensor log
// s: sensor
// expSmpls: expected number of samples
// expSomeSmpl: expecting some samples (TRUE to display expSmpls)
t_8_11_disp_sens(DI_SENSOR_TYPE_T s, int expSmpls, bool expSomeSmpls)
{
   info_log("%s:\n", di_query_sensor_name(di, s));
   //info_log("rate     : %d\n",di->sensor_info[s].rate);
   info_log("act rate : %d\n", di->sensor_info[s].actual_rate);
   info_log("smpls    : %d\n", g_8_11_d.eventsCount[s]);
   if (expSomeSmpls)
   {
      info_log("exp smpls: %d\n", expSmpls);
   }
}


// Display nw->w and w->nw transitions, then sensor informations
// smplRcv: samples received
// *s: struct with sensor list to display
// expSmpls: expecting some samples (to control if sensors expected sample count is displayed)
void t_8_11_disp(u32 smplRcv, t_8_11_use_sens_t *s, bool expSmpls)
{
   int i;
   info_log("Samples received           : %d\n", smplRcv);
   info_log("nw -> w  events transitions: %d\n", g_8_11_d.W_after_NW);
   info_log("w  -> nw events transitions: %d\n", g_8_11_d.NW_after_W);
   for (i = 0; i < s->sz; i++)
   {
      t_8_11_disp_sens(s->s[i], s->exp_evns[i], expSmpls);
   }
}


// Check sensor counter - adding allowed spread - set variables "percErr" and "intSigma"
// s: sensor
// epx_events: expected events count
bool chk_sens_cnt(DI_SENSOR_TYPE_T s, int exp_evnts)
{
   double multErr = 0.25;                                            // allowe error multiplicator +-
   int intSigma = 2;                                                 // integer error allowed +- (useful for low nombers where multiplicator wouldn't work)
   bool res;
   res = chk_val_with_margin((u32)(exp_evnts), g_8_11_d.eventsCount[s], multErr, intSigma);
   TAFR(res, "Sensor %s events count not in limit\n", di_query_sensor_name(di, s));
   return res;
}


// check that last W event is meta event "DST_WAKEUP_META_EVENT:DME_FLUSH_COMPLETE"
bool chk_last_w_meta_flush()
{
   bool resAll;
   s32 dif_us;
   dif_us = (s32)(g_8_11_d.last_W_time_us - g_8_11_d.meta_flush_W_time_us);
   info_log("last W meta flush complete event happened %d us before last w event\n", dif_us);
   resAll = dif_us <= META_EVENT_NO_SOONER_THAN_X_US;
   TAFR(resAll, "DST_WAKEUP_META_EVENT expected to occur no sooner than %d us since last wakeup event but occured %u us before",
        META_EVENT_NO_SOONER_THAN_X_US, dif_us);
   return resAll;
}


// check that last event is meta event "DST_META_EVENT:DME_FLUSH_COMPLETE"
bool chk_last_meta_flush()
{
   bool resAll;
   u32 dif_us;
   dif_us = g_8_11_d.last_time_us - g_8_11_d.meta_flush_NW_time_us;
   info_log("last NW meta flush complete event happened %u us before last nw event\n", dif_us);
   resAll = dif_us <= META_EVENT_NO_SOONER_THAN_X_US;
   TAFR(resAll, "DST_NON_WAKEUP_META_EVENT expected to occur no sooner than %d us since last Non-wakeup event but occured %u us before",
        META_EVENT_NO_SOONER_THAN_X_US, dif_us);
   return resAll;
}


// Enable all used sensors and compute test time and all sensors expected events count
// us: used sensors
// first_sensor_exp_events: First sensor expected number of events
//    - based on this requirement test time is computed
int t_8_11_en_sensors_and_count_events(t_8_11_use_sens_t *us, int first_sensor_exp_events)
{
#define LATENCY_8_11_MS 5000
   int i;
   int sr = 50;                                                      // sensor rate - use 50Hz for all sensors
   u16 qsr;                                                          // queried sensor rate
   u16 l = LATENCY_8_11_MS;                                          // sensor latency
   u16 ql;                                                           // queried sensor latency
   int period_ms;
   for (i = 0; i < us->sz; i++)
   {
      TEST_ASSERT(set_and_chk_lat(us->s[i], l, &ql, TRUE));
      TEST_ASSERT(set_and_chk_rate(us->s[i], sr, &qsr, TRUE));
      period_ms = (int)(1000.0 / qsr);
      if (i == 0)
      {
         us->time_delay_ms = period_ms * first_sensor_exp_events;
         APR(us->time_delay_ms < LATENCY_8_11_MS * 0.9, TEST_FAILED,
             "Period for %d events is longer than latency, increase latency time for this test to perform!\n",
             first_sensor_exp_events)
      }
      us->exp_evns[i] = us->time_delay_ms / period_ms;
   }
   return TEST_PASSED;
}


// epxected events for first sensor
#define T_8_11_EXP_EVENTS 20
// Test all possible flush commands
// - First flush fifo to start without data
// - wait some time to generate some data to FIFOs
// - then use flush commands
// - then check that
//   - data are appropriate for flush comand
//   - FLUSH meta event was generated
//   - first is W FIFO then NW FIFO
// s: list of used Sensors
// flush_cmd: flush command to test
void test_flush(t_8_11_use_sens_t *s, DI_SENSOR_TYPE_T flush_cmd)
{
   u32 smplRcv;
   RegIntStatus expIntr;
   int i;
   u32 start;
   u32 elapsed;

   expIntr.reg = 0;
   expIntr.bits.HostInterrupt = 1;
   if (di->hi_id != HIID_KITKAT)
   {
      expIntr.bits.NonWakeupImmediate = 1;
      expIntr.bits.WakeupImmediate = 1;
   }

   info_log("==========\n");
   info_log("this part will test flush cmd: 0x%02x\n", flush_cmd);
   info_log("## time: %u\n", time_ms());
   t_8_11_en_sensors_and_count_events(s, T_8_11_EXP_EVENTS);
   info_log("FLUSH all data at the beginning of test...\n");
   TAFR(di_fifo_flush(di, DST_FLUSH_ALL), "Did not manage to flush FIFOs");
   info_log("## time: %u\n", time_ms());
   read_out_while_intr(500, &smplRcv, 9);
   info_log("flushed %d events\n", smplRcv);
   fifo_discard();

   info_log("1.0 check no interrupt and no data received (long latency is set)\n");
   start = time_ms(); // must measure actual time in order to estimate actual number of samples in the FIFO
   info_log("## time: %u\n", start);
   t_8_11_data_reset();
   read_out_while_intr(500, &smplRcv, 9);
   TAFR(smplRcv == 0,
        "We do not expect data due to high latency but we got interrupt and received %d events\n",
        smplRcv);
   if (smplRcv != 0)
   {
      t_8_11_disp(smplRcv, s, FALSE);
      t_8_11_data_reset();
   }

   info_log("1.1 wait %d [ms] to generate sensor events\n", s->time_delay_ms);
   // wait approx for 10 sensor events
   time_delay_ms(s->time_delay_ms);
   info_log("## time: %u\n", time_ms());

   info_log("1.2 check that no interrupt was generated\n");
   checkHostIntr(0, 100, 10);
   info_log("## time: %u\n", time_ms());

   info_log("1.3 flush(0x%02x)", flush_cmd);
   switch (flush_cmd)
   {
      case 0x00:                                                     // 00 nop
         info_log(" - No Operation (acts like 0xFF on 7183 di01)\n");
         break;
      case DST_FLUSH_ALL :                                           // FF flush W+NW (in respective order)
         info_log(" - FF flush W+NW (in respective order)\n");
         break;
      case DST_FLUSH_W:                                              // FD flush W    but   flush W+NW
      case DST_FLUSH_NW:                                             // FC flush NW   but   flush W+NW
         info_log(" - same as 0xFF flush W+NW\n");
         break;
      case DST_DISCARD_ALL:                                          // FE discard both
         info_log(" - FE discard both\n");
         break;
      case DST_DISCARD_W:                                            // FB discard W
         info_log(" - discard W\n");
         break;
      case DST_DISCARD_NW:                                           // FA discard NW
         info_log(" - discard NW\n");
         break;
      default:
         info_log(" - flush one sensor = flush all\n");
         break;
   }
   TAFR(di_fifo_flush(di, flush_cmd), "fail fifo_flush(%d)", flush_cmd);
   elapsed = time_ms() - start;
   info_log("## time: %u\n", time_ms());
   
   // flush = 0x00 cannot be easily patched on the 7183 di01
   if ((flush_cmd == 0x00 && !(di->product_id == 0x83 && di->revision_id == 0x01)) || (flush_cmd == DST_DISCARD_ALL) || (flush_cmd == DST_DISCARD_W) || (flush_cmd == DST_DISCARD_NW))
   {                                                                 // discard FIFO or no-operation
      info_log("1.3.2 check that interrupt was not generated on discard cmd\n");
      checkHostIntr(0, 100, 10);
      info_log("1.3.3 flush and check data was discarded\n");
      TAFR(di_fifo_flush(di, DST_FLUSH_ALL), "fail fifo_flush(%d)", flush_cmd);
      // set expected data to 0 if FIFO was discarded
      for (i = 0; i < s->sz; i++)
      {
         if (flush_cmd == DST_DISCARD_ALL)
         {                                                           // discard W + NW
            s->exp_evns[i] = 0;
         }
         else if ((flush_cmd == DST_DISCARD_W) && is_wakeup_event(di, s->s[i]))
         {                                                           // FB discard W
            s->exp_evns[i] = 0;
         }
         else if ((flush_cmd == DST_DISCARD_NW) && !is_wakeup_event(di, s->s[i]))
         {                                                           // FA discard NW
            s->exp_evns[i] = 0;
         }
      }
   }

   info_log("1.4 check that interrupt was generated\n");
   checkHostIntr(expIntr.reg, 1000, 100);                            // PETE: check longer, system doesn't always come up that fast under all conditions
   info_log("## time: %u\n", time_ms());

   info_log("1.5 read out data and check that expected number of sensor events received\n");
   read_out_while_intr(1000, &smplRcv, 9);                           // PETE: restored to 9
   info_log("## time: %u\n", time_ms());

   t_8_11_disp(smplRcv, s, TRUE);

   info_log("expected sample generation time %u ms, but actually %u ms; adjusting counts\n", s->time_delay_ms, elapsed);
   for (i = 0; i < s->sz; i++)
   {
      if (s->time_delay_ms)
         s->exp_evns[i] = (s->exp_evns[i] * elapsed) / s->time_delay_ms; // correct the estimated events count based on actual time delay rather than intended time delay
      chk_sens_cnt(s->s[i], s->exp_evns[i]);
   }
   if ((di->hi_id != HIID_KITKAT) &&                                 // only Android L has a wakeup FIFO
       (
        ((flush_cmd >= di_wake_sensor_start(di)) && (flush_cmd <= di_max_sensor_id(di))) || // wakeup sensor specified
        (flush_cmd == DST_FLUSH_W) ||                                // flush just wakeup FIFO (actually empties both)
        (flush_cmd == DST_FLUSH_ALL)                                 // flush both
       )
      )
   {
      chk_last_w_meta_flush();
   }
   if ((di->hi_id == HIID_KITKAT) ||                                 // any command for non-Android L generates a regular flush event;
       (                                                             // Android L also generates it if a non-wakeup sensor or related command was given
        (flush_cmd < di_wake_sensor_start(di)) ||                    // non-wakeup sensor
        (flush_cmd == DST_FLUSH_NW) ||                               // flush the nonwake FIFO (empties both)
        (flush_cmd == DST_FLUSH_ALL)                                 // flush both
       )
      )
   {
      chk_last_meta_flush();
   }

   TAFR(g_8_11_d.W_after_NW == 0,
        "not expecting W event after NW but got %d NW->W transitions!\n",
        g_8_11_d.W_after_NW);

   info_log("1.6 check host interrupt is cleared\n");
   checkHostIntr(0, 100, 10);
   info_log("## time: %u\n", time_ms());

   info_log("1.7 turn off used sensors\n");
   set_list_sensors_rate(s->sz, s->s, 0);
   info_log("## time: %u\n", time_ms());
   fifo_discard();                                                   // PETE: need to remove all data, or next test fails at times
}


// test 8.11 to check all FLUSH command variants
TEST_START(8_11)
{
   DI_SENSOR_TYPE_T searchSensors[] = {
      DST_ACCELEROMETER, DST_GYROSCOPE, DST_GEOMAGNETIC_FIELD,
      DST_ORIENTATION, DST_ROTATION_VECTOR, DST_GAME_ROTATION_VECTOR,
      DST_GEOMAGNETIC_ROTATION_VECTOR
   };
   int searchSensorsSz = sizeof(searchSensors) / sizeof(searchSensors[0]);
   available_sensors_t as;                                           // available sensors
   t_8_11_use_sens_t us;                                             // use sensors

   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);

   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   avail_sens_list(searchSensorsSz, searchSensors, &as);
   TEST_ASSERTF(as.c > 0, "No sensors found");
   avail_sens_turn_off(&as);

   t_8_11_data_reset();
   TEST_ASSERT(di_register(di, t_8_11_data_callback, (void *)di));

   us.sz = 1;
   us.s[0] = as.s[0];
   test_flush(&us, DST_FLUSH_ALL);                                   // FF flush all
   test_flush(&us, us.s[0]);                                         // flush one sensor what means all
                                                                     // flush non existing sensor - TODO make it report error - or discard this test if Pete agree
                                                                     //test_flush(&us,DST_NUM_SENSOR_TYPES);
   test_flush(&us, 0x00);                                            // No operation

   if (as.c > 1)
   {
      us.sz = 2;
      us.s[1] = as.s[1];
      test_flush(&us, DST_FLUSH_ALL);                                // FF flush all
      test_flush(&us, us.s[0]);                                      // flush one sensor what means all
      test_flush(&us, 0x00);                                         // No operation
   }

   test_flush(&us, DST_DISCARD_ALL);                                 // FE discard both W+NW
   if (di->hi_id == HIID_KITKAT)
   {
      return g_current_test_retval;
   }

   us.sz = 2;
   us.s[1] = as.sw[0];
   test_flush(&us, DST_FLUSH_ALL);

   test_flush(&us, DST_FLUSH_W);                                     // FD flush W       flush W+NW
   test_flush(&us, DST_FLUSH_NW);                                    // FC flush NW      flush W+NW
   test_flush(&us, DST_DISCARD_ALL);                                 // FE discard both W+NW
   test_flush(&us, DST_DISCARD_W);                                   // FB discard W
   test_flush(&us, DST_DISCARD_NW);                                  // FA discard NW
   test_flush(&us, us.s[0]);                                         // flush one sensor what means all
   test_flush(&us, us.s[1]);                                         // flush one sensor what means all
   test_flush(&us, 0x00);                                            // No operation

   return g_current_test_retval;
}
TEST_END


