#include "test_common.h"

/***************************************************************************************
 * 6. Sensor Initialization
 **************************************************************************************/
/**
 * PRIORITY 2
 *  As indicated by nonzero Sensor Status parameters, sensors present match the loaded
 *  firmware (TBD how many combos to test?)
 */
TEST_START(6_1)
{
   SENSOR_STATUS sensor_status;
   int i;
   DI_SENSOR_TYPE_T sensors[3] = {DST_ACCELEROMETER, DST_GYROSCOPE, DST_GEOMAGNETIC_FIELD};
   bool got_i2c_nack = FALSE;
   bool got_device_id_error = FALSE;

   set_rates(50, 50, 50, 0);
   set_latencies(0, 0, 0, 0);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.incompatible_firmware, TRUE));
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(2000, FALSE));

   TEST_ASSERT(di_query_sensor_status(di));

   for (i = 0; i < 3; i++)
   {
      TEST_ASSERT(di_read_sensor_status(di, sensors[i], &sensor_status));
      if (sensor_status.i2c_nack)
      {
         got_i2c_nack = TRUE;
         info_log("got i2c nack on sensor %u %s\n", sensors[i], di_query_sensor_name(di, sensors[i]));
      }
      if (sensor_status.device_id_error)
      {
         got_device_id_error = TRUE;
         info_log("got device id error on sensor %u %s\n", sensors[i], di_query_sensor_name(di, sensors[i]));
      }
   }
   TEST_ASSERT(got_i2c_nack && got_device_id_error);
   return TEST_PASSED;
}
TEST_END


/**
 * PRIORITY 2
 * \brief If a required physical sensor is not present but
 * should be, confirm it is missing by means of Sensor Status
 * Bits I2C_NACK and/or Device ID Error
 * NOTE: absorbed into 6.1
 */
TEST_START(6_2)
{
   return TEST_NOT_IMPLEMENTED;
}
TEST_END


/**
 * PRIORITY 2
 * \brief Load a known-mismatched firmware image with a
 * sensor driver expecting a different WHO_AM_I register at the
 * same I2C address as an installed hardware sensor; confirm we
 * get a Device ID Error
 * NOTE: absorbed into 6.1
 */
TEST_START(6_3)
{
   return TEST_NOT_IMPLEMENTED;
}
TEST_END
