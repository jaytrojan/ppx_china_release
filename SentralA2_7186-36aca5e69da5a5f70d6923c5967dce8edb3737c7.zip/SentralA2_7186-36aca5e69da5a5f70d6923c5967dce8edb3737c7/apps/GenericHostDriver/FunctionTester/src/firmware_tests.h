/**
 * \file    firmware_tests.h
 *
 * \brief   firmware tests
 *
 * \copyright (C) 2013-2014 EM Microelectronic
 *
 */

#ifndef _FIRMWARE_TESTS_H_
#define _FIRMWARE_TESTS_H_

#include "types.h"
#include "host_services.h"
#include "driver_ext.h"
#include "EEPROMImage.h"

#define TEST_PASSED     0
#define TEST_FAILED     1
#define TEST_SKIPPED 2
#define TEST_NOT_IMPLEMENTED  3

#define TEST_ABORTED -1

typedef int (*test_function)(bool first_loop);

struct test_desc
{
   test_function  handler;
   const char     *name;
   const char     *desc;
   int             loop_count;
   int            iterations;
   int            result;
};

// set 1 for all tests to be detailed
#define ALL_TESTS_DETAILED 0

extern int get_num_tests(void);
extern struct test_desc *find_test(const char *name);
extern struct test_desc *get_test(int index);
extern int test_run_all(DI_INSTANCE_T *instance);
void set_all_tests_loop(int loops);

//----

typedef struct test_settings
{
   int prn_host_intr; // print host itnerrupt status
} test_settings_t;

void gtp_init();

#endif

