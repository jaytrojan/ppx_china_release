#include "test_common.h"

/***************************************************************************************
 * 5. Interrupt and Exception Handling
 **************************************************************************************/
//-----------------------------------------------------------------------------
// 5.1. Host Interface Control Register Host Interrupt Enable bit works properly
// Implemented according test plan v1.8
// TODO test it also with android K
TEST_START(5_1)
{
   RegHostStatus hst;
   u32 smplRecv;
   int sPMs;                                                         // sensor period [ms]
   int lat;                                                          // latency
   int loops;
   int loopCnt;
   bool wakeUpSensor;
   RegIntStatus expIntr;
   lat = 1000;                                                       // PETE: lengthen latency so test runs successfully on more systems
   sPMs = 1000 / config.accel_norm_rate;

   set_rates(config.accel_norm_rate, 0, 0, 0);
   set_latencies(lat, 0, 0, 0);

   if (first_loop)
   {
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
   }
   else
   {
      TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER, accel_rate, accel_latency));
      if (di->hi_id != HIID_KITKAT)
      {
         TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER | di_wake_sensor_start(di), 0, 0));
      }
   }

   if (di->hi_id != HIID_KITKAT)
      loops = 2;
   else
      loops = 1;

   for (loopCnt = 0; loopCnt < loops; loopCnt++)
   {
      expIntr.reg = 0;
      expIntr.bits.HostInterrupt = 1;
      if (loopCnt == 1)
      {
         info_log("5.1_0 Testing     Wakeup Accelerometer\n");
         TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER, 0, 0));
         if (di->hi_id != HIID_KITKAT)
         {
            TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER | di_wake_sensor_start(di), accel_rate, accel_latency));
         }
         wakeUpSensor = TRUE;
         expIntr.bits.WakeupLatency = 1;
         time_delay_ms(10);
      }
      else
      {
         info_log("5.1_0 Testing Non Wakeup Accelerometer\n");
         wakeUpSensor = FALSE;
         if (di->hi_id != HIID_KITKAT)
         {
            expIntr.bits.NonWakeupLatency = 1;
         }
      }
      TEST_ASSERT(read_out_while_intr(2000, &smplRecv, 9));
      //-------------------------------------------------------------------------
      info_log("5.1_1 enable host interrupt\n");
      info_log("time: %u ms\n", time_ms());
      setAndTestHostIntrDisable(0, wakeUpSensor);
      info_log("5.1_2 clear host interrupt if asserted by reset\n");
      info_log("time: %u ms\n", time_ms());
      TEST_ASSERT(di_reg_read(di, SR_HOST_STATUS, &hst.reg, 1));
      info_log("5.1_3 clear host interrupt if asserted by data\n");
      info_log("time: %u ms\n", time_ms());
      time_delay_ms(1000);
      flushBothFifoAndCheckEmpty();
      info_log("5.1_4 check interrupt cleared\n");
      info_log("time: %u ms\n", time_ms());
      checkHostIntr(0x00, lat + 500, 50);
      info_log("5.1_5 check interrupt is set\n");
      info_log("time: %u ms\n", time_ms());
      checkHostIntr(expIntr.reg, lat * 2, lat / 2);
      info_log("time: %u ms\n", time_ms());
      time_delay_ms(1000);
      flushBothFifoAndCheckEmpty();
      info_log("5.1_6 check interrupt cleared\n");
      info_log("time: %u ms\n", time_ms());
      checkHostIntr(0x00, lat + 500, 50);
      //-------------------------------------------------------------------------
      info_log("5.1_7 disable host int\n");
      info_log("time: %u ms\n", time_ms());
      setAndTestHostIntrDisable(1, wakeUpSensor);
      info_log("time: %u ms\n", time_ms());
      // this is not correct; if the interrupt is masked, bits 1-7 can still get set in the int status register
      // checkHostIntr(0x00, 0, 0);
      info_log("5.1_8 check enough time for interrupt\n");
      info_log("time: %u ms\n", time_ms());
      TAFR(FALSE == try_with_time_limit(check_IntStat_HostIntr_1, lat * 3, lat / 2),
           "Expecting that host interrupt won't be set, but it was!");
      info_log("time: %u ms\n", time_ms());
      expIntr.bits.HostInterrupt = 0;
      checkHostIntr(expIntr.reg, 0, 0);                              // masking the interrupt only stops the HostInterrupt bit from being set, not the other status bits
      info_log("5.1_9 enable host int\n");
      info_log("time: %u ms\n", time_ms());
      setAndTestHostIntrDisable(0, wakeUpSensor);
      info_log("5.1_10 check interrupt is set\n");
      info_log("time: %u ms\n", time_ms());
      expIntr.bits.HostInterrupt = 1;
      time_delay_ms(lat + 300);
      info_log("time: %u ms\n", time_ms());
      checkHostIntr(expIntr.reg, 0, 0);
      info_log("time: %u ms\n", time_ms());
      flushBothFifoAndCheckEmpty();
      info_log("5.1_11 check interrupt cleared\n");
      info_log("time: %u ms\n", time_ms());
      checkHostIntr(0x00, lat + 500, 50);
      //-------------------------------------------------------------------------
      info_log("5.1_12 check interrupt is set\n");
      info_log("time: %u ms\n", time_ms());
      checkHostIntr(expIntr.reg, lat * 2, lat / 2);
      info_log("5.1_13 disable host int\n");
      info_log("time: %u ms\n", time_ms());
      setAndTestHostIntrDisable(1, wakeUpSensor);
      info_log("time: %u ms\n", time_ms());
      checkHostIntr(expIntr.reg & 0xFE, 0, 0);
      info_log("5.1_14 enable host int\n");
      info_log("time: %u ms\n", time_ms());
      setAndTestHostIntrDisable(0, wakeUpSensor);
      info_log("time: %u ms\n", time_ms());
      checkHostIntr(expIntr.reg, 0, 0);
      info_log("time: %u ms\n", time_ms());
   }

   // clean up so if we run multiple loops of this test it will work
   TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER, 0, 0));
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER | di_wake_sensor_start(di), 0, 0));
   }
   fifo_discard();
   flushBothFifoAndCheckEmpty();

   return g_current_test_retval;
}
TEST_END

/**
 *  Enable just the reset interrupt; issue a reset request to the Reset Request register
 */
TEST_START(5_2)
{
   RegResetRequest reset;
   RegHostStatus hst;
   RegChipStatus cst;
   ATOMIC_INT start_int_count;
   u32 start;

   // first, set everything up -- previous tests have changed EEPROM
   default_rates();
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

   TEST_ASSERT(di_reg_read(di, SR_HOST_STATUS, &hst.reg, 1));
   TEST_ASSERT(hst.bits.CPUReset == 0);                              // this should be cleared once the RAM patch is loaded and running

   TEST_ASSERT(di_shutdown_request(di));
   time_delay_ms(1000);

   start_int_count = di->interrupt;

   // now reset U718x
   reset.reg = 0;
   reset.bits.ResetRequest = 1;
   TEST_ASSERT(di_reg_write(di, SR_RESET_REQ, &reset.reg, 1));

   start = time_ms();
   // keep reading U718x status until EEPROM Upload comes to a conclusion
   for (;;)
   {
      irq_check(di->irq_handle);
      TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cst.reg, 1));
      time_delay_ms(50);
      if (time_ms() > (start + TEST_5_2_TIME))
      {
         info_log("timeout waiting for proper U718x status: 0x%02X\n", cst.reg);
         break;
      }
      if (cst.bits.FirmwareHalted)
      {
         if (cst.bits.EEUploadError ||
             cst.bits.EEUploadDone ||
             cst.bits.NoEEPROM)
            break;
      }
   }
   TEST_ASSERT(di_reg_read(di, SR_HOST_STATUS, &hst.reg, 1));

   // make sure we got an interrupt, and not the Error one
   irq_check(di->irq_handle);
   if ((di->interrupt != start_int_count) && hst.bits.CPUReset)
   {
      //display_error_info(di);
      info_log("Got reset event\n");
      return TEST_PASSED;
   }
   else if (!irq_is_reliable(di->irq_handle) && hst.bits.CPUReset)
   {
      info_log("Simulated reset event\n");
      return TEST_PASSED;
   }
   else
   {
      if (di->interrupt == start_int_count)
         info_log("no change interrupt counter\n");
      return TEST_FAILED;
   }
}
TEST_END
