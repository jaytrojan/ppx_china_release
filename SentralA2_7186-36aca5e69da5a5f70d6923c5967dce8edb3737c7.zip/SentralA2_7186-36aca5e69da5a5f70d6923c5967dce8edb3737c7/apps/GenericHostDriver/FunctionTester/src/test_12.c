#include "test_common.h"

/***************************************************************************************
 * 12. I2C Pass through Mode
 **************************************************************************************/

/**
 * general operation of pass through (enter, communicate with
 * EEPROM, exit)
 */
TEST_START(12_1)
{
   return TEST_NOT_IMPLEMENTED;
}
TEST_END


/**
 * \brief SCLLowCycles + SensorToHostEn works (test using
 * oscilloscope and sensor that is known to stretch the clock)?
 * this always passes
 */
TEST_START(12_2)
{
   return TEST_NOT_IMPLEMENTED;
}
TEST_END


/**
 * PRIORITY 1
 * \brief U718x resumes properly after passthrough
 */
TEST_START(12_3)
{
   u8 buf[sizeof(EEPROMHeader) + 2];                                 // add two more bytes for the EEPROM address
   u16 eeprom_addr;
   DI_SENSOR_TYPE_T sensor;
   int i;

   default_rates();
   // start gathering data, using whatever's in EEPROM
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   // run for a while, measuring actual sample rates during this time
   reset_stats();
   restart_stats_time();
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_12_3_RUN_TIME, FALSE));

   // make sure that there are samples coming through
   calc_periodic_stats(di);
   display_periodic_stats(di, FALSE);
   if (rotation_sensor == DST_NOP)
   {
      if (di_has_sensor(di, DST_GRAVITY))
         sensor = DST_GRAVITY;
      else
         sensor = DST_ACCELEROMETER;
   }
   else
      sensor = rotation_sensor;
   TEST_ASSERT(get_measured_sample_rate(sensor) != 0);

   for (i = 1; i < TEST_12_3_LOOPS; i++)
   {
      // stop algorithm
      TEST_ASSERT(di_standby_request(di));

      // go into passthrough mode
      TEST_ASSERT(di_set_passthrough_mode(di, TRUE));

      // read the header from address 0
      info_log("try to read EEPROM header...\n");
      eeprom_addr = 0;
      buf[0] = (eeprom_addr >> 8) & 0x0ff;
      buf[1] = eeprom_addr & 0x0ff;

      i2c_blocking_write_read(eeprom_i2c_handle, &buf[0], 2, &buf[2], sizeof(EEPROMHeader));

      info_log("leave passthrough mode...\n");
      TEST_ASSERT(di_set_passthrough_mode(di, FALSE));

      // continue algorithm
      TEST_ASSERT(di_normal_exec_request(di));

      // run for a while, measuring actual sample rates during this time
      reset_stats();
      restart_stats_time();
      TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_12_3_RUN_TIME, FALSE));

      // make sure we still get samples
      calc_periodic_stats(di);
      display_periodic_stats(di, FALSE);
      TEST_ASSERT(get_measured_sample_rate(sensor) != 0);
   }
   return TEST_PASSED;
}
TEST_END
