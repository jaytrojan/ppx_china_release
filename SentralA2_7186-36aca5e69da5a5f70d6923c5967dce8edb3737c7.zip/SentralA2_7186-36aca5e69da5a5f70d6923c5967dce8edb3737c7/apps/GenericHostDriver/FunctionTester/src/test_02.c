#include "test_common.h"

/***************************************************************************************
 * 2. RAM Upload Tests
 **************************************************************************************/

/**
 * Upload valid image; confirm the Idle bit and NoEEPROM bits are correct in Chip Status,
 * and CRC Host registers match the expected CRC
 */
TEST_START(2_1)
{
   RegHostStatus  hs;
   RegChipStatus  cs;

   if (config.eeprom_present)
   {
      info_log("erasing EEPROM...\n");
      TEST_ASSERT(di_erase_eeprom(di, eeprom_i2c_handle));
   }

   info_log("Uploading to RAM...\n");
   TEST_ASSERT(di_upload_firmware(di, config.normal_firmware, 0, NULL));
   TEST_ASSERT(di_run_request(di));                                  // start it running

   time_delay_ms(1000);                                              // give it time to succeed or fail

   TEST_ASSERT(di_reg_read(di, SR_HOST_STATUS, &hs.reg, 1));
   TEST_ASSERT(!hs.bits.CPUReset);
   TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1))

   info_log("U718x Status: 0x%02X\n", cs.reg);
   if (config.eeprom_present)
   {
      TEST_ASSERT(!cs.bits.EEUploadDone && !cs.bits.EEUploadError && cs.bits.NoEEPROM);
   }
   else
   {
      TEST_ASSERT(!cs.bits.EEUploadDone && !cs.bits.EEUploadError && cs.bits.NoEEPROM);
   }

   return TEST_PASSED;
}
TEST_END


/**
 * \brief Invalid Image
 * confirm correct behavior (reset / error register?)
 */
TEST_START(2_2)
{
   RegHostStatus  hs;
   RegChipStatus  cs;

   if (config.eeprom_present)
   {
      info_log("erasing EEPROM...\n");
      TEST_ASSERT(di_erase_eeprom(di, eeprom_i2c_handle));
   }

   info_log("Uploading to RAM...\n");
   TEST_ASSERT(di_upload_firmware(di, config.wrong_firmware, TRUE, NULL));
   TEST_ASSERT(di_run_request(di));                                  // start it running

   time_delay_ms(2000);                                              // give it time to succeed or fail
   dump_all_registers(di);

   TEST_ASSERT(di_reg_read(di, SR_HOST_STATUS, &hs.reg, 1));
   TEST_ASSERT(hs.bits.CPUReset && !config.eeprom_present);

   TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1))

   info_log("Chip Status: 0x%02X\n", cs.reg);
   TEST_ASSERT((cs.bits.EEUploadDone && cs.bits.EEUploadError && cs.bits.NoEEPROM) || !config.eeprom_present);
   return TEST_PASSED;
}
TEST_END
