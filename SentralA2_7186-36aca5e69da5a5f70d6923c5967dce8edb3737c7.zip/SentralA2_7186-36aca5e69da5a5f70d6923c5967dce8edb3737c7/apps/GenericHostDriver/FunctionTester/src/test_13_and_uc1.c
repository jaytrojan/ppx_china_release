#include "test_common.h"

#define TOLERATE_RATE_AT_200HZ
#define COMPENSATE_OVERFLOW

/***************************************************************************************
 * 13. Configuration
 **************************************************************************************/
/**
 * \brief Configuration
 * Read firmware version register and confirm it matches the
 * build number
 */
TEST_START(13_1)
{
   u8 product_id;
   u8 revision_id;
   u16 rom_version;
   u16 ram_version;
   bool eeprom_present;

   default_rates();
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, FALSE));

   // now that we're running, we can check the ram version
   TEST_ASSERT(di_detect_chip(di, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present));
   info_log("ram version is now: %u; expected %u\n", ram_version, config.expected_ram_version);
   TEST_ASSERT(ram_version == config.expected_ram_version);
   return TEST_PASSED;
}
TEST_END

/**
 * PRIORITY 2
 * \brief Sensor Independence
 * Turn on sensors one-by-one and ensure there is no data from any other sensors
 */
struct test_uc_1_data
{
   bool  enabled_sensors[255];
   u32   disabled_sensor_samples;
   u32   invalid_sensor_samples;
   u32   value_errors;
   u32   fifo_ovf;                                                   // fifo overflow
};

struct test_uc_1_sensor_entry
{
   DI_SENSOR_TYPE_T     sensor;
   bool                 wakeup;
   u32                  rate;                                        // rate to be used in test
   u16                  discard_count;                               // number of samples to skip while sensor warms up
   bool                 ignore_actual_rate;                          // do not check actual rate (typicaly for gesture sensor, where rate is not applicable)

   bool                 present_in_system;                           // true if sensor is present in system
   u16                  discarded;                                   // count down when sensor turned on

   u32                  req_rate;                                    // requested rate [Hz]
   u32                  actual_rate;                                 // rate returned from device
   u32                  actual_rate_previous;                        // rate returned from device previously

   bool                 updated_actual_rate;                         // updated actual rate since rate requested
   bool                 ovf_plausible;                               // overflow plausible

   u32                  smpl_rate_chg_req_tm_ms;                     // sample rate change request time in [ms]

   u32                  timestamp_first_smpl_us;                     // timestamp of first sample [us]
   bool                 timestamp_last_smpl;                         // last timestamp available.
   u32                  timestamp_last_smpl_us;                      // timestamp of last sample [us]
   u32                  sample_count;                                // number of samples
   double               timestamp_measured_rate;                     // timestamp measured rate [Hz]
} test_uc_1_sensor_list[] = {
   { DST_ACCELEROMETER,                      FALSE, 200, 25, FALSE },
   { DST_GEOMAGNETIC_FIELD,                  FALSE, 200, 5,  FALSE }, // was TRUE why?
   { DST_ORIENTATION,                        FALSE, 200, 5,  FALSE },
   { DST_GYROSCOPE,                          FALSE, 200, 5,  FALSE },
   { DST_GRAVITY,                            FALSE, 200, 5,  FALSE },
   { DST_LINEAR_ACCELERATION,                FALSE, 200, 25, FALSE },
   { DST_ROTATION_VECTOR,                    FALSE, 200, 5,  FALSE },
   { DST_MAGNETIC_FIELD_UNCALIBRATED,        FALSE, 200, 5,  FALSE }, // was TRUE why?
   { DST_GAME_ROTATION_VECTOR,               FALSE, 200, 5,  FALSE },
   { DST_GYROSCOPE_UNCALIBRATED,             FALSE, 200, 5,  FALSE },
   { DST_SIGNIFICANT_MOTION,                 FALSE, 200, 0,  TRUE },
   { DST_STEP_DETECTOR,                      FALSE, 200, 0,  TRUE },
   { DST_STEP_COUNTER,                       FALSE, 200, 0,  TRUE },
   { DST_GEOMAGNETIC_ROTATION_VECTOR,        FALSE, 200, 5,  FALSE },
#if !defined(DI_SLIM)
   { DST_ACCELEROMETER,                      TRUE, 200, 25,  FALSE },
   { DST_GEOMAGNETIC_FIELD,                  TRUE, 200, 5,   FALSE }, // was TRUE why?
   { DST_ORIENTATION,                        TRUE, 200, 5,   FALSE },
   { DST_GYROSCOPE,                          TRUE, 200, 5,   FALSE },
   { DST_GRAVITY,                            TRUE, 200, 5,   FALSE },
   { DST_LINEAR_ACCELERATION,                TRUE, 200, 25,  FALSE },
   { DST_ROTATION_VECTOR,                    TRUE, 200, 5,  FALSE },
   { DST_MAGNETIC_FIELD_UNCALIBRATED,        TRUE, 200, 5,  FALSE }, // was TRUE why?
   { DST_GAME_ROTATION_VECTOR,               TRUE, 200, 5,  FALSE },
   { DST_GYROSCOPE_UNCALIBRATED,             TRUE, 200, 5,  FALSE },
   { DST_SIGNIFICANT_MOTION,                 TRUE, 200, 0,  TRUE },
   { DST_STEP_DETECTOR,                      TRUE, 200, 0,  TRUE },
   { DST_STEP_COUNTER,                       TRUE, 200, 0,  TRUE },
   { DST_GEOMAGNETIC_ROTATION_VECTOR,        TRUE, 200, 5,  FALSE },

   { DST_TILT_DETECTOR,                      FALSE, 200, 5,  TRUE },
   { DST_TILT_DETECTOR,                      TRUE,  200, 5,  TRUE },
   { DST_WAKE_GESTURE,                       FALSE, 200, 5,  TRUE },
   { DST_WAKE_GESTURE,                       TRUE,  200, 5,  TRUE },
   { DST_GLANCE_GESTURE,                     FALSE, 200, 5,  TRUE },
   { DST_GLANCE_GESTURE,                     TRUE,  200, 5,  TRUE },
   { DST_PICKUP_GESTURE,                     FALSE, 200, 5,  TRUE },
   { DST_PICKUP_GESTURE,                     TRUE,  200, 5,  TRUE },
   { DST_ACTIVITY,                           FALSE, 200, 5,  TRUE },
   { DST_ACTIVITY,                           TRUE,  200, 5,  TRUE },
#endif
};

typedef struct
{
   DI_SENSOR_TYPE_T    sensor;
   u32                 req_rate;                                     // requested rate
   u32                 set_rate_pc_time_ms;                          // PC time when rate was se (in [ms])
   u32                 first_smpl_pc_time_ms;                        // PC time when first sample was received
} t_uc_1;

t_uc_1 g_tst_uc_1;

void init_test_uc1()
{
   int i;
   for (i = 0; i < ARRAY_SIZE(test_uc_1_sensor_list); i++)
   {
      struct test_uc_1_sensor_entry *se = &test_uc_1_sensor_list[i];
      if (se->wakeup)
         se->sensor |= di_wake_sensor_start(di);
      se->discarded = se->discard_count;

      se->present_in_system = TRUE;

      if (di->hi_id == HIID_KITKAT)
      {
         if (se->sensor > di_max_sensor_id(di))                      // no wakeup sensors for KK
         {
            se->present_in_system = FALSE;
         }
         else if (!di_has_sensor(di, se->sensor))
         {
            se->present_in_system = FALSE;
         }
      }
      else
      {
         if (!di_has_sensor(di, se->sensor))
         {
            se->present_in_system = FALSE;
         }
      }

      se->req_rate = 0;                                              // requested rate [Hz]            u32
      se->actual_rate = 0;                                           // rate returned from device      u32
      se->actual_rate_previous = 0;                                  // rate returned from device      u32

      se->ovf_plausible = FALSE;                                     // FIFO overflow plausible

      se->smpl_rate_chg_req_tm_ms = 0;                               //                  u32
      se->updated_actual_rate = FALSE;

      se->timestamp_first_smpl_us = 0;                               //                  u32
      se->timestamp_last_smpl_us  = 0;                               //                  u32
      se->timestamp_last_smpl = FALSE;                               //                  bool
      se->sample_count = 0;                                          //                  u32
      se->timestamp_measured_rate = 0;                               //                  double


   }
}
#define UC_1_LATENCY 0

static struct test_uc_1_sensor_entry *test_uc_1_find_entry(DI_SENSOR_TYPE_T sensor)
{
   int i;
   for (i = 0; i < ARRAY_SIZE(test_uc_1_sensor_list); i++)
   {
      struct test_uc_1_sensor_entry *se = &test_uc_1_sensor_list[i];
      if (se->wakeup)
         se->sensor |= di_wake_sensor_start(di);
      if (se->sensor == sensor)
         return se;

   }

   return NULL;
}

#define MAX_VECTOR 4
struct vect
{
   int    len;
   double d[MAX_VECTOR];
   u32 t;
};

/* calculate the magnitude of a vector */
double vect_magnitude(struct vect *v)
{
   double s = 0.0;
   int i;
   for (i = 0; i < v->len; i++)
      s += pow(v->d[i], 2);

   return sqrt(s);
}

/* are the elements in v1 approximately equal to the corresponding elements in v2, +- e */
bool  vect_is_approx(struct vect *v1, struct vect *v2, double e)
{
   int i;

   BOOL_ASSERT(v1->len == v2->len);

   for (i = 0; i < v1->len; i++)
      BOOL_ASSERTF(is_approx(v1->d[i], v2->d[i], e), "i=%d: v1=%f v2=%f e=%f", i, v1->d[i], v2->d[i], e);

   return TRUE;
}

/* are the elements of v1 within the range of the corresponding elements in vmin, vmax */
bool vect_is_inrange(struct vect *v1, struct vect *vmin, struct vect *vmax)
{
   int i;

   BOOL_ASSERT((v1->len == vmin->len) &&
               (v1->len == vmax->len));

   for (i = 0; i < v1->len; i++)
   {
      BOOL_ASSERTF((v1->d[i] >= vmin->d[i]) &&
                   (v1->d[i] <= vmax->d[i]), "i=%d: v1=%f vmin=%f vmax=%f", i, v1->d[i], vmin->d[i], vmax->d[i]);
   }

   return TRUE;
}



void test_uc_1_logger(DI_SENSOR_DATA_T *data, DI_SENSOR_TYPE_T sensor)
{
   DI_SENSOR_TYPE_T base_sensor;
#if !defined(DI_SLIM)
   if (di->hi_id == HIID_KITKAT)
      base_sensor = sensor;
   else
      base_sensor = sensor & ~di_wake_sensor_start(di);
#else
   base_sensor = sensor;
#endif
   switch (base_sensor)
   {
      case DST_ACCELEROMETER:
         info_log("     accel, % f, % f, % f, %u, %u, %f\n", data->accel.x, data->accel.y, data->accel.z, data->accel.status, data->accel.t, magnitude_3axis((DI_3AXIS_DATA_T *)&data->accel));
         break;
      case DST_GYROSCOPE:
         info_log("      gyro, % f, % f, % f, %u, %u, %f\n", data->gyro.x, data->gyro.y, data->gyro.z, data->gyro.status, data->gyro.t, magnitude_3axis((DI_3AXIS_DATA_T *)&data->gyro));
         break;
      case DST_GEOMAGNETIC_FIELD:
         info_log("       mag, % f, % f, % f, %u, %u, %f\n", data->mag.x, data->mag.y, data->mag.z, data->mag.status, data->mag.t, magnitude_3axis((DI_3AXIS_DATA_T *)&data->mag));
         break;
      case DST_GYROSCOPE_UNCALIBRATED:
         info_log("gyro_uncal, % f, % f, % f, % f, % f, % f, %u, %u, %f\n",
                  data->gyro_uncal.x_uncal, data->gyro_uncal.y_uncal, data->gyro_uncal.z_uncal,
                  data->gyro_uncal.x_bias, data->gyro_uncal.y_bias, data->gyro_uncal.z_bias,
                  data->gyro_uncal.status, data->gyro_uncal.t, magnitude_3axis((DI_3AXIS_DATA_T *)&data->gyro_uncal));
         break;
      case DST_MAGNETIC_FIELD_UNCALIBRATED:
         info_log(" mag_uncal, % f, % f, % f, % f, % f, % f, %u, %u, %f\n",
                  data->mag_uncal.x_uncal, data->mag_uncal.y_uncal, data->mag_uncal.z_uncal,
                  data->mag_uncal.x_bias, data->mag_uncal.y_bias, data->mag_uncal.z_bias,
                  data->mag_uncal.status, data->mag_uncal.t, magnitude_3axis((DI_3AXIS_DATA_T *)&data->mag_uncal));
         break;
      case DST_ROTATION_VECTOR:
         info_log("   rotvect, % f, % f, % f, % f, % f, %u, %f\n", data->rotation_vector.x, data->rotation_vector.y, data->rotation_vector.z, data->rotation_vector.w,
                  data->rotation_vector.accuracy_estimate, data->rotation_vector.t, magnitude_quat((DI_QUATERNION_DATA_T *)&data->rotation_vector));
         break;
      case DST_GAME_ROTATION_VECTOR:
         info_log("  gamevect, % f, % f, % f, % f, % f, %u, %f\n", data->game_rotation_vector.x, data->game_rotation_vector.y, data->game_rotation_vector.z, data->game_rotation_vector.w,
                  data->game_rotation_vector.accuracy_estimate, data->game_rotation_vector.t, magnitude_quat((DI_QUATERNION_DATA_T *)&data->game_rotation_vector));
         break;
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         info_log(" geomgvect, % f, % f, % f, % f, % f, %u, %f\n", data->geomag_rotation_vector.x, data->geomag_rotation_vector.y, data->geomag_rotation_vector.z, data->geomag_rotation_vector.w,
                  data->geomag_rotation_vector.accuracy_estimate, data->geomag_rotation_vector.t, magnitude_quat((DI_QUATERNION_DATA_T *)&data->geomag_rotation_vector));
         break;
      case DST_LINEAR_ACCELERATION:
         info_log("  linaccel, % f, % f, % f, %u, %u, %f\n", data->linear_acceleration.x, data->linear_acceleration.y, data->linear_acceleration.z,
                  data->linear_acceleration.status, data->linear_acceleration.t, magnitude_3axis((DI_3AXIS_DATA_T *)&data->linear_acceleration));
         break;
      case DST_GRAVITY:
         info_log("   gravity, % f, % f, % f, %u, %u, %f\n", data->gravity.x, data->gravity.y, data->gravity.z,
                  data->gravity.status, data->gravity.t, magnitude_3axis((DI_3AXIS_DATA_T *)&data->gravity));
         break;
      case DST_ORIENTATION:
         info_log("    orient, % f, % f, % f, %u, %u\n", data->orientation.x, data->orientation.y, data->orientation.z,
                  data->orientation.status, data->orientation.t);
         break;
      case DST_RAW_DEBUG_OUTPUT_ACCEL:
         info_log("     raw_a, %d, %d, %d, %u\n", data->raw_accel.x, data->raw_accel.y, data->raw_accel.z, data->raw_accel.t);
         break;
      case DST_RAW_DEBUG_OUTPUT_MAG:
         info_log("     raw_m, %d, %d, %d, %u\n", data->raw_mag.x, data->raw_mag.y, data->raw_mag.z, data->raw_mag.t);
         break;
      case DST_RAW_DEBUG_OUTPUT_GYRO:
         info_log("     raw_g, %d, %d, %d, %u\n", data->raw_gyro.x, data->raw_gyro.y, data->raw_gyro.z, data->raw_gyro.t);
         break;
      case DST_STEP_COUNTER:
         info_log("step_count, %u, %u\n", data->step_counter.datum, data->step_counter.t);
         break;
      case DST_STEP_DETECTOR:
         info_log("stepdetect, %u\n", data->step_detector.t);
         break;
      case DST_SIGNIFICANT_MOTION:
         info_log(" sigmotion, %u\n", data->significant_motion.t);
         break;
      default:
         info_log("unsupported sensor\n");
   }
}

#define vect_init_0d(v,ts)           { (v)->len=0; (v)->t=ts; }
#define vect_init_1d(v,x,ts)         { (v)->len=1; (v)->d[1]=x; (v)->t=ts; }
#define vect_init_3d(v,x,y,z,ts)     { (v)->len=3; (v)->d[0]=x; (v)->d[1]=y; (v)->d[2]=z; (v)->t=ts; }
#define vect_init_4d(v,x,y,z,w,ts)   { (v)->len=4; (v)->d[0]=x; (v)->d[1]=y; (v)->d[2]=z; (v)->d[3]=w; (v)->t=ts; }

/* convert specified sensor and sample data to vector format. returns FALSE if sensor data could
   not be converted. */
bool  sensor_to_vect(DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *sample, struct vect *v)
{
   DI_SENSOR_TYPE_T base_sensor;
   DI_SENSOR_DATA_T scaled;
   BOOL_ASSERT(v != NULL);

#define vect_init_3axis(v,d)         vect_init_3d(v, (d)->x, (d)->y, (d)->z, (d)->t)
#define vect_init_3axis_uncal(v,d)   vect_init_3d(v, (d)->x_uncal, (d)->y_uncal, (d)->z_uncal, (d)->t)
#define vect_init_quat(v,d)          vect_init_4d(v, (d)->x, (d)->y, (d)->z, (d)->w, (d)->t)

   BOOL_ASSERT(di_convert_sensor_data(di, sensor, sample, &scaled, FALSE));
   //test_uc_1_logger(&scaled, sensor);

#if !defined(DI_SLIM)
   if (di->hi_id == HIID_KITKAT)
      base_sensor = sensor;
   else
      base_sensor = sensor & ~di_wake_sensor_start(di);
#else
   base_sensor = sensor;
#endif

   switch (base_sensor)
   {
      case DST_ACCELEROMETER:
         vect_init_3axis(v, &scaled.accel);
         break;
      case DST_GEOMAGNETIC_FIELD:
         vect_init_3axis(v, &scaled.mag);
         break;
      case DST_GYROSCOPE:
         vect_init_3axis(v, &scaled.gyro);
         break;
      case DST_GRAVITY:
         vect_init_3axis(v, &scaled.gravity);
         break;
      case DST_LINEAR_ACCELERATION:
         vect_init_3axis(v, &scaled.linear_acceleration);
         break;
      case DST_ORIENTATION:
         vect_init_3axis(v, &scaled.orientation);
         break;

      case DST_MAGNETIC_FIELD_UNCALIBRATED:
         vect_init_3axis_uncal(v, &scaled.mag_uncal);
         break;
      case DST_GYROSCOPE_UNCALIBRATED:
         vect_init_3axis_uncal(v, &scaled.gyro_uncal);
         break;

      case DST_ROTATION_VECTOR:
         vect_init_quat(v, &scaled.rotation_vector);
         break;
      case DST_GAME_ROTATION_VECTOR:
         vect_init_quat(v, &scaled.game_rotation_vector);
         break;
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         vect_init_quat(v, &scaled.geomag_rotation_vector);
         break;
#if !defined(DI_SLIM)
      case DST_TILT_DETECTOR:
         vect_init_0d(v, sample->tilt_detector.t);
         break;
      case DST_WAKE_GESTURE:
         vect_init_0d(v, sample->wake_gesture.t);
         break;
      case DST_GLANCE_GESTURE:
         vect_init_0d(v, sample->glance_gesture.t);
         break;
      case DST_PICKUP_GESTURE:
         vect_init_0d(v, sample->pickup_gesture.t);
         break;
      case DST_ACTIVITY:
         vect_init_1d(v, sample->activity.datum, sample->activity.t);
         break;
#endif
      default:
         return FALSE;
   }

   return TRUE;
}

#define EPSILON1   1.5
#define EPSILON2   3.0e-3
#define EPSILON3   2.5 // accel is uncalibrated and off by a lot
#define EPSILON4   1.0e-1
#define EPSILON5   2.0 // Linear accel is off by a lot...

// set all sensors overflow plausbile flag
// ovf: true if overflow plausible, false otherwise
void setSensOvf(bool ovf)
{
   int i;
   for (i = 0; i < ARRAY_SIZE(test_uc_1_sensor_list); i++)
   {
      if (test_uc_1_sensor_list[i].req_rate > 0)
      {                                                              // note when tring to turn off sensor we do not check rate anyway so req_rate > 0 is ok
         test_uc_1_sensor_list[i].ovf_plausible = ovf;
      }
   }
}

bool test_uc_1_handler(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                       DI_SENSOR_INT_DATA_T *sample, void *user)
{
   struct vect v;
   double m = 0.0;
   const char *name;
   struct test_uc_1_data *d = (struct test_uc_1_data *)user;
   struct test_uc_1_sensor_entry *se = test_uc_1_find_entry(sensor);
   DI_SENSOR_TYPE_T base_sensor;

   if (sensor == DST_META_EVENT ||
       sensor == DST_WAKEUP_META_EVENT)
   {
      if (sample->meta.event_id == DME_FIFO_OVERFLOW)
      {                                                              // count overflow events
         d->fifo_ovf++;
         info_log("fifo overflow: %u @t = %u\n", d->fifo_ovf, sample->meta.t);
#ifdef COMPENSATE_OVERFLOW
         setSensOvf(TRUE);
#endif
      }
   }
   /* ignore debug, meta and timestamp sensors */
   if (sensor > di_max_sensor_id(instance))
      return TRUE;

   if (sensor < DST_FIRST || !se)
   {
      d->invalid_sensor_samples++;
      return TRUE;
   }

   // enable sensor when rate is set and first sensor event is detected
   if ((sensor == g_tst_uc_1.sensor) &&
       (g_tst_uc_1.req_rate != 0) &&
       (g_tst_uc_1.first_smpl_pc_time_ms == 0))
   {
      g_tst_uc_1.first_smpl_pc_time_ms = time_ms();
      d->enabled_sensors[sensor] = TRUE;
   }

   if (!d->enabled_sensors[sensor])
   {
      d->disabled_sensor_samples++;
      info_log("received %s sample while sensor disabled\n", di_query_sensor_name(instance, sensor));
      return TRUE;
   }


   m = 0.0;
   name = di_query_sensor_name(instance, se->sensor);

   if (sensor_to_vect(sensor, sample, &v))
   {
      m = vect_magnitude(&v);
   }
   else
   {
      warn_log("error on sensor_to_vect for %s\n", name);
   }
   if (!se->timestamp_first_smpl_us)
   {
      se->timestamp_first_smpl_us = v.t;
      se->ovf_plausible = FALSE;                                     // clear overflow when now first sample detected
   }
   else
   {
      se->sample_count++;                                            // do not count first sample as then period would not fit nicely
                                                                     //(if only 2 samples (beg+end) then 1 period measured but 2 samples counted)
   }
#ifdef COMPENSATE_OVERFLOW
   if ((se->ovf_plausible == TRUE) && (se->req_rate != 0) && (se->timestamp_last_smpl))
   {
      u32 time_diff_us;
      double expected_period_us;
      if (se->updated_actual_rate)
      {
         expected_period_us = 1e6 / se->actual_rate;
      }
      else
      {
         expected_period_us = 1e6 / se->req_rate;
      }
      time_diff_us = v.t - se->timestamp_last_smpl_us;
      if (time_diff_us > (u32)(expected_period_us * 1.9))
      {
         u32 add_lost_smpls = (u32)(time_diff_us / expected_period_us - 1);
         //info_log("v.t = %u\n", v.t);
         //info_log("se->timestamp_last_smpl_us = %u\n", se->timestamp_last_smpl_us);
         info_log("Possibility of overflow for sensor id %u, time gap: %u [us]"
                  "period %3.0f [us] added samples: %u\n",
                  se->sensor, time_diff_us, expected_period_us, add_lost_smpls);
         se->sample_count += add_lost_smpls;
      }
   }
#endif
   // deactivate overflow plausible after first compensation for each sensor
   se->ovf_plausible = FALSE;
   se->timestamp_last_smpl = 1;
   se->timestamp_last_smpl_us = v.t;

   // compute rate on the go
   if (FALSE)
   {
      u32 tm_dif;
      double rate;
      tm_dif = se->timestamp_last_smpl_us - se->timestamp_first_smpl_us;
      if (tm_dif > 0)
         rate = (double)se->sample_count / (tm_dif / 1.0e6);
      else
         rate = 0;

      info_log("id: %u sensCnt: %u ;time measured: %u [ms] ; rate measured/expected %f/%u [Hz]\n",
               sensor, se->sample_count, tm_dif / 1000, rate, se->actual_rate);
   }

   if (se->discarded)
   {
      se->discarded--;
      return TRUE;
   }

   if (se->updated_actual_rate == FALSE)
   {                                                                 // do not check scaled values before dynamic range is updated using sensor IO read
                                                                     // dynamic range is used for propper scaling
      return TRUE;
   }

#define UC1_ASSERTF(cond,fmt,...) { do { if(!(cond)) { d->value_errors++; BOOL_ASSERTF(FALSE,fmt,##__VA_ARGS__); } } while(0); }

#if !defined(DI_SLIM)
   if (di->hi_id == HIID_KITKAT)
      base_sensor = se->sensor;
   else
      base_sensor = se->sensor & ~di_wake_sensor_start(di);
#else
   base_sensor = se->sensor;
#endif

   switch (se->sensor)
   {
      /* accel: magnitude should be 9.8 when still */
      case DST_ACCELEROMETER:
      case DST_GRAVITY:
         UC1_ASSERTF(is_approx(m, 9.8, EPSILON3), "%s: %u samples; magnitude=%f expected 9.8 +- %f v=%f,%f,%f",
                     name, se->sample_count, m, EPSILON3, v.d[0], v.d[1], v.d[2]);
         break;

         /* mag should be >30.0 */
      case DST_GEOMAGNETIC_FIELD:
      case DST_MAGNETIC_FIELD_UNCALIBRATED:
         // lower this from 30 to 21 -- AK09911 reads a little now
         UC1_ASSERTF(m > 18.0, "%s: %u samples; magnitude=%f expected >18.0", name, se->sample_count, m);
         break;

         /* rotation should be approx 1.0 */
      case DST_ROTATION_VECTOR:
      case DST_GAME_ROTATION_VECTOR:
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         UC1_ASSERTF(is_approx(m, 1.0, EPSILON2), "%s: %u samples; magnitude=%f expected 1.0+-%f", name, se->sample_count, m, EPSILON2);
         break;

         /* orientation should be within range: x &y:-180 - 180, z 0-360 */
      case DST_ORIENTATION:
         {
            struct vect vmin, vmax;
            if (instance->alg_id == AID_SPACE_POINT)
            {
               // Spacepoint algorithm
               vect_init_3d(&vmin, -180, -180, -90, 0);
               vect_init_3d(&vmax, 180, 180, 90, 0);
            }
            else
            {
               vect_init_3d(&vmin, 0, -180, -90, 0);
               vect_init_3d(&vmax, 360, 180, 90, 0);
            }
            UC1_ASSERTF(vect_is_inrange(&v, &vmin, &vmax), "%s: %u samples; %f,%f,%f", name, se->sample_count, v.d[0], v.d[1], v.d[2]);
         }
         break;

      case DST_GYROSCOPE:
      case DST_GYROSCOPE_UNCALIBRATED:
         {
            struct vect v2;
            vect_init_3d(&v2, 0, 0, 0, 0);
            UC1_ASSERTF(vect_is_approx(&v, &v2, EPSILON4), "%s: %u samples; %f,%f,%f",
                        name, se->sample_count, v.d[0], v.d[1], v.d[2]);
         }
         break;

      case DST_LINEAR_ACCELERATION:
         {
            struct vect v2;
            vect_init_3d(&v2, 0, 0, 0, 0);
            UC1_ASSERTF(vect_is_approx(&v, &v2, EPSILON5), "%s: %u samples; %f,%f,%f", name, se->sample_count, v.d[0], v.d[1], v.d[2]);
         }
         break;

      default:
         ;
   }

   return TRUE;
}

u32 g_tm_beg_ms;                                                     // time beginning
u32 g_tm_last_ms;                                                    // time last
// initialize g_tm_beg_ms and g_tm_last_ms
void init_start_time()
{
   g_tm_beg_ms = time_ms();
   g_tm_last_ms = g_tm_beg_ms;
}
// print PC time Total and difference from this last call (before first call, call init_start_time())
// preStr: string to be printed along with PC time
void prn_pc_time(const char *preStr)
{
   u32 tm_dif_beg_ms;
   u32 tm_dif_ms;
   u32 tm_now;
#define TMP_STR_SZ 100
   char tmp_str[TMP_STR_SZ];
   char tmp_str2[TMP_STR_SZ];

   tm_now = time_ms();
   tm_dif_beg_ms = tm_now - g_tm_beg_ms;
   tm_dif_ms = tm_now - g_tm_last_ms;
   g_tm_last_ms = tm_now;

   time_to_str(tmp_str, TMP_STR_SZ, tm_dif_beg_ms);
   time_to_str(tmp_str2, TMP_STR_SZ, tm_dif_ms);
   info_log("PC time : %s ; dif: %s --- %s\n", tmp_str, tmp_str2, preStr);
}
// Set Sensor Rate [Hz] - it also adjust other global variable to know that new actual rate has to be read, etc...
// req_rate: Requested Rate [Hz]
// se: Sensor Entry
int setSensorRate(int req_rate, struct test_uc_1_sensor_entry *se)
{
   SENSOR_INFORMATION sensor_info;
   SENSOR_CONFIG      sensor_config;
   u32 set_rate_tm;

   set_rate_tm = time_ms();

   se->smpl_rate_chg_req_tm_ms = set_rate_tm;
   se->updated_actual_rate = FALSE;
   se->sample_count = 0;
   se->timestamp_first_smpl_us = 0;
   g_tst_uc_1.set_rate_pc_time_ms = set_rate_tm;
   g_tst_uc_1.sensor = se->sensor;
   if (req_rate != 0)
   {
      se->discarded = se->discard_count;
      g_tst_uc_1.first_smpl_pc_time_ms = 0;
   }

   prn_pc_time("--- set rate ---");
   TEST_ASSERT(di_query_sensor_info(di, se->sensor, &sensor_info));
   TEST_ASSERT(di_query_sensor_config(di, se->sensor, &sensor_config));

   if (req_rate > sensor_info.max_rate)
      req_rate = sensor_info.max_rate;
   if ((req_rate != 0) && (di->hi_id != HIID_KITKAT) && (req_rate < sensor_info.min_rate))
      req_rate = sensor_info.min_rate;

   if(req_rate)
   {
      // Only set the new rate if we are tuning it on. If we are turning if off, clear the rate after it's off.
      se->req_rate = req_rate;
      g_tst_uc_1.req_rate = req_rate;
   }

   TEST_ASSERT(di_configure_rate(di, se->sensor, req_rate, UC_1_LATENCY));

   if(!req_rate)
   {
      se->req_rate = req_rate;
      g_tst_uc_1.req_rate = req_rate;
   }


   info_log("set %s (%u) to rate: %u [Hz] latency: %u [ms], time %u ms\n",
            di_query_sensor_name(di, se->sensor), se->sensor, req_rate, UC_1_LATENCY, time_ms());

   return TEST_PASSED;
}


// Get actual rate
// This function shall be called only after previously calling setSensorRate().
// Function setSensorRate() set requested rate to compare with
// return true when rate actually changed
//        NOTE: Actual sensor rate has range <req_rate,req_rate*2).
//              so if your requested rate change within this range sensor rate may not actually be changed.
//              In such case you would never get TRUE from this function.
bool check_for_rate_change(struct test_uc_1_data *data, struct test_uc_1_sensor_entry *se)
{
   SENSOR_CONFIG      sensor_config;
   u16 smpl_rate;

   TEST_ASSERT(di_query_sensor_config(di, se->sensor, &sensor_config));
   smpl_rate = sensor_config.sample_rate;
   se->actual_rate = smpl_rate;
   if (smpl_rate != se->req_rate ||
       smpl_rate != se->actual_rate_previous)                        // we expect one change from old rate to new rate, this is in case that new rate is not exact value of requested rate
   {
      se->actual_rate_previous = smpl_rate;
      if (smpl_rate > 0)
         se->updated_actual_rate = TRUE;
      return TRUE;
   }
   return FALSE;
}
// Check sensor rate
// computes actual sensor rate based on timestamps and PC time, then compare with expected sensor rate
// se: sensor to be checked
// tm_end_ms: time in ms when FIFO read ended.
void chk_sensor_rate(struct test_uc_1_sensor_entry *se, u32 tm_end_ms)
{
   double tm_dif_s_fl;
   double pc_measured_rate;
   if ((se->req_rate == 0) || (se->ignore_actual_rate == TRUE))
   {
      return;
   }

   tm_dif_s_fl = (tm_end_ms - se->smpl_rate_chg_req_tm_ms) / 1e3;
   if (tm_dif_s_fl)
      pc_measured_rate = se->sample_count / tm_dif_s_fl;
   else
      pc_measured_rate = 0;

   tm_dif_s_fl = (se->timestamp_last_smpl_us - se->timestamp_first_smpl_us) / 1e6;
   if (tm_dif_s_fl)
      se->timestamp_measured_rate = se->sample_count / tm_dif_s_fl;
   else
      se->timestamp_measured_rate = 0;
   info_log("sensor: %u %s : smpl count: %u, time %3.3f [s]\n",
            se->sensor, di_query_sensor_name(di, se->sensor), se->sample_count, tm_dif_s_fl);
   info_log("sensor: %u %s : measured rate: (sample timestamps/PC timebase) %3.2f/%3.2f Hz, diff %3.2f Hz\n",
            se->sensor, di_query_sensor_name(di, se->sensor),
            se->timestamp_measured_rate, pc_measured_rate, se->timestamp_measured_rate - pc_measured_rate);
   chk_val_with_margin_lr_dbl(se->actual_rate, pc_measured_rate, 0.45, 0, 0.35, 0, "Rate pc based [Hz]");
   chk_val_with_margin_lr_dbl(se->actual_rate, se->timestamp_measured_rate, 0.15, 0, 0.15, 0, "Rate timestamps based [Hz]");
}
// Do sensor change test
// this function is main test function. Typically you turn on/off sensor
// if sensor is turned on it is measured for "test_time_ms" and then is checked
// that rate is as expected and only enabled sensors are in FIFO.
// data: global data error counters (used for data handler function)
// i: index in test_uc_1_sensor_list
// sens_on: true if sensor shall be turned on/ false if sensor shall be turned off
// test_time_ms: test time in [ms]. In case of sensor turn off it is recommended to give short time
//               eg. 1s during which is tested that no sensor data of turned off sensor
//               appears in FIFO.
int doSensorChng(struct test_uc_1_data *data, int i, bool sens_on, u32 test_time_ms)
{
   u32 tm_beg_ms;                                                    // time begin [ms]
   u32 tm_dif_ms;                                                    // time difference (now - tm_beg_ms) [ms]
   u32 tm_end_ms;                                                    // time difference (now - tm_beg_ms) [ms]
   double tm_dif_s_fl;                                               // time difference [s] (float)

   int req_rate;

   struct test_uc_1_sensor_entry *se = &test_uc_1_sensor_list[i];

   if (se->present_in_system == FALSE)
   {
      return TEST_PASSED;
   }

   // clear statistics - do them for each sensor separately
   data->disabled_sensor_samples = 0;
   data->invalid_sensor_samples = 0;
   data->value_errors = 0;

   req_rate = sens_on ? se->rate : 0;

   setSensorRate(req_rate, se);

   tm_beg_ms = time_ms();
   info_log("time: %u ms\n", tm_beg_ms);
   while (TRUE)
   {
      TEST_ASSERT_PASSED(test_read_out_pending_data(50, TRUE));
      if ((g_tst_uc_1.first_smpl_pc_time_ms != 0) &&
          (g_tst_uc_1.req_rate != 0))
      {                                                              // when we have first sample we can get rate
         bool rate_changed;

         info_log("time: %u ms\n", time_ms());
         rate_changed = check_for_rate_change(data, se);
         if (rate_changed)
            break;
         else
            TAFR(FALSE, "Sens %u rate didn't change from %u to %u and it should, time %u ms\n", se->sensor, se->actual_rate_previous, se->req_rate, time_ms());
         // Force the enable bits to on. When we move on to a different sensor it's possible to have the enable bit off, but still recieve data when the sensor is on...
         data->enabled_sensors[se->sensor] = TRUE;
      }
      tm_dif_ms = time_ms() - tm_beg_ms;
      if (tm_dif_ms > UC_1_SENSOR_RATE_CHG_MAX_WAIT_MS)
      {
         info_log("time: %u ms\n", time_ms());
         check_for_rate_change(data, se);
         if ((se->req_rate != 0) && (!se->ignore_actual_rate))       // ignore actual rate for gesture sensor - they don't give data unless user interaction
         {                                                           // we expected sensor sample
            TAFR(FALSE, "Did not get first sensor %u sample in time (%u ms), time %u ms\n", se->sensor, UC_1_SENSOR_RATE_CHG_MAX_WAIT_MS, time_ms())
         }
         if (se->req_rate == 0)
         {                                                           // we expect that sensor turn off in wait time
            TAFR(se->actual_rate == 0, "Sensor %u did not turn off in time (%u ms), time %u ms\n", se->sensor, UC_1_SENSOR_RATE_CHG_MAX_WAIT_MS, time_ms())
            data->enabled_sensors[se->sensor] = FALSE;
         }
         break;
      }
   }
#ifdef TOLERATE_RATE_AT_200HZ
   {
      u32 maxAddRate = se->req_rate;
      if (maxAddRate < 200)
         maxAddRate = 200;
      chk_val_with_margin_lr_dbl(se->req_rate, se->actual_rate, 0, 0, 0, maxAddRate, "Actual sensor rate [Hz]");
   }
#else
   chk_val_with_margin_lr_dbl(se->req_rate, se->actual_rate, 0, 0, 0, se->req_rate, "Actual sensor rate [Hz]");
#endif

   info_log("time: %u ms\n", time_ms());
   TEST_ASSERT_PASSED(test_read_out_pending_data(test_time_ms, FALSE));
   tm_end_ms = time_ms();
   info_log("time: %u ms\n", tm_end_ms);

   chk_sensor_rate(se, tm_end_ms);
   info_log("time: %u ms\n", tm_end_ms);
   if (se->req_rate == 0)
   {
      if (se->timestamp_first_smpl_us != 0)                          // when no data (like gesture sensors) then time is not initilized
         tm_dif_s_fl = (se->timestamp_last_smpl_us - se->timestamp_first_smpl_us) / 1e6;
      else
         tm_dif_s_fl = 0;
      info_log("Sensor turned off in %3.3f [s]  checked for another : %u [ms] that no samples generated\n", tm_dif_s_fl, test_time_ms);
   }

   info_log("overflow events: %d\n", data->fifo_ovf);
   //info_log("value errors: %d\n",data->value_errors);
   TEST_ASSERT(data->value_errors == 0);
   TEST_ASSERTF(data->disabled_sensor_samples == 0, "disabled sensors sample count: %d", data->disabled_sensor_samples);
   TEST_ASSERTF(data->invalid_sensor_samples == 0, "invalid sensor sample count: %d", data->invalid_sensor_samples);

   TEST_ASSERT(i2c_blocking_read(di->i2c_handle, SR_ERROR_REGISTER, (u8 *)&di->error.error_register, 1));
   if (di->error.error_register == 0x29)
   {
      info_log("warning: error 0x29 detected\n"); // trigger delayed
   }
   else if (di->error.error_register == 0x28)
   {
      info_log("warning: error 0x28 detected\n"); // trigger dropped - high cpu load
   }
   else   {
      TEST_ASSERTF((di->error.error_register == 0), "Error 0x%04X detected!", di->error.error_register);
   }

   return TEST_PASSED;
}


TEST_START(UC_1)
{
   struct test_uc_1_data data;
   int i;
   u32 tm_end_ms;

   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   init_start_time();

   memset(&data, 0, sizeof(data));

   if (first_loop)
      TEST_ASSERT_PASSED(test_start_chip_normal());
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERT(di_configure_interrupts_ex(di, TRUE, TRUE, 0, 0));
      di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, TRUE, FALSE, TRUE);
      di_enable_meta_event_ex(di, DME_ALGORITHM_EVENT, TRUE, FALSE, TRUE);
   }
   else
   {
      TEST_ASSERT(di_configure_interrupts(di, TRUE, 0));
   }

   di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, TRUE, FALSE, FALSE);
   di_enable_meta_event_ex(di, DME_ALGORITHM_EVENT, TRUE, FALSE, FALSE);

   time_delay_ms(500);
   TEST_ASSERT(di_query_features(di));
   //di_control_logging(di, FALSE, FALSE, TRUE, TRUE);
   di_control_logging(di, FALSE, FALSE, TRUE, TRUE);
   set_verbose_sensor_data(TRUE);

   init_test_uc1();

   TEST_ASSERT(di_register(di, test_uc_1_handler, &data));

   info_log("\nUC_1 1. switch on sensors 1 at a time, ensure only current sensor samples are received\n");

   for (i = 0; i < ARRAY_SIZE(test_uc_1_sensor_list); i++)
   {
      info_log("*** UC_1 1.%d - %s ***\n", i + 1, di_query_sensor_name(di, test_uc_1_sensor_list[i].sensor));
      doSensorChng(&data, i, TRUE, UC_1_READ_TIME);
      doSensorChng(&data, i, FALSE, UC_1_READ_TIME_OFF);
   }

   //set_logging_level(LL_DEBUG);
   info_log("\nUC_1 2. incrementally switch on all sensors ensure only enabled sensor data received\n");
   for (i = 0; i < ARRAY_SIZE(test_uc_1_sensor_list); i++)
   {
      info_log("*** UC_1 2.%d - %s ***\n", i + 1, di_query_sensor_name(di, test_uc_1_sensor_list[i].sensor));
      doSensorChng(&data, i, TRUE, UC_1_READ_TIME);
   }
   tm_end_ms = time_ms();
   info_log("check all sensor rates for total time\n");
   for (i = 0; i < ARRAY_SIZE(test_uc_1_sensor_list); i++)
   {
      struct test_uc_1_sensor_entry *se;
      se = &test_uc_1_sensor_list[i];
      chk_sensor_rate(se, tm_end_ms);
   }
   info_log("\nUC_1 3. incrementally switch off in reverse order, ensuring only enabled sensor samples are received\n");
   for (i = ARRAY_SIZE(test_uc_1_sensor_list) - 1; i >= 0; i--)
   {
      info_log("*** UC_1 3.%d - %s ***\n", i + 1, di_query_sensor_name(di, test_uc_1_sensor_list[i].sensor));
      doSensorChng(&data, i, FALSE, UC_1_READ_TIME_OFF);
   }
}
TEST_END

