#include "test_common.h"

/***************************************************************************************
 * 10. Meta Events
  * test each to ensure they can be enabled, disabled, and
  * generated as appropriate
 **************************************************************************************/

/**
 * PRIORITY 2
 * Flush Complete
 * enable accel with long latency; delay enough that FIFO
 * accumulates some samples but not beyond latency; issue FIFO
 * flush; should get immediate interrupt; read FIFO, and should
 * get all data plus a Flush Complete event if enabled, or no
 * Flush Complete if disabled
 */
TEST_START(10_1)
{
   // set up base sensors and start gathering data
   default_rates();
   set_latencies(65535, 65535, 65535, 65535);
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   // enable meta event
   TEST_ASSERT(di_enable_meta_event(di, DME_FLUSH_COMPLETE, TRUE, FALSE));
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERT(di_configure_interrupts_ex(di, TRUE, TRUE, 5000, 5000));
   }
   else
   {
      TEST_ASSERT(di_configure_interrupts(di, TRUE, 5000));
   }

   // delay a bit
   time_delay_ms(1000);

   // flush the FIFO
   TEST_ASSERT(di_fifo_flush(di, DST_ACCELEROMETER));

   // read out all data
   di->meta_events[DME_FLUSH_COMPLETE] = 0;
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_1_RUN_TIME_1, FALSE));
   TEST_ASSERT(di->meta_events[DME_FLUSH_COMPLETE] != 0);

   // turn off meta event
   TEST_ASSERT(di_enable_meta_event(di, DME_FLUSH_COMPLETE, FALSE, FALSE));

   // clear data
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_1_RUN_TIME_2, FALSE));

   // flush the FIFO
   TEST_ASSERT(di_fifo_flush(di, DST_ACCELEROMETER));

   // read some more; there should be no meta event
   di->meta_events[DME_FLUSH_COMPLETE] = 0;
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_1_RUN_TIME_1, FALSE));
   TEST_ASSERT(di->meta_events[DME_FLUSH_COMPLETE] == 0);

   return TEST_PASSED;
}
TEST_END


/**
 * PRIORITY 2
 * \brief Sample Rate Changed
 * enable accel at a specific rate; when Sample Rate Changed
 * enabled, allow some samples to accumulate, change the
 * rate, then when we read the FIFO we should see the
 * rate change by virtue of the timestamps and also see
 * the meta event between changes in these rates; when
 * Sample Rate Changed is disabled, we should not see the
 * event but should still detect the rate change
 */
TEST_START(10_2)
{
   // set up base sensors and start gathering data
   default_rates();
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   // enable meta event
   TEST_ASSERT(di_enable_meta_event(di, DME_SAMPLE_RATE_CHANGED, TRUE, FALSE));
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERT(di_configure_interrupts_ex(di, TRUE, TRUE, 0, 0));
   }
   else
   {
      TEST_ASSERT(di_configure_interrupts(di, TRUE, 0));
   }

   // change the rate
   TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER, accel_rate * 2, 0));

   // read out all data
   di->meta_events[DME_SAMPLE_RATE_CHANGED] = 0;
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_2_RUN_TIME_1, FALSE));
   TEST_ASSERT(di->meta_events[DME_SAMPLE_RATE_CHANGED] != 0);

   // turn off meta event
   TEST_ASSERT(di_enable_meta_event(di, DME_SAMPLE_RATE_CHANGED, FALSE, FALSE));

   // clear data
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_2_RUN_TIME_2, FALSE));

   // change the rate
   TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER, accel_rate / 10, 0));

   // read some more; there should be no meta event
   di->meta_events[DME_SAMPLE_RATE_CHANGED] = 0;
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_2_RUN_TIME_1, FALSE));
   TEST_ASSERT(di->meta_events[DME_SAMPLE_RATE_CHANGED] == 0);

   return TEST_PASSED;
}
TEST_END



/**
 * PRIORITY 2
 * \brief Power Mode Changed
 * enable accel; gather data briefly; disable the accel; with
 * Power Mode Changed enabled, the last event in the FIFO should
 * be the accel�s Power Mode Changed meta event; if disabled, we
 * should just run out of data
 */
TEST_START(10_3)
{
   u32 count;
   DI_SENSOR_TYPE_T sensor;
   u16 rate;

   // set up base sensors and start gathering data
   accel_rate = 0;
   gyro_rate = 0;
   mag_rate = 0;
   quat_rate = 0;
   set_latencies(0, 0, 0, 0);

   di_control_logging(di, FALSE, FALSE, FALSE, FALSE);
   di->meta_events[DME_POWER_MODE_CHANGED] = 0;
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

   if (di_has_sensor(di, DST_ACCELEROMETER))
   {
      sensor = DST_ACCELEROMETER;
      rate = config.accel_norm_rate;
   }
   else if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
   {
      sensor = DST_GEOMAGNETIC_FIELD;
      rate = config.mag_norm_rate;
   }
   else
   {
      sensor = DST_GYROSCOPE;
      rate = config.gyro_norm_rate;
   }

   info_log("test for samples and power mode active meta event\n");
   // enable meta event (just power mode)
   TEST_ASSERT(di_enable_meta_event(di, DME_ALGORITHM_EVENT, FALSE, FALSE));
   TEST_ASSERT(di_enable_meta_event(di, DME_SAMPLE_RATE_CHANGED, FALSE, FALSE));
   TEST_ASSERT(di_enable_meta_event(di, DME_DYNAMIC_RANGE_CHANGED, FALSE, FALSE));
   TEST_ASSERT(di_enable_meta_event(di, DME_POWER_MODE_CHANGED, TRUE, FALSE));
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERT(di_configure_interrupts_ex(di, TRUE, TRUE, 0, 0));
   }
   else
   {
      TEST_ASSERT(di_configure_interrupts(di, TRUE, 0));
   }

   info_log("configuring the rate\n");

   // change the rate
   TEST_ASSERT(di_configure_rate(di, sensor, rate, 0));

   // read out all data
   count = di->sensor_info[sensor].samples_received;
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_3_RUN_TIME_1, FALSE));
   TEST_ASSERT(di->sensor_info[sensor].samples_received > count);

   // ensure POWER_MODE is received, as accel should have 0 rate entering test
   TEST_ASSERTF(di->meta_events[DME_POWER_MODE_CHANGED] > 0, "failed to received power up notification");

// ensure POWER_MODE is correct (low power active/active?)
   TEST_ASSERT(di->last_sample.meta.event_id == DME_POWER_MODE_CHANGED);
   TEST_ASSERT(di->last_sample.meta.sensor_id == sensor);
   TEST_ASSERT(di->last_sample.meta.extra_info >= SensorPowerModeLowPowerActive);

   info_log("turn off sensor and detect power mode suspend or power down meta event\n");
   // turn off sensor
   time_delay_ms(50);
   TEST_ASSERT(di_configure_rate(di, sensor, 0, 0));

   {
      SENSOR_CONFIG sensor_config;
      time_delay_ms(500);
      di_query_sensor_config(di, sensor, &sensor_config);
      TEST_ASSERT(sensor_config.sample_rate == 0);
   }

   // ensure meta_event POWER_CHANGED
   di->meta_events[DME_POWER_MODE_CHANGED] = 0;
   count = di->sensor_info[sensor].samples_received;
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_3_RUN_TIME_2, FALSE));
   TEST_ASSERT(di->sensor_info[sensor].samples_received > count);

   TEST_ASSERTF(di->meta_events[DME_POWER_MODE_CHANGED] > 0, "failed to receive power down notification");

// ensure POWER_MODE is correct (low power active/active?)
   TEST_ASSERT(di->last_sample.meta.event_id == DME_POWER_MODE_CHANGED);
   TEST_ASSERT(di->last_sample.meta.sensor_id == sensor);
   TEST_ASSERT(di->last_sample.meta.extra_info <= SensorPowerModeSuspend);

   info_log("test that we can turn off power mode meta event\n");
   // turn off meta event
   TEST_ASSERT(di_enable_meta_event(di, DME_POWER_MODE_CHANGED, FALSE, FALSE));

   // turn it back on
   time_delay_ms(1000);
   TEST_ASSERT(di_configure_rate(di, sensor, rate, 0));

   // make sure no power mode events
   di->meta_events[DME_POWER_MODE_CHANGED] = 0;
   TEST_ASSERT(TEST_PASSED == test_read_out_pending_data(TEST_10_3_RUN_TIME_3, FALSE));
   TEST_ASSERT(di->meta_events[DME_POWER_MODE_CHANGED] == 0);

   //TODO: run test for all sensor types

   return TEST_PASSED;
}
TEST_END


/**
 * PRIORITY 2
 * \brief Sensor Error
 * this meta event occurs if, for example, an existing sensor stops responding to I2C
 * transfers; or, if on initialization, the WHO_AM_I or DEVICE_ID register returns the
 * incorrect value; this could be triggered by loading a RAM patch for the BMX055 on a
 * board with the BMI160
 */
TEST_START(10_6)
{
   return TEST_NOT_IMPLEMENTED;
}
TEST_END


/**
 * PRIORITY 2
 * \brief FIFO Overflow
 * enable accel; allow FIFO to overflow; with enabled, we should
 * see FIFO Overflow meta event right after the time
 * discontinuity; with disabled, we should only see the
 * discontinuity
 */


typedef struct tst_10_7_exp_gaps
{
   DI_SENSOR_TYPE_T s;                                               //sensor ID
   u32 exp_gaps;                                                     // expected gaps
   u16 act_rate;                                                     // actual rate
   u32 exp_ovf;                                                      // expected overflows meta event count
   u16 full_fifo_events;                                             // number of fifo events that would fill whole FIFO
}
t_10_7_exp_gaps;

// wait for time suitable for requested FIFO fill
// test if gaps and meta events were generated as expected, and no slips or dups happened
// fifo_mult: multiplier of wanted FIFO fill (e.g. 1.5 means to fill 1.5 FIFO size)
// es: expected per sensor data - see struct
//     note prama full_fifo_events: will be used only form first (0 index) sensor
void t_10_7_wait_and_chk_gap(double fifo_mult, t_10_7_exp_gaps *es)
{
   int i;
   u32 exp_total_gaps;
   u32 wait_ms;
   int allow_add;

#define ALLOW_EXTRA_OVERFLOWS 3

   // clear fifo overflow events
   di->meta_events[DME_FIFO_OVERFLOW] = 0;
   di->meta_events_wakeup[DME_FIFO_OVERFLOW] = 0;
   di->total_timegaps = 0;
   di->total_timeslips = 0;
   di->total_timedups = 0;
   for (i = 0; i < 2; i++)
   {
      di->sensor_info[es[i].s].timestamp_gaps = 0;
      di->sensor_info[es[i].s].timestamp_slips = 0;
      di->sensor_info[es[i].s].timestamp_dups = 0;
   }
   wait_ms = (u32)(1000 * es[0].full_fifo_events * fifo_mult / es[0].act_rate);
   // wait and read FIFO
   info_log("wait %f seconds to fill %0.1f of FIFO\n", wait_ms / 1000.0, fifo_mult);
   time_delay_ms(wait_ms);
   test_read_out_pending_data(TEST_10_7_RUN_TIME_1, FALSE);
   // check fifo overflow events, and no out of range sensor period
   info_log("time-slips: ");
   chk_val_with_margin(0, di->total_timeslips, 0, 0);
   info_log("time-dups: ");
   chk_val_with_margin(0, di->total_timedups, 0, 0);
   exp_total_gaps = 0;
   for (i = 0; i < ((di->hi_id != HIID_KITKAT) ? 2 : 1); i++)
   {
      info_log("sensor %d time-gaps: ", es[i].s);
      allow_add = es[i].exp_gaps * ALLOW_EXTRA_OVERFLOWS;
      chk_val_with_margin_lr(es[i].exp_gaps, di->sensor_info[es[i].s].timestamp_gaps, 0, 0, 0, allow_add);
      exp_total_gaps += es[i].exp_gaps;
   }
   info_log("total time-gaps: ");
   allow_add = exp_total_gaps * ALLOW_EXTRA_OVERFLOWS;
   chk_val_with_margin_lr(exp_total_gaps, di->total_timegaps, 0, 0, 0, allow_add);
   info_log("nw fifo overflow meta event: ");
   allow_add = es[0].exp_ovf * ALLOW_EXTRA_OVERFLOWS;
   chk_val_with_margin_lr(es[0].exp_ovf, di->meta_events[DME_FIFO_OVERFLOW], 0, 0, 0, allow_add);
   if (di->hi_id != HIID_KITKAT)
   {
      info_log("w fifo overflow meta event: ");
      allow_add = es[1].exp_ovf * ALLOW_EXTRA_OVERFLOWS;
      chk_val_with_margin_lr(es[1].exp_ovf, di->meta_events_wakeup[DME_FIFO_OVERFLOW], 0, 0, 0, allow_add);
   }
}

// test if gaps and overflow meta events occured according to different configurations
TEST_START(10_7)
{
   u16 rate_req = config.accel_fast_rate;                            // rate request
   t_10_7_exp_gaps sp[2];                                            // sensors parameters, [0] is non wakeup, [1] is wakeup

   // set up accel and start gathering data
   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);
   di->quiet_gap_errors = FALSE;                                     // do not display gap errors - we expect them
   if (first_loop)
      TEST_ASSERT(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));

#if 0 // super verbose
   set_logging_level(LL_DEBUG);
   set_verbose_sensor_data(TRUE);
   di_control_logging(di, FALSE, FALSE, FALSE, TRUE);
#endif

   get_3axis_fifo_events(di, &sp[1].full_fifo_events, &sp[0].full_fifo_events);
   sp[0].s = DST_ACCELEROMETER;
   sp[1].s = DST_ACCELEROMETER | di_wake_sensor_start(di);
   set_and_chk_rate(sp[0].s, rate_req, &sp[0].act_rate, TRUE);
   if (di->hi_id != HIID_KITKAT)
   {
      info_log("fifo sizes ");
      TEST_ASSERTF(chk_val_with_margin(sp[0].full_fifo_events, sp[1].full_fifo_events, 0.1, 1),
                   "W and NW FIFO sizes differs more than 10% - for speed this test is testing both FIFOs at once\n"
                   "If the FIFO sizes differs this test has to be rewritten");
      set_and_chk_rate(sp[1].s, rate_req, &sp[1].act_rate, TRUE);
      TEST_ASSERTF(sp[0].act_rate == sp[1].act_rate, "For this test we expect both sensors shall run at same rate");
   }
   test_read_out_pending_data(2000, FALSE);

   // enable FIFO overflow meta-event
   TEST_ASSERT(di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, TRUE, FALSE, FALSE)); // non wakeup
   if (di->hi_id != HIID_KITKAT)
   {
      TEST_ASSERT(di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, TRUE, FALSE, TRUE)); // wakeup
   }

   info_log("=== delay for 1.5 fifo size ===\n");
   sp[0].exp_gaps = 1;
   sp[1].exp_gaps = 1;
   sp[0].exp_ovf = 1;
   sp[1].exp_ovf = 1;
   t_10_7_wait_and_chk_gap(1.5, sp);
   printCommunicationInfo(di);

   info_log("=== delay for 0.5 fifo size ===\n");
   sp[0].exp_gaps = 0;
   sp[1].exp_gaps = 0;
   sp[0].exp_ovf = 0;
   sp[1].exp_ovf = 0;
   t_10_7_wait_and_chk_gap(0.5, sp);
   printCommunicationInfo(di);

   sp[0].exp_gaps = 1;
   sp[1].exp_gaps = 1;

   if (di->hi_id != HIID_KITKAT)
   {
      info_log("=== disable only w meta event generation ===\n");
      TEST_ASSERT(di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, FALSE, FALSE, TRUE)); // wakeup
      sp[0].exp_ovf = 1;
      sp[1].exp_ovf = 0;
      t_10_7_wait_and_chk_gap(1.5, sp);
   }

   info_log("=== disable also nw meta event generation ===\n");
   TEST_ASSERT(di_enable_meta_event_ex(di, DME_FIFO_OVERFLOW, FALSE, FALSE, FALSE)); // non wakeup
   sp[0].exp_ovf = 0;
   sp[1].exp_ovf = 0;
   t_10_7_wait_and_chk_gap(1.5, sp);

   set_and_chk_rate(sp[0].s, 0, NULL, TRUE);
   if (di->hi_id != HIID_KITKAT)
   {
      set_and_chk_rate(sp[1].s, 0, NULL, TRUE);
   }

}
TEST_END

/**
* PRIORITY 3
* \brief Dynamic Range Changed Meta Event
* enable accel, set dynamic range to 4g (event expected?), set dr to 16g. ensure dynamic range event received only when enabled
*/
#define TEST_10_8_DR_MIN   0
#define TEST_10_8_DR_MAX   16
#define TEST_10_8_DR_STEP  4
#define TEST_10_8_RUN_TIME 7500

static bool di_configure_dynamic_range(DI_INSTANCE_T *di, DI_SENSOR_TYPE_T sensor, u16 dynamic_range)
{
   SENSOR_CONFIG cfg;
   BOOL_ASSERT(di_query_sensor_config(di, sensor, &cfg));
   info_log("original range: %u\n", cfg.dynamic_range);
   cfg.dynamic_range = dynamic_range;
   BOOL_ASSERT(di_configure_sensor(di, sensor, &cfg));
   info_log("requested range: %u\n", cfg.dynamic_range);
   return TRUE;
}

static int test_dynamic_range(DI_SENSOR_TYPE_T sensor, u16 range, int *events)
{
   SENSOR_CONFIG cfg;

   *events = 0;
   time_delay_ms(500);
   TEST_ASSERT(di_configure_rate(di, sensor, 50, 0));

   di->meta_events[DME_DYNAMIC_RANGE_CHANGED] = 0;

   time_delay_ms(500); // this timing should really be done better... was 100ms, caused a failure on slower fw.
   TEST_ASSERT(di_configure_dynamic_range(di, sensor, range));

   time_delay_ms(TEST_10_8_RUN_TIME);

   TEST_ASSERT_PASSED(test_read_out_pending_data(TEST_10_8_RUN_TIME, FALSE));


   *events = di->meta_events[DME_DYNAMIC_RANGE_CHANGED];

   /* flush fifo */
   time_delay_ms(100);
   TEST_ASSERT(di_configure_rate(di, sensor, 0, 0));
   TEST_ASSERT_PASSED(test_read_out_pending_data(TEST_10_8_RUN_TIME, FALSE));

   BOOL_ASSERT(di_query_sensor_config(di, sensor, &cfg));
   info_log("actual range %u\n", cfg.dynamic_range);

   return TEST_PASSED;
}

TEST_START(10_8)
{
   int events;
   DI_SENSOR_TYPE_T sensor = DST_ACCELEROMETER;
   bool enable = FALSE;
   bool int_enable = TRUE;

   set_rates(0, 0, 0, 0);
   set_latencies(0, 0, 0, 0);

   if (first_loop)
      TEST_ASSERT_PASSED(test_start_chip_running(config.normal_firmware, TRUE));

   /* disable other events */
   TEST_ASSERT(di_enable_meta_event(di, DME_SAMPLE_RATE_CHANGED, TRUE, FALSE));
   TEST_ASSERT(di_enable_meta_event(di, DME_POWER_MODE_CHANGED, TRUE, FALSE));

   /* enable event */
   TEST_ASSERT(di_enable_meta_event(di, DME_DYNAMIC_RANGE_CHANGED, TRUE, FALSE));

   TEST_ASSERT(di_query_meta_event(di, DME_DYNAMIC_RANGE_CHANGED, &enable, &int_enable));
   info_log("dynamic range meta event enable = %u, int = %u\n", enable, int_enable);
   TEST_ASSERT((enable == TRUE) && (int_enable == FALSE));

   /* set range to 8 */
   TEST_ASSERT_PASSED(test_dynamic_range(DST_ACCELEROMETER, 8, &events));
   TEST_ASSERTF(events >= 1, "sensor %u: %d dynamic range events", sensor, events);

   /* setting to previous value shouldn't generate an event <-- not the case currently */
   //TEST_ASSERT_PASSED(test_dynamic_range(DST_ACCELEROMETER, 8, &events));
   //TEST_ASSERTF(events == 0, "sensor %u: %d dynamic range events", sensor, events);

   /* set range to 0 */
   TEST_ASSERT_PASSED(test_dynamic_range(DST_ACCELEROMETER, 0, &events));
   TEST_ASSERTF(events >= 1, "sensor %u: %d dynamic range events", sensor, events);

   /* disable event */
   TEST_ASSERT(di_enable_meta_event(di, DME_DYNAMIC_RANGE_CHANGED, FALSE, FALSE));

   /* ensure no event */
   TEST_ASSERT_PASSED(test_dynamic_range(DST_ACCELEROMETER, 16, &events));
   TEST_ASSERTF(events == 0, "sensor %u: %d dynamic range events", sensor, events);

   return TEST_PASSED;
}
TEST_END

/**
 * PRIORITY 1
 * \brief FIFO Watermark
 * enable accel, set watermark to 10%; wait for interrupt; empty
 * FIFO; if enabled, we should see the FIFO Watermark meta event
 * after the data, otherwise, should not see one
 */
typedef struct struct_10_9
{
   int trans_w_x_2_w_x;                                              // transition counter from wakeup any       -> wakeup any
   int trans_w_x_2_w_watermark;                                      // transition counter from wakeup any       -> wakeup meta watermark
   int trans_w_watermark_2_nw_x;                                     // transition counter from wakeup watermark -> non wakeup any
   int trans_w_x_2_nw_x;                                             // transition counter from wakeup any       -> non wakeup any
   int trans_nw_x_2_nw_x;                                            // transition counter from non wakeup any   -> non wakeup any
   int trans_nw_x_2_nw_watermark;                                    // transition counter from non wakeup any   -> non wakeup watermark
   int trans_other;                                                  // transition different than above
   bool first_run;                                                   // is first event?
   DI_SENSOR_INT_UNION_T prev;                                       // store of previous event
}
t_10_9;
t_10_9 g_10_9;                                                       // global test structure

// init test 10.9 struct (clear counters)
void t_10_9_init()
{
   g_10_9.trans_w_x_2_w_x = 0;
   g_10_9.trans_w_x_2_w_watermark = 0;
   g_10_9.trans_w_x_2_nw_x = 0;
   g_10_9.trans_w_watermark_2_nw_x = 0;
   g_10_9.trans_nw_x_2_nw_x = 0;
   g_10_9.trans_nw_x_2_nw_watermark = 0;
   g_10_9.trans_other = 0;
   g_10_9.first_run = TRUE;
}
// print transition counters
void t_10_9_prn()
{
   info_log("trans:\n");
   info_log("w_x  -> w_x   : %d\n", g_10_9.trans_w_x_2_w_x);
   info_log("w_x  -> w_wm  : %d\n", g_10_9.trans_w_x_2_w_watermark);
   info_log("w_x  -> nw_x  : %d\n", g_10_9.trans_w_x_2_nw_x);
   info_log("w_wm -> nw_x  : %d\n", g_10_9.trans_w_watermark_2_nw_x);
   info_log("nw_x -> nw_x  : %d\n", g_10_9.trans_nw_x_2_nw_x);
   info_log("nw_x -> nw_wm : %d\n", g_10_9.trans_nw_x_2_nw_watermark);
   info_log("other         : %d\n", g_10_9.trans_other);
}
// check transitions as expected
// exp_w_wm: expected wakeup watermark
// exp_nw_wm: expected non-wakeup watermark
void t_10_9_chk(bool exp_w_wm, bool exp_nw_wm)
{
   if (exp_w_wm)
   {
      TAFR(g_10_9.trans_w_x_2_w_watermark == 1, "Expecting 1 transition from W -> W meta watermark\n");
      if (di->hi_id != HIID_KITKAT)
      {
         TAFR(g_10_9.trans_w_x_2_nw_x == 0, "Expecting 0 transition from W non meta watermark -> NW\n")
      }
   }
   else
   {
      TAFR(g_10_9.trans_w_x_2_w_watermark == 0, "Expecting 0 transition from W -> W meta watermark\n");
      if (di->hi_id != HIID_KITKAT)
      {
         TAFR(g_10_9.trans_w_x_2_nw_x == 1, "Expecting 1 transition from W non meta watermark -> NW\n")
      }
   }
   if (exp_nw_wm)
   {
      TAFR(g_10_9.trans_nw_x_2_nw_watermark == 1, "Expecting 1 transition from NW -> NW meta watermark\n");
   }
   else
   {
      TAFR(g_10_9.trans_nw_x_2_nw_watermark == 0, "Expecting 0 transition from NW -> NW meta watermark\n");
   }
   TAFR(g_10_9.trans_other == 0, "unexpected transition occured\n");
}
// return true if event is meta.watermark
bool is_meta_watermark(DI_SENSOR_INT_UNION_T *data)
{
   if (data->meta.sensor == DST_META_EVENT ||
       data->meta.sensor == DST_WAKEUP_META_EVENT)
   {
      if (data->meta.event_id == DME_FIFO_WATERMARK)
         return TRUE;
   }
   return FALSE;
}
// update transfer couters
void update_trans_cnt(DI_SENSOR_INT_UNION_T *d)
{
   if (is_wakeup_event(di, g_10_9.prev.sensor))
   {
      if (is_wakeup_event(di, d->sensor))
      {
         if (is_meta_watermark(d))
         {
            g_10_9.trans_w_x_2_w_watermark += 1;
            return;
         }
         g_10_9.trans_w_x_2_w_x += 1;
         return;
      }
      else
      {
         if (is_meta_watermark(&(g_10_9.prev)))
         {
            g_10_9.trans_w_watermark_2_nw_x += 1;
            return;
         }
         g_10_9.trans_w_x_2_nw_x += 1;
         return;
      }
   }
   else
   {
      if (!is_wakeup_event(di, d->sensor))
      {
         if (is_meta_watermark(d))
         {
            g_10_9.trans_nw_x_2_nw_watermark += 1;
            return;
         }
         g_10_9.trans_nw_x_2_nw_x += 1;
         return;
      }
   }
   g_10_9.trans_other += 1;
   info_log("weird transit: from %d % 27s to %d % 27s\n",
            g_10_9.prev.sensor, di_query_sensor_name(di, g_10_9.prev.sensor),
            d->sensor, di_query_sensor_name(di, d->sensor));
}
// callback founction
bool test_10_9_sample_callback(DI_INSTANCE_T *di2, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *data, void *user_param)
{
   DI_SENSOR_INT_UNION_T *union_data;
   data_callback(di2, sensor, data, user_param);

   union_data = getIntDataPtr_knownSensorType(di2, sensor, data);

   if (!g_10_9.first_run)
   {
      update_trans_cnt(union_data);
   }

   g_10_9.first_run = FALSE;
   memcpy(&(g_10_9.prev), union_data, sizeof(DI_SENSOR_INT_UNION_T));

   return TRUE;
}

TEST_START(10_9)
{
   char *txt[] = {"NW", "W"};
   fifo_test_sensor_config sc;
   u16 max_rt;
   fifo_test_config p;
   int fifo;
   int wm_en;
   int other_wm_en;
   bool exp_w_wm;
   bool exp_nw_wm;
   int loops;
   float min_fifo_water_mark = (float)0.10;                          // set between 0.05 and 0.4 - may be recomputed due to expected timing
   float max_fifo_water_mark;                                        // will be set as double of min_fifo_water_mark
   /*u16 fifo_sizes[2];
   u16 tmp_fifo_size_B;
   u32 time_ms;*/
// set minimum time to fill FIFO. Shorter time allow faster test. On the other hand
// some configuration would too long communicating with the device and initializing test
// in such case test likely fail because it expect that all is done within minimum time
// it is recommended to set it 800 ms or try even 1000 if you receive errors where more data
// are received than expected
#define REQUIRED_MINIMUM_TEST_TIME_ms 800

   TEST_ASSERT(min_fifo_water_mark < 0.4)
   TEST_ASSERT(min_fifo_water_mark > 0.05)

   fifo_test_init(first_loop, &sc, &p, &max_rt);
   TEST_ASSERT(di_register(di, test_10_9_sample_callback, (void *)di));
   loops = (di->hi_id != HIID_KITKAT) ? 2 : 1;

   sc.rt[0] = max_rt;
   sc.rt[1] = max_rt;
   p.intrpt[0] = 1;                                                  // NW/K
   p.intrpt[1] = 1;                                                  // W

   // increase FIFO fill percantage or decrease sensor rate in order to achieve test time
   // higher than REQUIRED_MINIMUM_TEST_TIME_ms in order to have enough time for all
   // test overhead (otherwise 718x may be too fast and generate expected interrupt twice
   // which would lead to [false] error reported by test)
   min_fifo_water_mark = get_size_ratio_for_min_time(sc, REQUIRED_MINIMUM_TEST_TIME_ms);
   if (min_fifo_water_mark > (float)0.4)
   {
      min_fifo_water_mark = (float)0.4;
      dec_rate_till_min_time_met(min_fifo_water_mark, &sc, REQUIRED_MINIMUM_TEST_TIME_ms);
   }
   max_fifo_water_mark = 2 * min_fifo_water_mark;

   for (fifo = 0; fifo < loops; fifo++)
   {
      if (fifo == 0)
      {
         p.wm_perc[0] = min_fifo_water_mark;                         // NW/K
         p.wm_perc[1] = max_fifo_water_mark;                         // W
      }
      else
      {
         p.wm_perc[0] = max_fifo_water_mark;                         // NW/K
         p.wm_perc[1] = min_fifo_water_mark;                         // W
      }
      for (wm_en = 0; wm_en < 2; wm_en++)
      {
         TAR(di_enable_meta_event_ex(di, DME_FIFO_WATERMARK, wm_en == 1, FALSE, fifo == 1));
         for (other_wm_en = 0; other_wm_en < loops; other_wm_en++)
         {
            info_log("=== intrpt. watermark: %s, wm meta en: %d, other wm meta en: %d\n", txt[fifo], wm_en, other_wm_en);
            if (di->hi_id != HIID_KITKAT)
            {
               TAR(di_enable_meta_event_ex(di, DME_FIFO_WATERMARK, other_wm_en == 1, FALSE, fifo == 0));
            }
            t_10_9_init();
            chk_water_mark(&p, &sc);
            t_10_9_prn();
            exp_w_wm = (fifo == 1) && (wm_en == 1);
            exp_nw_wm = (fifo == 0) && (wm_en == 1);
            t_10_9_chk(exp_w_wm, exp_nw_wm);
            //fifo_discard(); // PETE: get rid of data now, or next loop may fail due to left over data
            // VBE: it seems more precise if fifo_discard() is in chk_water_mark()
         }
      }
   }

   return g_current_test_retval;
}
TEST_END
