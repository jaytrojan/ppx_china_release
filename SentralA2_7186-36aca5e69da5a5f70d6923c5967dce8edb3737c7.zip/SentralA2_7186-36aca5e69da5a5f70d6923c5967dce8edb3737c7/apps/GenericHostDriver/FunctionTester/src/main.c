#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "driver_ext.h"
#include "host_services.h"
#include "host_definitions.h"
#include "firmware_tests.h"
#include "driver_util.h"
#include "sensor_handling.h"
#include "sensor_stats.h"
#include "test_config.h"
#include "main.h"

#if !defined(VERSION)
#define VERSION 4
#endif

void print_signon(void)
{
   info_log("U718x Firmware Test Suite v1.0.%d, %s, %s\n\n", VERSION, __DATE__, __TIME__);
}

int main(int argc, char *argv[])
{
   char config_file[1024];
   char log_file[1024] = {"log.txt"};
   I2C_HANDLE_T i2c_handle = NULL;
   I2C_HANDLE_T eeprom_i2c_handle = NULL;
   IRQ_HANDLE_T irq_handle = NULL;
   DI_INSTANCE_T *instance = NULL;
   u8 product_id;
   u8 revision_id;
   u16 rom_version;
   u16 ram_version;
   bool eeprom_present;
   bool append_log = FALSE;
   int i;
   bool verbose = FALSE;
   bool force_anyrom = FALSE;
   bool no_prompt = FALSE;
   struct tm *ltime;
   time_t now;
   char normal_firmware[CONF_MAX_STRING + 1] = "";
   char wrong_firmware[CONF_MAX_STRING + 1] = "";
   char *unique_id = NULL;

   // process command line
   strcpy(config_file, "TEST.CFG");


   if (argc > 1)
   {
      for (i = 1; i < argc; i++)
      {
         if ((argv[i][0] == '-') || (argv[i][0] == '/'))
         {
            switch (argv[i][1])
            {
               case 'C':
                  strcpy(config_file, &argv[i][2]);
                  info_log("using config file: %s\n", config_file);
                  break;
               case 'U':
                  unique_id = _strdup(&argv[i][2]);
                  break;
               case 'v':
                  verbose = TRUE;
                  break;
               case 'A':
                  append_log = TRUE;
                  info_log("will append to log\n");
                  break;
               case 'x':
                  force_anyrom = TRUE;
                  info_log("will run on any ROM\n");
                  break;
               case 'l':
                  strcpy(log_file, &argv[i][2]);
                  info_log("using log file: %s\n", log_file);
                  break;
               case 'p':
                  read_test_config(config_file);
                  dump_config();
                  return 0;
               case 'f':
                  strcpy(normal_firmware, &argv[i][2]);
                  info_log("using normal firmware file: %s\n", normal_firmware);
                  break;
               case 'w':
                  strcpy(wrong_firmware, &argv[i][2]);
                  info_log("using wrong firmware file: %s\n", wrong_firmware);
                  break;
               case 'y':
                  no_prompt = TRUE;
                  break;
               case 'h':
               case '?':
                  print_signon();
                  info_log("Usage: %s {-Uid} {-Cfile} {-p} {-v} {-A} {-llog} {-ffile} {-wfile}\n", argv[0]);
                  info_log("-Uid   select I2C interface with unique ID = id\n");
                  info_log("-Cfile set config file name to 'file'\n");
                  info_log("-p     print configuration\n");
                  info_log("-v     set verbose output\n");
                  info_log("-y     no prompt at end\n");
                  info_log("-x     run on any ROM\n");
                  info_log("-A     append to log\n");
                  info_log("-llog  log output to file 'log'\n");
                  info_log("-ffile override config file normal_firmware field (set the em718x firmware filename here)\n");
                  info_log("-wfile override config file wrong_firmware field (set the known-wrong em718x firmware filename here)\n");
                  return 0;
            }
         }
      }
   }

   // log to file if requested
   if (log_file[0] != '\0')
   {
      debug_set_log_file(log_file, append_log);
      info_log("Command line: ");
      for (i = 0; i < argc; i++)
         info_log("%s ", argv[i]);
      info_log("\n");
   }

   if (verbose)
      set_logging_level(LL_DEBUG);

   // log the name of the test
   print_signon();

   // display test start date / time
   time(&now);
   ltime = localtime(&now);
   info_log("current date and time: %s\n", asctime(ltime));

   if (!read_test_config(config_file))
   {
#if defined(CONFIG_FILE_REQUIRED)
      error_log("cannot read config file %s; stopping\n", config_file);
      for (;;) ;
#endif
   }
   if (verbose)
      dump_config();

   if (strlen(normal_firmware))
      strcpy(config.normal_firmware, normal_firmware);
   if (strlen(wrong_firmware))
      strcpy(config.wrong_firmware, wrong_firmware);
   //if (comm_port >= 0)
   //{
   //   config.comm_port = comm_port;
   //   sprintf(unique_id_str, "\\\\.\\COM%u", comm_port);
   //   unique_id = unique_id_str;
   //}

   /**************************************************************
   * set up I2C and Data Ready IRQ                               *
   ***************************************************************/
   i2c_handle = i2c_setup(0x28, unique_id);                   // handle for em718x I2C access
   if (!i2c_init(i2c_handle))
   {
      error_log("I2C init error\n");
      goto error_exit;
   }
   eeprom_i2c_handle = i2c_setup(0x50, unique_id);
   if (!i2c_init(eeprom_i2c_handle))
   {
      error_log("I2C init error\n");
      goto error_exit;
   }
   if (!i2c_handle || !eeprom_i2c_handle)
   {
      error_log("I2C setup error\n");
      goto error_exit;
   }

   irq_handle = irq_setup(5, unique_id);                      // the SPI /SS line on the Aardvark
   if (!irq_handle)
   {
      error_log("IRQ setup error\n");
      goto error_exit;
   }

   /**************************************************************
   * initialize em718x                                          *
   ***************************************************************/
   instance = di_init(i2c_handle, irq_handle, config.reset_each_test);
   if (!instance)
   {
      error_log("driver setup error\n");
      goto error_exit;
   }

   di_set_buffer_max_size(instance, i2c_get_max_read_length(i2c_handle));  // ask the underlying driver what its max size is, then use it

   if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
   {
      error_log("Error detecting u718x\n");
      goto error_exit;
   }

   info_log("U718x detected.  Product id: u71%02X, revision id: %u, rom version: %u, ram version: %u, eeprom present: %u\n",
            product_id, revision_id, rom_version, ram_version, eeprom_present);

   if (rom_version == 0)
   {
      info_log("Error: rom version is 0\n");
      goto error_exit;
   }

   // we select an interface automatically, so we don't need the config file to specify it
   config.using_dil_test_board = driver_is_com_bridge();

   test_run_all(instance);
   goto error_exit;

   error_exit:
   if (instance)
   {
      di_deregister(instance);
      di_shutdown_request(instance);
      di_deinit(instance);
   }
#ifdef WIN32
   if (!no_prompt)
   {
      printf("tests complete; hit a key\n");
      while (get_key() == -1);
   }
#endif
   debug_set_log_file(NULL, FALSE);
   return 0;
}


