#include "test_common.h"

// variables that are setup and valid before any tests are run
DI_INSTANCE_T *di;
I2C_HANDLE_T eeprom_i2c_handle;
int g_current_test_retval;
// global data
bool raw_data_enabled = FALSE;
u16 accel_rate = 0;
u16 gyro_rate = 0;
u16 mag_rate = 0;
u16 quat_rate = 0;
u16 accel_latency = 0;
u16 gyro_latency = 0;
u16 mag_latency = 0;
u16 quat_latency = 0;
char g_tmpTxt[2000];
DI_SENSOR_TYPE_T rotation_sensor = DST_ROTATION_VECTOR;
test_settings_t gtp;                                                 // global test parameters

void display_full_status(void);
void print_physical_sensor_status(void);


/**
 *  \brief global test parameters init
 */
void gtp_init()
{
   gtp.prn_host_intr = 1;
}


/**
 * \brief select specific rates for the upcoming test
 * \param accel
 * \param gyro
 * \param mag
 * \param quat
 *
 */
void set_rates(u16 accel, u16 gyro, u16 mag, u16 quat)
{
   accel_rate = accel;
   gyro_rate = gyro;
   mag_rate = mag;
   quat_rate = quat;
}


/**
 * \brief set latencies
 * \param accel -
 * \param gyro -
 * \param mag -
 * \param quat -
 */
void set_latencies(u16 accel, u16 gyro, u16 mag, u16 quat)
{
   accel_latency = accel;
   gyro_latency = gyro;
   mag_latency = mag;
   quat_latency = quat;
}


/**
 * \brief revert to default rates from config file
 *
 */
void default_rates(void)
{
   raw_data_enabled = FALSE;
   accel_rate = config.accel_norm_rate;
   gyro_rate = config.gyro_norm_rate;
   mag_rate = config.mag_norm_rate;
   quat_rate = config.quat_norm_rate;
   set_latencies(0, 0, 0, 0);
}


/**
 *  \brief calculate if v1 is approximately v2 +- e
 */
bool is_approx(double v1, double v2, double e)
{
   return (v1 >= (v2 - e)) && (v1 <= (v2 + e));
}


/**
 *  \brief Commonly used helper functions
 */
bool di_configure_rate(DI_INSTANCE_T *di, DI_SENSOR_TYPE_T sensor, int rate, int latency)
{
   SENSOR_CONFIG sconf;

   if (!di_query_sensor_config(di, sensor, &sconf))
      return FALSE;

   sconf.sample_rate = rate;
   sconf.max_report_latency = latency;

   if (!di_configure_sensor(di, sensor, &sconf))
      return FALSE;

   return TRUE;
}


/**
 * \brief
 * \param desired_rate -
 * \param measured_rate -
 * \return u16 -
 */
float calc_rate_error(float desired_rate, float measured_rate)
{
   float rate_error;
   if (desired_rate)
      rate_error = (fabs((desired_rate) - (measured_rate)) * 100.0F) / desired_rate;
   else
      rate_error = 100.0F;
   return rate_error;
}


/**
 * \brief
 * \param instance -
 */
void printCommunicationInfo(DI_INSTANCE_T *instance)
{
   int i;
   u32 sensor_data_received;
   if (instance == NULL)
   {
      info_log("Not valid instance");
      return;
   }
   info_log("total bytes transferred  = %u\n", instance->total_bytes_transferred);
   info_log("total samples received   = %u\n", instance->total_samples_received);
   info_log("total invalid samples    = %u\n", instance->total_invalid_samples_received);
   info_log("total pad bytes received = %u\n", instance->total_pad_bytes_received);
   sensor_data_received = 0;
   info_log("sensor, num samples, num slips, num dups, num gaps\n");
   for (i = 0; i <= di_max_sensor_id(instance); i++)
   {
      if (instance->sensor_info[i].samples_received)                 // PETE: shorten to only display sensors that have received data
         info_log("%s: %u, %u, %u, %u\n", di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)i), instance->sensor_info[i].samples_received,
                  instance->sensor_info[i].timestamp_slips, instance->sensor_info[i].timestamp_dups, instance->sensor_info[i].timestamp_gaps);
      sensor_data_received += instance->sensor_info[i].samples_received;
   }
   for (i = DST_FIRST_EXTRA_SENSOR; i <= DST_LAST_EXTRA_SENSOR; i++)
   {
      if (instance->other_events[i - DST_FIRST_EXTRA_SENSOR])
         info_log("%s: %u\n", di_query_extra_event_name(i), instance->other_events[i - DST_FIRST_EXTRA_SENSOR]);
   }
   for (i = 0; i < DME_NUM_META_EVENTS; i++)
   {
      if (instance->meta_events[i])
         info_log("NW meta %s: %u\n", di_query_meta_event_name((DI_META_EVENT_T)i), instance->meta_events[i]);
      if (instance->meta_events_wakeup[i])
         info_log("W meta %s: %u\n", di_query_meta_event_name((DI_META_EVENT_T)i), instance->meta_events_wakeup[i]);
   }
   if (sensor_data_received != instance->total_samples_received)
   {
      info_log("non-sensor events        = %u\n", instance->total_samples_received - sensor_data_received);
   }
}


/**
 *  \brief set up the system to acquire real data; used by many
 *         tests
 */
int test_start_chip_running(char *file, bool gather_data)
{
   RegChipStatus cs;
   u16 ram_version = 0;
   u8 buf[4];
   u32 output_timeout;
   u8 fpga_version;
   AlgIDValues alg_id;
   HIIDValues host_intf_id;
   DI_SENSOR_TYPE_T sensor;

   if (file)                                                         // caller specified a file, so upload it to EEPROM
   {
      if (config.upload_to_ram)
      {
         if (config.eeprom_present)
         {
            info_log("erasing EEPROM...\n");
            TEST_ASSERT(di_erase_eeprom(di, eeprom_i2c_handle));
         }
         info_log("Uploading to RAM...\n");
         TEST_ASSERT(di_upload_firmware(di, file, config.force_anyrom, NULL));
      }
      else
      {
         info_log("Uploading to EEPROM...\n");
         TEST_ASSERT(di_upload_eeprom(di, eeprom_i2c_handle, file, config.force_anyrom, NULL));
      }
   }
   else                                                              // otherwise run with what we've got
   {
      enable_reg_log(config.verbose_regs_at_start);
   }

   enable_reg_log(config.verbose_regs_at_start);

   if (!config.upload_to_ram)
   {
      TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1));
      TEST_ASSERT(cs.bits.EEUploadDone && !cs.bits.EEUploadError && !cs.bits.NoEEPROM);
   }

// TEST_ASSERT(di_set_host_test_mode(di, FALSE)); // force it off
   TEST_ASSERT(di_normal_exec_request(di));
   TEST_ASSERT(di_detect_chip(di, NULL, NULL, NULL, &ram_version, NULL));
   info_log("RAM version = %u\n", ram_version);

   TEST_ASSERT(di_read_registers(di, SR_PASSTHRU_STATUS, SR_PASSTHRU_STATUS + 1, buf));
   fpga_version = (buf[0] >> 1) & 0x7f;
   info_log("FPGA version: 0x%02X\n", fpga_version);
   if ((fpga_version == 0x37) || (fpga_version == 0x38) || (fpga_version == 0x39) || (fpga_version == 0x41) || (fpga_version == 0x43) || (fpga_version == 0x45) || (fpga_version == 0x47) || (fpga_version == 0x49))
   {
      TEST_ASSERT(di_read_registers(di, 0xB6, 0xB6, buf));
      info_log("TimoscDivCount was: %u\n", buf[0]);
      buf[0] = 66;
      TEST_ASSERT(di_write_registers(di, 0xB6, 0xB6, buf));
      info_log("Set TimoscDivCount to %u\n", buf[0]);
   }
   // reset the callbacks until the user changes it later (in case a previous test installed a special one)
   if (gather_data)
   {
      TEST_ASSERT(di_register(di, data_callback, (void *)di));
   }
   else
   {
      TEST_ASSERT(di_register(di, NULL, NULL));
   }

   // wait for initialized event -- after that, it is safe to talk to the device
   output_timeout = time_ms() + INITIALIZED_TIMEOUT_MS;
   di->meta_events[DME_INITIALIZED] = 0;
   do
   {
      if (!di_task_loop(di, NULL))
      {
         display_error_info(di);
         break;
      }
      if (di->meta_events[DME_INITIALIZED])
      {
         info_log("Initialized event received; device is ready\n");
         break;
      }
   }
   while (time_ms() < output_timeout);
   di_pause_task_loop(di);

   alg_id = di_get_algorithm_id(di);
   if (alg_id == AID_BSX)
      info_log("Running BSX fusion algorithm\n");
   else
      info_log("Running SpacePoint fusion algorithm\n");

   host_intf_id = di_get_host_interface_id(di);
   if (host_intf_id == HIID_KITKAT)
      info_log("Running Android KitKat host interface\n");
   else if (host_intf_id == HIID_LOLLIPOP)
      info_log("Running Android Lollipop host interface\n");
   else if (host_intf_id == HIID_LOLLIPOP_EX)
      info_log("Running Android Lollipop extended host interface\n");

   TEST_ASSERT(di_query_features(di));

   // Read out sensor fifo sizes.
   for (sensor = DST_FIRST; sensor <= di_max_sensor_id(di); sensor++)
   {
      SENSOR_INFORMATION info;
      di_query_sensor_info(di, sensor, &info);
   }

   if (raw_data_enabled && (accel_rate || gyro_rate || mag_rate))
   {
      if (di_has_sensor(di, DST_ACCELEROMETER))
         buf[0] = (accel_rate != 0);
      else
         buf[0] = 0;
      if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
         buf[1] = (mag_rate != 0);
      else
         buf[1] = 0;
      if (di_has_sensor(di, DST_GYROSCOPE))
         buf[2] = (gyro_rate != 0);
      else
         buf[2] = 0;
   }
   else
   {
      buf[0] = buf[1] = buf[2] = 0;
   }

   TEST_ASSERT(di_load_parameter(di, PP_ALGORITHM, RAW_INPUT_DATA, buf, 3));
   if (di_has_sensor(di, DST_ACCELEROMETER))
   {
      TEST_ASSERT(di_configure_rate(di, DST_ACCELEROMETER, accel_rate, accel_latency));
   }
   if (di_has_sensor(di, DST_GYROSCOPE))
   {
      TEST_ASSERT(di_configure_rate(di, DST_GYROSCOPE, gyro_rate, gyro_latency));
   }
   if (di_has_sensor(di, DST_GEOMAGNETIC_FIELD))
   {
      TEST_ASSERT(di_configure_rate(di, DST_GEOMAGNETIC_FIELD, mag_rate, mag_latency));
   }
   if (di_has_sensor(di, DST_ROTATION_VECTOR))
   {
      TEST_ASSERT(di_configure_rate(di, rotation_sensor = DST_ROTATION_VECTOR, quat_rate, quat_latency));
   }
   else if (di_has_sensor(di, DST_GAME_ROTATION_VECTOR))
   {
      TEST_ASSERT(di_configure_rate(di, rotation_sensor = DST_GAME_ROTATION_VECTOR, quat_rate, quat_latency));
   }
   else if (di_has_sensor(di, DST_GEOMAGNETIC_ROTATION_VECTOR))
   {
      TEST_ASSERT(di_configure_rate(di, rotation_sensor = DST_GEOMAGNETIC_ROTATION_VECTOR, quat_rate, quat_latency));
   }
   else
      rotation_sensor = DST_NOP;

   //info_log("BSX sensors requested: BSX_A=%u, BSX_B=%u, BSX_C=%u\n", buf[0], buf[1], buf[2], buf[3]);

   if (gather_data)
   {
      if (di->hi_id != HIID_KITKAT)
      {
         TEST_ASSERT(di_configure_interrupts_ex(di, 1, 1, 0, 0));    // enable events
      }
      else
      {
         TEST_ASSERT(di_configure_interrupts(di, 1, 0));             // enable events
      }
   }
   else
   {
      if (di->hi_id != HIID_KITKAT)
      {
         TEST_ASSERT(di_configure_interrupts_ex(di, 0, 0, 0, 0));    // clear all enabled events
      }
      else
      {
         TEST_ASSERT(di_configure_interrupts(di, 0, 0));             // clear all enabled events
      }
   }

   TEST_ASSERT(di_configure_output(di, config.force_ned));           // request normal output

   time_delay_ms(TEST_RUN_DELAY);

   if (gather_data)
   {
      // update the scale factors now that it is running
      TEST_ASSERT(di_query_features(di));
   }

   // should be running
   TEST_ASSERT(di_reg_read(di, SR_CHIP_STATUS, &cs.reg, 1));
   TEST_ASSERT(!cs.bits.FirmwareHalted);

   info_log("U718x is running\n\n");
   enable_reg_log(config.verbose_regs);

   return TEST_PASSED;
}


/**
 * \brief
 * \return int -
 */
int test_start_chip_normal()
{
   return test_start_chip_running(config.normal_firmware, FALSE);
}


/**
 * \brief read data from FIFO for a specific amount of time
 * timeout: time for reading fifo
 * stop_on_first_data:
 */
int test_read_out_pending_data(u32 timeout, bool stop_on_first_data)
{
   u32 start = time_ms();
   u32 sec_start = start;
   u32 secs_to_run = timeout / 1000;
   bool done = FALSE;
   //u16 count;

   for (;;)
   {
      if (!di_task_loop(di, &done))
      {
         display_error_info(di);
         TEST_ASSERT(0);
      }
      if ((time_ms() - start) > timeout)
         break;
      if ((time_ms() - sec_start) > 1000)
      {
         sec_start = time_ms();
         printf("reading FIFO: %u...\r", secs_to_run--);
      }
      if (done && stop_on_first_data)
         break;
   }
   TEST_ASSERT(di_pause_task_loop(di));
   return TEST_PASSED;
}


/**
 * \brief This function keeps trying to call user function until
 *        the user function returns true in such case TRUE is
 *        returned; it has also time limit (after which it
 *        return FALSE) and repeat delay
 * \param what - is the pointer to function which shall be
 *        repeatedly called
 * \param maxTimeMs -max time limit for trying in [ms] (NOTE
 *        actual time will be bigger (the multiple of
 *        loopWitMs))
 * \param loopWaitMs - delay between tries [ms]
 * \return bool -
 */
bool try_with_time_limit(bool (*what)(), u32 maxTimeMs, u32 loopWaitMs)
{
   u32 start_time = time_ms();
   while (1)
   {
      if (what())
         return TRUE;
      if (time_ms() - start_time >= maxTimeMs)
         return FALSE;
      if (loopWaitMs > 0)
         time_delay_ms(loopWaitMs);
   }
}


/**
 * \brief Check Interrupt Status - Host Interrupt bit
 * \param val - expected Host Interrupt Bit
 * \return bool -
 */
bool check_IntStat_HostIntr(bool val)
{
   u32 tm_a = time_ms();
   u32 tm_b;
   RegIntStatus ist;
   ist.reg = ~((u8)(val));
   if (!di_reg_read(di, SR_INT_STATUS, &ist.reg, 1))
   {
      TAFR(0, "Can not read di_reg_read(di, SR_INT_STATUS, &ist.reg, 1)");
      return FALSE;
   }
   tm_b = time_ms();
   if (gtp.prn_host_intr == 1)
   {
      info_log("host interrupt = %u in [ms]:<%u, %u>\n", ist.bits.HostInterrupt, tm_a, tm_b);
   }
   return  ist.bits.HostInterrupt == val;
}


/**
 * \brief Check Interrupt Status - Host Interrupt bit == 0
 * \return bool -
 */
bool check_IntStat_HostIntr_0()
{
   return check_IntStat_HostIntr(0);
}


/**
 * \brief Check Interrupt Status - Host Interrupt bit == 1
 * \return bool -
 */
bool check_IntStat_HostIntr_1()
{
   return check_IntStat_HostIntr(1);
}


/**
 * \brief read FIFO x times
 * \param times - times to read FIFO (if not host interrupt then just try x times)
 * \param prn - TRUE to print how many bytes was read each time
 * \param smpl_rcv - variable which sum of read bytes will be returned
 * \return bool - FALSE on FIFO read error else TRUE
 */
bool read_FIFO(int times, bool prn, u32 *smpl_rcv)
{
   u32 smpl_beg;
   u32 smpl_end;
   u32 smpl_dif;
   u32 b_beg;
   u32 b_dif;
   u32 tm_beg;
   u32 tm_end;
   int i;
   if (smpl_rcv != NULL)
   {
      *smpl_rcv = 0;
   }
   for (i = 0; i < times; i++)
   {
      smpl_beg = di->total_samples_received;
      b_beg = di->total_bytes_transferred;
      tm_beg = time_ms();
      if (!di_task_loop(di, NULL))
      {
         display_error_info(di);
         TAFR(0, "di_task_loop filed");
      }
      if (!di_pause_task_loop(di))
      {
         TAFR(0, "di_pause_task_loop failed");
         return FALSE;
      }
      smpl_end = di->total_samples_received;
      smpl_dif = smpl_end - smpl_beg;
      b_dif = b_beg = di->total_bytes_transferred - b_beg;
      tm_end = time_ms();
      if (smpl_rcv != NULL)
      {
         *smpl_rcv += smpl_dif;
      }
      if (prn == TRUE)
      {
         info_log("FIFO read [B/event] %u/%u; time [ms]: <%u,%u> dif: %u\n",
                  b_dif, smpl_dif, tm_beg, tm_end, tm_end - tm_beg);
      }
   }
   return TRUE;                                                      // FALSE will cause re-calling by try_with_time_limit()
}


/**
 * \brief Reads FIFO if interrupt; return FALSE if interrupt
 *        detected (reading may and probably won't finish unless
 *        multiple call); return TRUE when there is no intrrupt
 *        (no data to read); NOTE: return is inverted it is
 *        because expected caller try_with_time_limit is calling
 *        it again if some data was read (and FALSE is
 *        returned); NOTE: this function won't manage to read
 *        faster than fastest rate 200Hz in such a loop you
 *        would still read.
 * \return bool -
 */
bool read_if_int()
{
   bool ret;
   /*if (irq_check(di->irq_handle) == FALSE)
   {
      time_delay_us(1000);                                            // TODO assess what is max delay 718x takes to reassert interrupt if data pending
      if (irq_check(di->irq_handle) == FALSE)
         return TRUE;
   }*/

   // We have moved from irq_check to directly read host interrupt register
   //   irq_check may be delayed due to USB/AARDVARK
   ret = try_with_time_limit(check_IntStat_HostIntr_1, 9, 10);
   if (!ret)
   {                                                                 // if not host interrupt
      return TRUE;                                                   // true will cause not re-calling by try_with_time_limit()
   }

   read_FIFO(1, 0, NULL);
   return FALSE;                                                     // FALSE will cause re-calling by try_with_time_limit()
}


/**
 * \brief read FIFO as long as interrupt detected or timeout
 *        reached
 * \param timeoutMs - maximum timeout to try to read out FIFO
 * \param no_irq_tm - if no IRQ for more than this time (in[ms])
 *        this function will return
 * \param irq_limit - return after chosen interrupt number
 * \param irq_limit_for_long_tm - return after chosen interrupt
 *        when time diff is longer than long_irq_diff_tm
 * \param long_irq_diff_tm - [ms] see irq_limit_for_long_tm
 * \param smplRecv - pointer to variable which will contains
 *        number of samples (events [not bytes]) received
 * \return bool - false when timeoutMs expire, other timeout
 *         returns true
 */
bool read_out_while_intr_int(u32 timeoutMs, u32 no_irq_tm,
                             u32 irq_limit, u32 irq_limit_for_long_tm, u32 long_irq_diff_tm,
                             u32 *smplRecv)
{
   bool ok = TRUE;
   u32 start_time = time_ms();
   u32 irq_tm_ms;
   u32 irq_tm_dif_ms = 0;
   u32 irq_tm_prev_ms = 0;
   u32 irq_cnt = 0;
   u32 rd_tm_end = 0;
   u32 irq_tm_dif_subs_read_time_ms = 0;                             // IRQ time difference (with subtracted read time) [ms]
   bool was_read;
   if (smplRecv != NULL)
   {
      *smplRecv = di->total_samples_received;
   }

   rd_tm_end = irq_tm_prev_ms = time_ms();
   while (1)
   {
      if (irq_check(di->irq_handle) == TRUE)
      {
         was_read =  TRUE;
         irq_tm_ms = time_ms();
         irq_tm_dif_ms = irq_tm_ms - irq_tm_prev_ms;
         irq_tm_dif_subs_read_time_ms = irq_tm_ms - rd_tm_end;
         irq_tm_prev_ms = irq_tm_ms;
         irq_cnt++;
         info_log("IRQ last period: %u [ms], since end of read: %u [ms]\n", irq_tm_dif_ms, irq_tm_ms - rd_tm_end);
         read_FIFO(1, 1, NULL);
         rd_tm_end = time_ms();
         //info_log("IRQ read ends: [ms]: %u read time dif: %u\n",rd_tm_end,rd_tm_end-irq_tm_prev_ms);
         if (irq_cnt >= irq_limit)
         {
            info_log("IRQ limit %u is up\n", irq_limit);
            break;
         }
         if ((irq_cnt >= irq_limit_for_long_tm) && (irq_tm_dif_subs_read_time_ms >= long_irq_diff_tm))
         {
            info_log("IRQ long limit %u is up due to time diff longer than %u [ms]\n",
                     irq_limit_for_long_tm, long_irq_diff_tm);
            break;
         }
      }
      else
      {
         was_read = FALSE;
         if ((time_ms() - irq_tm_prev_ms) > no_irq_tm)
         {
            info_log("no IRQ for longer than %u [ms]- give up waiting\n", no_irq_tm);
            // no interrupt for 100 ms consider no data and return
            break;
         }
      }
      if ((time_ms() - start_time) > timeoutMs)
      {
         info_log("total receiving time %u [ms] is up\n", timeoutMs);
         ok = FALSE;
         break;
      }
      if (!was_read)
      {
         time_delay_ms(1);
      }
   }
   //if (!try_with_time_limit(read_if_int, timeoutMs, 0))
   //{
   //   ok = FALSE;
   //}
   if (!ok)
   {
      // --> PETE: this causes test 9.5 to fail some times for me ---
      //TAFR(0, "Didn't manage to read out all FIFO data in time\n");
      warn_log("Didn't manage to read out all FIFO data in time\n");
   }
   if (smplRecv != NULL)
   {
      *smplRecv = di->total_samples_received - *smplRecv;
   }
   return ok;
}


/**
 * \brief
 * \param timeoutMs -
 * \param smplRecv -
 * \param no_irq_time -
 * \return bool -
 */
bool read_out_while_intr(u32 timeoutMs, u32 *smplRecv, u32 no_irq_time)
{
   // we expect user will set his prefered total timeout, irq timeouts are rather huge
   u32 irq_limit = 1000;
   u32 irq_limit_for_long_tm = 200;
   u32 long_irq_diff_tm = 100;
   return read_out_while_intr_int(timeoutMs, no_irq_time, irq_limit, irq_limit_for_long_tm, long_irq_diff_tm, smplRecv);
}


/**
 * \brief Try to flush FIFO, and check it is empty by reading interrupt
 * \return int -
 */
int flushBothFifoAndCheckEmpty()
{
   u32 smplRecv;

   info_log("reading pending data\n");

   //test_read_out_pending_data(5000, FALSE);
   TEST_ASSERT(read_out_while_intr_int(5000, 500, 100, 100, 5000, &smplRecv));
   
   // check no interrupt asserted
   TEST_ASSERT(irq_check(di->irq_handle) == FALSE);

   return TEST_PASSED;
}


/**
 * \brief set hot interface disable bit and read it back to check it was set correctly
 * \param hostIntrDis - selects how to set "Host Interrupt Disable" value in "Host Control" register
 * \param wakeUpFIFO - FALSE - regarding Non Wake up FIFO
 *                     TRUE - regarding WAKEUP FIFO
 *                     Note for android K this param is ignored
 * \return int - TEST_PASSED if ok, otherwise error
 */
int setAndTestHostIntrDisable(bool hostIntrDis, bool wakeUpFIFO)
{
   RegHostIntfControl hcin, hcout;
   hcin.reg = 0;
   if ((di->hi_id != HIID_KITKAT) && (wakeUpFIFO == FALSE))
   {
      hcin.bits.NonWakeupFIFOIntDisable = hostIntrDis ? 1 : 0;
   }
   else
   {
      hcin.bits.HostIntDisable = hostIntrDis ? 1 : 0;
   }

   hcout.reg = ~hcin.reg;
   TAR(di_reg_write(di, SR_HOST_INTF_CONTROL, &hcin.reg, 1));
   TEST_ASSERT(di_reg_read(di, SR_HOST_INTF_CONTROL, &hcout.reg, 1));
   TEST_ASSERT(hcout.reg == hcin.reg);
   return TEST_PASSED;
}


/**
 * \brief Format host interrupt register to text
 * \param val - host interrupt register value
 * \param txt - text buffer to use (shall be at least 200B)
 * \return char* - txt buffer pointer
 */
char *hostIntrToStr(u8 val, char *txt)
{
   RegIntStatus ist;
   ist.reg = val;
   if (ist.bits.HostInterrupt == 1)
      sprintf(txt, "hstIntr==1");
   else
      sprintf(txt, "hstIntr==0");
   if (ist.bits.NonWakeupImmediate == 1)
      sprintf(txt, "%s,NW Imm", txt);
   if (ist.bits.NonWakeupLatency == 1)
      sprintf(txt, "%s,NW Lat", txt);
   if (ist.bits.NonWakeupWatermark == 1)
      sprintf(txt, "%s,NW Wtr", txt);
   if (ist.bits.WakeupImmediate == 1)
      sprintf(txt, "%s,W  Imm", txt);
   if (ist.bits.WakeupLatency == 1)
      sprintf(txt, "%s,W  Lat", txt);
   if (ist.bits.WakeupWatermark == 1)
      sprintf(txt, "%s,W  Wtr", txt);
   return txt;
}


/**
 * \brief check host interrupt
 * \param val - expected value of interrupt lsb is host
 *        interrupt
 * \param maxTimeMs - max time to wait for correct value
 * \param loopWaitMs - delay between polling the value
 * \return int - TEST_PASSED if value correct within time limit
 *         else error is returned
 */
int checkHostIntr(u8 val, u32 maxTimeMs, u32 loopWaitMs)
{
   char txtExp[200];
   char txtGot[200];
   RegIntStatus ist;
   if (di->hi_id == HIID_KITKAT)
   {
      val &= 0x01;
   }
   if (maxTimeMs > 0)
   {
      bool (*fnc)();
      if ((val & 1) == 1)
         fnc = check_IntStat_HostIntr_1;
      else
         fnc = check_IntStat_HostIntr_0;
      try_with_time_limit(fnc, maxTimeMs, loopWaitMs);
   }
   TEST_ASSERT(di_reg_read(di, SR_INT_STATUS, &ist.reg, 1));
   info_log("received intr: 0x%02x: %s\n", ist.reg, hostIntrToStr(ist.reg, txtGot));
   if (ist.reg != val)
   {
      display_full_status();
   }
   TEST_ASSERTF(ist.reg == val, "expecting interrupt 0x%02x (%s), but got 0x%02x (%s)"
                , val, hostIntrToStr(val, txtExp),
                ist.reg, hostIntrToStr(ist.reg, txtGot));
   return TEST_PASSED;
}


/**
 * \brief
 * \param val_a -
 * \param val_b -
 * \param val_c -
 * \return int -
 */
int checkHostIntr2(u8 val_a, u8 val_b, u8 val_c)
{
   char txtGot[200];
   RegIntStatus ist;
   if (di->hi_id == HIID_KITKAT)
   {
      val_a &= 0x01;
      val_b &= 0x01;
      val_c &= 0x01;

   }
   TEST_ASSERT(di_reg_read(di, SR_INT_STATUS, &ist.reg, 1));
   info_log("received intr: 0x%02x: %s\n", ist.reg, hostIntrToStr(ist.reg, txtGot));
   TEST_ASSERTF((ist.reg == val_a) || (ist.reg == val_b) || (ist.reg == val_c),
                "expecting interrupt 0x%02x or 0x%02x or 0x%02x, but got 0x%02x (%s)"
                , val_a, val_b, val_c,
                ist.reg, hostIntrToStr(ist.reg, txtGot));
   return TEST_PASSED;
}


/**
 * \brief
 * \param exp -
 * \param act -
 * \param marg_mult_l -
 * \param marg_add_l -
 * \param marg_mult_r -
 * \param marg_add_r -
 * \return bool -
 */
bool chk_d_val_with_margin_lr(s32 exp, s32 act,
                              double marg_mult_l, double marg_add_l,
                              double marg_mult_r, double marg_add_r)
{
   double dMax;
   double dMin;
   bool res;
   dMin = exp - ((exp * marg_mult_l) + marg_add_l);
   dMax = exp + ((exp * marg_mult_r) + marg_add_r);
   res = (act >= dMin) &&
         (act <= dMax);
   info_log("checking %f if in <%f, %f, %f>: %s\n",
            act, dMin, exp, dMax, res ? "ok" : "failed");
   TAR(res);
   return res;
}


/**
 * \brief
 * \param exp -
 * \param act -
 * \param marg_mult -
 * \param marg_add -
 * \return bool -
 */
bool chk_d_val_with_margin(s32 exp, s32 act,
                           double marg_mult, double marg_add)
{
   return chk_d_val_with_margin_lr(exp, act,
                                   marg_mult, marg_add,
                                   marg_mult, marg_add);
}


/**
 * \brief
 * \param exp -
 * \param act -
 * \param marg_mult_l -
 * \param marg_add_l -
 * \param marg_mult_r -
 * \param marg_add_r -
 * \return bool -
 */
bool chk_s_val_with_margin_lr(s32 exp, s32 act,
                              double marg_mult_l, int marg_add_l,
                              double marg_mult_r, int marg_add_r)
{
   double dMax;
   double dMin;
   s32 maxEvnts;
   s32 minEvnts;
   bool res;
   dMin = exp - ((exp * marg_mult_l) + marg_add_l);
   dMax = exp + ((exp * marg_mult_r) + marg_add_r);
   maxEvnts = (s32)(dMax + 0.5);                                     // round
   minEvnts = (s32)(dMin);                                           // floor
   res = (act >= minEvnts) &&
         (act <= maxEvnts);
   info_log("checking %d if in <%d, %d, %d>: %s\n",
            act, minEvnts, exp, maxEvnts, res ? "ok" : "failed");
   TAR(res);
   return res;
}


/**
 * \brief
 * \param exp -
 * \param act -
 * \param marg_mult -
 * \param marg_add -
 * \return bool -
 */
bool chk_s_val_with_margin(s32 exp, s32 act,
                           double marg_mult, int marg_add)
{
   return chk_s_val_with_margin_lr(exp, act,
                                   marg_mult, marg_add,
                                   marg_mult, marg_add);
}


/**
 * \brief
 * \param val -
 * \param min -
 * \param max -
 * \return bool -
 */
bool chk_val_min_max(u32 val, u32 min, u32 max)
{
   bool res;
   res = (val >= min) &&
         (val <= max);
   info_log("checking %u if in <%u, %u>: %s\n",
            val, min, max, res ? "ok" : "failed");
   TAR(res);
   return res;
}


/**
 * \brief check value with margin (on left or right)
 * \param exp - expected value
 * \param act - actual value
 * \param marg_mult_l - margin multiplier ig 0.2 -> 20%
 * \param marg_add_l - margin add integer
 * \param marg_mult_r - margin multiplier ig 0.2 -> 20%
 * \param marg_add_r - margin add integer
 * \param txt -
 * \return bool -
 */
bool chk_val_with_margin_lr_dbl(double exp, double act,
                                double marg_mult_l, double marg_add_l,
                                double marg_mult_r, double marg_add_r, char *txt)
{
   double dSigma_l;
   double dSigma_r;
   double dMax;
   double dMin;
   double maxEvnts;
   double minEvnts;
   bool res;
   dSigma_l = (exp * marg_mult_l) + marg_add_l;
   dSigma_r = (exp * marg_mult_r) + marg_add_r;
   dMin = exp - dSigma_l;
   dMin = (dMin < 0) ? 0 : dMin;
   dMax = exp + dSigma_r;
   maxEvnts = dMax;
   minEvnts = dMin;
   res = (act >= minEvnts) &&
         (act <= maxEvnts);
   info_log("checking %s %f if in <%f, %f, %f>: %s\n",
            txt, act, minEvnts, exp, maxEvnts, res ? "ok" : "failed");
   TAR(res);
   return res;
}


/**
 * \brief check value with margin (on left or right)
 * \param exp - expected value
 * \param act - actual value
 * \param marg_mult_l - margin multiplier ig 0.2 -> 20%
 * \param marg_add_l - margin add integer
 * \param marg_mult_r - margin multiplier ig 0.2 -> 20%
 * \param marg_add_r - margin add integer
 * \return bool -
 */
bool chk_val_with_margin_lr(u32 exp, u32 act,
                            double marg_mult_l, int marg_add_l,
                            double marg_mult_r, int marg_add_r)
{
   double dSigma_l;
   double dSigma_r;
   double dMax;
   double dMin;
   u32 maxEvnts;
   u32 minEvnts;
   bool res;
   dSigma_l = (exp * marg_mult_l) + marg_add_l;
   dSigma_r = (exp * marg_mult_r) + marg_add_r;
   dMin = exp - dSigma_l;
   dMin = (dMin < 0) ? 0 : dMin;
   dMax = exp + dSigma_r;
   maxEvnts = (u32)(dMax + 0.5);                                     // round
   minEvnts = (u32)(dMin);                                           // floor
   res = (act >= minEvnts) &&
         (act <= maxEvnts);
   info_log("checking %u if in <%u, %u, %u>: %s\n",
            act, minEvnts, exp, maxEvnts, res ? "ok" : "failed");
   TAR(res);
   return res;
}


/**
 * \brief
 * \param exp_l - expected value, left (lower)
 * \param exp_r - expected value, right (higher)
 * \param act - actual value
 * \param marg_mult_l - margin multiplier ig 0.2 -> 20%
 * \param marg_add_l - margin add integer
 * \param marg_mult_r - margin multiplier ig 0.2 -> 20%
 * \param marg_add_r - margin add integer
 * \return bool -
 */
bool chk_dual_val_with_margin_lr(u32 exp_l, u32 exp_r, u32 act,
                                 double marg_mult_l, int marg_add_l,
                                 double marg_mult_r, int marg_add_r)
{
   double dSigma_l;
   double dSigma_r;
   double dMax;
   double dMin;
   u32 maxEvnts;
   u32 minEvnts;
   bool res;
   dSigma_l = (exp_l * marg_mult_l) + marg_add_l;
   dSigma_r = (exp_r * marg_mult_r) + marg_add_r;
   dMin = exp_l - dSigma_l;
   dMin = (dMin < 0) ? 0 : dMin;
   dMax = exp_r + dSigma_r;
   maxEvnts = (u32)(dMax + 0.5);                                     // round
   minEvnts = (u32)(dMin);                                           // floor
   res = (act >= minEvnts) &&
         (act <= maxEvnts);
   info_log("checking %u if in <%u, %u, %u, %u>: %s\n",
            act, minEvnts, exp_l, exp_r, maxEvnts, res ? "ok" : "failed");
   TAR(res);
   return res;
}


/**
 * \brief
 * \param exp -
 * \param act -
 * \param marg_mult -
 * \param marg_add -
 * \return bool -
 */
bool chk_val_with_margin(u32 exp, u32 act, double marg_mult, int marg_add)
{
   return chk_val_with_margin_lr(exp, act,
                                 marg_mult, marg_add,
                                 marg_mult, marg_add);
}


/**
 * \brief Wait for IRQ pin
 * \param exp - expected value
 * \param max_wait_ms - max wait time [ms]
 * \return bool -
 */
bool wait_int_pin(bool exp, u32 max_wait_ms)
{
   bool ret;
   u32 tm_beg = time_ms();
   u32 tm_end = tm_beg + max_wait_ms;
   while (TRUE)
   {
      ret = irq_check(di->irq_handle);
      if (exp == ret)
      {
         info_log("IRQ pin: %d (as expected ) waited: %d [ms]: ", ret, time_ms() - tm_beg);
         return TRUE;
      }
      if (time_ms() > tm_end)
      {
         info_log("IRQ pin: %d (as NOT expected )waited: %d [ms]: ", ret, time_ms() - tm_beg);
         return FALSE;
      }
   }
}


/**
 * \brief check host interrupt pin
 * \param exp -
 * \return bool - TRUE if as expected, FALSE otherwise
 */
bool check_int_pin(bool exp)
{
   bool ret;
   u32 tm_a = time_ms();
   u32 tm_b;
   ret = irq_check(di->irq_handle);
   tm_b = time_ms();
   info_log("IRQ pin:%d occurred at run time %u -> %u; delta %u ms\n", ret, tm_a, tm_b, tm_b - tm_a);
   return exp == ret;
}

bool check_int_pin_0(void)
{
   return check_int_pin(0);
}

bool check_int_pin_1(void)
{
   return check_int_pin(1);
}


/**
 * \brief
 * \return bool -
 */
bool fifo_discard_by_read_fifo_data()
{
   u32 no_irq_tm = 50;
   u32 irq_limit = 6;
   u32 irq_limit_for_long_tm = 1;
   u32 long_irq_diff_tm = 10;
   info_log("FIFO FLUSH!\n");
   TAR(di_fifo_flush(di, 0xFF));
   info_log("FIFO DISCARD by reading out all samples!\n");
   return read_out_while_intr_int(2000, no_irq_tm, irq_limit, irq_limit_for_long_tm, long_irq_diff_tm, NULL);
}


/**
 * \brief Try to flush FIFO, and check it is empty by readings
 *        FIFO
 * \return int -
 */
int fifo_discard()
{
   static u8 counter = 0;

   if (1) // di->hi_id != HIID_KITKAT)
   {
      info_log("Discarding FIFOs %u\n", counter++);
      TAR(di_fifo_flush(di, DST_DISCARD_ALL));
   }
   else
   {
      fifo_discard_by_read_fifo_data();
   }
   return TEST_PASSED;
}


/**
 * \brief read bytes remaining - will be stored in di->fifo_bytes_remaining
 *        note this function shall be called after interrupt is generated (otherwise partial LSB/MSB may be read)
 * \return bool -
 */
bool read_bytes_remaining()
{
   static u8 buf[2];
   if (!di_read_registers(di, SR_BYTES_REMAINING_LSB, SR_BYTES_REMAINING_LSB + 1, buf))
   {
      TAFR(FALSE, "reading registers SR_BYTES_REMAINING_LSB failed");
      return FALSE;
   }

   di->fifo_bytes_remaining = ((u16)buf[0]) + (((u16)buf[1]) << 8);
   return TRUE;
}


/**
 * \brief
 * \return int -
 */
int check_FIFO_consistency()
{
   info_log("checking FIFO consistency: ");
   TEST_ASSERT(di->total_invalid_samples_received == 0);
   TEST_ASSERT(di->total_timeslips == 0);
   TEST_ASSERT(di->total_timegaps == 0);
   TEST_ASSERT(di->total_timedups == 0);
   info_log("ok\n");
   return TEST_PASSED;
}


/**
 * \brief return maximum number of events of type DI_3AXIS_INT_DATA_T (e.g. DST_ACCELEROMETER)
 *        which will fill full FIFO; expecting there will be LSW timestamp before each DI_3AXIS_INT_DATA_T event
 *        NOTE: in reality it will be less because there may be other events possibly generated in FIFO
 *        (like at least 1 MSW timesatmp, meta events, or other sensors data)
 * \param di - driver instance
 * \param w - will store maximum wakeup fifo events
 * \param nw - will store maximum non wakeup fifo events
 * \return bool -
 */
bool get_3axis_fifo_events(DI_INSTANCE_T *di, u16 *w, u16 *nw)
{
   FIFO_CONTROL_PARAM fifoCtrl;
   u16 w2;
   u16 nw2;
   // do not use fifo_max as is do NOT count in timestamps size
   //TEST_ASSERT(di_query_sensor_info(di, sp->s, &sensor_info));
   //sp->limit_fifo_events = sensor_info.fifo_max;
   // more accurate fifo max sensor events (count in expected at least one timestamp before sensor)
   di_save_parameter(di, PP_SYSTEM, SYSP_FIFO_CONTROL, (u8 *)&fifoCtrl, sizeof(FIFO_CONTROL_PARAM));
   w2 = fifoCtrl.fifo_size / ACCEL_EVENT_FIFO_REAL_SIZE;
   nw2 = fifoCtrl.nonwakeup_fifo_size / ACCEL_EVENT_FIFO_REAL_SIZE;
   info_log("fifo size [B/evnts] W: %u/%u NW: %u/%u\n", fifoCtrl.fifo_size, w2, fifoCtrl.nonwakeup_fifo_size, nw2);
   if (di->hi_id == HIID_KITKAT)
   {
      nw2 = w2;
      w2 = 0;
   }
   if (w != NULL)
   {
      *w = w2;
   }
   if (nw != NULL)
   {
      *nw = nw2;
   }
   return TRUE;
}


/**
 * \brief convert fifo size to events of requested sensor (compensate for LSW timestamp)
 * \param sz_B - size in bytes
 * \param s - sensor to be generating data events
 * \return u16 - expected sensor events (note actual number will be less due to meta events and MSW timestamps)
 */
u16 fifo_size_to_events(u16 sz_B, DI_SENSOR_TYPE_T s)
{
   u32 s_sz = get_sensor_data_size(s);
   if (s_sz == 0)
   {
      TAFR(s_sz != 0, "Error got 0 sensor size for sensor: %d", s)
      return 0;
   }
   else
   {
      s_sz -= sizeof(u32);                                           // subtract time add in driver
      s_sz += sizeof(DI_TIMESTAMP_DATA_T);                           // add timestamp usually before event
      return (u16)ceil((double)(sz_B) / s_sz);
   }
}

//-----------------------------------------------------------------------------
// global variables used by function chk_sens_stat_data_avail()
DI_SENSOR_TYPE_T g_chk_sens_stat_data_avail_sens;                    // sensor to be read for sensor "data avaialble" bit
bool g_chk_sens_stat_data_avail_exp;                                 // expected value of "data available" bit


/**
 * \brief set parameters for chk_sens_stat_data_avail() function
 * \param s - tested sensor
 * \param exp - expected value
 */
void chk_sens_stat_data_avail_param(DI_SENSOR_TYPE_T s, bool exp)
{
   g_chk_sens_stat_data_avail_sens = s;
   g_chk_sens_stat_data_avail_exp = exp;
}


/**
 * \brief Check sensor status - bit "data available"
 *        expected settings is set by function chk_sens_stat_data_avail_param;
 * \return bool -
 */
bool chk_sens_stat_data_avail()
{
   SENSOR_STATUS s_stat;
   TAR(di_query_sensor_status(di));
   TAR(di_read_sensor_status(di, g_chk_sens_stat_data_avail_sens, &s_stat));
   info_log("sens: %d data_available: got %d exp: %d, time [ms] %u\n",
            g_chk_sens_stat_data_avail_sens, s_stat.data_available,
            g_chk_sens_stat_data_avail_exp, time_ms());
   return s_stat.data_available == g_chk_sens_stat_data_avail_exp;
}


/**
 * \brief add sensor to struct "available_sensors_t"
 * \param a - struct of available sensor (with initialized counters)
 * \param s - sensor to add
 * \return bool -
 */
bool add_avail_sens(available_sensors_t *a, DI_SENSOR_TYPE_T s)
{
   bool ok = TRUE;
   SENSOR_INFORMATION info;
   if (!di_has_sensor(di, s))
   {
      info_log("sens: % 2d % 27s: NOT AVAILABLE\n", s, di_query_sensor_name(di, s));
      return FALSE;
   }
   di_query_sensor_info(di, s, &info);
   info_log("sens: % 2d % 27s: [hz] max: %u min: %u\n",
            s, di_query_sensor_name(di, s), info.max_rate, info.min_rate);
   if (a->cu >= MAX_AVAILABLE_SENSORS)
   {
      error_log("avail_sens_list: Too many sensors %d\n", a->cu);
      ok = FALSE;
   }
   else
   {
      a->su[a->cu++] = s;
   }
   if ((di->hi_id != HIID_KITKAT) && ((s & di_wake_sensor_start(di)) != 0))
   {                                                                 // wakeup sensor
      if (a->cw >= MAX_AVAILABLE_SENSORS)
      {
         error_log("avail_sens_list: Too many sensors %d\n", a->cw);
         ok = FALSE;
      }
      else
      {
         a->sw[a->cw++] = s;
      }
   }
   else
   {                                                                 // non wakeup sensor
      if (a->c >= MAX_AVAILABLE_SENSORS)
      {
         error_log("avail_sens_list: Too many sensors %d\n", a->c);
         ok = FALSE;
      }
      else
      {
         a->s[a->c++] = s;
      }
   }
   return ok;
}


/**
 * \brief creates list of sensor that are available (present) in system
 *        NOTE! works only after di_query_features was called before!!!
 * \param sz - size of sensor list
 * \param searchSensors - sensors to be checked if are present
 * \param a - output available sensors list
 */
void avail_sens_list(int sz, DI_SENSOR_TYPE_T searchSensors[], available_sensors_t *a)
{
   int i;
   int j;

   info_log("Available sensors:\n");
   // clear sensors list
   a->c = 0;
   a->cw = 0;
   a->cu = 0;
   for (i = 0; i < MAX_AVAILABLE_SENSORS; i++)
   {
      a->s[i] = DST_NOP;
      a->sw[i] = DST_NOP;
      a->su[i] = DST_NOP;
   }
   // detect available sensors in system
   for (j = 0; j <= (di->hi_id != HIID_KITKAT) ? 1 : 0; j++)
   {
      for (i = 0; i < sz; i++)
      {
         DI_SENSOR_TYPE_T s = searchSensors[i];
         if (s != DST_NOP)
         {
            s |= ((j == 1) ? di_wake_sensor_start(di) : 0);
            if (s != DST_NOP)                                           // suppress confusing error message
            {
               add_avail_sens(a, s);
            }
         }
      }
   }
}


/**
 * \brief set same rate for each sensor in sensor list
 * \param sz - size of sensor list
 * \param s - sensors list
 * \param sr - required sensor rate; U16_MAX +65535 = maximum rate
 */
void set_list_sensors_rate(int sz, DI_SENSOR_TYPE_T *s, u16 sr)
{
   int i;
   u16 qsr;
   for (i = 0; i < sz; i++) // sz - 1; i >= 0; i--)
   {
      info_log("setting rate of %u: %s to %u\n", s[i], di_query_sensor_name(di, s[i]), sr);
      if ((sr != 0) && (!di_has_sensor(di, s[i])))
      {
         warn_log("Sensor %d % 27s not present in system skipping setting rate %u\n",
                  s[i], di_query_sensor_name(di, s[i]), sr);
         continue;
      }
      AP(
         set_and_chk_rate(s[i], sr, &qsr, TRUE),
         "can not set sensor % 27s\n",
         di_query_sensor_name(di, s[i])
         );
   }
}


/**
 * \brief turn off (set rate 0) for all available sensors
 * \param a - list of Availabe sensors
 */
void avail_sens_turn_off(available_sensors_t *a)
{
   set_list_sensors_rate(a->c, a->s, 0);
   set_list_sensors_rate(a->cw, a->sw, 0);
}


DI_SENSOR_TYPE_T all_std_sens[] = {
   DST_ACCELEROMETER,       DST_GEOMAGNETIC_FIELD,           DST_ORIENTATION,
   DST_GYROSCOPE,           DST_LIGHT,                       DST_PRESSURE,
   DST_TEMPERATURE,         DST_PROXIMITY,                   DST_GRAVITY,
   DST_LINEAR_ACCELERATION, DST_ROTATION_VECTOR,             DST_RELATIVE_HUMIDITY,
   DST_AMBIENT_TEMPERATURE, DST_MAGNETIC_FIELD_UNCALIBRATED, DST_GAME_ROTATION_VECTOR,
   DST_GYROSCOPE_UNCALIBRATED, DST_GEOMAGNETIC_ROTATION_VECTOR, DST_HEART_RATE};
const int g_all_std_sens_sz = ARRAY_SIZE(all_std_sens);


/**
 * \brief set and check latency
 * \param s - sensor to configure
 * \param lat - required latency value [ms]
 * \param ql - latency read back
 * \param chkLat - set TRUE to check latency
 * \return bool -
 */
bool set_and_chk_lat(DI_SENSOR_TYPE_T s, u16 lat, u16 *ql, bool chkLat)
{
   SENSOR_CONFIG sensor_config;
   bool ret = TRUE;
   int wait_time_ms = 0;
   u16 ql2;

   if ((s == DST_NOP) || (!di_has_sensor(di, s)))
   {
      ql2 = 0;
   }
   else
   {
      ret &= di_query_sensor_config(di, s, &sensor_config);
      sensor_config.max_report_latency = lat;
      ret &= di_configure_sensor(di, s, &sensor_config);
      // PETE: some sensors take a long time to complete configuration;
      //   the readback of the current rate will be wrong if we ask for it below too soon
      //time_delay_ms(100);
      while (TRUE)
      {
         ret &= di_query_sensor_config(di, s, &sensor_config);
         if ((ret && (sensor_config.max_report_latency == lat))      // already configured sooner
             || (wait_time_ms > 100))                                // timeout reached
         {
            break;
         }
         time_delay_ms(10);
         wait_time_ms += 10;
      }
      ql2 = sensor_config.max_report_latency;
   }
   info_log("set % 20s latency: % 3u ret latency: % 3u\n", di_query_sensor_name(di, s), lat, ql2);
   if (chkLat)
   {
      TAFR(ql2 == lat, "Latency not set correctly expecting %d, got %d", lat, ql2);
   }
   if (ql != NULL)
   {
      *ql = ql2;
   }
   return ret;
}


/**
 * \brief
 */
void display_full_status(void)
{
   u16 max_fifo_B[2];
   u16 count;
   display_error_info(di);
   di_query_sensor_status(di);
   display_sensor_status_bytes(di, TRUE);
   display_actual_rates(di);
   print_physical_sensor_status();
   get_fifo_sizes(max_fifo_B);
   //di_update_transfer_count(di, &count);
   //info_log("current bytes_remaining: %u\n", count);
}


/**
 * \brief
 */
void print_physical_sensor_status(void)
{
   PHYS_SENSOR_STATUS phys_sensor_status;
   if (!di_save_parameter(di, PP_SYSTEM, SYSP_PHYS_SENS_STATUS, (u8 *)&phys_sensor_status, sizeof(phys_sensor_status)))
      error_log("error requesting physical sensor status\n");
   else
   {
      info_log("Physical sensor, rate, range, IRQ en, power mode\n");
      info_log("          Accel, % 4u, % 5u, % 6u, %u\n", phys_sensor_status.AccelRate, phys_sensor_status.AccelRange, phys_sensor_status.AccelIRQ, phys_sensor_status.AccelPowerMode);
      info_log("           Gyro, % 4u, % 5u, % 6u, %u\n", phys_sensor_status.GyroRate, phys_sensor_status.GyroRange, phys_sensor_status.GyroIRQ, phys_sensor_status.GyroPowerMode);
      info_log("            Mag, % 4u, % 5u, % 6u, %u\n\n", phys_sensor_status.MagRate, phys_sensor_status.MagRange, phys_sensor_status.MagIRQ, phys_sensor_status.MagPowerMode);
   }
}


/**
 * \brief set and querry back sensor rate
 * \param s - sensor
 * \param sr - sensor rate to set; U16_MAX == set max sensor's
 *        rate
 * \param qsr - queried (returned) sensor rate
 * \param chkLimit - set true to check that returned rate is in range <wanted_rate,wanted_rate*2>
 * \return bool - TRUE on ok, else FALSE
 */
bool set_and_chk_rate(DI_SENSOR_TYPE_T s, u16 sr, u16 *qsr, bool chkLimit)
{
   SENSOR_CONFIG sensor_config;
   bool ret = TRUE;
   int wait_time_ms = 0;
   u16 qsr2;
   u16 max_rate;
   u16 prev_rate;
   u16 prev_requested_rate = 0;

   memset(&sensor_config, 0, sizeof(sensor_config));

   if ((s == DST_NOP) || (!di_has_sensor(di, s)))
   {
      qsr2 = 0;
      info_log("skipping nonexistent sensor %u (%s)\n", s, di_query_sensor_name(di, s));
   }
   else
   {
      ret &= di_query_sensor_config(di, s, &sensor_config);
      prev_rate = sensor_config.sample_rate;

      max_rate = get_max_sensor_rate(s);
      if (sr == U16_MAX)
      {
         sr = max_rate;
      }

      if (sr > max_rate)                                             // never assume a sensor's max rate; ALWAYS ask
      {
         sr = max_rate;
      }

      ret &= di_get_last_requested_rate(di, s, &prev_requested_rate);

      sensor_config.sample_rate = sr;
      info_log("time: %u ms\n", time_ms());
      ret &= di_configure_sensor(di, s, &sensor_config);
      // PETE: some sensors take a long time to complete configuration;
      //   the readback of the current rate will be wrong if we ask for it below too soon
      time_delay_ms(50);
      while (TRUE)
      {
         ret &= di_query_sensor_config(di, s, &sensor_config);
         if (ret && (sensor_config.sample_rate != prev_rate))
         {
            if (sr && !sensor_config.sample_rate)
            {
               // if the rate goes to zero temporarily, ignore it and wait
            }
            else
            {
               info_log("sample_rate %u != prev_rate %u\n", sensor_config.sample_rate, prev_rate);
               break;
            }
         }
         if (ret && (sensor_config.sample_rate == sr))
         {
            info_log("sample_rate == sr == %u\n", sr);
            break;
         }
         if (ret && (prev_requested_rate == sr) && (sensor_config.sample_rate >= sr))
         {
            info_log("rate request did not change\n");
            break;
         }
         if (wait_time_ms > 1500)
         {
            info_log("timeout\n");
            break;
         }
         time_delay_ms(50);
         wait_time_ms += 50;
      }
      qsr2 = sensor_config.sample_rate;
   }
   info_log("set % 27.27s rate: % 3u Hz (per: %#4.1f ms) | ret.rate: % 3u Hz (per: %#4.1f ms)\n",
            di_query_sensor_name(di, s), sr, sr ? (1000.0 / sr) : 0, qsr2, qsr2 ? (1000.0 / qsr2) : 0);
   info_log("latency %u\n", sensor_config.max_report_latency);
   if (chkLimit)
   {
      DI_ERROR_T error_info;
      bool result;
      di_query_error(di, &error_info);
      TAFR((result = (qsr2 >= (sr * 0.8)) && (qsr2 <= (2 * (sr * 1.2)))), "Rate out of limit expecting <%d,%d> got %d; error reg %u", sr, 2 * sr, qsr2, error_info.error_register);
      if (!result)
      {
         display_full_status();
      }
   }
   if (qsr != NULL)
   {
      *qsr = qsr2;
   }
   return ret;
}


/**
 * \brief
 * \param s -
 * \return u16 -
 */
u16 get_max_sensor_rate(DI_SENSOR_TYPE_T s)
{
   SENSOR_INFORMATION sInf;
   TAR(di_query_sensor_info(di, s, &sInf));

   if (sInf.max_rate > 200)
   {                                                                 // hit BSX 718x maximum limit
//    if(di_get_algorithm_id(di)==AID_BSX) //bsx algo - TODO test it works in 7184
      sInf.max_rate = 200;
   }
   return sInf.max_rate;
}


/**
 * \brief
 * \param sw -
 * \param prn -
 * \param reset -
 */
void stop_watch(my_stop_watch_t *sw, int prn, bool reset)
{
   sw->te = time_us();
   sw->td = sw->te - sw->tb;
   if (reset)
   {
      sw->tb = sw->te;
   }
   switch (prn)
   {
      case 1:
         prn_num_sep(sw->td, 9);
         info_log(" us");
         break;
      case 2:
         info_log("tm dif: ");
         prn_num_sep(sw->td, 9);
         info_log(" us\n");
         break;
      default:
         break;
   }
}


/**
 * \brief
 * \param instance -
 * \param sensor -
 * \param pwrMode -
 * \return bool -
 */
bool getSensorPwrMode(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, SENSOR_POWER_MODE *pwrMode)
{
   bool ret;
   ret = di_query_sensor_status(instance);
   *pwrMode = instance->sensor_info[sensor].status.power_mode;
   return ret;
}


/**
 * \brief
 * \param pwrMode -
 * \return bool -
 */
bool testSensorPwrModeOn(SENSOR_POWER_MODE pwrMode)
{
   return  pwrMode == SensorPowerModeLowPowerActive ||
          pwrMode == SensorPowerModeActive;
}


/**
 * \brief
 * \param pwrMode -
 * \return bool -
 */
bool testSensorPwrModeOff(SENSOR_POWER_MODE pwrMode)
{
   return  pwrMode == SensorPowerModePowerDown ||
          pwrMode == SensorPowerModeSuspend;
}


/**
 * \brief init tested parameters
 * \param first_loop -
 * \param sc -
 * \param p -
 * \param max_rt -
 */
void fifo_test_init(bool first_loop, fifo_test_sensor_config *sc, fifo_test_config *p, u16 *max_rt)
{
   if (first_loop)
   {
// PETE: leave all sensors off and meta events off, so test doesn't get confused
      DI_META_EVENT_T evt;
      set_rates(0, 0, 0, 0);

      TAR(TEST_PASSED == test_start_chip_running(config.normal_firmware, TRUE));
      // disable all possible meta events, and remove everything from the FIFO
      for (evt = DME_FLUSH_COMPLETE; evt < DME_NUM_META_EVENTS; evt++)
      {
         TAR(di_enable_meta_event_ex(di, evt, FALSE, FALSE, FALSE));
         if (di->hi_id != HIID_KITKAT)
            TAR(di_enable_meta_event_ex(di, evt, FALSE, FALSE, TRUE));
      }
      fifo_discard();
   }

   if (di->hi_id != HIID_KITKAT)
   {
      sc->s[0] = DST_ACCELEROMETER;
      sc->s[1] = DST_ACCELEROMETER | di_wake_sensor_start(di);
      sc->sz = 2;
   }
   else
   {
      sc->s[0] = DST_ACCELEROMETER;
      sc->sz = 1;
   }
   *max_rt = get_max_sensor_rate(sc->s[0]);
   p->force_wait_max_time_ms = FALSE;
}


// compute expected interrupt (note - it does not computes time - it is state after all interrupts happen)
// exp_intr: returned final interrupts generated (NOTE if some interrupt reasons are generated sooner than others
// - u718x will never show other interrupts even when they occur - you are responsible to compenstate that)
void conf_exp_intr(RegIntStatus *exp_intr, fifo_test_sensor_config *sc, fifo_test_config *p, u16 *wm_B)
{
   exp_intr->reg = 0;
   exp_intr->bits.WakeupWatermark = (sc->rt[1] != 0) && (wm_B[1] != 0);
   exp_intr->bits.NonWakeupWatermark = (sc->rt[0] != 0) && (wm_B[0] != 0);
   exp_intr->bits.HostInterrupt = (exp_intr->bits.WakeupWatermark    && p->intrpt[1]) ||
                                  (exp_intr->bits.NonWakeupWatermark && p->intrpt[0]);
   info_log("## rt[1]:%u, wm_B[1]:%u, p->intrpt[1]:%u, WakeupWatermark:%u\n", sc->rt[1], wm_B[1], p->intrpt[1], exp_intr->bits.WakeupWatermark);
   info_log("## rt[0]:%u, wm_B[0]:%u, p->intrpt[0]:%u, NonWakeupWatermark:%u\n", sc->rt[0], wm_B[0], p->intrpt[0], exp_intr->bits.NonWakeupWatermark);
   info_log("## HI:%u\n", exp_intr->bits.HostInterrupt);
}


// count expected events from time
// events: funct will store expected number of events (0 when sensor is stopped)
// tm_ms: availalbe time for events generation in [ms]
// real_rt: real sensor rate [Hz]
void count_exp_evnts_from_tm(u16 *evnts, u32 tm_ms, u16 real_rt)
{
   *evnts = tm_ms * real_rt / 1000;
}


// count expected events from size
// events: funct will store expected number of events (0 when sensor is stopped)
// wm_B: size in B for events
// real_rt: real sensor rate [Hz]
// s: sensor
void count_exp_evnts_from_sz(u16 *evnts, u16 wm_B, u16 real_rt, DI_SENSOR_TYPE_T s)
{
   if (real_rt != 0)
   {
      *evnts = fifo_size_to_events(wm_B, s);
   }
   else
   {
      *evnts = 0;
   }
}


// count expected time in [ms] from events and rate
// tm: time will be returned via this variable
// events: events number
// real_rt: sensor's rate in [Hz]
void count_exp_tm(u32 *tm, u16 evnts, u16 real_rt)
{
   if (real_rt != 0)
   {
      *tm    = (u32)((double)(evnts) / real_rt * 1000.0);
   }
   else
   {
      if (evnts == 0)
      {
         *tm = 0;
      }
      else
      {
         *tm = U32_MAX;
      }
   }
}

// Configure interrupt
void config_intrpt(bool intrp_nw_k, bool intrp_w, u16 watermark_nw_k, u16 watermark_w)
{
   if (di->hi_id != HIID_KITKAT)
   {
      info_log("Setting interrupt NW/W: %d/%d watermark NW/W [B]: %u/%u\n", intrp_nw_k, intrp_w, watermark_nw_k, watermark_w);
      di_configure_interrupts_ex(di, intrp_nw_k, intrp_w, watermark_nw_k, watermark_w);
   }
   else
   {
      info_log("Setting andr K interrupt: %d watermark [B]: %u\n", intrp_nw_k, watermark_nw_k);
      di_configure_interrupts(di, intrp_nw_k, watermark_nw_k);
   }
}

// Get FIFO sizes
// 1st size is Non_wakeup (for android L) or only one (in android K)
// 2nd size is wakeup (adnroid L) or 0 (android K)
// NOTE: it is switched than L is returning because then it is easier to use between android K/L
//   because K sensor < 32 = only one  (it is reported as Non-wakeup by is_wakeup_event() )
//   L sensors < 32 are Non-wakeup
// thus if sensor is reported as non-wakeup we just get FIFO size[0] and we are fine
void get_fifo_sizes(u16 max_fifo_B[2])
{
   FIFO_CONTROL_PARAM fifo_ctrl;                                     // FIFO control structure

   di_save_parameter(di, PP_SYSTEM, SYSP_FIFO_CONTROL, (u8 *)&fifo_ctrl, sizeof(FIFO_CONTROL_PARAM));
   if (di->hi_id != HIID_KITKAT)
   {
      max_fifo_B[0] = fifo_ctrl.nonwakeup_fifo_size;
      max_fifo_B[1] = fifo_ctrl.fifo_size;
      info_log("NW FIFO size:%u, NW Watermark:%u; WK FIFO size:%u, WK Watermark:%u\n", fifo_ctrl.nonwakeup_fifo_size, fifo_ctrl.nonwakeup_watermark,
               fifo_ctrl.fifo_size, fifo_ctrl.watermark);
   }
   else
   {
      max_fifo_B[0] = fifo_ctrl.fifo_size;
      max_fifo_B[1] = 0;
      info_log("FIFO size:%u, Watermark:%u\n", fifo_ctrl.fifo_size, fifo_ctrl.watermark);
   }
}

// return time in ms to fill FIFO area of required size with only sensor data of required rate and sensor type
// fifo_B: are in [B] to be used
// rate: rate in [Hz] to be used
// sens: sensor whose data only will be stored in FIFO of size "fifo_B"
// return approximated expected [ms] to fill requested FIFO area
u32 fifo_size_to_time_ms(u16 fifo_B, u16 rate, DI_SENSOR_TYPE_T sens)
{
   u16 evnts;
   u32 time_ms;
   evnts = fifo_size_to_events(fifo_B, sens);
   count_exp_tm(&(time_ms), evnts, rate);
   return time_ms;
}

// Sets rates, watermarks and interrupts enable and big latencies
// cumputes expected interrupt times
// check that:
// - interrupt comes no later than in expected time (if is expected)
// - interupt has expected value
// - sensor events count is as expected
// - received bytes is as expected (this is not checked for W+NW which does not interrupt at same time)
// NOTE: this function expecting first sensor to be NW and second W in case of android L
// p: requested test Parameters (interrupts & watermarks)
// sc: list of sensorsto be used with requested rate
// return FALSE - if time of sensor interrupt would be too close torecognize
bool chk_water_mark(fifo_test_config *p, fifo_test_sensor_config *sc)
{
   char *txt[2] = {"NW", "W"};
   int fifo_idx;                                                     // index of FIFO 0=NW, 1=W
   u16 max_fifo_evnts[2];                                            // max FIFO events NW/W
   u16 max_fifo_B[2];                                                // max FIFO bytes  NW/W
   u32 max_fifo_fill_tm_ms[2];                                       // max time in ms to fill whole FIFO NW/W
   u32 max_test_time_to_fill_fifo = 0;                               // max of max_fifo_fill_tm_ms
   bool both_intrpt_at_same_tm = FALSE;                              // both interrupt happen at same time
   u32 total_B_expected;                                             // total B expected to be received
   u32 sens_running_count;                                           // counter of running sensors
   u16 wm_B[2];                                                      // requested watermark NW/W in [Bytes]
   u16 rt_real[2];                                                   // rate actually returned by sensor
   u16 exp_events[2];                                                // expected events to reach water mark
   u32 exp_tm_ms[2];                                                 // expected time to reach water mark
   u32 min_exp_tm_ms;                                                // expected time to reach soonest water mark
   DI_SENSOR_TYPE_T min_s;                                           // sensor which triggers first (at min_exp_tm_ms)
   u32 max_exp_tm_ms;                                                // expected time to reach latest water mark
   double tm_mult = 1.20;                                            // time multiplier; set 1.2 to wait 20% more
   double tm_mult_at_the_end = 0.1;                                  // time multiplier; 0.1 to wait 10% of shorter time at the end
   double total_margin_max_tm;                                       // total margin of max time
   RegIntStatus expIntr;                                             // expected interrupt value in shorter time
   RegIntStatus expIntrFinal;                                        // expected interrupt final value
   u32 tmp_use_tm_ms;                                                // temporary use time ms variable
   u32 time_tmp;                                                     // Temperary use for timer calculations
   u32 data_started_time_ms;                                         // time that data has started accumulating
   int i = 0;
   bool stat;
   RegIntStatus ist;
   char txtGot[200];

   total_margin_max_tm = tm_mult - 1 + tm_mult_at_the_end;

   if (di->hi_id == HIID_KITKAT)
   {
      wm_B[1] = 0;
      rt_real[1] = 0;
      exp_events[1] = 0;
      exp_tm_ms[1] = 0;
      p->intrpt[1] = 0;
      p->wm_perc[1] = 0;
   }

   info_log("===\nCWM 1.0: Intr En NW/W: %d/%d  Watermark [%%] NW/W: %2.0f/%2.0f sens [Hz]:",
            p->intrpt[0], p->intrpt[1], p->wm_perc[0] * 100, p->wm_perc[1] * 100);
   for (i = 0; i < sc->sz; i++)
   {
      info_log(" %s %u |", is_wakeup_event(di, sc->s[i]) ? "W" : "NW", sc->rt[i]);
   }

   info_log(" time: %u\n", time_ms());
   get_fifo_sizes(max_fifo_B);

   info_log("\nCWM 1.1: fifo sizes NW/W [B] %u/%u\n", max_fifo_B[0], max_fifo_B[1]);


   di->total_bytes_transferred = 0;
   for (i = 0; i < sc->sz; i++)
   {
      info_log("  %d. time: %u\n", i + 1, time_ms());
      set_and_chk_lat(sc->s[i], U16_MAX, NULL, TRUE);
      set_and_chk_rate(sc->s[i], sc->rt[i], &(rt_real[i]), TRUE);
      di->sensor_info[sc->s[i]].samples_received = 0;

      fifo_idx = is_wakeup_event(di, sc->s[i]) ? 1 : 0;

      max_fifo_evnts[fifo_idx] = fifo_size_to_events(max_fifo_B[fifo_idx], sc->s[i]);
      count_exp_tm(&(max_fifo_fill_tm_ms[fifo_idx]), max_fifo_evnts[fifo_idx], rt_real[i]);
      info_log("CWM 1.2: fifo %s size [B/evnts] %u/%u will fill at rate %u [Hz] in %u ms\n",
               txt[fifo_idx], max_fifo_B[fifo_idx], max_fifo_evnts[fifo_idx],
               rt_real[i], max_fifo_fill_tm_ms[fifo_idx]);
      if (rt_real[i] != 0)
      {
         STORE_MAX(max_test_time_to_fill_fifo, max_fifo_fill_tm_ms[fifo_idx]);
      }
   }


   data_started_time_ms = time_ms();
   info_log("time: %u\n", data_started_time_ms);

   fifo_discard();                                                   // make sure there are no meta events or other detrius in the FIFO before continuing
   time_delay_ms(50);

   TEST_ASSERT(di_reg_read(di, SR_INT_STATUS, &ist.reg, 1));
   info_log("received intr: 0x%02x: %s\n",ist.reg, hostIntrToStr(ist.reg, txtGot));

   min_exp_tm_ms = U32_MAX;
   max_exp_tm_ms = 0;
   total_B_expected = 0;
   sens_running_count = 0;
   for (i = 0; i < sc->sz; i++)
   {
      fifo_idx = is_wakeup_event(di, sc->s[i]) ? 1 : 0;
      // bytes size of watermark
      wm_B[i] = (u16)(max_fifo_B[i] * p->wm_perc[i]);
      if (rt_real[i] != 0)
      {
         total_B_expected += wm_B[i];
         sens_running_count++;
      }
      count_exp_evnts_from_sz(&(exp_events[i]), wm_B[i], rt_real[i], sc->s[i]);
      count_exp_tm(&(exp_tm_ms[i]), exp_events[i], rt_real[i]);
      info_log("CWM 1.3: To generate %u B (%2.0f%% of %s FIFO) at real rate %u [Hz] it is necessary to read %u events in %u ms\n",
               wm_B[i], p->wm_perc[i] * 100, txt[fifo_idx], rt_real[i], exp_events[i], exp_tm_ms[i]);
      if (exp_tm_ms[i] < min_exp_tm_ms)
      {
         min_exp_tm_ms = exp_tm_ms[i];
         min_s = sc->s[i];
      }
      max_exp_tm_ms = MAX(max_exp_tm_ms, exp_tm_ms[i]);
   }

   if (min_exp_tm_ms == max_exp_tm_ms)
   {
      both_intrpt_at_same_tm = TRUE;
   }
   TEST_ASSERTF(!(max_exp_tm_ms < min_exp_tm_ms), "Error in test case itself - ");

   info_log("IRQ = %u\n", irq_check(di->irq_handle));

   info_log("time: %u\n", data_started_time_ms);
   info_log("CWM 1.4: configure interrupts and watermarks\n");
   di_query_sensor_status(di);   // read all sensor status bits and clear the data loss bits, so they are accurate below if we have an error
   config_intrpt(p->intrpt[0], p->intrpt[1], wm_B[0], wm_B[1]);

   TEST_ASSERT(di_reg_read(di, SR_INT_STATUS, &ist.reg, 1));
   info_log("received intr: 0x%02x: %s\n",ist.reg, hostIntrToStr(ist.reg, txtGot));

   if (p->force_wait_max_time_ms)
   {
      info_log("CWM 1.5: Forcing to wait time %u ms when both FIFO overflows\n", max_test_time_to_fill_fifo);
      max_exp_tm_ms = max_test_time_to_fill_fifo;
      min_exp_tm_ms = max_test_time_to_fill_fifo / 2;
   }

   if (max_exp_tm_ms > max_test_time_to_fill_fifo)
   {
      warn_log("max wait time %u ms to fill FIFO would be too long reducing to %u ms\n", max_test_time_to_fill_fifo);
      max_exp_tm_ms = max_test_time_to_fill_fifo;
   }
   if (min_exp_tm_ms > max_test_time_to_fill_fifo)
   {
      warn_log("min wait time %u ms to fill FIFO would be too long reducing to %u ms\n", max_test_time_to_fill_fifo);
      min_exp_tm_ms = max_test_time_to_fill_fifo;
   }
   if (max_exp_tm_ms == 0)
   {
      warn_log("max wait time %u ms setting 1 s\n", max_exp_tm_ms);
      max_exp_tm_ms = 1000;
   }
   if (min_exp_tm_ms == 0)
   {
      warn_log("min wait time %u ms setting %u ms\n", min_exp_tm_ms, max_exp_tm_ms / 2);
      min_exp_tm_ms = max_exp_tm_ms / 2;
   }

   if (max_exp_tm_ms != min_exp_tm_ms)
   {
      if (((max_exp_tm_ms * total_margin_max_tm) > min_exp_tm_ms)    // we might get extra interrupt at the end due to minimum interrupt will re-trigger
          || ((max_exp_tm_ms * (1 - total_margin_max_tm)) < min_exp_tm_ms)) // we might get final interrupt in the middle cos final interrupt is too soon after first interrupt

      {
         TEST_ASSERTF(FALSE, "Test is stable if min_time = <%d, %d>%% of max_time) or max+ime==min_time",
                      (int)(total_margin_max_tm * 100), (int)((1 - total_margin_max_tm) * 100));
      }
   }


   tmp_use_tm_ms = (u32)(min_exp_tm_ms * tm_mult);
   time_tmp = (time_ms() - data_started_time_ms);
   tmp_use_tm_ms = tmp_use_tm_ms > time_tmp ? tmp_use_tm_ms - time_tmp : 0; // PETE: reduce it by the actual time since we turned on the sensors
   info_log("time: %u\n", data_started_time_ms);
   info_log("CWM 1.6: Waiting time %u ms to generate first data\n", tmp_use_tm_ms);
   time_delay_ms(tmp_use_tm_ms);

   // if we have 2 different times for watermark fill then:
   // - if interrupt shall be generated - then check IRQ and check all data are ok and quit test
   // - if interrupt shall not be generated - then check not IRQ and continu test for longer time
   if ((max_exp_tm_ms * (1 - total_margin_max_tm)) >= min_exp_tm_ms)
   {
      u16 use_tm_ms;
      // expected interrupt (note it does not know time)
      conf_exp_intr(&expIntr, sc, p, wm_B);
      // correct for half time - only one interrupt source
      if (is_wakeup_event(di, min_s))
      {
         expIntr.bits.NonWakeupWatermark = 0;                        // shorter time for W -> we do not expect interrupt of NW sensor yet
         info_log("## cleared NW Watermark\n");
      }
      else
      {
         expIntr.bits.WakeupWatermark = 0;                           // shorter time for NW -> we do not expect interrupt of W sensor yet
         info_log("## cleared W Watermark\n");
      }

      // PETE: we don't expect the host interrupt bit if the corresponding interrupt is masked
      expIntr.bits.HostInterrupt = (expIntr.bits.WakeupWatermark && p->intrpt[1])
                                   || (expIntr.bits.NonWakeupWatermark && p->intrpt[0]);

      if (expIntr.bits.HostInterrupt == 1)
      {
         use_tm_ms = min_exp_tm_ms;                                  // if interrupt occured, time for events will be shorter
      }
      else
      {
         use_tm_ms = max_exp_tm_ms;                                  // if interrupt didn't occur, time for generating events will be longer
      }
      // correct expected events number
      for (i = 0; i < sc->sz; i++)
      {
         count_exp_evnts_from_tm(&(exp_events[i]), use_tm_ms, rt_real[i]);
         if (exp_events[i] > max_fifo_evnts[i])
         {
            exp_events[i] = max_fifo_evnts[i];
         }
      }

      info_log("time: %u\n", data_started_time_ms);
      info_log("CWM 1.7: check int pin\n");
      TAR(stat = check_int_pin(expIntr.bits.HostInterrupt));
      info_log("time: %u\n", data_started_time_ms);
      info_log("CWM 1.8: check host interrupt\n");
      if (checkHostIntr(expIntr.reg, 0, 1) == TEST_FAILED)
         stat = FALSE;
      if (!stat)
      {
         info_log("DUMPING FIFO\n");
         config_intrpt(TRUE, TRUE, 0, 0); // enable so we can see what's in the FIFO causing the fuss
         di_fifo_flush(di, DST_FLUSH_ALL);
         di_control_logging(di, FALSE, FALSE, FALSE, FALSE);
         set_verbose_sensor_data(TRUE);
         read_out_while_intr(1000, NULL, 1000);
         set_verbose_sensor_data(FALSE);
         config_intrpt(p->intrpt[0], p->intrpt[1], wm_B[0], wm_B[1]);
      }

      if (expIntr.bits.HostInterrupt == 1)
      {                                                              // if interrupt already generated do not wait anymore and
         expIntrFinal = expIntr;
         goto t_8_5_read_out_data;
      }
      tmp_use_tm_ms = (u32)((max_exp_tm_ms - min_exp_tm_ms) * tm_mult);
      info_log("CWM 1.9: Waiting time %u ms to generate next data\n", tmp_use_tm_ms);
      time_delay_ms(tmp_use_tm_ms);
   }


   conf_exp_intr(&expIntrFinal, sc, p, wm_B);

   info_log("time: %u\n", data_started_time_ms);
   info_log("CWM 1.10: check int pin\n");
   TAR(check_int_pin(expIntrFinal.bits.HostInterrupt));

   info_log("time: %u\n", data_started_time_ms);
   info_log("CWM 1.11: check host interrupt\n");
   if (checkHostIntr(expIntrFinal.reg, 300, 50) == TEST_FAILED)
      stat = FALSE;
   if (!stat)
   {
      info_log("DUMPING FIFO\n");
      config_intrpt(TRUE, TRUE, 0, 0); // enable so we can see what's in the FIFO causing the fuss
      di_fifo_flush(di, DST_FLUSH_ALL);
      di_control_logging(di, FALSE, FALSE, FALSE, FALSE);
      set_verbose_sensor_data(TRUE);
      read_out_while_intr(1000, NULL, 1000);
      set_verbose_sensor_data(FALSE);
      config_intrpt(p->intrpt[0], p->intrpt[1], wm_B[0], wm_B[1]);
   }

   // if interrupt is expected
   if (expIntrFinal.bits.HostInterrupt)
   {                                                                 // read data and check sensors events number is as expected
      t_8_5_read_out_data:
      info_log("time: %u\n", data_started_time_ms);
      info_log("CWM 1.12: read data\n");
      read_out_while_intr(1000, NULL, 9);
      info_log("Checking events counts:\n");
      for (i = 0; i < sc->sz; i++)
      {
         chk_val_with_margin(exp_events[i], di->sensor_info[sc->s[i]].samples_received, 0.2, 0);
      }
      // if we epxect watermarks for W and NW sensors to have interrupt at different
      // times then we can not check fifo size match watermarks as we count
      // W+NW so we can not distinguish and one would clearly not be fill full
      // - android K or if we expect data only from one W or NW FIFO it is ok to check bytes
      if (both_intrpt_at_same_tm || sens_running_count == 1 || (di->hi_id == HIID_KITKAT))
      {
         info_log("time: %u\n", data_started_time_ms);
         info_log("CWM 1.13: Checking total bytes count:\n");
         chk_val_with_margin(total_B_expected, di->total_bytes_transferred, 0.2, 0);
      }
   }

   // PETE: the interrupt will only now be clear if we actually read the data out
   // VBE: I think interrupt shall be off in either case whether we read it out or whether we do not expect it
   TAR(check_int_pin(0));
   tmp_use_tm_ms = (u32)(min_exp_tm_ms * tm_mult_at_the_end);
   info_log("time: %u\n", data_started_time_ms);
   info_log("CWM 1.14: Waiting little bit extra time %u ms to check there is no double interrupt from second FIFO\n",
            tmp_use_tm_ms);
   time_delay_ms(tmp_use_tm_ms);
   info_log("time: %u\n", data_started_time_ms);
   info_log("CWM 1.15: check int pin\n");
   TAR(check_int_pin(0));
   info_log("time: %u\n", data_started_time_ms);
   info_log("CWM 1.16: check host interrupt 0x%02X\n", expIntrFinal.reg);
   if (expIntrFinal.bits.HostInterrupt)
   {                                                                 // data were read out check empty interrupt
      if (checkHostIntr(0x00, 0, 1) == TEST_FAILED)
         stat = FALSE;
   }
   else
   {                                                                 // data were not read out check same final interrupt
      if (checkHostIntr(expIntrFinal.reg, 300, 50) == TEST_FAILED)
         stat = FALSE;
   }
   if (!stat)
   {
      info_log("DUMPING FIFO\n");
      config_intrpt(TRUE, TRUE, 0, 0); // enable so we can see what's in the FIFO causing the fuss
      di_fifo_flush(di, DST_FLUSH_ALL);
      di_control_logging(di, FALSE, FALSE, FALSE, FALSE);
      set_verbose_sensor_data(TRUE);
      read_out_while_intr(1000, NULL, 1000);
      set_verbose_sensor_data(FALSE);
      config_intrpt(p->intrpt[0], p->intrpt[1], wm_B[0], wm_B[1]);
   }

   info_log("time: %u\n", data_started_time_ms);
   info_log("CWM 1.17: cleanup\n");
   // turn off sensors
   for (i = 0; i < sc->sz; i++)
   {
      set_and_chk_rate(sc->s[i], 0, NULL, TRUE);
   }
   // enable interrupt to discard FIFO and discard fifo
   config_intrpt(1, 1, 0, 0);
   fifo_discard();
   info_log("IRQ = %u\n", irq_check(di->irq_handle));
   time_delay_ms(100);
   di_fifo_flush(di, DST_FLUSH_ALL);
   set_verbose_sensor_data(TRUE);
   read_out_while_intr(1000, NULL, 1000);
   set_verbose_sensor_data(FALSE);

   return TRUE;
}

// determine fifo fill percentage to meet minimum filling time
// sc: used sensors and their rate
// min_req_time_ms: minimum required tim in milisecond
// return percentage of fifo which needs to be fill
float get_size_ratio_for_min_time(fifo_test_sensor_config sc, u32 min_req_time_ms)
{
   u16 fifo_sizes[2];
   u32 time_ms;
   u16 sens_idx;
   u16 use_fifo;
   float fifo_ratio;
   float min_fifo_ratio = 0;
   get_fifo_sizes(fifo_sizes);
   for (sens_idx = 0; sens_idx < sc.sz; sens_idx++)
   {
      if (sc.rt[sens_idx] == 0)
         continue;                                                   // do not compute for disabled sensors
      use_fifo = is_wakeup_sensor(di, sc.s[sens_idx]) ? 1 : 0;
      time_ms = fifo_size_to_time_ms(fifo_sizes[use_fifo], sc.rt[sens_idx], sc.s[sens_idx]);
      fifo_ratio = (float)min_req_time_ms / time_ms;
      if (min_fifo_ratio < fifo_ratio)
      {
         min_fifo_ratio = fifo_ratio;
      }
   }
   return min_fifo_ratio;
}

// decrese sensor rate till minimum fifo fill time is reached
// fifo_ratio: fifo ratio you wish to fill (eg 0.5 = fill 50%)
// sc: sensors ID and rates - rates will be modified to meet "min_req_time_ms"
// min_req_time_ms: minimum required time in ms
u16 dec_rate_till_min_time_met(float fifo_ratio, fifo_test_sensor_config *sc, u32 min_req_time_ms)
{
   u16 fifo_sizes[2];
   u16 tmp_fifo_size_B;
   u32 time_ms;
   u16 use_fifo;
   u16 sens_idx;
   u16 min_rt = sc->rt[0];
   get_fifo_sizes(fifo_sizes);
   for (sens_idx = 0; sens_idx < sc->sz; sens_idx++)
   {
      if (sc->rt[sens_idx] == 0)
         continue;                                                   // do not compute for disabled sensors
      use_fifo = is_wakeup_sensor(di, sc->s[sens_idx]) ? 1 : 0;
      tmp_fifo_size_B = (u16)(fifo_sizes[use_fifo] * fifo_ratio);
      time_ms = fifo_size_to_time_ms(tmp_fifo_size_B, sc->rt[sens_idx], sc->s[sens_idx]);
      // note we divide by 2 because actual rate of sensor may be between <rt,rt*2)
      sc->rt[sens_idx] = (u16)(sc->rt[sens_idx] / ((float)min_req_time_ms / time_ms) / 2);
      if (min_rt > sc->rt[sens_idx])
      {
         min_rt = sc->rt[sens_idx];
      }
   }
   return min_rt;
}

// convert miliseconds to time struct (h,m,s,ms)
void ms_2_my_tm(u32 ms, my_tm_t *t)
{
   t->ms = ms % 1000;
   t->s = (ms / 1000) % 60;
   t->m = (ms / 1000 / 60) % 60;
   t->h = (ms / 1000 / 60 / 60);
}
// convert time struct (h,m,s,ms) to miliseconds
u32 my_tm_2_ms(my_tm_t *t)
{
   u32 ms;
   ms = t->h * 60;
   ms = (ms + t->m) * 60;
   ms = (ms + t->s) * 1000;
   ms = (ms + t->ms);
   return ms;
}
// convert miliseconds to string time (HH:MM:SS.mmm)
// str: string buffer
// sz: size of "str" string buffer
// time_ms: time in miliseconds to display
void time_to_str(char *str, u32 sz, u32 time_ms)
{
   my_tm_t t;
   ms_2_my_tm(time_ms, &t);
#if _WIN32
   sprintf_s(str, sz, "%02d:%02d:%02d.%03d", t.h, t.m, t.s, t.ms);
#else
   snprintf(str,sz,"%02d:%02d:%02d.%03d",t.h,t.m,t.s,t.ms);
#endif
}
