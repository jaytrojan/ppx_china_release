#ifndef __TEST_COMMON_H__
#define __TEST_COMMON_H__

#include <string.h>
#include <stdio.h>
#include <time.h>
#include <stdarg.h>
#include <stdlib.h>
#include <math.h>
#include <setjmp.h>

#include "firmware_tests.h"
#include "driver_util.h"
//#include "config.h"
#include "host_services.h"
#include "host_definitions.h"
#include "sensor_stats.h"
#include "sensor_handling.h"
#include "test_config.h"
#include <u718x_registers.h>
#include <driver_core.h>

// these should be ok files for these tests, and are not in the config file
#define EEPROM_NOEXEC_FILE          "NOEXEC.FW"
#define EEPROM_EXEC_FILE            "EXEC.FW"
#define EEPROM_INVALID_FILE         "INVALID.FW"
#define EEPROM_DI01_SPECIFIC_FILE   "DI01SPC.FW"
#define EEPROM_DI02_SPECIFIC_FILE   "DI02SPC.FW"
#define EEPROM_NORMAL_FILE          "EXEC.FW"
#define EEPROM_FAST_FILE            "FAST.FW"

#define ARRAY_SIZE(x)   ( sizeof( x )  / sizeof( x[0] ) )
#define BIT(x)          ( (u64)1 << (x) )

// variables that are setup and valid before any tests are run
extern DI_INSTANCE_T *di;
extern I2C_HANDLE_T eeprom_i2c_handle;
#if 0
static char *ram_test_file;
#endif

// not implemented yet:
#define TEST_INVALID_PARAMETER_IO

// from AppNote 002
#define SP_STILLNESS_MODE 73
#define DISABLE_STILLNESS
// amount of data we discard when the FIFO is full
#define DISCARD_COUNT 200

// these are hard coded here; need to be moved to config file
#define TEST_5_1_RUN_TIME 2000
#define TEST_5_2_TIME 5000
#define TEST_7_NUM_PARAMS 1000
#define TEST_8_2_ACCURACY_THRESHOLD 20 // percent
#define TEST_8_2_RUN_TIME 2000
#define TEST_8_4_RUN_TIME_1 15000
#define TEST_8_4_RUN_TIME_2 10000
#define TEST_8_5_ACCURACY_THRESHOLD 10 // percent
#define TEST_8_5_RUN_TIME 5000
#define TEST_8_10_DISCARD_TIME 5000
#define TEST_8_10_RUN_TIME 15000
#define TEST_10_1_RUN_TIME_1 10000
#define TEST_10_1_RUN_TIME_2 5000
#define TEST_10_2_RUN_TIME_1 10000
#define TEST_10_2_RUN_TIME_2 5000
#define TEST_10_3_RUN_TIME_1 5000
#define TEST_10_3_RUN_TIME_2 5000
#define TEST_10_3_RUN_TIME_3 5000
#define TEST_10_7_RUN_TIME_1 5000
#define TEST_10_7_RUN_TIME_2 5000
#define TEST_10_9_RUN_TIME_1 10000
#define TEST_10_9_RUN_TIME_2 5000
#define TEST_12_3_RUN_TIME 10000
#define TEST_12_3_LOOPS 5
#define TEST_8_9_RUN_TIME 2000
#define TEST_9_5_TIME 4000
#define TEST_15_1_RUN_TIME 120000
#define TEST_15_1_ACCEL_DUPS 20
#define TEST_15_1_MAG_DUPS 40
#define TEST_15_1_GYRO_DUPS 20
#define TEST_15_2_DISCARD_TIME 5000
#define TEST_15_2_RUN_TIME 60000
#define UC_1_SENSOR_RATE_CHG_MAX_WAIT_MS 1500
#define UC_1_READ_TIME 2000
#define UC_1_READ_TIME_OFF 1000

#define TEST_RUN_DELAY 2000
#define INITIALIZED_TIMEOUT_MS 2000

//accel real event size in FIFO - it assumes that before each Accel event is LSW timestamp event
 // it is still an estimation because it is not counting in occasional MSW timestamp event
#define ACCEL_EVENT_FIFO_REAL_SIZE (sizeof(DI_TIMESTAMP_DATA_T)+sizeof(DI_3AXIS_INT_DATA_T)-4)

extern int g_current_test_retval;

/** Defines the start of a test method.

   This declares a wrapper around the test functions that sets up the 'g_current_test_retval' global variable. Using
   the TEST_CHECK, TEST_ASSERT, etc macros sets this global.
*/
#define TEST_START(id)  int do_test_##id(bool first_loop) {   \
      g_current_test_retval = TEST_PASSED;                           \
      gtp_init();

/* Declares the end of a test method

   This returns the current value of g_current_test_retval.

   NOTE: generally it is not necessary for a test function to return a value. If no return value is specified,
   the default value of g_current_test_retval is TEST_PASSED.
*/
#define TEST_END                                                     \
      return g_current_test_retval;                                  \
}

/* Check a condition, setting the global test return value if the check fails.

   This allows a test to test a condition, and if FALSE, will cause the test to fail, though it will allow
   the test to continue running to perform other checks. This allows several failures to occur which can
   ease debugging

   NOTE: test functions using this macro should not return a value and should instead rely on TEST_END to
         return the current value of g_current_test_retval
*/
#ifdef __GNUC__
#define TEST_CHECKF(x,fmt,...)    { if(!(x)) { g_current_test_retval = TEST_FAILED; do_log(LL_ERROR, "CHECK FAILED:%s:%04d: " #x " " fmt "\n", __FILE__, __LINE__, ##__VA_ARGS__); } }
#else
#define TEST_CHECKF(x,fmt,...)    { if(!(x)) { g_current_test_retval = TEST_FAILED; do_log(LL_ERROR, "CHECK FAILED:%s:%04d: " #x " " fmt "\n", __FILE__, __LINE__,   __VA_ARGS__); } }
#endif

#define TEST_CHECK(x)    TEST_CHECKF(x,"")


/* check "cond". If false, log the error, fail the currently running test, and return FALSE.

   Useful in functions that must return a bool  */
#ifdef __GNUC__
#define BOOL_ASSERTF(x, fmt, ...)  { if(!(x)) { g_current_test_retval = TEST_FAILED; do_log(LL_ERROR, "CHECK FAILED:%s:%04d: " #x " " fmt "\n", __FILE__, __LINE__, ##__VA_ARGS__); return FALSE; } }
#else
#define BOOL_ASSERTF(x, fmt, ...)  { if(!(x)) { g_current_test_retval = TEST_FAILED; do_log(LL_ERROR, "CHECK FAILED:%s:%04d: " #x " " fmt "\n", __FILE__, __LINE__,   __VA_ARGS__); return FALSE; } }
#endif

#define BOOL_ASSERT(x)  BOOL_ASSERTF(x,"")



/* check "cond". If false, log the error, fail the currently running test, and return TEST_FAILED  */
#ifdef __GNUC__
#define TEST_ASSERTF(x,fmt,...) { if(!(x)) { g_current_test_retval = TEST_FAILED; do_log(LL_ERROR, "CHECK FAILED:%s:%04d: " #x " " fmt "\n", __FILE__, __LINE__, ##__VA_ARGS__); return TEST_FAILED; } }
#else
#define TEST_ASSERTF(x,fmt,...) { if(!(x)) { g_current_test_retval = TEST_FAILED; do_log(LL_ERROR, "CHECK FAILED:%s:%04d: " #x " " fmt "\n", __FILE__, __LINE__,   __VA_ARGS__); return TEST_FAILED; } }
#endif

#define TEST_ASSERT(x)  TEST_ASSERTF(x,"")
#define TEST_ASSERT_PASSED(cond) { TEST_ASSERT( TEST_PASSED == (cond) ); }


#ifndef __GNUC__ /* Windows */
// Test Assert + Format parameters + Recover (not return)
#define TAFR(x,fmt,...) { if(!(x)) { g_current_test_retval = TEST_FAILED; do_log(LL_ERROR, "CHECK FAILED:%s:%04d: " #x " " fmt "\n", __FILE__, __LINE__,   __VA_ARGS__); } }

#define TAR(x) TAFR(x,"")
// could use also __FILE__ but not now - to long text
// assert + print if error
#define AP(x,fmt,...)    { if(!(x)) { do_log(LL_ERROR, "%s():%s:%04d: " #x " " fmt "\n", __FUNCTION__,  __FILE__, __LINE__, __VA_ARGS__); } }
// assert + print if error + return r;
#define APR(x,r,fmt,...) { if(!(x)) { do_log(LL_ERROR, "%s():%s:%04d: " #x " " fmt "\n", __FUNCTION__, __FILE__, __LINE__,  __VA_ARGS__); return r;} }
// assert + print if error + do;
#define APD(x,d,fmt,...) { if(!(x)) { do_log(LL_ERROR, "%s():%s:%04d: " #x " " fmt "\n", __FUNCTION__, __FILE__, __LINE__,  __VA_ARGS__); d} }

#else /* GNUC */

// Test Assert + Format parameters + Recover (not return)
#define TAFR(x,fmt,...) { if(!(x)) { g_current_test_retval = TEST_FAILED; do_log(LL_ERROR, "CHECK FAILED:%s:%04d: " #x " " fmt "\n", __FILE__, __LINE__, ##__VA_ARGS__); } }

#define TAR(x) TAFR(x,"")
// could use also __FILE__ but not now - to long text
// assert + print if error
#define AP(x,fmt,...)    { if(!(x)) { do_log(LL_ERROR, "%s():%s:%04d: " #x " " fmt "\n", __FUNCTION__,  __FILE__, __LINE__, ##__VA_ARGS__); } }
// assert + print if error + return r;
#define APR(x,r,fmt,...) { if(!(x)) { do_log(LL_ERROR, "%s():%s:%04d: " #x " " fmt "\n", __FUNCTION__, __FILE__, __LINE__,  ##__VA_ARGS__); return r;} }
// assert + print if error + do;
#define APD(x,d,fmt,...) { if(!(x)) { do_log(LL_ERROR, "%s():%s:%04d: " #x " " fmt "\n", __FUNCTION__, __FILE__, __LINE__,  ##__VA_ARGS__); d} }
#endif

#define MAX_AVAILABLE_SENSORS 64

/* functions that should be part of di core */
#define di_reg_read( d, addr, buf, cnt )  i2c_blocking_read(d->i2c_handle, addr, buf, cnt)
#define di_reg_write(d, addr, buf, cnt )  i2c_blocking_write(d->i2c_handle, addr, buf, cnt)

// global data
extern bool raw_data_enabled;
extern u16 accel_rate;
extern u16 gyro_rate;
extern u16 mag_rate;
extern u16 quat_rate;
extern u16 accel_latency;
extern u16 gyro_latency;
extern u16 mag_latency;
extern u16 quat_latency;
extern char g_tmpTxt[2000];
extern DI_SENSOR_TYPE_T rotation_sensor;

extern test_settings_t gtp; // global test parameters

// global test parameters init
void gtp_init();

/**
 * \brief select specific rates for the upcoming test
 * \param accel
 * \param gyro
 * \param mag
 * \param quat
 *
 */
void set_rates(u16 accel, u16 gyro, u16 mag, u16 quat);

void set_latencies(u16 accel, u16 gyro, u16 mag, u16 quat);

/**
 * \brief revert to default rates from config file
 *
 */
void default_rates(void);

/* calculate if v1 is approximately v2 +- e */
bool is_approx(double v1, double v2, double e);

/** \brief Commonly used helper functions
 *
 */
bool di_configure_rate(DI_INSTANCE_T *di, DI_SENSOR_TYPE_T sensor, int rate, int latency);

float calc_rate_error(float desired_rate, float measured_rate);

void printCommunicationInfo(DI_INSTANCE_T *instance);

/** \brief set up the system to acquire real data; used by many
 *         tests
 *
 **/
int test_start_chip_running(char *file, bool gather_data);

int test_start_chip_normal();

/**
 * \brief read data from FIFO for a specific amount of time
 * timeout: time for reading fifo
 * stop_on_first_data:
 */
int test_read_out_pending_data(u32 timeout, bool stop_on_first_data);


bool try_with_time_limit(bool (*what)(), u32 maxTimeMs, u32 loopWaitMs);
bool check_IntStat_HostIntr(bool val);
bool check_IntStat_HostIntr_0();
bool check_IntStat_HostIntr_1();
bool read_FIFO(int times,bool prn,u32 *smpl_rcv);
bool read_if_int();
bool read_out_while_intr_int(u32 timeoutMs, u32 no_irq_tm,
   u32 irq_limit,u32 irq_limit_for_long_tm, u32 long_irq_diff_tm,
   u32 *smplRecv);
bool read_out_while_intr(u32 timeoutMs, u32 *smplRecv, u32 no_irq_time);
int flushBothFifoAndCheckEmpty();
int setAndTestHostIntrDisable(bool hostIntrDis, bool wakeUpFIFO);
char *hostIntrToStr(u8 val, char *txt);
int checkHostIntr(u8 val, u32 maxTimeMs, u32 loopWaitMs);
int checkHostIntr2(u8 val_a,u8 val_b,u8 val_c);

typedef struct
{ // [0] = non wakeup(or only variant of android K) [1] = wakeup
   bool intrpt[2];      // intrrupt 1=enable 0=disable
   float wm_perc[2];    // water-mark - fifo max size multiplication - eg 0.20 means 20% of FIFO
   bool force_wait_max_time_ms; // force to wait enough time to (both) FIFO overflows
} fifo_test_config;

typedef struct
{
   int sz;
   // in current implementation expecting only following sensor configurations:
   //   android L: DST_ACCELEROMETER,DST_WAKEUP_ACCELEROMETER
   //   android K: DST_ACCELEROMETER
   DI_SENSOR_TYPE_T s[MAX_AVAILABLE_SENSORS]; //sensors to be used
   u16 rt[MAX_AVAILABLE_SENSORS];             // requested rate [Hz]
} fifo_test_sensor_config;

typedef struct my_stop_watch
{
   u32 tb; // time beg
   u32 te; // time end
   u32 td; // time dif
} my_stop_watch_t;

#define MAX(a,b) ((a>b)?a:b)
#define MIN(a,b) ((a<b)?a:b)
#define STORE_MAX(store,actual) store = (actual>store)? actual:store;
#define STORE_MIN(store,actual) store = (actual<store)? actual:store;

typedef struct available_sensors
{
   DI_SENSOR_TYPE_T s[MAX_AVAILABLE_SENSORS];  //sensors non wakeup
   DI_SENSOR_TYPE_T sw[MAX_AVAILABLE_SENSORS]; //sensors wakeup
   DI_SENSOR_TYPE_T su[MAX_AVAILABLE_SENSORS]; //sensors w+nw
   int c;  // counter of standard sensors
   int cw; // counter of wakeup sensors
   int cu; // counter of w + nw
} available_sensors_t;

extern DI_SENSOR_TYPE_T all_std_sens[];
extern const int g_all_std_sens_sz;

void stop_watch(my_stop_watch_t *sw,int prn,bool reset);

bool chk_water_mark(fifo_test_config *p, fifo_test_sensor_config *sc);
void fifo_test_init(bool first_loop,fifo_test_sensor_config *sc,fifo_test_config *p,u16 *max_rt);

bool chk_val_with_margin_lr_dbl(double exp, double act,
   double marg_mult_l,double marg_add_l,
   double marg_mult_r,double marg_add_r, char* txt);
bool chk_d_val_with_margin_lr(s32 exp, s32 act,
   double marg_mult_l,double marg_add_l,
   double marg_mult_r,double marg_add_r);
bool chk_d_val_with_margin(s32 exp, s32 act,
   double marg_mult,double marg_add);
bool chk_s_val_with_margin_lr(s32 exp, s32 act,
   double marg_mult_l,int marg_add_l,
   double marg_mult_r,int marg_add_r);
bool chk_s_val_with_margin(s32 exp, s32 act,
   double marg_mult,int marg_add);
bool chk_val_min_max(u32 val, u32 min, u32 max);
bool chk_val_with_margin_lr(u32 exp, u32 act,
   double marg_mult_l,int marg_add_l,
   double marg_mult_r,int marg_add_r);
bool chk_dual_val_with_margin_lr(u32 exp_l, u32 exp_r, u32 act,
   double marg_mult_l,int marg_add_l,
   double marg_mult_r,int marg_add_r);
extern bool chk_val_with_margin(u32 exp, u32 act,
   double marg_mult,int marg_add);

bool check_int_pin(bool exp);
bool check_int_pin_0(void);
bool check_int_pin_1(void);

bool fifo_discard_by_read_fifo_data();
extern int fifo_discard();
bool read_bytes_remaining();

int check_FIFO_consistency();
bool get_3axis_fifo_events(DI_INSTANCE_T *di, u16 *w,u16 *nw);
u16 fifo_size_to_events(u16 sz_B,DI_SENSOR_TYPE_T s);

void chk_sens_stat_data_avail_param(DI_SENSOR_TYPE_T s,bool exp);
bool chk_sens_stat_data_avail();

bool add_avail_sens(available_sensors_t *a,DI_SENSOR_TYPE_T s);
void avail_sens_list(int sz,DI_SENSOR_TYPE_T searchSensors[],available_sensors_t *a);
void set_list_sensors_rate(int sz, DI_SENSOR_TYPE_T *s,u16 sr);
void avail_sens_turn_off(available_sensors_t *a);

extern bool set_and_chk_lat(DI_SENSOR_TYPE_T s, u16 l, u16 *ql,bool chkLat);
extern bool set_and_chk_rate(DI_SENSOR_TYPE_T s, u16 sr, u16 *qsr,bool chkLimit);

u16 get_max_sensor_rate(DI_SENSOR_TYPE_T s);

bool getSensorPwrMode(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, SENSOR_POWER_MODE *pwrMode);
bool testSensorPwrModeOn(SENSOR_POWER_MODE pwrMode);
bool testSensorPwrModeOff(SENSOR_POWER_MODE pwrMode);

extern bool chk_water_mark(fifo_test_config *p, fifo_test_sensor_config *sc);

u32 fifo_size_to_time_ms(u16 fifo_B,u16 rate, DI_SENSOR_TYPE_T sens);
void get_fifo_sizes(u16 max_fifo_B[2]);
float get_size_ratio_for_min_time(fifo_test_sensor_config sc, u32 min_req_time_ms);
u16 dec_rate_till_min_time_met(float fifo_ratio,fifo_test_sensor_config *sc, u32 min_req_time_ms);

bool wait_int_pin(bool exp, u32 max_wait_ms);

// time structure
typedef struct my_tm_s
{
   int ms;  // mili-seconds
   int s;   // seconds
   int m;   // minutes
   int h;   // hours
} my_tm_t;

// convert miliseconds to time struct (h,m,s,ms)
void ms_2_my_tm(u32 ms,my_tm_t *t);

// convert time struct (h,m,s,ms) to miliseconds
u32 my_tm_2_ms(my_tm_t *t);

// convert miliseconds to string time (HH:MM:SS.mmm)
// str: string buffer
// sz: size of "str" string buffer
// time_ms: time in miliseconds to display
void time_to_str(char *str,u32 sz,u32 time_ms);

extern void display_full_status(void);

#endif //__TEST_COMMON_H__
