#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#ifdef _MSC_VER
#include <conio.h>
#else
int _kbhit()
{
   return 0;
}
#endif

#include "driver_ext.h"
#include "host_services.h"
#include "host_definitions.h"
#include "driver_util.h"
#include "sensor_handling.h"
#include "sensor_stats.h"
#include "tests.h"
#include "main.h"

#if !defined(VERSION)
#define VERSION 7
#endif

#define TEST_ERROR_TIMEOUT_MS 90000

typedef struct test_result
{
   u8 major;
   u8 minor;
   bool passed;
   bool failed;
   bool warned;
   bool skipped;
} TEST_RESULT;


#define RET_OK 0              // no test failures or warnings
#define RET_ERROR 1           // there was at least one test failure
#define RET_WARN 2            // there were no test failures, but at least one warning
#define RET_TESTER_FAILURE 1  // some other reason the tests could not be run

DI_SENSOR_TYPE_T find_sensor_type(DI_INSTANCE_T *instance, char *name)
{
   DI_SENSOR_TYPE_T st;

   for (st = DST_NOP+1; st <= di_max_sensor_id(instance); st++)
   {
      if (strncmp(di_query_sensor_short_name(instance, st), name, strlen(name)) == 0)
      {
         if (st == DST_GYROSCOPE)
         {
            warn_log("replacing Gyroscope with GyroscopeUncalibrated\n");
            st = DST_GYROSCOPE_UNCALIBRATED;
         }
         else if (st == DST_GEOMAGNETIC_FIELD)
         {
            warn_log("replacing GeomagneticField with MagneticFieldUncalibrated\n");
            st = DST_MAGNETIC_FIELD_UNCALIBRATED;
         }
         return st;
      }
   }
   return DST_NOP;
}

int run_unit_tests(DI_INSTANCE_T * instance, DI_SENSOR_TYPE_T sensor_type, RegImplementedPowerModes modes, int test_hi_num, int test_lo_num, bool skip)
{
   //DI_SENSOR_TYPE_T sensor[] = {
   //   DST_ACCELEROMETER, DST_GYROSCOPE_UNCALIBRATED, DST_MAGNETIC_FIELD_UNCALIBRATED, DST_LIGHT, DST_PRESSURE, DST_PROXIMITY, DST_AMBIENT_TEMPERATURE, DST_RELATIVE_HUMIDITY, DST_TEMPERATURE, -1
   //};
   RegTestControl control;
   RegTestStatus status;
   TestError error;
   bool executing;
   bool sensing;
   u8 buf[2];
   u8 aux;
   u16 aux12;
   u16 aux34;
   u8 aux5;
   int num_passed = 0;
   int num_warned = 0;
   int num_skipped = 0;
   int num_failed = 0;
   int num_executed = 0;
   int i;
   TEST_RESULT results[100];
   u32 start;

   memset(results, 0, sizeof(results));

   control.reg = 0;
   control.bits.SensorType = sensor_type; // i;

   info_log("\n\nUnit Tests starting up.  Sensor type %s = %u, power modes 0x%02X\n", di_query_sensor_name(instance, sensor_type), control.bits.SensorType, modes.reg);
   // clear initial control registers
   buf[0] = test_lo_num;
   buf[1] = test_hi_num;
   if (!i2c_blocking_write(instance->i2c_handle, SR_TEST_START_LOW_NUM, buf, 2))
   {
      return -3;
   }
   // write supported power modes to test against
   if (!i2c_blocking_write(instance->i2c_handle, SR_TEST_IMPLEMENTED_POWER_MODES, &modes.reg, 1))
   {
      return -4;
   }
   //info_log("  write Start=1\n");
   if (test_lo_num || test_hi_num)
   {
      control.bits.Continue = skip; // if you set skip, then it will continue on from the specified test; if you don't (the default) it will keep testing just this test
   }
   else
      control.bits.Continue = TRUE; // iterate through all tests
   control.bits.Start = TRUE;
   if (!i2c_blocking_write(instance->i2c_handle, SR_TEST_CONTROL, &control.reg, 1))
   {
      return -5;
   }

   //if (!di_configure_rate(instance, sensor_type, 100))
   //{
   //   return -6;
   //}

   info_log("  start firmware running\n");
   if (!di_normal_exec_request(instance))
   {
      return -7;
   }

   // confirm all is well
   if (!di_query_status(instance, &executing, &sensing))
      error_log("error reading status\n");
   info_log("  executing: %d, sensing: %d\n", executing, sensing);

   info_log("  wait for unit test framework ready\n");
   do
   {
      if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_STATUS, &status.reg, 1))
         return -8;
   }
   while (!status.bits.Fail);

   info_log("  ready to begin\n");

   for (;;)
   {
      //info_log("  write Start=0\n");
      control.bits.Start = FALSE;
      if (!i2c_blocking_write(instance->i2c_handle, SR_TEST_CONTROL, &control.reg, 1))
      {
         return -9;
      }

      //info_log("  wait for Fail=0\n");
      do
      {
         if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_STATUS, &status.reg, 1))
         {
            return -10;
         }
      }
      while (status.bits.Fail);

      // now we are synced, really request to start
      info_log("starting test... ");
      control.bits.Start = TRUE;
      if (!i2c_blocking_write(instance->i2c_handle, SR_TEST_CONTROL, &control.reg, 1))
      {
         return -11;
      }

      error = 0;
      start = time_ms();
      info_log("waiting for results...\r");
      do
      {
         if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_STATUS, &status.reg, 1))
         {
            return -12;
         }
         if (_kbhit() || ((time_ms() - start) > TEST_ERROR_TIMEOUT_MS))
         {
            error_log("Timeout or user cancelled\n");
            status.bits.Fail = TRUE;
            status.bits.Pass = FALSE;
            status.bits.Running = FALSE;
            error = TE_TIMEOUT;
            break;
         }
      }
      while (status.bits.Running || !(status.bits.Pass || status.bits.Fail));

      if (error != TE_TIMEOUT)
      {
         if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_ERROR, (u8 *)&error, 1))
         {
            return -13;
         }
      }
      if (error == TE_END_OF_TESTS)
         break;
      if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_LOW_NUM, buf, 2))
      {
         return -14;
      }
      if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_AUX, &aux, 1))
      {
         return -15;
      }
      if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_AUX1, (u8 *)&aux12, 2))
      {
         return -16;
      }
      if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_AUX3, (u8 *)&aux34, 2))
      {
         return -17;
      }
      if (!i2c_blocking_read(instance->i2c_handle, SR_TEST_AUX5, &aux5, 1))
      {
         return -18;
      }
      results[num_executed].major = buf[1];
      results[num_executed].minor = buf[0];
      if (status.bits.Pass)
      {
         results[num_executed].passed = TRUE;
         if (!aux)
            info_log("Unit Test %u.%u: PASSED.   Passed %u, Aux 0x%02X\n", buf[1], buf[0], error, aux);
         else
            info_log("Unit Test %u.%u: PASSED.   Passed %u, Aux 0x%02X, Aux12 0x%04X (%u), Aux34 0x%04X (%u), Aux5 0x%02X\n", buf[1], buf[0], error, aux, aux12, aux12, aux34, aux34, aux5);
         num_passed++;
      }
      else if (error == TE_CANNOT_TEST)
      {
         results[num_executed].skipped = TRUE;
         info_log("Unit Test %u.%u: SKIPPED.  Skipped %u, Aux 0x%02X\n", buf[1], buf[0], error, aux);
         num_skipped++;
      }
      else if (error == TE_WARNING)
      {
         results[num_executed].warned = TRUE;
         info_log("Unit Test %u.%u: %s.   Warning %u, Aux 0x%02X, Aux12 0x%04X (%u), Aux34 0x%04X (%u), Aux5 0x%02X\n", buf[1], buf[0], "WARNING", error, aux, aux12, aux12, aux34, aux34, aux5);
         num_warned++;
      }
      else
      {
         results[num_executed].failed = TRUE;
         info_log("Unit Test %u.%u: %s.   Error %u, Aux 0x%02X, Aux12 0x%04X (%u), Aux34 0x%04X (%u), Aux5 0x%02X\n", buf[1], buf[0], "FAILED", error, aux, aux12, aux12, aux34, aux34, aux5);
         num_failed++;
         display_error_info(instance);
      }
      num_executed++;
      if (error == TE_TIMEOUT)
      {
         display_error_info(instance);
         break;
      }
      time_delay_ms(100);

   }

   info_log("\nEND OF TESTS\n");
   info_log("***********************\nSummary:\nTESTS PASSED:  %d\nTESTS WARNED: %d\nTESTS FAILED: %d\nTESTS SKIPPED:  %d\n\n", num_passed, num_warned, num_failed, num_skipped);
   info_log("PASSED:  ");
   for (i = 0; i < num_executed; i++)
   {
      if (results[i].passed)
         info_log("%u.%u ", results[i].major, results[i].minor);
   }
   info_log("\nWARNED:  ");
   for (i = 0; i < num_executed; i++)
   {
      if (results[i].warned)
         info_log("%u.%u ", results[i].major, results[i].minor);
   }
   info_log("\nFAILED:  ");
   for (i = 0; i < num_executed; i++)
   {
      if (results[i].failed)
         info_log("%u.%u ", results[i].major, results[i].minor);
   }
   info_log("\nSKIPPED: ");
   for (i = 0; i < num_executed; i++)
   {
      if (results[i].skipped)
         info_log("%u.%u ", results[i].major, results[i].minor);
   }
   info_log("\n");
   if ((num_passed != 0) && (num_failed == 0))
   {
      if (num_warned == 0)
         return 0;
      else
         return -1;
   }
   else
      return -2;
}

void print_signon(void)
{
   info_log("U7180 Driver Unit Test Suite v1.0.%d, %s, %s\n\n", VERSION, __DATE__, __TIME__);
}

void print_usage(char *app)
{
//   const char *name;
//   int st;
   info_log("usage: %s {-Uid -fFILE -a -lLOG -sSENSOR -pPOWER}\n\
   -Uid      set unique ID for I2C interface\n\
   -fFILE    set firmware file name to FILE\n", app);
   info_log("\
   -tL.H     select a specific test (omit to run all tests), and keep repeating until failure or keypress\n\
   -TL.H     start at a specific test, and continue on to subsequent ones\n\
   -r        do not reset at start\n\
   -E        load to EEPROM not RAM\n\
   -a        append to log (not overwrite)\n\
   -x        run on any ROM\n\
   -lLOG     log to file LOG\n\
   -y        no prompt\n\
   -sSENSOR  test sensor type SENSOR (* = all)\n\
             valid SENSOR values: ");
#if 0
   for (st = (DST_NOP+1); st < DST_NUM_SENSOR_TYPES; st++)
   {
      name = di_query_sensor_name((DI_SENSOR_TYPE_T)st);
      if (name)
         info_log("%s ", name);
   }
#else
   info_log("Accel, MagField, Gyro, Light, Pressure, Temp, Prox, Humid, AmbTemp, HrtRte\n");
#endif
   info_log("\n\
   -pPOWER   set supported power modes to test against; letters d s t i o l a:\n\
             d = power down, s = suspend, t = self test, i = interrupt motion, o = oneshot,\n\
             l = low power active, a = active; e.g. -pdsla; default -dsla for accel, mag, gyro\n\
             NOTE: tests 3.2 and 3.4 fail if this list does not match the driver's capabilities.\n");
}

int main(int argc, char *argv[])
{
   char firmware_file[200];
   char log_file[200];
   char sensor_name[20];
   DI_SENSOR_TYPE_T sensor_type = DST_ACCELEROMETER;
   I2C_HANDLE_T i2c_handle = NULL;
   I2C_HANDLE_T eeprom_i2c_handle = NULL;
   IRQ_HANDLE_T irq_handle = NULL;
   DI_INSTANCE_T * instance = NULL;
   u8 product_id;
   u8 revision_id;
   u16 rom_version;
   u16 ram_version;
   bool eeprom_present;
   bool append_log = FALSE;
   bool all_sensors = TRUE;
   bool force_reset = TRUE;
   bool force_anyrom = FALSE;
   bool load_to_ram = TRUE;
   bool no_prompt = FALSE;
   bool skip_test = FALSE;
   int i;
   int j;
   char *unique_id = NULL;
   struct tm *ltime;
   time_t now;
   int ret = -100;
   int cur_ret;
   RegImplementedPowerModes modes;
   u8 min_sensor_power_modes[255];
   int lo_num = 0;
   int hi_num = 0;

   memset(min_sensor_power_modes, 0, sizeof(min_sensor_power_modes));

   // according to app note 5 (programmer's guide), table 18, page 20, rev. 1.2, 12/14/2015, all physical drivers must implement power down, suspend, active, and low power active
   // power down, suspend, active, low power active
   min_sensor_power_modes[DST_ACCELEROMETER] = 0x63;
   min_sensor_power_modes[DST_GYROSCOPE_UNCALIBRATED] = 0x63;
   min_sensor_power_modes[DST_MAGNETIC_FIELD_UNCALIBRATED] = 0x63;
   min_sensor_power_modes[DST_TEMPERATURE] = 0x63;
   min_sensor_power_modes[DST_AMBIENT_TEMPERATURE] = 0x63;
   min_sensor_power_modes[DST_PRESSURE] = 0x63;
   min_sensor_power_modes[DST_RELATIVE_HUMIDITY] = 0x63;
   min_sensor_power_modes[DST_LIGHT] = 0x63;
   min_sensor_power_modes[DST_PROXIMITY] = 0x63;
   min_sensor_power_modes[DST_HEART_RATE] = 0x63;

   // log the name of the test
   print_signon();

   // display test start date / time
   time(&now);
   ltime = localtime(&now);
   info_log("current date and time: %s\n", asctime(ltime));

   // process command line
   firmware_file[0] = '\0';
   log_file[0] = '\0';
   modes.reg = 0;

   if (argc > 1)
   {
      for (i = 1; i < argc; i++)
      {
         if ((argv[i][0] == '-') || (argv[i][0] == '/'))
         {
            switch (argv[i][1])
            {
               case 'f':
                  strcpy(firmware_file, &argv[i][2]);
                  info_log("using firmware file: %s\n", firmware_file);
                  break;
               case 'x':
                  force_anyrom = TRUE;
                  info_log("will run on any ROM\n");
                  break;
               case 'a':
                  append_log = TRUE;
                  info_log("will append to log\n");
                  break;
               case 'l':
                  strcpy(log_file, &argv[i][2]);
                  info_log("using log file: %s\n", log_file);
                  break;
               case 't':
                  sscanf(&argv[i][2], "%d.%d", &hi_num, &lo_num);
                  info_log("selected just test %d.%d\n", hi_num, lo_num);
                  break;
               case 'T':
                  sscanf(&argv[i][2], "%d.%d", &hi_num, &lo_num);
                  info_log("selected just test %d.%d\n", hi_num, lo_num);
                  skip_test = TRUE;
                  break;
               case 'U':
                  unique_id = _strdup(&argv[i][2]);
                  break;
               case 'p':
                  modes.reg = 0;
                  // d = power down, s = suspend, i = interrupt motion, o = oneshot,
                  // l = low power active, a = active
                  for (j = 2; j < (int)strlen(argv[i]); j++)
                  {
                     switch (argv[i][j])
                     {
                        case 'd':
                           modes.bits.PowerDown = 1;        // bit 0
                           break;
                        case 's':
                           modes.bits.Suspend = 1;          // bit 1
                           break;
                        case 't':
                           modes.bits.SelfTest = 1;         // bit 2
                           break;
                        case 'i':
                           modes.bits.InterruptMotion = 1;  // bit 3
                           break;
                        case 'o':
                           modes.bits.OneShot = 1;          // bit 4
                           break;
                        case 'l':
                           modes.bits.LowPowerActive = 1;   // bit 5
                           break;
                        case 'a':
                           modes.bits.Active = 1;           // bit 6
                           break;
                        default:
                           print_signon();
                           print_usage(argv[0]);
                           info_log("\nError: unrecognized power mode: %c\n", argv[i][j]);
                           return -100;
                     }
                  }
                  break;
               case 'r':
                  force_reset = FALSE;
                  info_log("will not reset U718x at start\n");
                  break;
               case 'E':
                  load_to_ram = FALSE;
                  info_log("will load to EEPROM\n");
                  break;
               case 'y':
                  no_prompt = TRUE;
                  info_log("will not prompt\n");
                  break;
               case 'h':
               case '?':
                  print_signon();
                  print_usage(argv[0]);
                  return 0;
            }
         }
      }
   }

   // log to file if requested
   if (log_file[0] != '\0')
      debug_set_log_file(log_file, append_log);

   /**************************************************************
   * set up I2C and Data Ready IRQ                               *
   ***************************************************************/
   i2c_handle = i2c_setup(0x28, unique_id);                   // handle for U718x I2C access
   eeprom_i2c_handle = i2c_setup(0x50, unique_id);
   if (!i2c_handle || !eeprom_i2c_handle)
   {
      info_log("I2C setup error\n");
      goto error_exit;
   }

   irq_handle = irq_setup(5, unique_id);                      // the SPI /SS line on the Aardvark
   if (!irq_handle)
   {
      info_log("IRQ setup error\n");
      goto error_exit;
   }

   /**************************************************************
   * initialize U718x                                            *
   ***************************************************************/
   instance = di_init(i2c_handle, irq_handle, force_reset);
   if (!instance)
   {
      info_log("Driver setup error\n");
      goto error_exit;
   }

   di_control_logging(instance, no_prompt, no_prompt, no_prompt, FALSE);

   if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
   {
      error_log("error detecting u718x\n");
      goto error_exit;
   }

   info_log("U718x detected.  Product id: u71%02X, revision id: %u, rom version: %u, ram version: %u, eeprom present: %u\n",
             product_id, revision_id, rom_version, ram_version, eeprom_present);

   if (rom_version == 0)
   {
      error_log("rom version is 0\n");
      goto error_exit;
   }

   // need to handle sensor specifying command line parameter after we init
   if (argc > 1)
   {
      for (i = 1; i < argc; i++)
      {
         if ((argv[i][0] == '-') || (argv[i][0] == '/'))
         {
            switch (argv[i][1])
            {
               case 's':
                  if ((argv[i][2] == '*') || (argv[i][2] == 'X'))
                  {
                     all_sensors = TRUE;
                     info_log("will test all sensors\n");
                  }
                  else
                  {
                     all_sensors = FALSE;
                     strncpy(sensor_name, &argv[i][2], sizeof(sensor_name));
                     sensor_name[sizeof(sensor_name)-1] = '\0';
                     sensor_type = find_sensor_type(instance, sensor_name); // FIXME
                     if (sensor_type == DST_NOP)
                     {
                        print_signon();
                        print_usage(argv[0]);
                        info_log("\nError: sensor %s not valid\n", sensor_name);
                        return -100;
                     }
                     else
                     {
                        if (modes.reg == 0) // no param yet to set power modes
                           modes.reg = min_sensor_power_modes[sensor_type];
                     }
                     info_log("will test %s\n", sensor_name);
                  }
                  break;
            }
         }
      }
   }


   if (strlen(firmware_file))
   {
      if (load_to_ram)
      {
         info_log("Uploading to RAM...\n");
         if (!di_upload_firmware(instance, firmware_file, force_anyrom, NULL))
         {
            error_log("error uploading firmware\n");
            goto error_exit;
         }
      }
      else
      {
         info_log("Uploading to EEPROM...\n");
         if (!di_upload_eeprom(instance, eeprom_i2c_handle, firmware_file, force_anyrom, NULL))
         {
            error_log("error uploading EEPROM\n");
            goto error_exit;
         }
      }
   }

   /**************************************************************
   * run unit tests                                              *
   ***************************************************************/
   if (all_sensors)
   {
      DI_SENSOR_TYPE_T sensor_types[3] = {DST_ACCELEROMETER, DST_GYROSCOPE_UNCALIBRATED, DST_MAGNETIC_FIELD_UNCALIBRATED};
      ret = 0;
      for (i = 0; i < 3; i++)
      {
         sensor_type = sensor_types[i];
         strncpy(sensor_name, di_query_sensor_name(instance, sensor_type), sizeof(sensor_name));
         modes.reg = min_sensor_power_modes[sensor_type];
         cur_ret = run_unit_tests(instance, sensor_type, modes, hi_num, lo_num, skip_test);
         if (cur_ret != 0)
            ret = cur_ret;
         info_log("\nreset\n");
         di_reset_chip(instance, TRUE);
         info_log("detect\n");
         if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
            break;
         if (i != 2)
            info_log("next sensor\n");
      }
   }
   else
      ret = run_unit_tests(instance, sensor_type, modes, hi_num, lo_num, skip_test);

   /**************************************************************
   * done                                                        *
   ***************************************************************/
   if (!no_prompt)
   {
      info_log("tests complete; hit a key\n");
      while (get_key() == -1);
   }

   error_exit:
   if (instance)
   {
      di_deregister(instance);
      di_shutdown_request(instance);
      di_deinit(instance);
   }
   info_log("exit code = %d\n", ret);
   debug_set_log_file(NULL, FALSE);
   if (ret == 0)
      return RET_OK;
   else if (ret == -1)
      return RET_WARN;
   else if (ret == -2)
      return RET_ERROR;
   else
      return RET_TESTER_FAILURE;
}


