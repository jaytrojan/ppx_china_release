#ifndef _MAIN_H_
#define _MAIN_H_

#include "types.h"
#include "host_services.h"
#include "driver_ext.h"


// test application configuration flags
#define CONFIG_FILE_REQUIRED              // don't run if we can't find the config file

#define SENSORS_PRESENT_SIZE 6

// these defines affect non-firmware-test mode
//#define FILE_TEST                       // do a simple file test against the DataFlash
#define RAM_FILE           "SFPTEST.FW"   // file to load to RAM if in force-upload
//#define LOAD_TO_RAM                     // upload file to RAM (else to EEPROM)
#define EEPROM_FILE        "SFPTEST.FW"   // file to load to EEPROM if in force-upload
//#define DYNAMIC_SENSORS                 // uncomment to enable starting firmware with 0 rates, then querying which sensors are present
#define REQUIRE_ALL_SENSORS               // uncomment to check that all basic sensors are present and working
//#define DUMP_ALL_REGS                   // uncomment to log all register values prior to starting a run
#define ACCEL_RATE_HZ      100            // 125
#define GYRO_RATE_HZ       190            // 200
#define MAG_RATE_HZ        30
#define QUATERNION_RATE_HZ 190            // 200

//typedef uint32_t bool;
#define TRUE 1
#define FALSE 0

#endif

