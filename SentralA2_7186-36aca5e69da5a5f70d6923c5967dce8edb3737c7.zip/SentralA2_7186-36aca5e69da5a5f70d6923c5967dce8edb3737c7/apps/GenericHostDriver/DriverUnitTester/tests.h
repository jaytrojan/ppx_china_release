//////////////////////////////////////////////////////////////////////////////
///
/// @file		tests.h
///
///
/// @project	718x
///
/// @brief		Driver Unit Test defines
///
////////////////////////////////////////////////////////////////////////////////
///
////////////////////////////////////////////////////////////////////////////////
///
/// @copyright	(C) EM Microelectronic US Inc.
///
/// @copyright Disclosure to third parties or reproduction in any form
/// 	whatsoever, without prior written consent, is strictly forbidden
///
////////////////////////////////////////////////////////////////////////////////
#ifndef _TESTS_H
#define _TESTS_H

/** @brief host writeable registers */
#define SR_TEST_CONTROL       0x5C
#define SR_TEST_START_LOW_NUM 0x5D     /**< test to start with; set both this and next reg to 0 to start with first test */
#define SR_TEST_START_HI_NUM  0x5E
#define SR_TEST_IMPLEMENTED_POWER_MODES 0x5F /**< specify the intended power modes supported by this driver */
/** @brief host readable registers */
#define SR_TEST_STATUS        0x3B     /**< status bits for test execution */
#define SR_TEST_LOW_NUM       0x3C     /**< current test running or finished */
#define SR_TEST_HI_NUM        0x3D
#define SR_TEST_ERROR         0x3E     /**< test-specific error code, if needed */
#define SR_TEST_AUX           0x3F
#define SR_TEST_AUX1          0x40
#define SR_TEST_AUX2          0x41
#define SR_TEST_AUX3          0x42
#define SR_TEST_AUX4          0x43
#define SR_TEST_AUX5          0x44

/**
 * @brief Test Control bits
 */
typedef union TestControl
{
	/**
	 * @brief Direct access to the complete 8bit register
	 */
	u8 reg;
	/**
	 * @brief Access to individual bits in the register.
	 */
	struct {
		u8 SensorType : 5;   /**< type of sensor to test */
      u8 Step : 1;         /**< execute a single test then stop */
      u8 Continue : 1;     /**< continue to next test */
      u8 Start : 1;        /**< start running tests, beginning with the starting test number in SR_TEST_START_LOW_NUM and SR_TEST_START_HI_NUM */
	} bits;
} RegTestControl;

/**
 * @brief Implemented Power Mode bits
 */
typedef union ImplementedPowerModes
{
	/**
	 * @brief Direct access to the complete 8bit register
	 */
	u8 reg;
	/**
	 * @brief Access to individual bits in the register.
	 */
	struct {
	  u8 PowerDown : 1; 		// 0
      u8 Suspend : 1;   		// 1
      u8 SelfTest : 1;  		// 2
      u8 InterruptMotion : 1;   // 3
	  u8 OneShot : 1;   		// 4
      u8 LowPowerActive : 1;	// 5
      u8 Active : 1;			// 6
      u8 reserved : 1;  		// 7
	} bits;
} RegImplementedPowerModes;


/**
 * @brief Test Status bits
 */
typedef union TestStatus
{
	/**
	 * @brief Direct access to the complete 8bit register
	 */
	u8 reg;
	/**
	 * @brief Access to individual bits in the register.
	 */
	struct {
		u8 SensorType : 5;   /**< type of sensor tested */
      u8 Fail : 1;         /**< the test in SR_TEST_LOW_NUM and ST_TEST_HI_NUM has failed; mutually exclusive with Pass */
      u8 Pass : 1;         /**< the test in SR_TEST_LOW_NUM and SR_TEST_HI_NUM has passed; mutually exclusive with Fail */
      u8 Running : 1;      /**< a test is executing */
	} bits;
} RegTestStatus;

typedef enum TestErrorEnum
{
   TE_NONE, TE_PASS, TE_CANNOT_TEST, TE_FAIL, TE_BAD_SENSOR_NUM, TE_BAD_CUST_ID, TE_MISSING_SENSOR, TE_BAD_TEST_NUM, TE_WARNING, TE_END_OF_TESTS, TE_TIMEOUT
} TestError;

#endif

