// ghd.c: simplified generic host driver interface
//

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "ghd.h"


bool init = FALSE;
DI_INSTANCE_T * instance;
DI_3AXIS_DATA_T prev_3axis;
DI_QUATERNION_DATA_T prev_rotation_vector;
DI_SENSOR_DATA_T the_sensor_data;

// firmware tests, normal main
bool ghd_data_callback(DI_INSTANCE_T * instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T * data, void *user_param)
{
   // convert from integer to floating point
   if (init)
      di_convert_sensor_data(instance, sensor, data, (DI_SENSOR_DATA_T *)&the_sensor_data, FALSE);

   return TRUE;
}


bool ghd_get_orient(DI_SENSOR_TYPE_T sensor, float *x, float *y, float *z)
{
   DI_3AXIS_DATA_T *od;

   if (!init)
      return FALSE;
   switch(sensor)
   {
      case DST_ACCELEROMETER:
         od = &the_sensor_data.accel;
         break;
      case DST_GYROSCOPE:
         od = &the_sensor_data.gyro;
         break;
      case DST_GEOMAGNETIC_FIELD:
         od = &the_sensor_data.mag;
         break;
      case DST_GRAVITY:
         od = &the_sensor_data.gravity;
         break;
      case DST_LINEAR_ACCELERATION:
         od = &the_sensor_data.linear_acceleration;
         break;
      case DST_ORIENTATION:
         od = &the_sensor_data.orientation;
         break;
      default:
         return FALSE;
   }

   if (od->t != prev_3axis.t)
   {
      if (sensor == DST_ORIENTATION)
      {
         *x = - od->y;
         *y = - od->x;
         *z = od->z;
      }
      else
      {
         *x = - od->x; // y;
         *y = od->z; // x;
         *z = od->y; // z;
      }

      prev_3axis.x = od->x;
      prev_3axis.y = od->y;
      prev_3axis.z = od->z;
      prev_3axis.t = od->t;
      return TRUE;
   }
   return FALSE;
}

bool ghd_get_quaternion(DI_SENSOR_TYPE_T sensor, float *x, float *y, float *z, float *w)
{
   DI_QUATERNION_DATA_T *qd;

   if (!init)
      return FALSE;

   switch(sensor)
   {
      case DST_ROTATION_VECTOR:
         qd = &the_sensor_data.rotation_vector;
         break;
      case DST_GAME_ROTATION_VECTOR:
         qd = &the_sensor_data.game_rotation_vector;
         break;
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         qd = &the_sensor_data.geomag_rotation_vector;
         break;
      default:
         return FALSE;
   }
   if (qd->t != prev_rotation_vector.t)
   {
      *z = - qd->y;
      *x = qd->x;
      *y = qd->z;
      *w = qd->w;
      prev_rotation_vector.x = qd->x;
      prev_rotation_vector.y = qd->y;
      prev_rotation_vector.z = qd->z;
      prev_rotation_vector.w = qd->w;
      prev_rotation_vector.t = qd->t;
      return TRUE;
   }
   return FALSE;
}


bool ghd_enable_sensor(DI_SENSOR_TYPE_T sensor, unsigned int rate)
{
   DI_ERROR_T error_info;
   SENSOR_CONFIG sensor_config;

   if (!init)
      return FALSE;

   if (!di_pause_task_loop(instance))
      return 0;

   if (!di_has_sensor(instance, sensor))
      return FALSE;

   // set up the sample rates for all sensors
   sensor_config.change_sensitivity = 0;
   sensor_config.dynamic_range = 0;
   sensor_config.max_report_latency = 0;
   sensor_config.sample_rate = rate;
   if (!di_configure_sensor(instance, sensor, &sensor_config))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d setting Accel rate\n", error_info.driver_error);
      return 0;
   }

   time_delay_ms(500);

   // display actual sample rates implemented by the drivers
   if (!di_query_sensor_config(instance, sensor, &sensor_config))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error reading status: %d\n", error_info.driver_error);
      return 0;
   }
   info_log("Sample rate set to %u Hz\n", sensor_config.sample_rate);
   return 1;
}

//**************************************************************
//* example chip program                                       *
//**************************************************************
bool ghd_init(char *fw, char *unique_id)
{
   I2C_HANDLE_T i2c_handle;
   I2C_HANDLE_T eeprom_i2c_handle;
   IRQ_HANDLE_T irq_handle;
   u8 product_id;
   u8 revision_id;
   u16 rom_version;
   u16 ram_version;
   bool eeprom_present;
   DI_ERROR_T error_info;
   SENSOR_CONFIG sensor_config;
   u32 prev_received = 0;
   bool executing;
   bool sensing;
   //int port = 5;                                                     // change this to match your COM port number
   //char *port = "\\\\.\\COM5";
   bool force_anyrom = TRUE;
   DI_SENSOR_TYPE_T sensor;
   HIIDValues host_intf_id;
   u8 buf[4];
   u32 size;

   info_log("U718x Spinning Cube v1.1\n\n");
   init = FALSE;

   //**************************************************************
   //* set up I2C and Data Ready IRQ                              *
   //*                                                            *
   //* In this example, we assume we've already written functions *
   //* i2c_setup() and irq_setup() to interface our test platform *
   //* I2C and IRQ drivers to chip's Platform-intependent      *
   //* services.                                                  *
   //**************************************************************
   i2c_handle = i2c_setup(0x28, unique_id);                   // handle for chip I2C access
   if (!i2c_init(i2c_handle))
   {
      error_log("I2C init error\n");
      return FALSE;
   }
   eeprom_i2c_handle = i2c_setup(0x50, unique_id);
   if (!i2c_init(eeprom_i2c_handle))
   {
      error_log("I2C init error\n");
      return FALSE;
   }
   if (!i2c_handle || !eeprom_i2c_handle)
   {
      error_log("I2C setup error\n");
      return FALSE;
   }

   irq_handle = irq_setup(5, unique_id);                      // the SPI /SS line on the Aardvark
   if (!irq_handle)
   {
      error_log("IRQ setup error\n");
      return FALSE;
   }


   //**************************************************************
   //* initialize chip                                            *
   //**************************************************************
   instance = di_init(i2c_handle, irq_handle, TRUE);                // reset chip
   if (!instance)
   {
      info_log("Driver setup error\n");
      return FALSE;
   }

   // make sure we can communicate with it
   if (!di_detect_chip(instance, NULL, NULL, NULL, NULL, NULL))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d detecting chip\n", error_info.driver_error);
      return FALSE;
   }
   if (fw && (strlen(fw) > 0))
   {
      info_log("Uploading to RAM...\n");
      if (!di_upload_firmware(instance, fw, force_anyrom, NULL))
      {
         error_log("error uploading firmware %s\n", fw);
         return FALSE;
      }
   }

   size = i2c_get_max_read_length(i2c_handle);
   info_log("set max buffer size to %u\n", size);
   di_set_buffer_max_size(instance, size);  // ask the underlying driver what its max size is, then limit transfers to that size

   // start chip firmware running
   if (!di_run_request(instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error starting: %d\n", error_info.driver_error);
      return FALSE;
   }

   // tell driver to call us when data arrives
   if (!di_register(instance, ghd_data_callback, (void *)instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error registering data callback: %d\n", error_info.driver_error);
      return FALSE;
   }

   // start the algorithm running
   if (!di_normal_exec_request(instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error running: %d\n", error_info.driver_error);
      return FALSE;
   }

   if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error %d detecting u718x\n", error_info.driver_error);
      return FALSE;
   }
   info_log("U718x detected.  Product id: u71%02X, revision id: %u, rom version: %u, ram version: %u, eeprom present: %u\n",
             product_id, revision_id, rom_version, ram_version, eeprom_present);

   if (di_read_registers(instance, SR_PASSTHRU_STATUS, SR_PASSTHRU_STATUS + 1, buf))
   {
      u8 fpga_version = (buf[0] >> 1) & 0x7f;
      info_log("FPGA version: 0x%02X\n", fpga_version);
      // apply timing correction to u7180_jtag_v37, u7180_jtag_v38, u7183_jtag_v39, u7180_jtag_v41, u7183_jtag_v43, u7183_jtag_v45 (10MHz), u7183_jtag_v47 (15MHz)
      if ((fpga_version == 0x37) || (fpga_version == 0x38) || (fpga_version == 0x39) || (fpga_version == 0x41) || (fpga_version == 0x43) || (fpga_version == 0x45) || (fpga_version == 0x47))
      {
         if (di_read_registers(instance, 0xB6, 0xB6, buf))
         {
            info_log("TimoscDivCount was: %u\n", buf[0]);
            buf[0] = 66;
            if (di_write_registers(instance, 0xB6, 0xB6, buf))
            {
               info_log("Set TimoscDivCount to %u\n", buf[0]);
            }
         }
      }
   }

   time_delay_ms(1000);

   // confirm all is well
   if (!di_query_status(instance, &executing, &sensing))
   {
      info_log("Error reading status\n");
      display_error_info(instance);
      return FALSE;
   }
   info_log("executing: %d, sensing: %d\n", executing, sensing);

   // init statistics
   reset_stats();
   di_control_logging(instance, FALSE, FALSE, TRUE, FALSE);

   // find out what sensors are there
   if (!di_query_features(instance))
   {
      error_log("error retrieving sensor list\n");
      display_error_info(instance);
      return FALSE;
   }

   // set up the sample rates for all sensors
   sensor_config.change_sensitivity = 0;
   sensor_config.dynamic_range = 0;
   sensor_config.max_report_latency = 0;
   sensor_config.sample_rate = 0;
   for (sensor = DST_FIRST; sensor <= di_max_sensor_id(instance); sensor++)
   {
      if (di_has_sensor(instance, sensor) && !di_configure_sensor(instance, sensor, &sensor_config))
      {
         di_get_last_error(instance, &error_info);
         info_log("Error %d setting rate\n", error_info.driver_error);
         display_error_info(instance);
         return FALSE;
      }
   }

   // display info about the sensor drivers
   info_log("\nSensor driver information:\n");
   if (!display_driver_info(instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error reading status: %d\n", error_info.driver_error);
      display_error_info(instance);
      return FALSE;
   }

#if 0
   // display actual sample rates implemented by the drivers
   info_log("\nActual sensor settings:\n");
   if (!display_actual_rates(instance))
   {
      di_get_last_error(instance, &error_info);
      info_log("Error reading status: %d\n", error_info.driver_error);
      display_error_info(instance);
      return FALSE;
   }
#endif

   // select a sensor as the source of host interrupts
   host_intf_id = di_get_host_interface_id(instance);
   if (host_intf_id == HIID_KITKAT)
   {
      info_log("KitKat interface\n");
      if (!di_configure_interrupts(instance, TRUE, 0))
      {
         di_get_last_error(instance, &error_info);
         error_log("Error enabling sensor: %d\n", error_info.driver_error);
         display_error_info(instance);
         return FALSE;
      }
   }
   else
   {
      info_log("Lollipop interface\n");
      if (!di_configure_interrupts_ex(instance, TRUE, TRUE, 0, 0))
      {
         di_get_last_error(instance, &error_info);
         error_log("Error enabling sensor: %d\n", error_info.driver_error);
         display_error_info(instance);
         return FALSE;
      }
   }
   info_log("\nRunning:\n");
   init = TRUE;
   return TRUE;
}


void ghd_callback(void)
{
   if (!di_task_loop(instance, NULL))
   {
      display_error_info(instance);
   }
}


void ghd_deinit(void)
{
   if (init)
   {
      init = FALSE;
      info_log("\nSummary:\n");
      di_pause_task_loop(instance);
      display_error_info(instance);

      info_log("\nDone.\n");
      di_deregister(instance);
      //di_standby_request(instance);
      //di_shutdown_request(instance);
      di_deinit(instance);
   }
}

