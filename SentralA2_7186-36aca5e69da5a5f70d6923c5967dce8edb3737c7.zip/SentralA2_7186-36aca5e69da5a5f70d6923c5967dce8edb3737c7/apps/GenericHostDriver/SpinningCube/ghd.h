#ifndef _GHD_H_
#define _GHD_H_

#include "host_definitions.h"
#include "driver_ext.h"
#include "host_services.h"
#include "driver_util.h"
#include "sensor_handling.h"
#include "sensor_stats.h"



extern bool ghd_init(char *fw, char *unique_id);
extern bool ghd_get_orient(DI_SENSOR_TYPE_T sensor, float *x, float *y, float *z);
extern bool ghd_get_quaternion(DI_SENSOR_TYPE_T sensor, float *x, float *y, float *z, float *w);
extern void ghd_callback(void);
extern bool ghd_enable_sensor(DI_SENSOR_TYPE_T sensor, unsigned int rate);

extern void ghd_deinit(void);


#endif

