// Example1.c : Defines the entry point for the console application.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#include "host_definitions.h"
#include "driver_ext.h"
#include "host_services.h"
#include "driver_util.h"


//**************************************************************
//* example the chip program                                    *
//**************************************************************
int main(int argc, char *argv[])
{
   I2C_HANDLE_T i2c_handle;
   I2C_HANDLE_T eeprom_i2c_handle;
   IRQ_HANDLE_T irq_handle;
   DI_INSTANCE_T * instance;
   DI_SENSOR_UNION_T sample;
   DI_SENSOR_TYPE_T the_sensor;
   SENSOR_CONFIG sensor_config;
   SENSOR_INFORMATION sensor_info;
   u16 ram_version = 0;
   //int port = 5;                                         // change this to match your COM port number
   char *port = "\\\\.\\COM5";

   info_log("U718x Generic Host Driver Example 1\n\n");

   //**************************************************************
   //* set up I2C and Data Ready IRQ                              *
   //*                                                            *
   //* In this example, we assume we've already written functions *
   //* i2c_setup() and irq_setup() to interface our test platform *
   //* I2C and IRQ drivers to the chip's Platform-intependent      *
   //* services.                                                  *
   //**************************************************************
   i2c_handle = i2c_setup(0x28, port);                   // handle for the chip I2C access
   if (!i2c_init(i2c_handle))
   {
      error_log("I2C init error\n");
      return 1;
   }
   eeprom_i2c_handle = i2c_setup(0x50, port);
   if (!i2c_init(eeprom_i2c_handle))
   {
      error_log("I2C init error\n");
      return 1;
   }
   if (!i2c_handle || !eeprom_i2c_handle)
   {
      error_log("I2C setup error\n");
      return 1;
   }

   irq_handle = irq_setup(5, port);                      // the SPI /SS line on the Aardvark
   if (!irq_handle)
   {
      error_log("IRQ setup error\n");
      return 1;
   }

   // show no register transfers
   enable_reg_log(FALSE);

   //**************************************************************
   //* initialize the chip                                        *
   //**************************************************************
   instance = di_init(i2c_handle, irq_handle, TRUE);                // reset the chip
   if (instance)
   {
      di_control_logging(instance, FALSE, TRUE, TRUE, FALSE);
      // for testing I2CHID, work around limited I2C size by setting max buffer size
      di_set_buffer_max_size(instance, 950);
      // detect the chip and the ROM
      if (di_detect_chip(instance, NULL, NULL, NULL, NULL, NULL))
      {
         // start the everything running in the chip
         if (di_normal_exec_request(instance))
         {
            // detect the RAM version
            if (di_detect_chip(instance, NULL, NULL, NULL, &ram_version, NULL))
            {
               if (ram_version != 0)
               {
                  // wait a bit so chip has time to get going
                  time_delay_ms(1000);

                  the_sensor = DST_ACCELEROMETER;
                  di_query_sensor_info(instance, the_sensor, &sensor_info);
                  // set up the sample rates for one sensor
                  sensor_config.change_sensitivity = 0;
                  sensor_config.dynamic_range = 0;
                  sensor_config.max_report_latency = 0;
                  sensor_config.sample_rate = 10;
                  if (di_configure_sensor(instance, the_sensor, &sensor_config))
                  {
                     time_delay_ms(1000);

                     // update the scale factors now that it is running
                     if (di_query_features(instance))
                     {
                        // select a sensor as the source of host interrupts
                        if (di_configure_interrupts(instance, TRUE, 0))
                        {
                           // now get the sample
                           if (di_query_sensor(instance, the_sensor, &sample))
                           {
                              info_log("Accelerometer reading in gs: (%f, %f, %f)\n", sample.accel.x, sample.accel.y, sample.accel.z);
                           }
                           else
                           {
                              display_error_info(instance);
                              info_log("Error reading sample\n");
                           }
                        }
                        else
                        {
                           display_error_info(instance);
                           info_log("Error configuring interrupts\n");
                        }
                     }
                     else
                     {
                        display_error_info(instance);
                        info_log("Error querying features\n");
                     }
                  }
                  else
                  {
                     display_error_info(instance);
                     info_log("Error setting Accel rate\n");
                  }
               }
               else
               {
                  info_log("No firmware loaded in RAM\n");
               }
               di_shutdown_request(instance);
            }
            else
            {
               display_error_info(instance);
               info_log("Error detecting the chip\n");
            }
         }
         else
         {
            display_error_info(instance);
            info_log("Error running\n");
         }
      }
      else
      {
         display_error_info(instance);
         info_log("Error detecting the chip\n");
      }
         di_deinit(instance);
   }
   else
      info_log("Driver setup error\n");

   return 0;
}

