/**
 * @file    driver_util.c
 *
 *
 * @brief   driver utility functions
 *
 * @copyright (C) 2013-2014 EM Microelectronic
 *
 */

#include <string.h> // will need conditionals to offer cross-platform version
//#include "main.h"
#include "driver_util.h"

/** \addtogroup Driver_Util
 *  @{
 */

//#define LOW_LEVEL_DEBUG // uncomment to pass actual bytes to logging system

bool i2c_blocking_read(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   TransferStatus status = TS_I2C_IDLE;
   u16 rlen = 0;
   u32 start = time_us();

   if (i2c_read_start(handle, reg_addr, buffer, len))
   {
      //debug_log("i2c_read_start: %u us\n", time_us() - start);
      start = time_us();
      while (!i2c_check_status(handle, &status, &rlen))
      {
         if ((status == TS_I2C_COMPLETE) || (status == TS_I2C_ERROR))
         {
            break;
         }
      }
      //debug_log("i2c status received: %u us\n", time_us() - start);
   }
   else
      error_log("i2c_blocking_read failed to start\n");
   if ((status == TS_I2C_COMPLETE) && (rlen == len))
   {
#if defined(LOW_LEVEL_DEBUG)
      insane_log("# read 0x%02X %u: ", reg_addr, len);
      while (len--)
         insane_log("0x%02X ", *(buffer++));
      insane_log("; %u\n", time_ms());
#endif
      return TRUE;
   }
   else
   {
      error_log("i2c_blocking_read failed: status = %u, rlen %u, len %u\n", status, rlen, len);
      return FALSE;
   }
}


bool i2c_blocking_write(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   TransferStatus status = TS_I2C_IDLE;
   u16 wlen = 0;
   u32 start = time_us();

   if (i2c_write_start(handle, reg_addr, buffer, len))
   {
      //debug_log("i2c_write_start: %u us\n", time_us() - start);
      start = time_us();
      while (!i2c_check_status(handle, &status, &wlen))
      {
         if (status != TS_I2C_IN_PROGRESS)
         {
            break;
         }
      }
      //debug_log("i2c status received: %u us\n", time_us() - start);
   }
#if defined(LOW_LEVEL_DEBUG)
   else
      error_log("i2c_blocking_write failed to start\n");
#endif
   if ((status == TS_I2C_COMPLETE) && (wlen == len))
   {
#if defined(LOW_LEVEL_DEBUG)
      insane_log("# write 0x%02X ", reg_addr);
      while (len--)
         insane_log("0x%02X ", *(buffer++));
      insane_log("; %u\n", time_ms());
#endif
      return TRUE;
   }
   else
   {
#if defined(LOW_LEVEL_DEBUG)
      error_log("i2c_blocking_write failed: status = %u, wlen %u, len %u\n", status, wlen, len);
#endif
      return FALSE;
   }
}


bool i2c_blocking_write_read(I2C_HANDLE_T handle, u8 *wbuffer, u16 wlen, u8 *rbuffer, u16 rlen)
{
   TransferStatus status = TS_I2C_IDLE;
   u16 tlen;
   u32 start = time_us();

   if (i2c_write_read_start(handle, wbuffer, wlen, rbuffer, rlen))
   {
      //debug_log("i2c_write_read_start: %u us\n", time_us() - start);
      start = time_us();
      while (!i2c_check_status(handle, &status, &tlen))
      {
         if (status != TS_I2C_IN_PROGRESS)
            break;
      }
      //debug_log("i2c status received: %u us\n", time_us() - start);
   }
   else
      error_log("i2c_blocking_write_read failed to start\n");
   if ((status == TS_I2C_COMPLETE) && (rlen == tlen))
   {
      return TRUE;
   }
   else
   {
      error_log("i2c_blocking_write_read failed: status = %u, wlen %u, rlen %u\n", status, wlen, rlen);
      return FALSE;
   }
}


int read_line(FILE_HANDLE_T f, char *line, int max_len)
{
   int len = 0;
   if (!f || !line || !max_len)
      return len;
   do
   {
      if (!file_read(f, (u8 *)line, 1, NULL))
      {
         *line = '\0';
         break;
      }
      if ((*line == '\r') || (*line == '\n') || (*line == '\0'))
      {
         if (len == 0)                                               // just found the \n after the \r; keep going
            continue;
         *line = '\0';
         break;
      }
      line++;
      len++;
      max_len--;
   }
   while (max_len);
   return len;
}


float uint16_reg_to_float(u8 *buf)
{
   return (float)((s16)(((u16)buf[0]) + (((u16)buf[1]) << 8)));
}


float uint32_reg_to_float(u8 *buf)
{
   u32 temp =  ((u32)buf[0]) +
              (((u32)buf[1]) << 8) +
              (((u32)buf[2]) << 16) +
              (((u32)buf[3]) << 24);
   return *((float *)&temp);
}


void record_error(DI_INSTANCE_T *instance, DI_ERROR_CODE_T error, int line, const char *fn, const char *file)
{
   instance->error.driver_error = error;
   if (error != DE_NONE)
   {
      instance->error.driver_error_aux = (u16)line;
      instance->error.driver_error_func = fn;
      instance->error.driver_error_file = file;
      error_log("%d at %s line %d in %s\n", error, instance->error.driver_error_func, instance->error.driver_error_aux, instance->error.driver_error_file);
   }
   else
   {
      instance->error.driver_error_aux =  0;
      instance->error.driver_error_func = NULL;
   }
}


/** @}*/

