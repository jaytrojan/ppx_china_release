/**
 * \file    driver_core.c
 *
 *
 * \brief  the core of the generic host driver, with entry points to manage all
 *         aspects of detecting, configuring, and transferring data with U718x
 *
 * \copyright (C) 2013-2014 EM Microelectronic
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h> // will need conditionals to offer cross-platform version
#include "config.h"
#include "driver_core.h"
#include "EEPROMImage.h"
#include "driver_util.h"
#include "driver_ext.h"

/** \addtogroup Driver_Core
 *  @{
 */


#define ALLOWED_SLIP_US 5100           /**< permit up to 5ms regression in timestamp due to differing firmware priorities */
#define RAM_BUF_LEN 256                /**< number of bytes to write to U718x RAM at a time; allocated on the stack */
#define EEPROM_BUF_LEN 64              /**< number of bytes to write to EEPROM at a time; allocated on the stack */
#define PARAM_ACK_TIMEOUT_MS 1000      /**< timeout value for acknowledgement from U718x for parameter request; this could be tighter, but will at least stop utter paralysis */
#define EEPROM_ERASE_TIMEOUT_MS 1000   /**< timeout value for writing a byte or page to the EEPROM */
#define EEPROM_WRITE_TIMEOUT_MS 100    /**< timeout value for writing a byte or page to the EEPROM */
#define RUN_TIMEOUT_MS 1000            /**< timeout value for algorithm start */
#define PAUSE_TIMEOUT_MS 1000          /**< timeout value for algorithm pause */
#define QUERY_SENSOR_TIMEOUT_MS 1000   /**< timeout value for querying a sensor */
#define SHUTDOWN_TIMEOUT_MS 2000       /**< timeout value for shutting down */
#define EEPROM_UPLOAD_TIME_MS 4000     /**< maximum expected time to upload an EEPROM, in milliseconds */
#define PASSTHROUGH_TIMEOUT_MS 1000    /**< maximum time to wait to enter passthrough mode */

#define STOP_ON_PAD_BYTE               /**< don't keep parsing after this */
#define DEBUG_EVENTS                   /**< uncomment this to generate a circular buffer of sensor event history for debugging */
//#define RESET_CHIP_BEFORE_UPLOAD  /**< force a reset of U718x before doing an upload to RAM */

static bool timestamp_cur_sample(DI_INSTANCE_T *instance);
void reset_timestamp_checking_for_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor);
void reset_timestamp_checking(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T discard_cmd);

#define DI_PRECHECK(x) ((x) && (x)->initialized) /**< this checks that the handle is valid */
#define DI_PRECHECK_FULL(x) ((x) && (x)->initialized && (x)->detected) /**< this checks that the handle is valid and we've confirmed that U718x is accessible */
#define DI_PREAMBLE(x) if (!DI_PRECHECK(x)) { INSTANCE_ERROR(DE_INVALID_INSTANCE); return FALSE; } /**< combines instance checking with error indication and return from function */
#define DI_PREAMBLE_FULL(x) if (!DI_PRECHECK_FULL(x)) { INSTANCE_ERROR(DE_INVALID_INSTANCE); return FALSE; } /**< combines full instance checking with error indication and return from function */

#if defined(DEBUG_EVENTS)
#define EVENT_COUNT 32                                               /**< maximum amount of history to gather (new events overwrite oldest) */
u8 event_hist[EVENT_COUNT];                                          /**< list of event status register values at each interrupt */
u32 event_time[EVENT_COUNT];                                         /**< system time in milliseconds that this was read */
u8 event_index = 0;                                                  /**< index into history at which the next event will be stored */
#endif


static u8 sensor_data_size[255];                                     /* 255 total possible sensor ids */
#define SENSOR_DATA_SIZE_LEN (sizeof(sensor_data_size) / sizeof(sensor_data_size[0])) ///< number of elements in the sensor_data_size array

t_sensor_int_data_types get_sensor_type(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if ((sensor >= di_wake_sensor_start(instance)) && (sensor <= di_max_sensor_id(instance)))
   {
      sensor -= di_wake_sensor_start(instance);                      // cast wakeup sensors to non wakeup as types are mirrored
   }
   switch (sensor)
   {
      case DST_ACCELEROMETER:
      case DST_GEOMAGNETIC_FIELD:
      case DST_ORIENTATION:
      case DST_GYROSCOPE:
      case DST_GRAVITY:
      case DST_LINEAR_ACCELERATION:
         return E_DI_3AXIS_INT_DATA_T;
      case DST_LIGHT:
      case DST_PROXIMITY:
      case DST_RELATIVE_HUMIDITY:
      case DST_STEP_COUNTER:
      case DST_ACTIVITY:
         return E_DI_USCALAR_INT_DATA_T;
      case DST_PRESSURE:
         return E_DI_LUSCALAR_INT_DATA_T;
      case DST_TEMPERATURE:
      case DST_AMBIENT_TEMPERATURE:
         return E_DI_SCALAR_INT_DATA_T;
      case DST_ROTATION_VECTOR:
      case DST_GAME_ROTATION_VECTOR:
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         return E_DI_QUATERNION_INT_DATA_T;
      case DST_MAGNETIC_FIELD_UNCALIBRATED:
      case DST_GYROSCOPE_UNCALIBRATED:
         return E_DI_3AXIS_UNCAL_INT_DATA_T;
      case DST_SIGNIFICANT_MOTION:
      case DST_STEP_DETECTOR:
      case DST_TILT_DETECTOR:
      case DST_WAKE_GESTURE:
      case DST_GLANCE_GESTURE:
      case DST_PICKUP_GESTURE:
         return E_DI_SINGLETON_INT_DATA_T;
      case DST_HEART_RATE:
         return E_DI_BYTE_INT_DATA_T;
#if !defined(DI_SLIM)
      case DST_DEBUG:
         return E_DI_DEBUG_INT_DATA_T;
      case DST_WAKEUP_TIMESTAMP_LSW:
      case DST_WAKEUP_TIMESTAMP_MSW:
#endif
      case DST_TIMESTAMP_LSW:
      case DST_TIMESTAMP_MSW:
         return E_DI_TIMESTAMP_DATA_T;
#if !defined(DI_SLIM)
      case DST_WAKEUP_META_EVENT:
#endif
      case DST_META_EVENT:
         return E_DI_META_EVENT_INT_DATA_T;
      case DST_RAW_DEBUG_OUTPUT_GYRO:
      case DST_RAW_DEBUG_OUTPUT_MAG:
      case DST_RAW_DEBUG_OUTPUT_ACCEL:
         if (instance->alg_id == AID_SPACE_POINT)
            return E_DI_3AXIS_RAW_FL_DATA_T;
         return E_DI_3AXIS_RAW_INT_DATA_T;
      default:
         return E_DI_UNKNOWN;
   }
}

/**
 * \brief determine the number of bytes for the specified
 *        sensor, including ID and timestamp
 * \param sensor - the sensor ID to check
 * \return int - the number of bytes or 0 if not valid
 */
int get_sensor_data_size(DI_SENSOR_TYPE_T sensor)
{
   if ((sensor <= 0) || (sensor >= SENSOR_DATA_SIZE_LEN))
      return 0;
   else
      return sensor_data_size[sensor];
}

/**
 * \brief determine the number of bytes for the specified
 *        sensor, including ID and timestamp
 * \param sensor - the sensor ID to set
 * \param size - the number of bytes in a packet.
 * \return bool - the sensor was updated
 */
bool set_sensor_data_size(DI_SENSOR_TYPE_T sensor, int size)
{
   if ((sensor <= 0) || (sensor >= SENSOR_DATA_SIZE_LEN))
      return FALSE;


   sensor_data_size[sensor] = (u8)size;                              // todo: clean this up -- never will use a full int for the size, 8 bits is enough
   return TRUE;
}

/**
 * \brief determine the number of bytes that get transferred
 *        over the interface for a specified sensor, including
 *        the ID itself
 * \param sensor - the sensor to check
 * \return int - the number of bytes, or 0 if not valid
 */
int get_sensor_data_wire_size(DI_SENSOR_TYPE_T sensor)
{
   int len = get_sensor_data_size(sensor);
   if (len)
   {
      // the timestamp pseudo-sensors are themselves the source of the timestamp; they do not include a timestamp field
      if (
          (sensor != DST_TIMESTAMP_LSW) &&
          (sensor != DST_TIMESTAMP_MSW) &&
#if !defined(DI_SLIM)
          (sensor != DST_WAKEUP_TIMESTAMP_LSW) &&                    // future Android L product
          (sensor != DST_WAKEUP_TIMESTAMP_MSW) &&                    // future Android L product
#endif
          (sensor != DST_RAW_DEBUG_OUTPUT_ACCEL) &&
          (sensor != DST_RAW_DEBUG_OUTPUT_MAG) &&
          (sensor != DST_RAW_DEBUG_OUTPUT_GYRO)
         )
         len -= sizeof(u32);                                         // all other sensors include a timestamp derived from the most recent timestamp pseudo-sensors; don't include this timestamp in the wire size
   }
   return len;
}


bool di_init_core(DI_INSTANCE_T *instance, u8 *sensor_buf, u32 sensor_buf_size, I2C_HANDLE_T i2c_handle, IRQ_HANDLE_T irq_handle, bool reset)
{
   uint16_t max_size;
   if (!i2c_handle || !irq_handle)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      goto error_exit;
   }
   max_size = i2c_get_max_read_length(i2c_handle); // ask driver what max size it supports


   instance->sensor_buf = sensor_buf;
   instance->sensor_buf_size = sensor_buf_size;
   instance->sensor_buf_max_xfer_size = max_size > sensor_buf_size ? sensor_buf_size : max_size; // use max supported by buffer and i2c size.
   instance->sensor_buf_valid_data_size = 0;
   instance->sensor_buf_idx = 0;
   instance->i2c_handle = i2c_handle;
   instance->irq_handle = irq_handle;
   instance->state = DS_POLL_HOST_IRQ;
   instance->initialized = TRUE;


#if !defined(DI_SLIM)
   set_sensor_data_size(DST_DEBUG,                  sizeof(DI_DEBUG_INT_DATA_T));
   set_sensor_data_size(DST_WAKEUP_TIMESTAMP_LSW,   sizeof(DI_TIMESTAMP_DATA_T));
   set_sensor_data_size(DST_WAKEUP_TIMESTAMP_MSW,   sizeof(DI_TIMESTAMP_DATA_T));
   set_sensor_data_size(DST_WAKEUP_META_EVENT,      sizeof(DI_META_EVENT_INT_DATA_T));
#endif
   set_sensor_data_size(DST_RAW_DEBUG_OUTPUT_GYRO,  sizeof(DI_3AXIS_RAW_INT_DATA_T));
   set_sensor_data_size(DST_RAW_DEBUG_OUTPUT_MAG,   sizeof(DI_3AXIS_RAW_INT_DATA_T));
   set_sensor_data_size(DST_RAW_DEBUG_OUTPUT_ACCEL, sizeof(DI_3AXIS_RAW_INT_DATA_T));
   set_sensor_data_size(DST_TIMESTAMP_LSW,          sizeof(DI_TIMESTAMP_DATA_T));
   set_sensor_data_size(DST_TIMESTAMP_MSW,          sizeof(DI_TIMESTAMP_DATA_T));
   set_sensor_data_size(DST_META_EVENT,             sizeof(DI_META_EVENT_INT_DATA_T));


   INSTANCE_ERROR(DE_NONE);
   if (reset)
   {
      info_log("Reset em718x...\n");
      if (!di_reset_chip(instance, TRUE))
         goto error_exit;
   }
   else
   {
      if (!di_detect_chip(instance, NULL, NULL, NULL, NULL, NULL))
         goto error_exit;
      if (!read_chip_error_registers(instance))
         goto error_exit;
   }
   return TRUE;

   error_exit:
   return FALSE;
}


bool di_deinit_core(DI_INSTANCE_T *instance)
{
   if (!DI_PRECHECK(instance))
      return FALSE;

   // stop U718x
   //di_shutdown_request(instance);

   // release resources
   if (instance->i2c_handle)
   {
      i2c_deregister(instance->i2c_handle);
      instance->i2c_handle = NULL;
   }
   if (instance->irq_handle)
   {
      irq_deregister(instance->irq_handle);
      instance->irq_handle = NULL;
   }
   instance->initialized = FALSE;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}

void reset_internal_stats(DI_INSTANCE_T *instance)
{
   int i;
   memset(&instance->meta, 0, sizeof(instance->meta));
#if !defined(DI_SLIM)
   memset(&instance->meta_wakeup, 0, sizeof(instance->meta_wakeup)); // future Android L product
#endif
   instance->meta_valid = FALSE;
   if (instance->sensor_buf)
      memset(instance->sensor_buf, 0, instance->sensor_buf_size);
   instance->fifo_bytes_remaining = 0;
   instance->fifo_bytes_so_far = 0;
   instance->total_bytes_transferred = 0;
   instance->total_samples_received = 0;
   instance->total_invalid_samples_received = 0;
   instance->total_pad_bytes_received = 0;
   instance->total_timeslips = 0;
   instance->total_timegaps = 0;
   instance->sensor_bytes_read = 0;
   memset(&instance->cur_sample, 0, sizeof(instance->cur_sample));
   instance->cur_sample_len = 0;
   instance->cur_sample_idx = 0;
   instance->cur_timestamp[0] = 0;
   instance->cur_timestamp[1] = 0;
   memset(instance->meta_events, 0, sizeof(instance->meta_events));
#if !defined(DI_SLIM)
   memset(instance->meta_events_wakeup, 0, sizeof(instance->meta_events_wakeup)); // future Android L product
#endif
   memset(instance->other_events, 0, sizeof(instance->other_events));
   instance->num_sensors = 0;
   memset(instance->sensor_info, 0, sizeof(instance->sensor_info));
   for (i = DST_FIRST; i < sizeof(instance->sensor_info) / sizeof(instance->sensor_info[0]); i++)
   {
      reset_timestamp_checking_for_sensor(instance, i);
   }
   memset(instance->sensor_info_raw, 0, sizeof(instance->sensor_info_raw));
   memset(&instance->last_sample, 0, sizeof(instance->last_sample));
#if !defined(DI_SLIM)
   memset(&instance->last_sample_w, 0, sizeof(instance->last_sample_w));
#endif
   memset(&instance->error, 0, sizeof(instance->error));
   instance->sensor_len = 0;
   instance->sensor_rlen = 0;
   timestamp_cur_sample(NULL);
}


bool di_detect_chip(DI_INSTANCE_T *instance, u8 *product_id, u8 *revision_id, u16 *rom_version, u16 *ram_version, bool *eeprom_present)
{
   u8 buf[2];
   u8 version[4];

   DI_PREAMBLE(instance);

   // read informational registers that are present even without uploaded RAM
   if (!i2c_blocking_read(instance->i2c_handle, SR_PRODUCT_ID, buf, 2))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   instance->product_id = buf[0];
   instance->revision_id = buf[1];
   if (!i2c_blocking_read(instance->i2c_handle, SR_ROM_VERSION, version, 4))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   instance->rom_version = ((u16)version[0]) | (((u16)version[1]) << 8);
   instance->ram_version = ((u16)version[2]) | (((u16)version[3]) << 8);

   if (!i2c_blocking_read(instance->i2c_handle, SR_CHIP_STATUS, &instance->error.chip_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   // this bit is clear in U718x Status if the firmware is executing
   instance->executing = !instance->error.chip_status.bits.FirmwareHalted;

   if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
   {
      // Ensure we don't lose the AP suspend bit.
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }


   // Update hardware versions for FPGA....
   if (instance->rom_version == ROM_VER_REG_7181_DI02)
   {
      instance->product_id = 0x81;
      instance->revision_id = 0x02;
   }
   else if (instance->rom_version == ROM_VER_REG_7181_DI03)
   {
      instance->product_id = 0x81;
      instance->revision_id = 0x03;
   }
   else if (instance->rom_version == ROM_VER_REG_7183_DI01)
   {
      instance->product_id = 0x83;
      instance->revision_id = 0x01;
   }
   else if (instance->rom_version == ROM_VER_REG_7184_DI01)
   {
      instance->product_id = 0x84;
      instance->revision_id = 0x01;
   }

   // return register values that the caller cares about
   if (product_id)
      *product_id = instance->product_id;
   if (revision_id)
      *revision_id = instance->revision_id;
   if (rom_version)
      *rom_version = instance->rom_version;
   if (ram_version)
      *ram_version = instance->ram_version;
   if (eeprom_present)
      *eeprom_present = instance->error.chip_status.bits.EEUploadDone;

   instance->detected = TRUE;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool eeprom_check_header(EEPROMHeader *header, u16 file_size)
{
   if (!header)                                                      // need a pointer
      return FALSE;
   if (header->magic != EEPROM_MAGIC_VALUE)                          // check the magic number
      return FALSE;
   if (!file_size)                                                   // host service could not determine, so skip this check
      return TRUE;
   if ((sizeof(EEPROMHeader) + header->text_length) > file_size)     // sanity check the lengths
      return FALSE;
   return TRUE;
}


bool di_upload_firmware_start(DI_INSTANCE_T *instance, EEPROMHeader *header)
{
   RegChipControl host;
   u8 buf[2];

   DI_PREAMBLE_FULL(instance);
   reset_internal_stats(instance);

   // check the file header
   info_log("check the header...\n");
   if (!eeprom_check_header(header, 0))
   {
      INSTANCE_ERROR(DE_INVALID_FILE_HEADER);
      return FALSE;
   }

   info_log("header: EEPROMNoExec: %u, I2CClockSpeed: %u, ROMVerExp: %u, ImageLength: %u\n",
            header->flags.bits.EEPROMNoExec, header->flags.bits.I2CClockSpeed, header->flags.bits.ROMVerExp, header->text_length);

   // check whether the file is appropriate for this U718x's ROM
   if (header->flags.bits.ROMVerExp != ROM_VERSION_ANY)              // does it matter what ROM the U718x has?
   {
      if (instance->product_id == PRODUCT_ID_7180)
      {
         if (header->flags.bits.ROMVerExp == ROM_VERSION_DI01)
         {
            if (!((instance->rom_version == ROM_VER_REG_7180_DI01) || (instance->rom_version == ROM_VER_REG_7181_DI01) || (instance->rom_version == ROM_VER_REG_7184_DI01)))
            {
               INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
               return FALSE;
            }
         }
         else if (header->flags.bits.ROMVerExp == ROM_VERSION_DI02)
         {
            if (!((instance->rom_version == ROM_VER_REG_7180_DI02) || (instance->rom_version == ROM_VER_REG_7181_DI02)))
            {
               INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
               return FALSE;
            }
         }
      }
      else if (instance->product_id == PRODUCT_ID_7181)
      {
         if (((header->flags.bits.ROMVerExp == ROM_VERSION_DI01) && (instance->rom_version != ROM_VER_REG_7181_DI01)) ||
             ((header->flags.bits.ROMVerExp == ROM_VERSION_DI02) && (instance->rom_version != ROM_VER_REG_7181_DI02)))
         //((header->flags.bits.ROMVerExp == ROM_VERSION_DI03) && (instance->rom_version != ROM_VER_REG_7181_DI03)))
         {
            INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
            return FALSE;
         }
      }
      else if (instance->product_id == PRODUCT_ID_7183)
      {
         if (((header->flags.bits.ROMVerExp == ROM_VERSION_DI01) && (instance->rom_version != ROM_VER_REG_7183_DI01))) /*||*/
         //((header->flags.bits.ROMVerExp == ROM_VERSION_DI02) && (instance->rom_version != ROM_VER_REG_7183_DI02)))
         {
            INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
            return FALSE;
         }
      }
      else if (instance->product_id == PRODUCT_ID_7184)
      {
         if (((header->flags.bits.ROMVerExp == ROM_VERSION_DI01) && (instance->rom_version != ROM_VER_REG_7184_DI01))) /*||*/
         //((header->flags.bits.ROMVerExp == ROM_VERSION_DI02) && (instance->rom_version != ROM_VER_REG_7184_DI02)))
         {
            INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
            return FALSE;
         }
      }
   }

#if defined(RESET_CHIP_BEFORE_UPLOAD)
   info_log("reset U718x...\n");
   // reset
   if (!di_reset_chip(instance, TRUE))
      return FALSE;
#endif

   info_log("set upload address to 0...\n");
   // start upload at address 0
   buf[0] = buf[1] = 0;
   if (!i2c_blocking_write(instance->i2c_handle, SR_UPLOAD_ADDR_H, buf, 2))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   info_log("request upload mode...\n");
   // go into upload mode
   host.reg = 0;
   host.bits.HostUpload = 1;
   if (!i2c_blocking_write(instance->i2c_handle, SR_CHIP_CONTROL, &host.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   instance->header_crc = header->text_CRC;
   instance->upload_ofs = 0;
   instance->upload_len = (s32)((u32)header->text_length);
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_upload_firmware_data(DI_INSTANCE_T *instance, u32 *words, u16 wlen)
{
   u32 buf[RAM_BUF_LEN / 4];
   u32 temp;
   u16 eewlen;
   int i;
   u16 maxw = i2c_get_max_write_length(instance->i2c_handle) / 4;

   DI_PREAMBLE_FULL(instance);

   // upload all the text section data from the file
#if !defined(__KERNEL__)
#if !defined(DI_SLIM)
   if (!instance->quiet_loading)
      printf("load data ofs %u...\r", instance->upload_ofs);
#endif
#endif
   while ((instance->upload_len > 0) && wlen)
   {
      if (wlen > RAM_BUF_LEN / 4)                                    // limit writes to the buffer size
         eewlen = RAM_BUF_LEN / 4;
      else
         eewlen = wlen;
      if (eewlen > maxw)                                             // also limit to transport max size
         eewlen = maxw;

      for (i = 0; i < eewlen; i++)
      {
         temp = *(words++);
         buf[i] = swab32(temp);                                      // the bytes are stored in little endian order in the .fw image, but need to be uploaded in big endian order
      }

      if (!i2c_blocking_write(instance->i2c_handle, SR_UPLOAD_DATA, (u8 *)buf, eewlen * 4))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      instance->upload_ofs += eewlen * 4;
      instance->upload_len -= (s32)((u32)eewlen * 4);
      wlen -= eewlen;
   }
   if (wlen)                                                         // they gave us extra
   {
      INSTANCE_ERROR(DE_INVALID_FILE_LENGTH);
      return FALSE;
   }

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}

bool di_upload_firmware_finish(DI_INSTANCE_T *instance)
{
   RegChipControl host;
   u32 our_crc;

   DI_PREAMBLE_FULL(instance);

   if (!i2c_blocking_read(instance->i2c_handle, SR_CRC_HOST, (u8 *)&our_crc, sizeof(our_crc)))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   info_log("calculated CRC: 0x%08X, original CRC: 0x%08X\n", our_crc, instance->header_crc);

   // end upload mode
   host.reg = 0;
   host.bits.HostUpload = 0;
   if (!i2c_blocking_write(instance->i2c_handle, SR_CHIP_CONTROL, &host.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   irq_check(instance->irq_handle);

   // check results
   if (instance->upload_len != 0)
   {
      INSTANCE_ERROR(DE_INVALID_FILE_LENGTH);
      return FALSE;
   }
   if (our_crc != instance->header_crc)
   {
      INSTANCE_ERROR(DE_INVALID_CRC);
      return FALSE;
   }
   info_log("upload complete\n");
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_upload_eeprom_start(DI_INSTANCE_T *instance, I2C_HANDLE_T eeprom_handle, EEPROMHeader *header)
{
   u8 buf[EEPROM_BUF_LEN + 2];                                       // add two more bytes for the EEPROM address
   u16 eeprom_addr;
   u8 *src;
   u8 *dst;
   int i;
   u32 start;
   u16 eelen;
   u16 len;
   u16 maxb = i2c_get_max_write_length(instance->i2c_handle);

   DI_PREAMBLE_FULL(instance);
   reset_internal_stats(instance);

   // check the file header
   info_log("check the header...\n");
   if (!eeprom_check_header(header, 0))
   {
      INSTANCE_ERROR(DE_INVALID_FILE_HEADER);
      return FALSE;
   }

   info_log("header: EEPROMNoExec: %u, I2CClockSpeed: %u, ROMVerExp: %u, ImageLength: %u\n",
            header->flags.bits.EEPROMNoExec, header->flags.bits.I2CClockSpeed, header->flags.bits.ROMVerExp, header->text_length);

   // check whether the file is appropriate for this U718x's ROM
   if (header->flags.bits.ROMVerExp != ROM_VERSION_ANY)              // does it matter what ROM the U718x has?
   {
      if (instance->product_id == PRODUCT_ID_7180)
      {
         if (header->flags.bits.ROMVerExp == ROM_VERSION_DI01)
         {
            if (!((instance->rom_version == ROM_VER_REG_7180_DI01) || (instance->rom_version == ROM_VER_REG_7181_DI01) || (instance->rom_version == ROM_VER_REG_7184_DI01)))
            {
               INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
               return FALSE;
            }
         }
         else if (header->flags.bits.ROMVerExp == ROM_VERSION_DI02)
         {
            if (!((instance->rom_version == ROM_VER_REG_7180_DI02) || (instance->rom_version == ROM_VER_REG_7181_DI02)))
            {
               INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
               return FALSE;
            }
         }
      }
      else if (instance->product_id == PRODUCT_ID_7181)
      {
         if (((header->flags.bits.ROMVerExp == ROM_VERSION_DI01) && (instance->rom_version != ROM_VER_REG_7181_DI01)) ||
             ((header->flags.bits.ROMVerExp == ROM_VERSION_DI02) && (instance->rom_version != ROM_VER_REG_7181_DI02)))
         //((header->flags.bits.ROMVerExp == ROM_VERSION_DI03) && (instance->rom_version != ROM_VER_REG_7181_DI03)))
         {
            INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
            return FALSE;
         }
      }
      else if (instance->product_id == PRODUCT_ID_7183)
      {
         if (((header->flags.bits.ROMVerExp == ROM_VERSION_DI01) && (instance->rom_version != ROM_VER_REG_7183_DI01))) /*||*/
         //((header->flags.bits.ROMVerExp == ROM_VERSION_DI02) && (instance->rom_version != ROM_VER_REG_7183_DI02)))
         {
            INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
            return FALSE;
         }
      }
      else if (instance->product_id == PRODUCT_ID_7184)
      {
         if (((header->flags.bits.ROMVerExp == ROM_VERSION_DI01) && (instance->rom_version != ROM_VER_REG_7184_DI01))) /*||*/
         //((header->flags.bits.ROMVerExp == ROM_VERSION_DI02) && (instance->rom_version != ROM_VER_REG_7184_DI02)))
         {
            INSTANCE_ERROR(DE_INCORRECT_ROM_VERSION);
            return FALSE;
         }
      }
   }

#if defined(RESET_CHIP_BEFORE_UPLOAD)
   info_log("reset U718x...\n");
   // reset
   if (!di_reset_chip(instance, TRUE))
      return FALSE;
#endif
   info_log("shut down processor...\n");
   if (!di_shutdown_request(instance))
	   return FALSE;

   info_log("enter passthrough mode...\n");
   // go into passthrough mode
   if (!di_set_passthrough_mode(instance, TRUE))
      return FALSE;

   // write the header to address 0
   info_log("write EEPROM header...\n");

   len = sizeof(EEPROMHeader);
   eeprom_addr = 0;
   src = (u8 *)header;

   while (len)
   {
      buf[0] = (eeprom_addr >> 8) & 0x0ff;
      buf[1] = eeprom_addr & 0x0ff;
      if (len > EEPROM_BUF_LEN)                                      // limit to EEPROM page size
         eelen = EEPROM_BUF_LEN;
      else
         eelen = len;
      if (eelen > maxb)                                              // limit to maximum transport size, so we can rewrite the EEPROM address at the start of each transfer
         eelen = maxb;
      dst = &buf[2];
      for (i = 0; i < eelen; i++)
         *(dst++) = *(src++);
      if (!i2c_blocking_write(eeprom_handle, buf[0], &buf[1], eelen + 1))
     {
         error_log("i2c write failure\n");
         INSTANCE_ERROR(DE_I2C_PASSTHRU_ERROR);
         return FALSE;
      }

      // wait for page to finish
      start = time_ms();
      while (!i2c_blocking_write(eeprom_handle, 0, NULL, 0))
      {
         time_delay_ms(1);
         if (time_ms() > (start + EEPROM_WRITE_TIMEOUT_MS))
         {
            error_log("timeout waiting for EEPROM page write complete\n");
            INSTANCE_ERROR(DE_I2C_PASSTHRU_ERROR);
            return FALSE;
         }
      }
      eeprom_addr += eelen;
      len -= eelen;
   }
   info_log("header done.\n");
   // after the header, upload all the text section data from the file
   instance->upload_len = (s32)((u32)header->text_length);
   instance->upload_ofs = sizeof(EEPROMHeader);

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}

bool di_upload_eeprom_data(DI_INSTANCE_T *instance, I2C_HANDLE_T eeprom_handle, u32 *words, u16 wlen)
{
   u16 eelen;
   u8 buf[EEPROM_BUF_LEN + 2];                                       // add two more bytes for the EEPROM address
   u32 start;
   u16 maxb = i2c_get_max_write_length(instance->i2c_handle);

   DI_PREAMBLE(instance);

#if !defined(__KERNEL__)
#if !defined(DI_SLIM)
   if (!instance->quiet_loading)
      printf("load data ofs %u...\r", instance->upload_ofs);
#endif
#endif
   while ((instance->upload_len > 0) && wlen)
   {
      buf[0] = ((instance->upload_ofs) >> 8) & 0x0ff;
      buf[1] = (instance->upload_ofs) & 0x0ff;
      if (wlen * 4 > EEPROM_BUF_LEN)                                 // limit to EEPROM page size
         eelen = EEPROM_BUF_LEN;
      else
         eelen = wlen * 4;
      if (eelen > maxb)                                              // also limit to transport size
         eelen = maxb;
      memcpy(&buf[2], words, eelen);
      if (!i2c_blocking_write(eeprom_handle, buf[0], &buf[1], eelen + 1))
      {
         error_log("I2C write to EEPROM failed\n");
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      // wait for page to finish
      //info_log("wait for block written...\n");
      //time_delay_ms(1);
      start = time_ms();
      while (!i2c_blocking_write(eeprom_handle, 0, NULL, 0))
      {
         time_delay_ms(1);
         if (time_ms() > (start + EEPROM_WRITE_TIMEOUT_MS))
         {
            error_log("timeout waiting for EEPROM page write complete\n");
            INSTANCE_ERROR(DE_I2C_ERROR);
            return FALSE;
         }
      }
      instance->upload_ofs += eelen;
      instance->upload_len -= (s32)((u32)eelen);
      wlen -= eelen / 4;
   }
   if (wlen)                                                         // they gave us extra
   {
      error_log("remainder %u\n", wlen);
      INSTANCE_ERROR(DE_INVALID_FILE_LENGTH);
      return FALSE;
   }

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}

bool di_upload_eeprom_finish(DI_INSTANCE_T *instance)
{
   if (!DI_PRECHECK_FULL(instance))
   {
      INSTANCE_ERROR(DE_INVALID_INSTANCE);
      return FALSE;
   }

   // leave passthrough mode
   irq_check(instance->irq_handle);
   if (!di_set_passthrough_mode(instance, FALSE))
      return FALSE;

   irq_check(instance->irq_handle);
   info_log("finished uploading...\nresetting U718x...\n");
   // reset
   if (!di_reset_chip(instance, TRUE))
      return FALSE;

   // check results
   if (instance->upload_len != 0)
   {
      INSTANCE_ERROR(DE_INVALID_FILE_LENGTH);
      return FALSE;
   }
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_erase_eeprom(DI_INSTANCE_T *instance, I2C_HANDLE_T eeprom_handle)
{
   u8 buf[sizeof(EEPROMHeader) + 2];                                 // add two more bytes for the EEPROM address
   u16 eeprom_addr;
   u32 start;

   DI_PREAMBLE_FULL(instance);

   info_log("reset U718x...\n");
   // reset
#if defined(RESET_CHIP_BEFORE_UPLOAD)
   di_reset_chip(instance, TRUE);                                    // if this fails, it's ok -- we might have a bad upload
#endif

   info_log("shut down processor...\n");
   if (!di_shutdown_request(instance))
	   return FALSE;

   info_log("enter passthrough mode...\n");
   // go into passthrough mode
   if (!di_set_passthrough_mode(instance, TRUE))
      return FALSE;

   // write the header to address 0
   info_log("write invalid EEPROM header...\n");
   memset(buf, 0, sizeof(buf));
   eeprom_addr = 0;
   buf[0] = (eeprom_addr >> 8) & 0x0ff;
   buf[1] = eeprom_addr & 0x0ff;
   if (!i2c_blocking_write(eeprom_handle, buf[0], &buf[1], sizeof(EEPROMHeader) + 1))
   {
      error_log("I2C write failed\n");
      INSTANCE_ERROR(DE_I2C_PASSTHRU_ERROR);
      return FALSE;
   }
   // wait for page to finish
   start = time_ms();
   while (!i2c_blocking_write(eeprom_handle, 0, NULL, 0))
   {
      time_delay_ms(1);
      if (time_ms() > (start + EEPROM_ERASE_TIMEOUT_MS))
      {
         error_log("timeout waiting for erase complete\n");
         INSTANCE_ERROR(DE_I2C_PASSTHRU_ERROR);
         return FALSE;
      }
   }

   // leave passthrough mode
   if (!di_set_passthrough_mode(instance, FALSE))
      return FALSE;

   info_log("finished erasing EEPROM...\nresetting U718x...\n");
   // reset
   if (!di_reset_chip(instance, TRUE))
      return FALSE;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_query_features(DI_INSTANCE_T *instance)
{
   DI_SENSOR_TYPE_T sensor;
   SENSOR_CONFIG config;


   // clear present flag for all sensors
   for (sensor = DST_FIRST; sensor <= di_max_sensor_id(instance); sensor++)
      instance->sensor_info[sensor].present = FALSE;
   instance->num_sensors = 0;

   if (!di_query_sensor_status(instance))
      return FALSE;

   for (sensor = DST_FIRST; sensor <= di_max_sensor_id(instance); sensor++)
   {
      instance->sensor_info[sensor].present = (instance->sensor_info[sensor].status.power_mode != SensorNotPresent);
      if (instance->sensor_info[sensor].present)
      {
         instance->num_sensors++;
         di_query_sensor_config(instance, sensor, &config);
      }
   }
#if !defined(DI_SLIM)
   if (di_get_algorithm_id(instance) == AID_BSX)
   {
      if (instance->hi_id != HIID_KITKAT)
      {
         instance->sensor_info_raw[0].present = TRUE;
         instance->sensor_info_raw[1].present = TRUE;
         instance->sensor_info_raw[2].present = TRUE;
      }
      else
      {
         if (di_query_sensor_config(instance, DST_RAW_DEBUG_OUTPUT_ACCEL, &config))
         {
            instance->sensor_info_raw[2].present = TRUE;
         }
         if (di_query_sensor_config(instance, DST_RAW_DEBUG_OUTPUT_MAG, &config))
         {
            instance->sensor_info_raw[1].present = TRUE;
         }
         if (di_query_sensor_config(instance, DST_RAW_DEBUG_OUTPUT_GYRO, &config))
         {
            instance->sensor_info_raw[0].present = TRUE;
         }
      }
   }
   else
   {
      instance->sensor_info_raw[0].present = FALSE;
      instance->sensor_info_raw[1].present = FALSE;
      instance->sensor_info_raw[2].present = FALSE;
   }
#else
   instance->sensor_info_raw[0].present = FALSE;
#endif
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_has_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   DI_PREAMBLE(instance);

   if ((sensor >= DST_FIRST) && (sensor <= di_max_sensor_id(instance)))
   {
      return instance->sensor_info[sensor].present;
   }
   else
   {
      if ((sensor != DST_RAW_DEBUG_OUTPUT_ACCEL) && (sensor != DST_RAW_DEBUG_OUTPUT_MAG) && (sensor != DST_RAW_DEBUG_OUTPUT_GYRO))
      {
         INSTANCE_ERROR(DE_UNKNOWN_SENSOR);
         return FALSE;
      }
      return instance->sensor_info_raw[sensor - DST_RAW_DEBUG_OUTPUT_GYRO].present;
   }
}

bool is_wakeup_event(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if ((sensor == DST_TIMESTAMP_LSW) || (sensor == DST_TIMESTAMP_MSW) || (sensor == DST_META_EVENT) || (sensor < di_wake_sensor_start(instance)))
      return FALSE;
   else
      return TRUE;
}

bool di_is_sensor_on_change(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if ((sensor >= DST_FIRST) && (sensor <= di_max_sensor_id(instance)))
   {
      if (is_wakeup_event(instance, sensor))
         sensor -= di_wake_sensor_start(instance);
      switch (sensor)
      {
         case DST_LIGHT:
         case DST_PROXIMITY:
         case DST_RELATIVE_HUMIDITY:
         case DST_AMBIENT_TEMPERATURE:
         case DST_TEMPERATURE:
         case DST_STEP_COUNTER:
         case DST_STEP_DETECTOR:
         case DST_HEART_RATE:
         case DST_ACTIVITY:
         case DST_TILT_DETECTOR:
            return TRUE;

         default:
            return FALSE;
      }
   }
   return FALSE;
}

bool di_is_sensor_one_shot(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if ((sensor >= DST_FIRST) && (sensor <= di_max_sensor_id(instance)))
   {
      if (is_wakeup_event(instance, sensor))
         sensor -= di_wake_sensor_start(instance);
      switch (sensor)
      {
         case DST_SIGNIFICANT_MOTION:
         case DST_WAKE_GESTURE:
         case DST_PICKUP_GESTURE:
         case DST_GLANCE_GESTURE:
            return TRUE;

         default:
            return FALSE;
      }
   }
   return FALSE;
}

bool di_is_sensor_continuous(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if (!di_is_sensor_on_change(instance, sensor) && !di_is_sensor_one_shot(instance, sensor))
      return TRUE;
   return FALSE;
}

bool di_configure_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, SENSOR_CONFIG *sensor_config)
{
   u8 param;
   u8 page = PP_SENSORS;
   DI_PREAMBLE_FULL(instance);



   if ((sensor < DST_FIRST) || (sensor > di_max_sensor_id(instance)))
   {
      INSTANCE_ERROR(DE_UNKNOWN_SENSOR);
      return FALSE;
   }
   else
   {
      if (instance->hi_id == HIID_KITKAT)
         param = SP_SENSOR_CONFIG_START + sensor - DST_FIRST;
      else if (instance->hi_id == HIID_LOLLIPOP)
         param = SP_SENSOR_CONFIG_START_L + sensor;
      else if (instance->hi_id == HIID_LOLLIPOP_EX)
         param = SP_SENSOR_CONFIG_START_LEX + sensor;
      else
      {
         INSTANCE_ERROR(DE_INVALID_INSTANCE);
         return FALSE;
      }

      if (instance->hi_id == HIID_LOLLIPOP_EX)
         page = PP_SENSOR_CONFIG_LEX;
   }

   if (!sensor_config)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }

   if (!di_load_parameter(instance, page, param, (u8 *)sensor_config, sizeof(SENSOR_CONFIG)))
      return FALSE;

   if (sensor <= di_max_sensor_id(instance))
   {
      if (instance->sensor_info[sensor].rate != sensor_config->sample_rate)
      {
         reset_timestamp_checking_for_sensor(instance, sensor);      // reset time analysis, so when rate is changed, it starts clean
      }
      instance->sensor_info[sensor].rate = sensor_config->sample_rate;
   }
   INSTANCE_ERROR(DE_NONE);

   return TRUE;
}


bool di_get_last_requested_rate(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, u16 *last_rate)
{
   if (!di_has_sensor(instance, sensor) || !last_rate)
      return FALSE;
   *last_rate = instance->sensor_info[sensor].rate;
   return TRUE;
}

bool di_query_sensor_config(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, SENSOR_CONFIG *sensor_config)
{
   u8 param;
   u8 page = PP_SENSORS;
   float dynamic_range;
   DI_PREAMBLE_FULL(instance);

   if ((sensor < DST_FIRST) || (sensor > di_max_sensor_id(instance)))
   {
      if (instance->hi_id == HIID_KITKAT)
      {
         if ((sensor != DST_RAW_DEBUG_OUTPUT_ACCEL) && (sensor != DST_RAW_DEBUG_OUTPUT_MAG) && (sensor != DST_RAW_DEBUG_OUTPUT_GYRO))
         {
            INSTANCE_ERROR(DE_UNKNOWN_SENSOR);
            return FALSE;
         }
         else
         {
            param = 125 + sensor - DST_RAW_DEBUG_OUTPUT_GYRO;
         }
      }
      else
      {
         INSTANCE_ERROR(DE_UNKNOWN_SENSOR);
         return FALSE;
      }
   }
   else
   {
      if (instance->hi_id == HIID_KITKAT)
         param = SP_SENSOR_CONFIG_START + sensor - DST_FIRST;
      else if (instance->hi_id == HIID_LOLLIPOP)
         param = SP_SENSOR_CONFIG_START_L + sensor;
      else if (instance->hi_id == HIID_LOLLIPOP_EX)
         param = SP_SENSOR_CONFIG_START_LEX + sensor;
      else
      {
         INSTANCE_ERROR(DE_INVALID_INSTANCE);
         return FALSE;
      }

      if (instance->hi_id == HIID_LOLLIPOP_EX)
         page = PP_SENSOR_CONFIG_LEX;
   }

   if (!sensor_config)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }

   if (!di_save_parameter(instance, (ParameterPage)page, param, (u8 *)sensor_config, sizeof(SENSOR_CONFIG)))
      return FALSE;

   if (sensor <= di_max_sensor_id(instance))
   {
      instance->sensor_info[sensor].actual_rate = sensor_config->sample_rate;
      dynamic_range = sensor_config->dynamic_range;
      instance->sensor_info[sensor].scale_factor = dynamic_range / 32767.0F;
   }
   INSTANCE_ERROR(DE_NONE);

   return TRUE;
}

u8 di_max_sensor_id(DI_INSTANCE_T *instance)
{
   // Determin maximum number of valid parameters
   if (instance->hi_id == HIID_KITKAT)
      return 31;                                                     // Maximum 32 visible sensors;
   if (instance->hi_id == HIID_LOLLIPOP)
      return 63;                                                     // Maximum 64 visible sensors;
   if (instance->hi_id == HIID_LOLLIPOP_EX)
      return 127;                                                    // Maximum 128 visible sensors;

   INSTANCE_ERROR(DE_DETECTION_REQUIRED);
   return 0;
}

u8 di_wake_sensor_start(DI_INSTANCE_T *instance)
{
   // Determin maximum number of valid parameters
   if (instance->hi_id == HIID_KITKAT)
      return 255;                                                    // no wake sensors
   if (instance->hi_id == HIID_LOLLIPOP)
      return 32;                                                     // First half is non-wake;
   if (instance->hi_id == HIID_LOLLIPOP_EX)
      return 64;                                                     // First half is non-wake;

   INSTANCE_ERROR(DE_DETECTION_REQUIRED);
   return 0;
}


bool di_query_sensor_info(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, SENSOR_INFORMATION *sensor_info)
{
   u8 param;
   u8 max_param;
   DI_PREAMBLE_FULL(instance);

   // Determin maximum number of valid parameters
   max_param = di_max_sensor_id(instance);

   // Determine actual parameter
   if (instance->hi_id != HIID_KITKAT)
      param = SP_SENSOR_INFO_START + sensor - DST_FIRST;
   else
      param = sensor;


   if ((sensor < DST_FIRST) || (sensor > max_param))
   {
      info_log("Unknown id %d\n", sensor);
      INSTANCE_ERROR(DE_UNKNOWN_SENSOR);
      return FALSE;
   }

   if (!sensor_info)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }

   if (!di_save_parameter(instance, PP_SENSORS, param, (u8 *)sensor_info, sizeof(SENSOR_INFORMATION)))
      return FALSE;

   if (sensor_info->sensor_type == 0)                                // type will be zero if this sensor is not supported
   {
      instance->sensor_info[sensor].present = FALSE;
   }
   else if (sensor_info->sensor_type != sensor)                      // it should equal this
   {
      INSTANCE_ERROR(DE_INCORRECT_SENSOR);
      return FALSE;
   }
   if ((sizeof(u32) + sensor_info->event_size) != get_sensor_data_size(sensor))
   {
      if (get_sensor_data_size(sensor))
         warn_log("Firmware reported a sensor size of %d, expected %d\n", sizeof(u32) + sensor_info->event_size, get_sensor_data_size(sensor));

      // Update expected sensor size to ensure FIFO is decoded properly.
      set_sensor_data_size(sensor, sensor_info->event_size + sizeof(u32));
   }

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_query_sensor_status(DI_INSTANCE_T *instance)
{
   DI_SENSOR_TYPE_T sensor;
   u8 param_data[PARAM_SAVE_SIZE];
   u8 sensors_per_param = PARAM_SAVE_SIZE;
   u8 start_param = SYSP_SENSOR_STATUS_BANK_0;
   u8 max_sensors;
   u8 num_pages;
   int i;

   DI_PREAMBLE(instance);

   if (!instance->executing)
   {
      INSTANCE_ERROR(DE_EXECUTING_REQUIRED);
      return FALSE;
   }

   max_sensors = di_max_sensor_id(instance) + 1;
   num_pages = ((max_sensors - 1) / sensors_per_param) + 1;

   for (i = start_param; i < start_param + num_pages; i++)
   {
      int start_sensor = DST_FIRST + (i - start_param) * sensors_per_param;
      if (!di_save_parameter(instance, PP_SYSTEM, i, param_data, PARAM_SAVE_SIZE))
         return FALSE;

      for (sensor = start_sensor; sensor < min(start_sensor + sensors_per_param, max_sensors); sensor++)
      {
#if defined(DI_SLIM)
         if (sensor >= DST_NUM_SENSOR_TYPES)
            break;
#endif
         *((u8 *)&instance->sensor_info[sensor].status) = param_data[sensor - start_sensor];
      }
#if defined(DI_SLIM)
      if (sensor >= DST_NUM_SENSOR_TYPES)
         break;
#endif
   }

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_read_sensor_status(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, SENSOR_STATUS *sensor_status)
{
   DI_PREAMBLE_FULL(instance);

   if ((sensor < DST_FIRST) || (sensor > di_max_sensor_id(instance)))
   {
      INSTANCE_ERROR(DE_UNKNOWN_SENSOR);
      return FALSE;
   }

   if (!sensor_status)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }

   *sensor_status = instance->sensor_info[sensor].status;

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_enable_meta_event_ex(DI_INSTANCE_T *instance, DI_META_EVENT_T meta_event, bool enable, bool int_enable, bool wakeup_fifo)
{
   u8 *p;
   int shift;
   u8 param;
   bool *valid;

   DI_PREAMBLE(instance);

   if (!instance->executing)
   {
      INSTANCE_ERROR(DE_EXECUTING_REQUIRED);
      return FALSE;
   }

   if ((meta_event <= DME_NONE) || (meta_event >= DME_NUM_META_EVENTS) || (wakeup_fifo && (instance->hi_id == HIID_KITKAT)))
   {
      INSTANCE_ERROR(DE_PARAM_OUT_OF_RANGE);
      return FALSE;
   }

   param = wakeup_fifo ? SYSP_META_EVENT_CONTROL_WAKEUP_FIFO : SYSP_META_EVENT_CONTROL;
#if !defined(DI_SLIM)
   p = (u8 *)(wakeup_fifo ? &instance->meta_wakeup : &instance->meta);
#else
   p = (u8 *)(&instance->meta);
#endif
   valid = wakeup_fifo ? &instance->meta_wakeup_valid : &instance->meta_valid;
   if (!*valid)
   {
      if (!di_save_parameter(instance, PP_SYSTEM, param, p, sizeof(META_EVENT_CONTROL_PARAM)))
         return FALSE;
      *valid = TRUE;
   }

   p += (meta_event - 1) / 4;                                        // 4 events per byte
   shift = 2 * ((meta_event - 1) % 4);                               // find event number then double for bit position
   *p &= ~((ME_ENABLE | ME_INTERRUPT) << shift);                     // mask off enable and int bits
   if (enable)
      *p |= (ME_ENABLE << shift);
   if (int_enable)
      *p |= (ME_INTERRUPT << shift);

#if !defined(DI_SLIM)
   p = (u8 *)(wakeup_fifo ? &instance->meta_wakeup : &instance->meta);
#else
   p = (u8 *)(&instance->meta);
#endif
   if (!di_load_parameter(instance, PP_SYSTEM, param, p, sizeof(META_EVENT_CONTROL_PARAM)))
      return FALSE;

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}

bool di_enable_meta_event(DI_INSTANCE_T *instance, DI_META_EVENT_T meta_event, bool enable, bool int_enable)
{
   return di_enable_meta_event_ex(instance, meta_event, enable, int_enable, FALSE);
}

bool di_query_meta_event_ex(DI_INSTANCE_T *instance, DI_META_EVENT_T meta_event, bool *enable, bool *int_enable, bool wakeup_fifo)
{
   u8 *p;
   int shift;
   u8 param;
   bool *valid;

   DI_PREAMBLE(instance);

   if (!instance->executing)
   {
      INSTANCE_ERROR(DE_EXECUTING_REQUIRED);
      return FALSE;
   }

   if ((meta_event <= DME_NONE) || (meta_event >= DME_NUM_META_EVENTS) || (wakeup_fifo && (instance->hi_id == HIID_KITKAT)))
   {
      INSTANCE_ERROR(DE_PARAM_OUT_OF_RANGE);
      return FALSE;
   }

#if !defined(DI_SLIM)
   param = wakeup_fifo ? SYSP_META_EVENT_CONTROL_WAKEUP_FIFO : SYSP_META_EVENT_CONTROL;
   p = (u8 *)(wakeup_fifo ? &instance->meta_wakeup : &instance->meta);
   valid = wakeup_fifo ? &instance->meta_wakeup_valid : &instance->meta_valid;
#else
   param = SYSP_META_EVENT_CONTROL;
   p = (u8 *)(&instance->meta);
   valid = &instance->meta_valid;
#endif
   if (!*valid)
   {
      if (!di_save_parameter(instance, PP_SYSTEM, param, p, sizeof(META_EVENT_CONTROL_PARAM)))
         return FALSE;
      *valid = TRUE;
   }

   p += (meta_event - 1) / 4;                                        // 4 events per byte
   shift = 2 * ((meta_event - 1) % 4);                               // find event number then double for bit position

   if (enable)
   {
      if (*p & (ME_ENABLE << shift))
         *enable = TRUE;
      else
         *enable = FALSE;
   }
   if (int_enable)
   {
      if (*p & (ME_INTERRUPT << shift))
         *int_enable = TRUE;
      else
         *int_enable = FALSE;
   }

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}

bool di_query_meta_event(DI_INSTANCE_T *instance, DI_META_EVENT_T meta_event, bool *enable, bool *int_enable)
{
   return di_query_meta_event_ex(instance, meta_event, enable, int_enable, FALSE);
}

// save == read
bool di_save_parameter(DI_INSTANCE_T *instance, ParameterPage page, u8 param_number, u8 *param_buf, u8 param_len)
{
   u8 param;
   u32 start_tick;
   RegParameterPageSel sel;
   bool ret = TRUE;
   u32 orig_start_time;
   u32 start_time;
   u32 delta_time;

   DI_PREAMBLE_FULL(instance);

   if (!instance->ram_version)
   {
      INSTANCE_ERROR(DE_INITIALIZATION_REQUIRED);
      return FALSE;
   }

   if (!param_number || !param_buf || !param_len || (param_len > PARAM_SAVE_SIZE))
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }
   if (param_number > MAX_PARAM_NUMBER)
   {
      INSTANCE_ERROR(DE_PARAM_OUT_OF_RANGE);
      return FALSE;
   }
   INSTANCE_ERROR(DE_NONE);

   //< TODO: this is backwards -- the firmware is wrong (pagesel written before param request)
   // write the parameter page (this starts the parameter procedure)
   sel.bits.ParameterPage = page;
   sel.bits.ParameterSize = param_len;
   orig_start_time = start_time = time_us();
   if (!i2c_blocking_write(instance->i2c_handle, SR_PARAMETER_PAGE_SEL, &sel.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   delta_time = time_us() - start_time;
   debug_log("page_sel write: %u us at %u us\n", delta_time, start_time);

   // write the parameter number
   start_time = time_us();
   if (!i2c_blocking_write(instance->i2c_handle, SR_PARAMETER_REQUEST, &param_number, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   delta_time = time_us() - start_time;
   debug_log("param req write: %u us at %u us\n", delta_time, start_time);

   // wait for acknowledge from U718x
   start_tick = time_ms();
   for (;;)
   {
      start_time = time_us();
      if (!i2c_blocking_read(instance->i2c_handle, SR_PARAMETER_ACKNOWLEDGE, &param, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      delta_time = time_us() - start_time;
      debug_log("param_ack read: %u us at %u us\n", delta_time, start_time);
      // it matches... we can move on
      if (param == param_number)
      {
         debug_log("param_ack time: %u ms at %u ms\n", time_ms() - start_tick, start_tick);
         break;
      }

      // check for error
      if (param == 0x80)
      {
         INSTANCE_ERROR(DE_PARAM_OUT_OF_RANGE);
         info_log("parameter error 0x80 returned from u718x on page %u, parameter %u, len %u\n", page, param_number, param_len);
         ret = FALSE;
         break;
      }
      // check for timeout
      if ((time_ms() - start_tick) > PARAM_ACK_TIMEOUT_MS)
      {
         INSTANCE_ERROR(DE_PARAM_ACK_TIMEOUT);
         info_log("timeout waiting for param ack\n");
         ret = FALSE;
         break;
      }
      time_delay_ms(1);
   }
   // now read the parameter value

   start_time = time_us();
   if (!i2c_blocking_read(instance->i2c_handle, SR_SAVED_PARAM_B0, param_buf, param_len))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      ret = FALSE;
   }
   delta_time = time_us() - start_time;
   debug_log("param_val read: %u us at %u us\n", delta_time, start_time);
   debug_log("param save time: %u us\n", time_us() - orig_start_time);

   return ret;
}


// load == write
bool di_load_parameter(DI_INSTANCE_T *instance, ParameterPage page, u8 param_number, u8 *param_buf, u8 param_len)
{
   u8 param;
   u32 start_tick;
   RegParameterPageSel sel;
   bool ret = TRUE;
   u32 start_time;
   u32 orig_start_time;
   u32 delta_time;

   DI_PREAMBLE_FULL(instance);

   if (!instance->ram_version)
   {
      INSTANCE_ERROR(DE_INITIALIZATION_REQUIRED);
      return FALSE;
   }

   if (!param_number || !param_buf || !param_len || (param_len > PARAM_LOAD_SIZE))
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }
   INSTANCE_ERROR(DE_NONE);


   // write the parameter value first
   orig_start_time = start_time = time_us();
   if (!i2c_blocking_write(instance->i2c_handle, SR_LOAD_PARAM_B0, param_buf, param_len))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   delta_time = time_us() - start_time;
   debug_log("param_val write: %u us at %u us\n", delta_time, start_time);

   // write the parameter page (this starts the parameter procedure)
   sel.bits.ParameterPage = page;
   sel.bits.ParameterSize = param_len;
   start_time = time_us();
   if (!i2c_blocking_write(instance->i2c_handle, SR_PARAMETER_PAGE_SEL, &sel.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   delta_time = time_us() - start_time;
   debug_log("page_sel write: %u us\n", delta_time);

   // now set the parameter number with MSB high to request a load of the parameter
   param = param_number | 0x80;
   start_time = time_us();
   if (!i2c_blocking_write(instance->i2c_handle, SR_PARAMETER_REQUEST, &param, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   delta_time = time_us() - start_time;
   debug_log("param_req write: %u us at %u us\n", delta_time, start_time);

   // wait for acknowledge from U718x
   start_tick = time_ms();
   for (;;)
   {
      start_time = time_us();
      if (!i2c_blocking_read(instance->i2c_handle, SR_PARAMETER_ACKNOWLEDGE, &param, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      delta_time = time_us() - start_time;
      debug_log("param_ack read: %u us at %u us\n", delta_time, start_time);
      // it matches... we can move on
      if (param == (param_number | 0x80))
      {
         debug_log("param_ack time: %u ms at %u ms\n", time_ms() - start_tick, start_tick);
         break;
      }

      // check for error
      if (param == 0x80)
      {
         INSTANCE_ERROR(DE_PARAM_OUT_OF_RANGE);
         info_log("parameter error 0x80 returned from u718x\n");
         ret = FALSE;
         break;
      }
      // check for timeout
      if ((time_ms() - start_tick) > PARAM_ACK_TIMEOUT_MS)
      {
         INSTANCE_ERROR(DE_PARAM_ACK_TIMEOUT);
         info_log("timeout waiting for param ack\n");
         ret = FALSE;
         break;
      }
      time_delay_ms(1);
   }
#if 0
   // we have requested the procedure, so tell it we're done
   // write the parameter page to 0 to end the parameter procedure
   sel.bits.ParameterPage = 0;
   sel.bits.ParameterSize = 0;
   if (!i2c_blocking_write(instance->i2c_handle, SR_PARAMETER_PAGE_SEL, &sel.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      ret = FALSE;
   }

   // clear the parameter number
   param_number = 0;
   if (!i2c_blocking_write(instance->i2c_handle, SR_PARAMETER_REQUEST, &param_number, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      ret = FALSE;
   }
#endif
   debug_log("param load time: %u us\n", time_us() - orig_start_time);
   return ret;
}


bool di_load_parameter_with_verify(DI_INSTANCE_T *instance, ParameterPage page, u8 param_number, u8 *param_buf, u8 param_len)
{
   u8 read_param[PARAM_LOAD_SIZE];

   if (di_load_parameter(instance, page, param_number, param_buf, param_len))
   {
      if (di_save_parameter(instance, page, param_number, read_param, param_len))
      {
         // compare to what we wrote
         if (memcmp(read_param, param_buf, param_len) != 0)
         {
            error_log("miscompare param %u, wrote: 0x%02X, 0x%02X, 0x%02X, 0x%02X; read: 0x%02X, 0x%02X, 0x%02X, 0x%02X\n",
                      param_number & 0x7f,
                      param_buf[0], param_buf[1], param_buf[2], param_buf[3],
                      read_param[0], read_param[1], read_param[2], read_param[3]);
            INSTANCE_ERROR(DE_CHIP_ERROR);
         }
         else
            return TRUE;
      }
   }
   return FALSE;
}


bool di_configure_output(DI_INSTANCE_T *instance, bool ned)
{
   DI_PREAMBLE_FULL(instance);

   // set the output format
   instance->host_intf_control.bits.NED = ned;
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   INSTANCE_ERROR(DE_NONE);

   return TRUE;
}


bool di_configure_interrupts_ex(DI_INSTANCE_T *instance, bool nonwakeup_int_enable, bool wakeup_int_enable, u16 nonwakeup_fifo_watermark, u16 wakeup_fifo_watermark)
{
   u8 buf[1];
   FIFO_CONTROL_PARAM fifo_control_param;

   DI_PREAMBLE_FULL(instance);

   instance->host_intf_control.bits.HostIntDisable = !wakeup_int_enable;
   if (instance->hi_id != HIID_KITKAT)
      instance->host_intf_control.bits.NonWakeupFIFOIntDisable = !nonwakeup_int_enable;
   buf[0] = instance->host_intf_control.reg;

   // write all registers
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, buf, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   if (instance->sensing)
   {
      fifo_control_param.watermark = wakeup_fifo_watermark;
      fifo_control_param.fifo_size = 0;                              // not writeable
      if (instance->hi_id != HIID_KITKAT)
      {
         fifo_control_param.nonwakeup_watermark = nonwakeup_fifo_watermark;
         fifo_control_param.nonwakeup_fifo_size = 0;
      }
      else
      {
         fifo_control_param.nonwakeup_watermark = 0;
         fifo_control_param.nonwakeup_fifo_size = 0;
      }
      if (!di_load_parameter(instance, PP_SYSTEM, SYSP_FIFO_CONTROL, (u8 *)&fifo_control_param, sizeof(fifo_control_param)))
         return FALSE;
   }
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}

bool di_configure_interrupts(DI_INSTANCE_T *instance, bool int_enable, u16 fifo_watermark)
{
   return di_configure_interrupts_ex(instance, FALSE, int_enable, 0, fifo_watermark);
}


bool di_abort_transfer(DI_INSTANCE_T *instance)
{
   RegHostIntfControl host;                                          // use local copy so instance copy does not remember it

   DI_PREAMBLE(instance);

   host.reg = instance->host_intf_control.reg;
   host.bits.AbortTransfer = 1;
   host.bits.UpdateBytesRemaining = 0;
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &host.reg, 1))
      return FALSE;
   instance->state = DS_IDLE;                                        // start a fresh host transfer after this
   instance->cur_sample.sensor = DST_NOP;                            // start a fresh sensor decoding
   return TRUE;
}


bool di_update_transfer_count(DI_INSTANCE_T *instance, u16 *count)
{
   RegHostIntfControl host;
   u8 temp[2];

   DI_PREAMBLE(instance);

   host.reg = instance->host_intf_control.reg;
   host.bits.AbortTransfer = 0;
   host.bits.UpdateBytesRemaining = 1;
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &host.reg, 1))
      return FALSE;
   time_delay_ms(10);                                                // give it time to update (this is plenty)
   if (count)
   {
      if (!i2c_blocking_read(instance->i2c_handle, SR_BYTES_REMAINING_LSB, temp, 2))
         return FALSE;
      *count = (u16)temp[0] + (((u16)temp[1]) << 8);
   }
   return TRUE;
}



bool di_set_ap_suspended_mode(DI_INSTANCE_T *instance, bool ap_suspended)
{
   DI_PREAMBLE(instance);
   instance->host_intf_control.bits.APSuspended = ap_suspended;
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
      return FALSE;
   return TRUE;
}

#if 0
bool di_set_host_test_mode(DI_INSTANCE_T *instance, bool host_test_mode)
{
   DI_PREAMBLE(instance);
   instance->host_intf_control.bits.HostTest = host_test_mode;
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
   return FALSE;
   return TRUE;
}
#endif

bool di_set_sensor_self_test_mode(DI_INSTANCE_T *instance, bool self_test_mode)
{
   DI_PREAMBLE(instance);
   instance->host_intf_control.bits.SensorSelfTest = self_test_mode;
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
      return FALSE;
   return TRUE;
}

bool di_poll_host_interrupt(DI_INSTANCE_T *instance, bool *interrupt)
{
   RegIntStatus int_status;

   DI_PREAMBLE(instance);

   if (!i2c_blocking_read(instance->i2c_handle, SR_INT_STATUS, &int_status.reg, 1))
      return FALSE;
   *interrupt = (int_status.bits.HostInterrupt != 0);
   return TRUE;
}


bool di_fifo_flush(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   reset_timestamp_checking(instance, sensor);                       // will reset if the sensor = discard command
   if (!i2c_blocking_write(instance->i2c_handle, SR_FIFO_FLUSH, (u8 *)&sensor, 1))
      return FALSE;
   return TRUE;
}


bool di_register(DI_INSTANCE_T *instance, DATA_CALLBACK data_callback, void *user_param)
{
   DI_PREAMBLE(instance);

   /// @todo: prevent race conditions while modifying these two values...
   instance->data_callback = data_callback;
   instance->user_param = user_param;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_deregister(DI_INSTANCE_T *instance)
{
   DI_PREAMBLE(instance);

   /// @todo: prevent race conditions while modifying these two values...
   instance->data_callback = NULL;
   instance->user_param = NULL;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_run_request(DI_INSTANCE_T *instance)
{
   RegChipControl chip;

   DI_PREAMBLE_FULL(instance);

   // start the firmware running
   chip.reg = 0;
   chip.bits.CPURunReq = 1;
   if (!i2c_blocking_write(instance->i2c_handle, SR_CHIP_CONTROL, &chip.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   instance->executing = TRUE;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_normal_exec_request(DI_INSTANCE_T *instance)
{
   u32 start;

   DI_PREAMBLE_FULL(instance);

   // get the algorithm to run
   instance->host_intf_control.bits.AlgorithmStandbyRequest = 0;
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   if (!di_run_request(instance))
      return FALSE;

   // check that it has started
   start = time_ms();
   do
   {
      irq_check(instance->irq_handle);
      if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_STATUS, &instance->error.host_status.reg, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      time_delay_ms(1);
      if (time_ms() > (start + RUN_TIMEOUT_MS))
         break;
   }
   while (instance->error.host_status.bits.AlgorithmStandby);
   instance->hi_id = instance->error.host_status.bits.HostInterfaceID;
   instance->sensing = !instance->error.host_status.bits.AlgorithmStandby;
   di_host_status_store(instance, &(instance->error.host_status));
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_standby_request(DI_INSTANCE_T *instance)
{
   u32 start;

   DI_PREAMBLE(instance);
   if (!instance->executing)
   {
      INSTANCE_ERROR(DE_EXECUTING_REQUIRED);
      return FALSE;
   }

   // get the algorithm to pause
   instance->host_intf_control.bits.AlgorithmStandbyRequest = 1;
   if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   // check that it has paused
   start = time_ms();
   do
   {
      irq_check(instance->irq_handle);
      if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_STATUS, &instance->error.host_status.reg, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      time_delay_ms(1);
      if (time_ms() > (start + PAUSE_TIMEOUT_MS))
         break;
   }
   while (!instance->error.host_status.bits.AlgorithmStandby);

   instance->sensing = FALSE;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_shutdown_request(DI_INSTANCE_T *instance)
{
   RegChipControl host;
   u32 start;

   DI_PREAMBLE_FULL(instance);

   // tell U718x we don't want any more interrupts
   if (!di_configure_interrupts(instance, FALSE, 0))
      return FALSE;

   // tell U718x to shut down sensors and stop the algorithm
   if (instance->sensing)
      if (!di_standby_request(instance))
         return FALSE;

   // shut down processor
   host.reg = 0;
   host.bits.CPURunReq = 0;
   if (!i2c_blocking_write(instance->i2c_handle, SR_CHIP_CONTROL, &host.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   // check that it has stopped
   start = time_ms();
   do
   {
      irq_check(instance->irq_handle);
      if (!i2c_blocking_read(instance->i2c_handle, SR_CHIP_STATUS, &instance->error.chip_status.reg, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      time_delay_ms(1);
      if (time_ms() > (start + SHUTDOWN_TIMEOUT_MS))
         break;
   }
   while (!instance->error.chip_status.bits.FirmwareHalted);

   instance->executing = FALSE;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_query_status(DI_INSTANCE_T *instance, bool *executing, bool *sensing)
{
   DI_PREAMBLE(instance);

   if (!i2c_blocking_read(instance->i2c_handle, SR_CHIP_STATUS, &instance->error.chip_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_STATUS, &instance->error.host_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   if (executing)
      *executing = !instance->error.chip_status.bits.FirmwareHalted;

   instance->hi_id = instance->error.host_status.bits.HostInterfaceID;
   instance->sensing = !instance->error.host_status.bits.AlgorithmStandby;
   if (sensing)
      *sensing = instance->sensing;
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_query_error(DI_INSTANCE_T *instance, DI_ERROR_T *error_info)
{
   DI_PREAMBLE(instance);
   if (!error_info)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }
   if (read_chip_error_registers(instance))
   {
      memcpy(error_info, &instance->error, sizeof(DI_ERROR_T));
      return TRUE;
   }
   return FALSE;
}


bool di_get_last_error(DI_INSTANCE_T *instance, DI_ERROR_T *error_info)
{
   DI_PREAMBLE(instance);
   if (!error_info)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }
   memcpy(error_info, &instance->error, sizeof(DI_ERROR_T));
   return TRUE;
}


bool di_read_registers_with_handle(DI_INSTANCE_T *instance, I2C_HANDLE_T handle, u8 start_reg, u8 end_reg, u8 *dest)
{
   DI_PREAMBLE(instance);

   if (!i2c_blocking_read(handle, start_reg, dest, end_reg - start_reg + 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_write_registers_with_handle(DI_INSTANCE_T *instance, I2C_HANDLE_T handle, u8 start_reg, u8 end_reg, u8 *src)
{
   DI_PREAMBLE(instance);

   if (!i2c_blocking_write(handle, start_reg, src, end_reg - start_reg + 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool di_read_registers(DI_INSTANCE_T *instance, u8 start_reg, u8 end_reg, u8 *dest)
{
   return di_read_registers_with_handle(instance, instance->i2c_handle, start_reg, end_reg, dest);
}


bool di_write_registers(DI_INSTANCE_T *instance, u8 start_reg, u8 end_reg, u8 *src)
{
   return di_write_registers_with_handle(instance, instance->i2c_handle, start_reg, end_reg, src);
}


bool di_set_passthrough_mode(DI_INSTANCE_T *instance, bool enable)
{
   RegPassthruStatus status;
   RegPassthruControl control;
   u32 start;
   bool ret = TRUE;

   // go into passthrough mode
   control.reg = 0;
   control.bits.PassthroughEn = enable;
   if (!i2c_blocking_write(instance->i2c_handle, SR_PASSTHRU_CONTROL, &control.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   // check that we're in passthrough mode
   start = time_ms();
   do
   {
      irq_check(instance->irq_handle);
      if (!i2c_blocking_read(instance->i2c_handle, SR_PASSTHRU_STATUS, &status.reg, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         ret = FALSE;
      }
      if (time_ms() > (start + PASSTHROUGH_TIMEOUT_MS))
      {
         INSTANCE_ERROR(DE_PASSTHROUGH_TIMEOUT);
         ret = FALSE;
      }
      if (!ret)                                                      // it failed, so try cleaning up by writing it back to non-passthrough
      {
         if (enable)
         {
            control.bits.PassthroughEn = FALSE;
            i2c_blocking_write(instance->i2c_handle, SR_PASSTHRU_CONTROL, &control.reg, 1);
         }
         break;
      }
   }
   while (status.bits.PassthruReady != enable);

   instance->passthrough = enable;
   return ret;
}


bool di_reset_chip(DI_INSTANCE_T *instance, bool wait_for_standby)
{
   RegResetRequest reset;
   u32 start;

   // reset timestamp validation
   reset_internal_stats(instance);

   instance->prev_int_count = instance->interrupt;
   irq_check(instance->irq_handle);

   instance->executing = FALSE;
   instance->sensing = FALSE;
   reset.reg = 0;
   reset.bits.ResetRequest = 1;
   if (!i2c_blocking_write(instance->i2c_handle, SR_RESET_REQ, &reset.reg, 1))
   {
      warn_log("error writing to reset register; ignoring\n");
      time_delay_ms(100);
      //INSTANCE_ERROR(DE_I2C_ERROR);
      //return FALSE;
   }
   // wait for interrupt
   start = time_ms();
   while (instance->interrupt == instance->prev_int_count)
   {
      irq_check(instance->irq_handle);
      if (time_ms() > (start + EEPROM_UPLOAD_TIME_MS))
      {
         warn_log("timeout waiting for interrupt\n");
         break;
      }
   }

   start = time_ms();
   // keep reading U718x status until EEPROM Upload comes to a conclusion
   for (;;)
   {
      irq_check(instance->irq_handle);
      if (!i2c_blocking_read(instance->i2c_handle, SR_CHIP_STATUS, &instance->error.chip_status.reg, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      time_delay_ms(1);
      if (time_ms() > (start + EEPROM_UPLOAD_TIME_MS))
      {
         warn_log("timeout waiting for proper U718x status: 0x%02X\n", instance->error.chip_status.reg);
         break;
      }
      if (instance->error.chip_status.bits.FirmwareHalted || !wait_for_standby)
      {
         if (instance->error.chip_status.bits.EEUploadError ||
             instance->error.chip_status.bits.EEUploadDone ||
             instance->error.chip_status.bits.NoEEPROM)
            break;
      }
   }

   return read_chip_error_registers(instance);
}


bool read_chip_error_registers(DI_INSTANCE_T *instance)
{
   if (!i2c_blocking_read(instance->i2c_handle, SR_CHIP_STATUS, &instance->error.chip_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_STATUS, &instance->error.host_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   instance->hi_id = instance->error.host_status.bits.HostInterfaceID;
   instance->executing = !instance->error.chip_status.bits.FirmwareHalted;
   instance->error.error_register = (RegErrorValues)0;
   if (!i2c_blocking_read(instance->i2c_handle, SR_ERROR_REGISTER, (u8 *)&instance->error.error_register, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   if (!i2c_blocking_read(instance->i2c_handle, SR_INT_STATUS, &instance->error.int_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   //if (instance->executing && instance->ram_version)
   //   return di_query_sensor_status(instance);
   //else
   return TRUE;
}

void di_host_status_store(DI_INSTANCE_T *instance, RegHostStatus *host_status)
{
   int use_size;
   instance->alg_id = (AlgIDValues)(host_status->bits.AlgorithmID);
   instance->hi_id = instance->error.host_status.bits.HostInterfaceID;

   if (instance->alg_id == AID_SPACE_POINT)
   {
      use_size = sizeof(DI_3AXIS_RAW_FL_DATA_T);
   }
   else
   {
      use_size = sizeof(DI_3AXIS_RAW_INT_DATA_T);
   }
   set_sensor_data_size(DST_RAW_DEBUG_OUTPUT_GYRO, use_size);
   set_sensor_data_size(DST_RAW_DEBUG_OUTPUT_MAG, use_size);
   set_sensor_data_size(DST_RAW_DEBUG_OUTPUT_ACCEL, use_size);
}

AlgIDValues di_get_algorithm_id(DI_INSTANCE_T *instance)
{
   DI_PREAMBLE_FULL(instance);

   if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_STATUS, &instance->error.host_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   di_host_status_store(instance, &(instance->error.host_status));
   return instance->error.host_status.bits.AlgorithmID;
}


HIIDValues di_get_host_interface_id(DI_INSTANCE_T *instance)
{
   DI_PREAMBLE_FULL(instance);

   if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_STATUS, &instance->error.host_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   di_host_status_store(instance, &(instance->error.host_status));
   instance->hi_id = (HIIDValues)instance->error.host_status.bits.HostInterfaceID;
   return instance->hi_id;
}


void di_control_logging(DI_INSTANCE_T *instance, bool quiet_loading, bool quiet_meta_events, bool quiet_timestamp_errors, bool dump_raw_data)
{
   instance->quiet_loading = quiet_loading;
   instance->quiet_meta_events = quiet_meta_events;
   instance->quiet_timestamp_errors = quiet_timestamp_errors;
   instance->dump_raw_data = dump_raw_data;
}


static void *get_sensor_pointer(DI_INSTANCE_T *instance, DI_SENSOR_INT_DATA_T *sample, DI_SENSOR_TYPE_T sensor)
{
   if ((sensor < DST_FIRST) || (sensor > DST_LAST_EXTRA_SENSOR))
   {
      return NULL;
   }
   return getIntDataPtr_knownSensorType(instance, sensor, sample);
}

DI_SENSOR_INT_DATA_T *get_sensors_struct(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if (is_wakeup_event(instance, sensor))
   {
#if !defined(DI_SLIM)
      return &instance->last_sample_w;
#else
      return NULL;
#endif
   }
   return &instance->last_sample;
}

bool di_query_sensor_most_recent_sample(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_UNION_T *data, u8 len)
{
   u8 orig_len;
   void *src;
   DI_SENSOR_INT_DATA_T *sensors_struct;

   DI_PREAMBLE_FULL(instance);

   sensors_struct = get_sensors_struct(instance, sensor);
   src = get_sensor_pointer(instance, sensors_struct, sensor);
   if (!src)
      return FALSE;

   orig_len = (u8)get_sensor_data_size(sensor);

   if (!data || !len || !orig_len)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }

   if (len > orig_len)
      len = orig_len;

   // finally, copy the sample
   memcpy(data, src, len);
   if (data->sensor != sensor)
      return FALSE;

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}


bool i2c_callback(I2C_HANDLE_T handle, TransferStatus complete, u16 len_transferred, void *user_param)
{
   DI_INSTANCE_T *instance = (DI_INSTANCE_T *)user_param;
   if (DI_PRECHECK(instance))
   {
      instance->i2c_interrupt++;                                     // we define the interrupt field as being an atomic integer -- we want the increment to occur in 1 cycle ideally
      instance->sensor_complete = complete;
      instance->sensor_rlen = len_transferred;
   }
   return TRUE;
}


bool irq_callback(IRQ_HANDLE_T handle, u32 os_param, void *user_param)
{
   DI_INSTANCE_T *instance = (DI_INSTANCE_T *)user_param;
   if (DI_PRECHECK(instance))
   {
      instance->host_int_timestamp = time_ms();
      instance->interrupt++;                                         // we define the interrupt field as being an atomic integer -- we want the increment to occur in 1 cycle ideally
      irq_acknowledge(handle);
   }
   return TRUE;
}

#if 0
static u32 timestamp_lsw_to_microseconds(u16 val)
{
   return (((u32)val) * SENSOR_SCALE_TIME_NUM) / SENSOR_SCALE_TIME_DEN;
}
#endif

void reset_timestamp_checking_for_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   DI_SENSOR_INFO_T *info;
   if (sensor <= di_max_sensor_id(instance))
      info = &instance->sensor_info[sensor];
   else if ((sensor == DST_RAW_DEBUG_OUTPUT_ACCEL) || (sensor == DST_RAW_DEBUG_OUTPUT_MAG) || (sensor == DST_RAW_DEBUG_OUTPUT_GYRO))
      info = &instance->sensor_info_raw[sensor - DST_RAW_DEBUG_OUTPUT_GYRO];
   else
      info = NULL;

   if (info)
   {
      info->timestamp_prev = 0;                 // reset time analysis, so when rate is changed, it starts clean
#if !defined(DI_SLIM)
      info->timestamp_delta = 0;
      info->timestamps_since_change = 0;
      info->timestamp_true_last_delta = 0;
      info->timestamp_min_delta = U32_MAX;
      info->timestamp_max_delta = 0;
#endif
   }
}


void reset_timestamp_checking(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T discard_cmd)
{
   // todo: make this work for DST_DISCARD_NW and DST_DISCARD_W also
   if (discard_cmd == DST_DISCARD_ALL)
   {
      DI_SENSOR_TYPE_T s;

      for (s = DST_FIRST; s <= di_max_sensor_id(instance); s++)
      {
         reset_timestamp_checking_for_sensor(instance, s);
      }
      timestamp_cur_sample(NULL);                                    // reset memory of old timestamps
      info_log("timestamp checking reset\n");
   }
}

#if defined(NEW_PARSER)

// add separator to text ie 1234567 -> 123'456'7
void addSep(char *txt, char *txt2, int len, char sep)
{
   int j = 0;
   int i;
   for (i = 0; txt[i] != 0; i++)
   {
      txt2[j++] = txt[i];
      if ((i + 1) % len == 0)
         txt2[j++] = sep;
   }
   txt2[--j] = 0;
}

// print number with fixed size and separator ie "  1'234'567"
// len fixed size of numbers (will be filled with spaces at begining)
// num: number to print
void myPrintNum(u32 num, int len)
{
   char txt[50];
   char txt2[50];
   sprintf_s(txt, 50, "% *u", len, num);
   addSep(txt, txt2, 3, '\'');
   info_log("%s", txt2);
}


static bool timestamp_cur_sample(DI_INSTANCE_T *instance)
{
   static u16 prev_lsw[2] = {0, 0};
   static u16 prev_msw[2] = {0, 0};
   static u64 prev_timestamp[2] = {0, 0};
   DI_SENSOR_TYPE_T sensor;
   DI_SENSOR_INFO_T *info;
   bool ret = TRUE;
   int fifo;
#define N 10 /**< IIR filter period */
#define K 6  /**< IIR filter feedback */

   if (!instance)                                                    // reset local data
   {
      prev_lsw[0] = 0;
      prev_msw[0] = 0;
      prev_timestamp[0] = 0;
      prev_lsw[1] = 0;
      prev_msw[1] = 0;
      prev_timestamp[1] = 0;
      return TRUE;
   }
   sensor = instance->cur_sample.sensor;

   if (sensor <= di_max_sensor_id(instance))
      info = &instance->sensor_info[sensor];
   else
      info = NULL;

   // Some firmware versions place the initalize event in the wakeup fifo, but don't specify it as a wakeup event.
   // Fore the event type here.
#if !defined(DI_SLIM)
   if (instance->hi_id == HIID_LOLLIPOP &&
       sensor == DST_META_EVENT &&
       instance->cur_sample.meta.event_id == DME_INITIALIZED)
   {
      instance->cur_sample.sensor = DST_WAKEUP_META_EVENT;
      sensor = DST_WAKEUP_META_EVENT;
   }
#endif

   fifo = is_wakeup_event(instance, sensor) ? 1 : 0;
   prev_timestamp[fifo] = instance->cur_timestamp[fifo];
   if ((sensor == DST_TIMESTAMP_LSW)
#if !defined(DI_SLIM)
       || (sensor == DST_WAKEUP_TIMESTAMP_LSW)
#endif
      )
   {
      prev_lsw[fifo] = instance->cur_sample.timestamp_lsw.datum;
      if (!instance->quiet_meta_events && instance->dump_raw_data)
         debug_log("timestamp %s LSW: %u\n", fifo ? "wake " : "nonw", prev_lsw[fifo]);
      instance->prev_timestamp[fifo] = instance->cur_timestamp[fifo];
      instance->cur_timestamp[fifo] = (((((u64)prev_lsw[fifo]) | (((u64)prev_msw[fifo]) << 16)) * SENSOR_SCALE_TIME_NUM) / SENSOR_SCALE_TIME_DEN);
#ifdef VBE_DBG_EACH_EVNT_TIME
      info_log("Tm [ms]: ");
      myPrintNum(instance->cur_timestamp[fifo] / 1000, 9);
      info_log("  dif [ms]: ");
      myPrintNum((instance->cur_timestamp[fifo] - instance->prev_timestamp[fifo]) / 1000, 9);
      info_log("\n");
#endif

      // this detects out-of-order but unrelated timestamps; this is expected by design due to the variety of execution priorities these can be generated from;
      // I'm relaxing this test to permit slips under 5ms (200Hz), the BSX tick rate
      if ((instance->cur_timestamp[fifo] + ALLOWED_SLIP_US) < prev_timestamp[fifo])
      {
         if (!instance->quiet_timestamp_errors)
            error_log("timeslip: was %I64u [us], is %I64u [us], by %I64d [us]; prev MSW: %u, LSW: %u\n",
                      prev_timestamp[fifo], instance->cur_timestamp[fifo], (s64)prev_timestamp[fifo] - (s64)instance->cur_timestamp[fifo],
                      prev_msw[fifo], prev_lsw[fifo]);
         instance->total_timeslips++;
         ret = FALSE;
      }
   }
   else if ((sensor == DST_TIMESTAMP_MSW)
#if !defined(DI_SLIM)
            || (sensor == DST_WAKEUP_TIMESTAMP_MSW)
#endif
           )
   {
      prev_msw[fifo] = instance->cur_sample.timestamp_msw.datum;
      instance->cur_timestamp[fifo] = ((((((u64)prev_msw[fifo]) << 16)) * SENSOR_SCALE_TIME_NUM) / SENSOR_SCALE_TIME_DEN);
      if (!instance->quiet_meta_events && instance->dump_raw_data)
         debug_log("timestamp %s MSW: %u\n", fifo ? "wake " : "nonw", prev_msw[fifo]);
   }
   else if ((sensor != DST_RAW_DEBUG_OUTPUT_ACCEL) && (sensor != DST_RAW_DEBUG_OUTPUT_MAG) && (sensor != DST_RAW_DEBUG_OUTPUT_GYRO))
   {
      // place the timestamp in the last 4 bytes of the sample
      if (info)
      {
         if (!info->timestamp_delta || (info->rate != info->prev_rate))
         {
            u16 rate = info->actual_rate ? info->actual_rate : info->rate; // actual rate is better to estimate next timestamp
            if (rate)
               info->timestamp_delta = 1000000 / rate;
            else
               info->timestamp_delta = 0;
            info->timestamp_delta_sum = info->timestamp_delta;
            info->timestamps_since_change = 0;
            info->prev_rate = info->rate;
         }
#if defined(TIMESTAMP_HISTORY)
         info->timestamp_delta_actual = instance->cur_timestamp[fifo] - info->timestamp_prev;
         info->timestamp_delta_history[info->timestamp_delta_index++] = info->timestamp_delta_actual;
         if (info->timestamp_delta_index >= TIMESTAMP_HISTORY_SIZE)
            info->timestamp_delta_index = 0;
#endif
         if ((info->timestamps_since_change > 0) && info->rate)
         {
            info->timestamp_true_last_delta = instance->cur_timestamp[fifo] - info->timestamp_prev;
            // todo vbe remove log
            //info_log("s: %d [us] c: %u - p: %u = %u\n",sensor,instance->cur_timestamp[fifo], info->timestamp_prev, info->timestamp_true_last_delta);
            if (info->timestamp_true_last_delta > info->timestamp_max_delta)
            {
               info->timestamp_max_delta = info->timestamp_true_last_delta;
            }
            if (info->timestamp_true_last_delta < info->timestamp_min_delta)
            {
               info->timestamp_min_delta = info->timestamp_true_last_delta;
            }
         }

         if ((info->timestamps_since_change > 1) && info->rate && info->timestamp_prev)
         {
            if ((instance->cur_timestamp[fifo] < info->timestamp_prev) && di_is_sensor_continuous(instance, sensor))
            {
               if (!instance->quiet_timestamp_errors)
                  info_log("slip: sensor %u, by: %I64u [us], sample: %u\n", sensor, info->timestamp_prev - instance->cur_timestamp[fifo], info->samples_received);
               info->timestamp_slips++;
               instance->total_timeslips++;
               ret = FALSE;
            }
            else if (instance->cur_timestamp[fifo] == info->timestamp_prev) // check for dups even for non-continuous sensors
            {
               if (!instance->quiet_timestamp_errors)
                  info_log("dup: sensor: %u, ts: %I64u [us], sample: %u\n", sensor, instance->cur_timestamp[fifo], info->samples_received);
               info->timestamp_dups++;
               instance->total_timedups++;
               ret = FALSE;
            }
            else
            {
               if ((instance->cur_timestamp[fifo] > (info->timestamp_prev + (info->timestamp_delta * 3) / 2)) && di_is_sensor_continuous(instance, sensor))
               {
                  if (!instance->quiet_timestamp_errors && !instance->quiet_gap_errors)
                  {
#if defined(TIMESTAMP_HISTORY)
                     u32 i;
                     info_log("History (oldest first):\n");
                     for (i = 0; i < TIMESTAMP_HISTORY_SIZE; i++)
                        info_log("%I64u ", info->timestamp_delta_history[(i + info->timestamp_delta_index) % TIMESTAMP_HISTORY_SIZE]);
                     info_log("\n");
#endif
                     info->timestamp_last_gap_us = instance->cur_timestamp[fifo] - info->timestamp_prev;
                     info_log("gap: sensor: %u, time delta exp: %I64u [us], got: %I64u [us], sample #: %u, rate: %u, curts:%I64u, prevts:%I64u\n",
                              sensor, info->timestamp_delta, info->timestamp_last_gap_us,
                              info->samples_received, info->rate, instance->cur_timestamp[fifo], info->timestamp_prev);
                     // this check no longer serves a purpose, and is confusing when testing FIFO overflows
                     // if ((instance->cur_timestamp[fifo] - info->timestamp_prev) > 2000000)
                     //    error_log("possible early Timestamp MSW event!\n");
                  }
                  info->timestamp_gaps++;
                  instance->total_timegaps++;
                  ret = FALSE;
               }
               info->timestamp_delta_sum = (instance->cur_timestamp[fifo] - info->timestamp_prev) * K + info->timestamp_delta * (N - K);
               info->timestamp_delta = info->timestamp_delta_sum / N;
            }
         }
         if (info->rate)
         {
            info->timestamp_prev = instance->cur_timestamp[fifo];
            info->timestamps_since_change++;
         }
         else
         {
            info->timestamp_prev = info->timestamp_delta = 0;
            info->timestamps_since_change = 0;
         }
      }

      // finally, store the actual timestamp at the end of the current sample
      memcpy(&instance->cur_sample.data[instance->cur_sample_len], &instance->cur_timestamp[fifo], sizeof(instance->cur_timestamp[0]));
   }
   else // check raw debug data timestamps
   {
      DI_3AXIS_RAW_INT_DATA_T *raw = &instance->cur_sample.raw_gyro;
      // handle difference in t parameter between algorithms; SpacePoint uses it for temperature, BSX uses it for original physical sensor timestamp
      u64 t = (instance->alg_id == AID_SPACE_POINT) ? instance->cur_timestamp[0] : raw->t;
      info = &instance->sensor_info_raw[sensor - DST_RAW_DEBUG_OUTPUT_GYRO];
      if (!info->timestamp_delta)
      {
         if (info->timestamps_since_change)
            info->timestamp_delta = t - info->timestamp_prev;
      }
      else if (info->timestamp_prev)
      {
         if (t < info->timestamp_prev)
         {
            info_log("slip: sensor %u (%s), by: %I64u [us], sample: %u\n", sensor, di_query_extra_event_name(sensor), info->timestamp_prev - t, info->samples_received);
            info->timestamp_prev = t;
            info->timestamp_slips++;
            instance->total_timeslips++;
         }
         else if (t == info->timestamp_prev)
         {
            if (sensor != DST_RAW_DEBUG_OUTPUT_MAG) // kludge -- this will very often be duplicate as it runs so much slower than other sensors, so suppress output
            {
               info_log("dup: sensor: %u (%s), ts: %I64u [us], sample: %u\n", sensor, di_query_extra_event_name(sensor), (u64)t, info->samples_received);
               info->timestamp_dups++;
               instance->total_timedups++;
            }
         }
         else
         {
            TS_T new_delta = t - info->timestamp_prev;
            if (sensor == DST_RAW_DEBUG_OUTPUT_MAG) // output mag debug info
            {
               //info_log("t:%I64u pt:%I64u newdelta:%I64u delta:%I64u\n", t, info->timestamp_prev, new_delta, info->timestamp_delta);
            }
            if (new_delta > ((info->timestamp_delta * 3) / 2))
            {
               info_log("gap: sensor: %u (%s), time delta exp: %I64u [us], got: %I64u [us], sample #: %u, rate: %u, curts:%I64u, prevts:%I64u\n",
                        sensor, di_query_extra_event_name(sensor), (u64)info->timestamp_delta, (u64)new_delta,
                        info->samples_received, info->rate, (u64)t, (u64)info->timestamp_prev);
               info->timestamp_gaps++;
               instance->total_timegaps++;
            }
            //info->timestamp_delta = new_delta;
            info->timestamp_delta_sum = new_delta * K + info->timestamp_delta * (N - K);
            info->timestamp_delta = info->timestamp_delta_sum / N;
         }
      }
      info->timestamp_prev = t;
      info->timestamps_since_change++;
   }
#if 0
   if (!ret && !instance->quiet_timestamp_errors)
   {
      j = i - 97;
      if (j < 0)
      j = 0;
      debug_txt[0] = '\0';
      for (k = 0; k < 128; j++)
      {
         sprintf(debug_val, "%s%02X%s", (j == (i - 3)) ? "|" : " ", instance->sensor_buf[j], (j == (i - 1)) ? "|" : " ");
         strcat(debug_txt, debug_val);
         k++;
         if (k && !(k % 32))
         strcat(debug_txt, "\n");
      }
      info_log("%s", debug_txt);
   }
#endif
   return ret;
}


static bool store_cur_sample(DI_INSTANCE_T *instance)
{
   void *dst;
   DI_SENSOR_INT_DATA_T *sensors_struct;
   int size;
   int i;

   memcpy(&(instance->last_sample_u), &(instance->cur_sample), sizeof(DI_SENSOR_INT_UNION_T));

   sensors_struct = get_sensors_struct(instance, (DI_SENSOR_TYPE_T)instance->cur_sample.sensor);
   dst = get_sensor_pointer(instance, sensors_struct, (DI_SENSOR_TYPE_T)instance->cur_sample.sensor);
   size = get_sensor_data_size((DI_SENSOR_TYPE_T)instance->cur_sample.sensor);
   if (dst)
   {
      memcpy(dst, &instance->cur_sample, size);
      if (instance->cur_sample.sensor <= di_max_sensor_id(instance))
         instance->sensor_info[instance->cur_sample.sensor].valid = TRUE;
      else if ((instance->cur_sample.sensor >= DST_RAW_DEBUG_OUTPUT_GYRO) && (instance->cur_sample.sensor <= DST_RAW_DEBUG_OUTPUT_ACCEL))
         instance->sensor_info_raw[instance->cur_sample.sensor - DST_RAW_DEBUG_OUTPUT_GYRO].valid = TRUE;
   }
   else
   {
      warn_log("Unable to store data for event %d, %d bytes\n", instance->cur_sample.sensor, size - sizeof(u32) - 1);
      info_log("event %d data: ", instance->cur_sample.sensor);
      if (size > (1 + sizeof(u32)))
      {
         for (i = 1; i < (int)(size - sizeof(u32)); i++)
         {
            info_log("0x%0.2X ", instance->cur_sample.data[i]);
         }
         info_log("\n");

      }
      return FALSE;                                                  // unknown sensor type.
   }
   return TRUE;                                                      // known sensor type
}

// Process one event from di->sensor_buf
// data from event can be found in di->last_sample
// returns: 0 ok (valid event recognized)
//          1 nop recoginized
//          2 not valid event
//          3 not complete event (read more fifo)
di_process_one_event_ret_t di_process_one_event(DI_INSTANCE_T *di)
{
   extern void display_meta_event(DI_INSTANCE_T * instance, DI_META_EVENT_INT_DATA_T * meta); // for debug
   int j;
   int k;
   int i;
   static u8 s = 0;
   char debug_val[8];
   char debug_txt[1024];
   bool raw_debug = FALSE;
   bool other = FALSE;

   if (di->cur_sample.sensor == DST_NOP)                             // in case process one event didn't have enough data
   {
      s = di->sensor_buf[di->sensor_buf_idx++];
      di->cur_sample.sensor = s;
      di->cur_sample_idx = 1;                                        // we have the first byte already...
      di->cur_sample_len = get_sensor_data_wire_size(s);
      if (di->cur_sample_len == 0)
      {
         if (s != DST_NOP)
         {
            error_log("invalid sensor %u at offset %u of %u; total bytes so far %u\n",
                      s, di->fifo_bytes_so_far + di->sensor_buf_idx - 1,
                      di->fifo_bytes_remaining + di->fifo_bytes_so_far,
                      di->total_bytes_transferred);
            j = di->sensor_buf_idx - 25;
            if (j < 0)
               j = 0;
            debug_txt[0] = '\0';
            for (k = 0; k < 48; k++, j++)
            {
               sprintf(debug_val, "%s%02X%s", (j == di->sensor_buf_idx) ? "|" : "",
                       di->sensor_buf[j], (j == di->sensor_buf_idx) ? "| " : " ");
               strcat(debug_txt, debug_val);
            }
            insane_log("%s\n", debug_txt);
            di->total_invalid_samples_received++;
            di->cur_sample.sensor = DST_NOP;                         // try to recognise sensor on next read
            return DI_PROC_ONE__UNKNOWN_EVENT;                       // not valid; we should probably resync with the chip at this point...
         }
         else
         {
            // PETE: no need to log this, it's normal: info_log("Pad bytes received at idx %u/%u B\n",di->sensor_buf_idx-1, di->sensor_buf_valid_data_size-1);
            di->total_pad_bytes_received++;
            return DI_PROC_ONE__NOP;
         }
      }
   }
   while (1)
   {
      if (di->cur_sample_idx >= di->cur_sample_len)
         break;
      if (di->sensor_buf_idx >= di->sensor_buf_valid_data_size)
      {
         if (di->sensor_buf_size > di->fifo_bytes_remaining)
            insane_log("event decoded partially - need next part of FIFO buffer; sensor id:%u, cur sample index:%u, cur sample len:%u, sensor buffer index:%u, sensor buffer len:%u\n",
                  di->cur_sample.sensor, di->cur_sample_idx, di->cur_sample_len, di->sensor_buf_idx, di->sensor_buf_valid_data_size);
         return DI_PROC_ONE__EVENT_NOT_COMPLETE;
      }
      di->cur_sample.data[di->cur_sample_idx++] = di->sensor_buf[di->sensor_buf_idx++];
   }

   if ((s >= DST_RAW_DEBUG_OUTPUT_GYRO) && (s <= DST_RAW_DEBUG_OUTPUT_ACCEL))
      raw_debug = TRUE;
   if ((s - DST_FIRST_EXTRA_SENSOR) <= DST_LAST_EXTRA_SENSOR)
      other = TRUE;

   if (di->dump_raw_data)
   {
      TS_T ts;
      u32 sample;

      if (raw_debug)
      {
         ts = di->cur_timestamp[0];
         sample = di->sensor_info_raw[s - DST_RAW_DEBUG_OUTPUT_GYRO].samples_received;
      }
      else if (other)
      {
         ts = di->cur_timestamp[is_wakeup_event(di, s) ? 1 : 0];
         sample = di->other_events[s - DST_FIRST_EXTRA_SENSOR];
      }
      else
      {
         ts = di->cur_timestamp[is_wakeup_event(di, s) ? 1 : 0];
         sample = di->sensor_info[s].samples_received;
      }
      debug_log("sample: sensor %u (%s), len %u, sample %u, ts %I64u us, ofs %u\n", s, di_query_sensor_name(di, s), di->cur_sample_len,
                sample, ts, di->sensor_buf_idx);
   }
   timestamp_cur_sample(di);                                         // append the most recent timestamp or update the timestamp if that's the sensor type

#ifdef VBE_DBG_EACH_EVNT
   //printTimeLSW(di,s);
   info_log("  <% 5u,% 5u>(% 2u)/% 5u B, ", di->sensor_buf_idx - di->cur_sample_len, di->sensor_buf_idx - 1,  di->cur_sample_len, di->sensor_buf_valid_data_size - 1);
   info_log("sensor: % 3u (% 27s)", s, di_query_sensor_name(di, (DI_SENSOR_TYPE_T)s));
   if (s == DST_META_EVENT || s == DST_WAKEUP_META_EVENT)
   {
      info_log("(%24s): ", di_query_meta_event_name(di->cur_sample.meta.event_id));
   }
   for (j = 0; j < di->cur_sample_idx; j++)
      info_log("%02x ", di->cur_sample.data[j]);
   info_log("\n");
#endif
   store_cur_sample(di);                                             // copy it to the correct place in the last_sample structure
   if (s <= di_max_sensor_id(di))
   {
      di->sensor_info[s].samples_received++;
   }
   else
   {
      if (raw_debug)
      {
         di->sensor_info_raw[s - DST_RAW_DEBUG_OUTPUT_GYRO].samples_received++;
      }
      if (other)
      {
         di->other_events[s - DST_FIRST_EXTRA_SENSOR]++;
      }

#if !defined(DI_SLIM)
      if (s == DST_DEBUG)
      {
         char *payload = (char *)malloc(sizeof(di->cur_sample.debug.payload) + 1);
         int size = di->cur_sample.debug.payload[0] & DEBUG_SIZE_MASK;
         int type = di->cur_sample.debug.payload[0] & ~DEBUG_SIZE_MASK;
         memcpy(payload, di->cur_sample.debug.payload + 1, size);
         switch (type)
         {
            case DEBUG_PACKET_STRING:
               payload[size] = 0;
               info_log("%s", payload);
               break;

            case DEBUG_PACKET_BINARY:
               info_log("Debug binary data: ");
               for (i = 0; i < size; i++)
               {
                  info_log("0x%02X ", (uint8_t)payload[i]);
               }
               info_log("\n");
            default:
               break;
         }
         free(payload);
      }
#endif
   }
   di->total_samples_received++;
   if (s == DST_META_EVENT)
   {
      di->cur_sample.meta.sensor = s;
      if (di->cur_sample.meta.event_id < DME_NUM_META_EVENTS)
      {
         di->meta_events[di->cur_sample.meta.event_id]++;
      }
      else
      {
         di->total_invalid_samples_received++;
         error_log("Unknown meta event id: %d detected\n", di->cur_sample.meta.event_id);
      }
      // allow most meta events to be suppressed, but do not suppress errors
      if (!di->quiet_meta_events || (di->cur_sample.meta.event_id == DME_ERROR) || (di->cur_sample.meta.event_id == DME_SENSOR_ERROR))
      {
         display_meta_event(di, &di->cur_sample.meta);
      }
   }
#if !defined(DI_SLIM)
   else if (s == DST_WAKEUP_META_EVENT)
   {
      di->cur_sample.meta.sensor = s;
      if (di->cur_sample.meta.event_id < DME_NUM_META_EVENTS)
         di->meta_events_wakeup[di->cur_sample.meta.event_id]++;
      if (!di->quiet_meta_events || (di->cur_sample.meta.event_id == DME_ERROR) || (di->cur_sample.meta.event_id == DME_SENSOR_ERROR))
         display_meta_event(di, &di->cur_sample.meta);
   }
#endif
   if (di->data_callback)
   {
      DI_SENSOR_INT_DATA_T *sensors_struct;
      sensors_struct = get_sensors_struct(di, s);

      di->data_callback(di, s, sensors_struct, di->user_param);
   }
   di->cur_sample.sensor = DST_NOP;
   return DI_PROC_ONE__OK;
}

// todo debug thoroughly it works same as original in rev 8126
bool process_fifo_chunk(DI_INSTANCE_T *instance)
{
   u32 i;
   int j;

   char debug_txt[1024];

   if (instance->dump_raw_data)
   {
      for (i = instance->sensor_buf_idx; i < instance->sensor_buf_valid_data_size; i += 16)
      {
         for (j = 0; j < 16; j++)
         {
            if ((i + j) >= instance->sensor_buf_valid_data_size)
               break;
            sprintf(&debug_txt[j * 3], "%02X ", instance->sensor_buf[i + j]);
         }
         debug_log("%04X: %s\n", i, debug_txt);
      }
   }

   while (instance->sensor_buf_idx < instance->sensor_buf_valid_data_size)
   {
      instance->event_decode_status = di_process_one_event(instance);
      if (instance->event_decode_status == DI_PROC_ONE__NOP)
      {
#if !defined(STOP_ON_PAD_BYTE)
         continue;
#else
         break;
#endif
      }
      else if (instance->event_decode_status == DI_PROC_ONE__UNKNOWN_EVENT)
      {
         return FALSE;
      }
   }
   return TRUE;
}

void debug_xfer(DI_INSTANCE_T *instance)
{
   u8 buf[3];
   if (di_read_registers(instance, SR_I2C_SLVRD_INT_LOC, SR_I2C_SLVRD_INT_LOC + 2, buf))
   {
      insane_log("I2C Int Loc: %u, Buf Ctrl: 0x%02X, Buf Count: %u\n", buf[0], buf[1], buf[2]);
   }
}

// todo vbe test it works same as di_task_loop when processData=1
// there were small changes. In case something does not work original is in revision 8126
bool di_task_loop_int(DI_INSTANCE_T *instance, bool *done, bool processData)
{
   bool host_interrupt;
   static u8 buf[2];
   u8 start;

   if (!DI_PRECHECK_FULL(instance))
   {
      INSTANCE_ERROR(DE_INVALID_INSTANCE);
      instance->state = DS_IDLE;                                     // reset state machine as a side-effect
      return FALSE;
   }

   // call routine used to simulate interrupts on some platforms
   irq_check(instance->irq_handle);

   if (done)
      *done = FALSE;

   //insane_log("task loop state: %d\n", instance->state);


   switch (instance->state)
   {
      case DS_POLL_HOST_IRQ:
         // The desktop interface driver might not notify us of the first host interrupt if it's asserted before we start.
         // Poll the host interrupt when we initialize the di.
         di_poll_host_interrupt(instance, &host_interrupt);
         if(host_interrupt) instance->state = DS_QUERY_BYTES_REMAINING; // host irq found, handle it.
         else instance->state = DS_IDLE; // no host irq, wait until we get the interrupt.
         break;

      case DS_IDLE:
         if (instance->interrupt == instance->prev_int_count)        // check for recent data ready interrupt
            break;

      case DS_QUERY_BYTES_REMAINING:
         debug_log("di_task_loop: got int, querying bytes remaining\n");
         while (instance->prev_int_count != instance->interrupt)     // loop to prevent race conditions
         {
            instance->prev_int_count = instance->interrupt;
         }

         if (instance->hi_id != HIID_KITKAT)
         {
            if (!di_read_registers(instance, SR_HOST_IRQ_TIMESTAMP, SR_HOST_IRQ_TIMESTAMP + 3, (u8 *)&instance->host_irq_timestamp))
            {
               INSTANCE_ERROR(DE_I2C_ERROR);
               return FALSE;
            }
            instance->host_irq_timestamp = (u32)((((u64)instance->host_irq_timestamp) * SENSOR_SCALE_TIME_NUM) / SENSOR_SCALE_TIME_DEN);
         }

         instance->prev_i2c_count = instance->i2c_interrupt;
         instance->fifo_bytes_so_far = instance->fifo_bytes_remaining = 0;
         instance->cur_sample.sensor = DST_NOP;

         //debug_xfer(instance);
         if (!i2c_read_start(instance->i2c_handle, SR_BYTES_REMAINING_LSB, buf, 2))
         {
            INSTANCE_ERROR(DE_I2C_ERROR);
            return FALSE;
         }

         irq_check(instance->irq_handle);                            // on systems with simulated interrupts, check immediately after reading event status to try to catch deassertion of interrupt
         instance->prev_int_count = instance->interrupt;
         instance->state = DS_WAIT_BYTES_REMAINING;
         break;

      case DS_WAIT_BYTES_REMAINING:
         if (instance->i2c_interrupt == instance->prev_i2c_count)
         {
            return TRUE;
         }
         instance->prev_i2c_count = instance->i2c_interrupt;         // no need to loop; we presume no other I2C int can occur now
         if ((instance->sensor_complete != TS_I2C_COMPLETE) || (instance->sensor_rlen != 2)) // check status of I2C transfer
         {
            error_log("bytes_remaining read error; sensor_complete = %u, sensor_rlen = %u\n", instance->sensor_complete, instance->sensor_rlen);
            INSTANCE_ERROR(DE_I2C_ERROR);
            instance->state = DS_IDLE;
            return FALSE;
         }
         // we have the number of bytes pending in the chip's buffer
         instance->fifo_bytes_remaining = ((u16)buf[0]) + (((u16)buf[1]) << 8);
#if defined(DEBUG_EVENTS)
         /** for debugging only, keep a history of recent events */
         event_hist[event_index] = 0;                                // \todo: decide what to log... event_status.reg;
         event_time[event_index++] = time_ms();
         if (event_index >= EVENT_COUNT)
            event_index = 0;
#endif
         debug_log("di_task_loop: got bytes remaining %u\n", instance->fifo_bytes_remaining);
         if (!instance->fifo_bytes_remaining)
         {                                                           //error_log("host int but bytes remaining == 0\n");
            instance->state = DS_IDLE;
            break;
         }
         instance->sensor_buf_valid_data_size = 0;
         instance->sensor_buf_idx = 0;
         instance->state = DS_START_READ_FIFO;

      case DS_START_READ_FIFO:
         instance->prev_int_count = instance->interrupt;
         // we can read "clean" bytes and as much as we have space for
         if ((instance->sensor_buf_size - instance->sensor_buf_valid_data_size) == 0)
         {
            debug_log("Internal buffer full - process the data and set instance->sensor_buf_valid_data_size=0\n");
            return TRUE;
         }
         instance->sensor_bytes_read = instance->sensor_buf_max_xfer_size;
         if (instance->fifo_bytes_remaining < instance->sensor_bytes_read)
         {
            instance->sensor_bytes_read = instance->fifo_bytes_remaining;
         }
         start = SR_BUFFER_OUT_START;
         instance->sensor_len = instance->sensor_bytes_read;
         if (instance->dump_raw_data)
         {
            debug_log("reading %u bytes %u to %u of %u\n",
                      instance->sensor_len,
                      instance->fifo_bytes_so_far,
                      instance->fifo_bytes_so_far + instance->sensor_len - 1,
                      instance->fifo_bytes_so_far + instance->fifo_bytes_remaining);
         }
         // if we restart a paused transfer, we need to start at fifo_bytes_so_far % 50

#ifdef VBE_DBG_FIFO_READ
         info_log("di_task_loop: read fifo start: % 3u, buf offset: %u, read len: %u\n", start, instance->sensor_buf_valid_data_size, instance->sensor_len);
#endif

         instance->prev_i2c_count = instance->i2c_interrupt;         // no need to loop; we presume no other I2C int can occur now
         if (i2c_read_start(instance->i2c_handle, start,
                            instance->sensor_buf + instance->sensor_buf_valid_data_size,
                            instance->sensor_len)
            )
         {
            instance->state = DS_WAIT_READ_FIFO;
         }
         else
         {
            instance->state = DS_QUERY_BYTES_REMAINING;
            return FALSE;
         }
         break;

      case DS_WAIT_READ_FIFO:
         if (instance->i2c_interrupt == instance->prev_i2c_count)
         {
            return TRUE;
         }
         instance->prev_i2c_count = instance->i2c_interrupt;         // no need to loop; we presume no other I2C int can occur now
         if ((instance->sensor_complete != TS_I2C_COMPLETE) || (instance->sensor_rlen != instance->sensor_len))
         {
            error_log("FIFO read error; sensor_complete = %u, sensor_len = %u, sensor_rlen = %u\n", instance->sensor_complete, instance->sensor_len, instance->sensor_rlen);
            INSTANCE_ERROR(DE_I2C_ERROR);
            instance->state = DS_IDLE;
            return FALSE;
         }
         instance->state = DS_PARSE_FIFO;
         instance->sensor_buf_valid_data_size += instance->sensor_bytes_read;
         break;

      case DS_PARSE_FIFO:
         instance->last_chunk_samples_rec = instance->total_samples_received;
         if (processData)
         {
            if (!process_fifo_chunk(instance))
            {
               error_log("process_fifo_chunk found an invalid event. Bytes processed %u/%u B\n",
                         instance->sensor_buf_idx, instance->sensor_buf_valid_data_size);
               instance->sensor_buf_valid_data_size = 0;
               instance->sensor_buf_idx = 0;
            }
         }
         instance->last_chunk_samples_rec = instance->total_samples_received - instance->last_chunk_samples_rec;
         instance->fifo_bytes_remaining -= instance->sensor_bytes_read;
         instance->fifo_bytes_so_far += instance->sensor_bytes_read;
         instance->total_bytes_transferred += instance->sensor_bytes_read;
         if (!instance->fifo_bytes_remaining)
         {
            instance->total_host_transfers++;
            instance->state = DS_IDLE;
            if (done)
               *done = TRUE;
         }
         else
         {
            debug_log("bytes so far: %u, bytes remaining: %u\n", instance->fifo_bytes_so_far, instance->fifo_bytes_remaining);
            instance->state = DS_START_READ_FIFO;
         }
         break;
   }
#if 0
   // uncomment this so that the done bit is high while reading and false otherwise
   // but if you do, function test 8.5 will fail
   if ((instance->state == DS_WAIT_BYTES_REMAINING) || (instance->state == DS_START_READ_FIFO) || (instance->state == DS_WAIT_READ_FIFO))
   {
      if (done) *done = TRUE;
   }
   else
   {
      if (done) *done = FALSE;
   }
#endif
   return TRUE;
}

bool di_task_loop(DI_INSTANCE_T *instance, bool *done)
{
   bool processData = TRUE;
   return di_task_loop_int(instance, done, processData);
}



/// \todo implement pause / resume of long reads (restart at address fifo_bytes_so_far % 50)
bool di_pause_task_loop(DI_INSTANCE_T *instance)
{
   while (instance->state != DS_IDLE)
   {
      if (!di_task_loop(instance, NULL))
      {
         return FALSE;
      }
   }
   return TRUE;
}

// TODO VBE check that di_read_fifo_unified is working same as origina di_read_fifo
bool di_read_fifo_unified(DI_INSTANCE_T *instance, bool *done, u16 timeout_ms)
{
   u32 end_ms;
   bool ret;
   bool waitForever;
   end_ms = time_ms() + timeout_ms;
   waitForever = (timeout_ms == 0xffff);                             // 0xffff means wait forever

   while (1)
   {
      if ((time_ms() >= end_ms) && (!waitForever))
      {
         return TRUE;
      }
      ret = di_task_loop(instance, done);
      if (!ret)
         return FALSE;
      if (instance->state == DS_START_READ_FIFO)
         break;
   }
   return di_pause_task_loop(instance);
}

bool di_read_fifo_known_bytes_remaining(DI_INSTANCE_T *instance)
{
   u8 start = SR_BUFFER_OUT_START;
   u16 fifo_bytes_remaining = instance->fifo_bytes_remaining;  // don't modify original; need it to supress warning when reading small chunks

   // we can read "clean" bytes and as much as we have space for
   instance->sensor_bytes_read = instance->sensor_buf_max_xfer_size;

   while (fifo_bytes_remaining)
   {
      if (fifo_bytes_remaining < instance->sensor_bytes_read)
      {
         instance->sensor_bytes_read = fifo_bytes_remaining;
      }
      instance->sensor_len = instance->sensor_bytes_read;

      if (instance->dump_raw_data)
      {
         debug_log("reading %u bytes %u to %u of %u\n",
                   instance->sensor_len,
                   instance->fifo_bytes_so_far,
                   instance->fifo_bytes_so_far + instance->sensor_len - 1,
                   instance->fifo_bytes_remaining);
      }

#ifdef VBE_DBG_FIFO_READ
      info_log("vbe read fifo start: % 3u, buf offset: %u, read len: %u\n", start, instance->sensor_buf, instance->sensor_len);
#endif

      if (!i2c_blocking_read(instance->i2c_handle, start, instance->sensor_buf, instance->sensor_len))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         instance->fifo_bytes_remaining = fifo_bytes_remaining;
         return FALSE;
      }
      instance->sensor_buf_idx = 0;
      instance->sensor_buf_valid_data_size = instance->sensor_bytes_read;
      if (!process_fifo_chunk(instance))
      {
         error_log("process_fifo_chunk found an invalid event. Bytes processed %u/%u B\n",
                   instance->sensor_buf_idx, instance->sensor_buf_valid_data_size);
         instance->fifo_bytes_remaining = fifo_bytes_remaining;
         return FALSE;
      }

      fifo_bytes_remaining -= instance->sensor_bytes_read;
      instance->fifo_bytes_so_far += instance->sensor_bytes_read;
      instance->total_bytes_transferred += instance->sensor_bytes_read;
   }
   instance->fifo_bytes_remaining = fifo_bytes_remaining;
   instance->total_host_transfers++;
   return TRUE;
}

// di_read_fifo bellow is demonstration how to use blocking i2c read
bool di_read_fifo(DI_INSTANCE_T *instance, bool *done, u16 timeout_ms, u32 interrupt_delayed_reponse_ms)
{
   static u8 buf[6];
   u32 start_ms;
   static TS_T last_hits = 0;

   if (!DI_PRECHECK_FULL(instance))
   {
      INSTANCE_ERROR(DE_INVALID_INSTANCE);
      instance->state = DS_IDLE;                                     // reset state machine as a side-effect
      return FALSE;
   }
   instance->state = DS_IDLE;

   // call routine used to simulate interrupts on some platforms
   irq_check(instance->irq_handle);

   if (done)
      *done = FALSE;

   start_ms = time_ms();

   while (instance->interrupt == instance->prev_int_count)        // check for recent data ready interrupt
   {
      irq_check(instance->irq_handle);
      if ((time_ms() >= (start_ms + timeout_ms)) && (timeout_ms != 0xffff)) // 0xffff means wait forever
         return TRUE;
   }
   if (!instance->interrupt)
   {
      return TRUE;
   }

   // this is used to simulate slow response on customer phone for issue 374
   if (interrupt_delayed_reponse_ms)
      time_delay_ms(interrupt_delayed_reponse_ms);

#if 0
   if (!i2c_blocking_read(instance->i2c_handle, SR_ERROR_REGISTER, (u8 *)&instance->error.error_register, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   if (instance->error.error_register)
   {
      info_log("Error 0x%04X detected!\n", instance->error.error_register);
   }
#endif

#if 0
   // optionally check the host status register to see if we reset (due to watchdog timeout or other fatal error)
   if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_STATUS, &instance->error.host_status.reg, 1))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   if (instance->error.host_status.bits.CPUReset)
   {
      info_log("Reset interrupt!\n");
      return FALSE;
   }
#endif
#if 1
   if (!di_read_registers(instance, SR_INT_STATUS, SR_INT_STATUS, &instance->error.int_status.reg))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }
   if (!instance->error.int_status.bits.HostInterrupt)
      return TRUE;
#endif

   instance->prev_int_count = instance->interrupt;
   instance->prev_i2c_count = instance->i2c_interrupt;
   instance->fifo_bytes_so_far = instance->fifo_bytes_remaining = 0;
   instance->cur_sample.sensor = DST_NOP;

   if (instance->hi_id != HIID_KITKAT)
   {
      if (!di_read_registers(instance, SR_HOST_IRQ_TIMESTAMP, SR_HOST_IRQ_TIMESTAMP + 3, (u8 *)&instance->host_irq_timestamp))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      instance->host_irq_timestamp = (u32)((((u64)instance->host_irq_timestamp) * SENSOR_SCALE_TIME_NUM) / SENSOR_SCALE_TIME_DEN);
   }

   if (!di_read_registers(instance, SR_BYTES_REMAINING_LSB, SR_BYTES_REMAINING_LSB + 1, buf))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   instance->fifo_bytes_remaining = ((u16)buf[0]) + (((u16)buf[1]) << 8);
   if (!instance->fifo_bytes_remaining)
   {
      info_log("Zero length FIFO!  IRQ = %u, Int Status = 0x%02X\n", irq_check(instance->irq_handle), instance->error.int_status.reg);
   }

   if (instance->dump_raw_data)
   {
      debug_log("fifo bytes remaining: %u; host irq ts %I64u, delta %I64u\n", instance->fifo_bytes_remaining,
               instance->host_irq_timestamp, instance->host_irq_timestamp - last_hits);
   }
   last_hits = instance->host_irq_timestamp;

   instance->prev_i2c_count = instance->i2c_interrupt;
   if (!di_read_fifo_known_bytes_remaining(instance))
   {
      return FALSE;
   }

   if (done)
      *done = TRUE;
   return TRUE;
}


#else // old parser

static bool timestamp_cur_sample(DI_INSTANCE_T *instance)
{
   static u16 prev_lsw[2] = {0, 0};
   static u16 prev_msw[2] = {0, 0};
   static u64 prev_timestamp[2] = {0, 0};
   DI_SENSOR_TYPE_T sensor;
#if defined(TIMESTAMP_STATS) // !defined(DI_SLIM)
   DI_SENSOR_INFO_T *info;
#endif
   bool ret = TRUE;
   int fifo;
#define N 10 /**< IIR filter period */
#define K 3  /**< IIR filter feedback */

   if (!instance)                                                    // reset local data
   {
      prev_lsw[0] = 0;
      prev_msw[0] = 0;
      prev_timestamp[0] = 0;
      prev_lsw[1] = 0;
      prev_msw[1] = 0;
      prev_timestamp[1] = 0;
      return TRUE;
   }
   sensor = instance->cur_sample.sensor;

#if defined(TIMESTAMP_STATS)
   if (sensor <= di_max_sensor_id(instance))
      info = &instance->sensor_info[sensor];
   else
      info = NULL;
#endif
#if !defined(DI_SLIM)
   fifo = is_wakeup_event(instance, sensor) ? 1 : 0;
#else
   fifo = 0;
#endif

   prev_timestamp[fifo] = instance->cur_timestamp[fifo];
   if ((sensor == DST_TIMESTAMP_LSW)
#if !defined(DI_SLIM)
       || (sensor == DST_WAKEUP_TIMESTAMP_LSW)
#endif
      )
   {
      prev_lsw[fifo] = instance->cur_sample.timestamp_lsw.datum;
      if (!instance->quiet_meta_events && instance->dump_raw_data)
         debug_log("timestamp LSW: %u\n", prev_lsw[fifo]);
      instance->cur_timestamp[fifo] = (((((u64)prev_lsw[fifo]) | (((u64)prev_msw[fifo]) << 16)) * SENSOR_SCALE_TIME_NUM) / SENSOR_SCALE_TIME_DEN);
      // this detects out-of-order but unrelated timestamps; this is expected by design due to the variety of execution priorities these can be generated from;
      // I'm relaxing this test to permit slips under 5ms (200Hz), the BSX tick rate
      if ((instance->cur_timestamp[fifo] + ALLOWED_SLIP_US) < prev_timestamp[fifo])
      {
         if (!instance->quiet_timestamp_errors)
            error_log("timeslip: was %I64u us, is %I64u us, by %I64d us\n",
                      prev_timestamp[fifo], instance->cur_timestamp[fifo], (s32)prev_timestamp[fifo] - (s32)instance->cur_timestamp[fifo]);
         instance->total_timeslips++;
         ret = FALSE;
      }
   }
   else if ((sensor == DST_TIMESTAMP_MSW)
#if !defined(DI_SLIM)
            || (sensor == DST_WAKEUP_TIMESTAMP_MSW)
#endif
           )
   {
      prev_msw[fifo] = instance->cur_sample.timestamp_msw.datum;
      instance->cur_timestamp[fifo] = ((((((u64)prev_msw[fifo]) << 16)) * SENSOR_SCALE_TIME_NUM) / SENSOR_SCALE_TIME_DEN);
      if (!instance->quiet_meta_events && instance->dump_raw_data)
         debug_log("timestamp MSW: %u\n", prev_msw[fifo]);
   }
   else if ((sensor != DST_RAW_DEBUG_OUTPUT_GYRO) && (sensor != DST_RAW_DEBUG_OUTPUT_ACCEL) && (sensor != DST_RAW_DEBUG_OUTPUT_MAG))
   {
#if defined(TIMESTAMP_STATS) // !defined(DI_SLIM)
      if (info)   // analyze timestamps
      {
         if (info->timestamp_prev && info->rate)
         {
            if (!info->timestamp_delta || (info->rate != info->prev_rate))
            {
               info->timestamp_delta = 1000000 / info->rate;
               info->prev_rate = info->rate;
            }
            if ((instance->cur_timestamp[fifo] < info->timestamp_prev) && di_is_sensor_continuous(instance, sensor))
            {
               if (!instance->quiet_timestamp_errors)
                  info_log("slip: sensor %u, by: %I64u, sample: %u\n", sensor, info->timestamp_prev - instance->cur_timestamp[fifo], info->samples_received);
               info->timestamp_slips++;
               instance->total_timeslips++;
               ret = FALSE;
            }
            else if (instance->cur_timestamp[fifo] == info->timestamp_prev) // check for dups even for non-continuous sensors
            {
               if (!instance->quiet_timestamp_errors)
                  info_log("dup: sensor: %u, ts: %I64u, sample: %u\n", sensor, instance->cur_timestamp[fifo], info->samples_received);
               info->timestamp_dups++;
               instance->total_timedups++;
               ret = FALSE;
            }
            else
            {
               if ((instance->cur_timestamp[fifo] > (info->timestamp_prev + (info->timestamp_delta * 3) / 2)) && di_is_sensor_continuous(instance, sensor))
               {
                  if (!instance->quiet_timestamp_errors)
                     info_log("gap: sensor: %u, exp: %I64u, got: %I64u, sample: %u\n", sensor, info->timestamp_delta, instance->cur_timestamp[fifo] - info->timestamp_prev, info->samples_received);
                  info->timestamp_gaps++;
                  instance->total_timegaps++;
                  ret = FALSE;
               }
               info->timestamp_delta_sum = (instance->cur_timestamp[fifo] - info->timestamp_prev) * K + info->timestamp_delta * (N - K);
               info->timestamp_delta = info->timestamp_delta_sum / N;
            }
         }
         else                                                        // start up period measurements
         {
            if (info->rate)
               info->timestamp_delta = 1000000 / info->rate;
            else
               info->timestamp_delta = 0;
         }
         info->timestamp_prev = instance->cur_timestamp[fifo];
      }
#endif
      // finally, store the actual timestamp at the end of the current sample
      memcpy(&instance->cur_sample.data[instance->cur_sample_len], &instance->cur_timestamp[fifo], sizeof(instance->cur_timestamp[0]));
   }
   else
   {
      insane_log("BSX\n");
   }
#if 0
   if (!ret && !instance->quiet_timestamp_errors)
   {
      j = i - 97;
      if (j < 0)
      j = 0;
      debug_txt[0] = '\0';
      for (k = 0; k < 128; j++)
      {
         sprintf(debug_val, "%s%02X%s", (j == (i - 3)) ? "|" : " ", instance->sensor_buf[j], (j == (i - 1)) ? "|" : " ");
         strcat(debug_txt, debug_val);
         k++;
         if (k && !(k % 32))
         strcat(debug_txt, "\n");
      }
      info_log("%s", debug_txt);
   }
#endif
   return ret;
}


static void store_cur_sample(DI_INSTANCE_T *instance)
{
   void *dst;

   dst = get_sensor_pointer(instance, &instance->last_sample, (DI_SENSOR_TYPE_T)instance->cur_sample.sensor);
   if (dst)
   {
      memcpy(dst, &instance->cur_sample, get_sensor_data_size((DI_SENSOR_TYPE_T)instance->cur_sample.sensor));
      if (instance->cur_sample.sensor <= di_max_sensor_id(instance))
         instance->sensor_info[instance->cur_sample.sensor].valid = TRUE;
#if !defined(DI_SLIM)
      else if ((instance->cur_sample.sensor >= DST_RAW_DEBUG_OUTPUT_GYRO) && (instance->cur_sample.sensor <= DST_RAW_DEBUG_OUTPUT_ACCEL))
         instance->sensor_info_raw[instance->cur_sample.sensor - DST_RAW_DEBUG_OUTPUT_GYRO].valid = TRUE;
#endif
   }
}


bool process_fifo_chunk(DI_INSTANCE_T *instance, u16 bytes_read)
{
   extern void display_meta_event(DI_INSTANCE_T * instance, DI_META_EVENT_INT_DATA_T * meta); // for debug
   int i;
   int j;
   int k;
   static u8 s = 0;
   char debug_val[8];
   char debug_txt[1024];


   if (instance->dump_raw_data)
   {
      for (i = 0; i < bytes_read; i += 16)
      {
         for (j = 0; j < 16; j++)
         {
            if ((i + j) >= bytes_read)
               break;
            sprintf(&debug_txt[j * 3], "%02X ", instance->sensor_buf[i + j]);
         }
         debug_log("%04X: %s\n", i, debug_txt);
      }
   }

   for (i = 0; i < bytes_read;)
   {
      // parse instance->sensor_buf
      if (instance->cur_sample.sensor == DST_NOP)                    // starting a new sensor
      {
         s = instance->sensor_buf[i++];
         instance->cur_sample_len = get_sensor_data_wire_size(s);
         if (instance->cur_sample_len)                               // valid sensor type?
         {
            instance->cur_sample_idx = 1;                            // we have the first byte already...
            instance->cur_sample.sensor = s;
            if (instance->cur_sample_idx < instance->cur_sample_len) // fall through if we have a whole sample, otherwise keep getting bytes
               continue;
         }
         else
         {
            if (s != DST_NOP)
            {
               error_log("invalid sensor %u at offset %u of %u; total bytes so far %u\n", s, instance->fifo_bytes_so_far + i - 1, instance->fifo_bytes_remaining + instance->fifo_bytes_so_far, instance->total_bytes_transferred);
               j = i - 25;
               if (j < 0)
                  j = 0;
               debug_txt[0] = '\0';
               for (k = 0; k < 48; k++, j++)
               {
                  sprintf(debug_val, "%s%02X%s", (j == (i - 1)) ? "|" : "", instance->sensor_buf[j], (j == (i - 1)) ? "| " : " ");
                  strcat(debug_txt, debug_val);
               }
               insane_log("%s\n", debug_txt);
               instance->total_invalid_samples_received++;
               continue;                                             // not valid; we should probably resync with the chip at this point...
            }
            else
            {
               instance->total_pad_bytes_received++;
               break;
            }
         }
      }
      if (instance->cur_sample_idx < instance->cur_sample_len)
         instance->cur_sample.data[instance->cur_sample_idx++] = instance->sensor_buf[i++];
      if (instance->cur_sample_idx >= instance->cur_sample_len)
      {
         if (instance->dump_raw_data)
            debug_log("sample: sensor %u (%s) len %u\n", s, instance->cur_sample_len);
         timestamp_cur_sample(instance);                             // append the most recent timestamp or update the timestamp if that's the sensor type

         store_cur_sample(instance);                                 // copy it to the correct place in the last_sample structure
         if (s <= di_max_sensor_id(instance))
            instance->sensor_info[s].samples_received++;
         else
         {
            if ((s >= DST_RAW_DEBUG_OUTPUT_GYRO) && (s <= DST_RAW_DEBUG_OUTPUT_ACCEL))
               instance->sensor_info_raw[s - DST_RAW_DEBUG_OUTPUT_GYRO].samples_received++;
            if ((s - DST_FIRST_EXTRA_SENSOR) <= DST_LAST_EXTRA_SENSOR)
               instance->other_events[s - DST_FIRST_EXTRA_SENSOR]++;
         }
         instance->total_samples_received++;
         if (s == DST_META_EVENT)
         {
            instance->cur_sample.meta.sensor = s;
            if (instance->cur_sample.meta.event_id < DME_NUM_META_EVENTS)
               instance->meta_events[instance->cur_sample.meta.event_id]++;
            // allow most meta events to be suppressed, but do not suppress errors
            if (!instance->quiet_meta_events || (instance->cur_sample.meta.event_id == DME_ERROR) || (instance->cur_sample.meta.event_id == DME_SENSOR_ERROR))
               display_meta_event(instance, &instance->cur_sample.meta);
         }
#if !defined(DI_SLIM)
         else if (s == DST_WAKEUP_META_EVENT)
         {
            instance->cur_sample.meta.sensor = s;
            if (instance->cur_sample.meta.event_id < DME_NUM_META_EVENTS)
               instance->meta_events_wakeup[instance->cur_sample.meta.event_id]++;
            if (!instance->quiet_meta_events || (instance->cur_sample.meta.event_id == DME_ERROR) || (instance->cur_sample.meta.event_id == DME_SENSOR_ERROR))
               display_meta_event(instance, &instance->cur_sample.meta);
         }
#endif
         if (instance->data_callback)
            instance->data_callback(instance, s, &instance->last_sample, instance->user_param);
         instance->cur_sample.sensor = DST_NOP;
      }
   }
   return TRUE;
}

void debug_xfer(DI_INSTANCE_T *instance)
{
   u8 buf[3];
   if (di_read_registers(instance, SR_I2C_SLVRD_INT_LOC, SR_I2C_SLVRD_INT_LOC + 2, buf))
   {
      insane_log("I2C Int Loc: %u, Buf Ctrl: 0x%02X, Buf Count: %u\n", buf[0], buf[1], buf[2]);
   }
}

bool di_task_loop(DI_INSTANCE_T *instance, bool *done)
{
   static u8 buf[2];
   u8 start;

   if (!DI_PRECHECK_FULL(instance))
   {
      INSTANCE_ERROR(DE_INVALID_INSTANCE);
      instance->state = DS_IDLE;                                     // reset state machine as a side-effect
      return FALSE;
   }

   // call routine used to simulate interrupts on some platforms
   irq_check(instance->irq_handle);

   if (done)
      *done = FALSE;

   insane_log("task loop state: %d\n", instance->state);


   switch (instance->state)
   {
      case DS_IDLE:
         if (instance->interrupt == instance->prev_int_count)        // check for recent data ready interrupt
            break;

      case DS_QUERY_BYTES_REMAINING:
         while (instance->prev_int_count != instance->interrupt)     // loop to prevent race conditions
            instance->prev_int_count = instance->interrupt;
         instance->prev_i2c_count = instance->i2c_interrupt;
         instance->fifo_bytes_so_far = instance->fifo_bytes_remaining = 0;
         instance->cur_sample.sensor = DST_NOP;
         //debug_xfer(instance);
         if (!i2c_read_start(instance->i2c_handle, SR_BYTES_REMAINING_LSB, buf, 2))
         {
            INSTANCE_ERROR(DE_I2C_ERROR);
            return FALSE;
         }

         irq_check(instance->irq_handle);                            // on systems with simulated interrupts, check immediately after reading event status to try to catch deassertion of interrupt
         instance->prev_int_count = instance->interrupt;
         instance->state = DS_WAIT_BYTES_REMAINING;
         break;

      case DS_WAIT_BYTES_REMAINING:
         if (instance->i2c_interrupt == instance->prev_i2c_count)
            return TRUE;
         instance->prev_i2c_count = instance->i2c_interrupt;         // no need to loop; we presume no other I2C int can occur now
         if ((instance->sensor_complete != TS_I2C_COMPLETE) || (instance->sensor_rlen != 2)) // check status of I2C transfer
         {
            INSTANCE_ERROR(DE_I2C_ERROR);
            instance->state = DS_IDLE;
            return FALSE;
         }
         // we have the number of bytes pending in the chip's buffer
         instance->fifo_bytes_remaining = ((u16)buf[0]) + (((u16)buf[1]) << 8);
#if defined(DEBUG_EVENTS)
         /** for debugging only, keep a history of recent events */
         event_hist[event_index] = 0;                                // \todo: decide what to log... event_status.reg;
         event_time[event_index++] = time_ms();
         if (event_index >= EVENT_COUNT)
            event_index = 0;
#endif
         // reading this is asynchronous, so log it manually here
         if (instance->dump_raw_data)
            debug_log("fifo bytes remaining: %u\n", instance->fifo_bytes_remaining);
         if (!instance->fifo_bytes_remaining)
         {
            //error_log("host int but bytes remaining == 0\n");
            instance->state = DS_IDLE;
            break;
         }
         instance->state = DS_START_READ_FIFO;

      case DS_START_READ_FIFO:
         instance->prev_int_count = instance->interrupt;
         // we can read "clean" bytes and as much as we have space for
         instance->sensor_bytes_read = instance->sensor_buf_max_xfer_size;
         if (instance->fifo_bytes_remaining < instance->sensor_bytes_read)
            instance->sensor_bytes_read = instance->fifo_bytes_remaining;
         start = SR_BUFFER_OUT_START;
         instance->sensor_len = instance->sensor_bytes_read;
         if (instance->dump_raw_data)
         {
            debug_log("reading %u bytes %u to %u of %u\n",
                      instance->sensor_len,
                      instance->fifo_bytes_so_far,
                      instance->fifo_bytes_so_far + instance->sensor_len - 1,
                      instance->fifo_bytes_so_far + instance->fifo_bytes_remaining);
         }
         // if we restart a paused transfer, we need to start at fifo_bytes_so_far % 50
         // time_delay_us(100);
         if (i2c_read_start(instance->i2c_handle, start, instance->sensor_buf, instance->sensor_len))
         {
            instance->state = DS_WAIT_READ_FIFO;
         }
         else
         {
            instance->state = DS_QUERY_BYTES_REMAINING;
            return FALSE;
         }
         break;

      case DS_WAIT_READ_FIFO:
         if (instance->i2c_interrupt == instance->prev_i2c_count)
            return TRUE;
         instance->prev_i2c_count = instance->i2c_interrupt;         // no need to loop; we presume no other I2C int can occur now
         if ((instance->sensor_complete != TS_I2C_COMPLETE) || (instance->sensor_rlen != instance->sensor_len))
         {
            INSTANCE_ERROR(DE_I2C_ERROR);
            instance->state = DS_IDLE;
            return FALSE;
         }
         //debug_xfer(instance);
         instance->state = DS_PARSE_FIFO;
         break;
      case DS_PARSE_FIFO:
         process_fifo_chunk(instance, instance->sensor_bytes_read);
         instance->fifo_bytes_remaining -= instance->sensor_bytes_read;
         instance->fifo_bytes_so_far += instance->sensor_bytes_read;
         instance->total_bytes_transferred += instance->sensor_bytes_read;
         if (!instance->fifo_bytes_remaining)
         {
            if (instance->cur_sample.sensor != DST_NOP)
            {
               error_log("incomplete sample at end of FIFO: sensor ID:%u, index:%u, len:%u\n", instance->cur_sample.sensor, instance->cur_sample_idx, instance->cur_sample_len);
               instance->total_invalid_samples_received++;
            }
            instance->total_host_transfers++;
            instance->state = DS_IDLE;
            if (done)
               *done = TRUE;
         }
         else
         {
            instance->state = DS_START_READ_FIFO;
         }
         break;
   }
   return TRUE;
}


/// \todo implement pause / resume of long reads (restart at address fifo_bytes_so_far % 50)
bool di_pause_task_loop(DI_INSTANCE_T *instance)
{
   while (instance->state != DS_IDLE)
   {
      if (!di_task_loop(instance, NULL))
      {
         return FALSE;
      }
   }
   return TRUE;
}


bool di_read_fifo(DI_INSTANCE_T *instance, bool *done, u16 timeout_ms, u32 interrupt_delayed_reponse_ms)
{
   static u8 buf[2];
   u8 start;
   u32 start_ms;

   if (!DI_PRECHECK_FULL(instance))
   {
      INSTANCE_ERROR(DE_INVALID_INSTANCE);
      instance->state = DS_IDLE;                                     // reset state machine as a side-effect
      return FALSE;
   }
   instance->state = DS_IDLE;

   // call routine used to simulate interrupts on some platforms
   irq_check(instance->irq_handle);

   if (done)
      *done = FALSE;

   start_ms = time_ms();

   for (;;)
   {
      while (instance->interrupt == instance->prev_int_count)        // check for recent data ready interrupt
      {
         irq_check(instance->irq_handle);
         if ((time_ms() >= (start_ms + timeout_ms)) && (timeout_ms != 0xffff)) // 0xffff means wait forever
            return TRUE;
      }

      // this is used to simulate slow response on customer phone for issue 374
      if (interrupt_delayed_reponse_ms)
         time_delay_ms(interrupt_delayed_reponse_ms);

      /*
      remove extra 718x error checking for now:
      if (!i2c_blocking_read(instance->i2c_handle, SR_ERROR_REGISTER, &instance->error.error_register, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }
      if (instance->error.error_register)
      {
         info_log("Error 0x%04X detected!\n", instance->error.error_register);
      }

      if (!i2c_blocking_read(instance->i2c_handle, SR_HOST_STATUS, &instance->error.host_status.reg, 1))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }

      if (instance->error.host_status.bits.CPUReset)
      {
         info_log("Reset interrupt!\n");
         return FALSE;
      }*/

      instance->prev_int_count = instance->interrupt;
      instance->prev_i2c_count = instance->i2c_interrupt;
      instance->fifo_bytes_so_far = instance->fifo_bytes_remaining = 0;
      instance->cur_sample.sensor = DST_NOP;

      if (!di_read_registers(instance, SR_BYTES_REMAINING_LSB, SR_BYTES_REMAINING_LSB + 1, buf))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }

      instance->fifo_bytes_remaining = ((u16)buf[0]) + (((u16)buf[1]) << 8);
      if (instance->fifo_bytes_remaining)
         break;

      if ((time_ms() >= (start_ms + timeout_ms)) && (timeout_ms != 0xffff)) // 0xffff means wait forever
         return TRUE;
   }

   if (instance->dump_raw_data)
      debug_log("fifo bytes remaining: %u\n", instance->fifo_bytes_remaining);
   start = SR_BUFFER_OUT_START;

   // we can read "clean" bytes and as much as we have space for
   instance->sensor_bytes_read = instance->sensor_buf_max_xfer_size;

   while (instance->fifo_bytes_remaining)
   {
      if (instance->fifo_bytes_remaining < instance->sensor_bytes_read)
         instance->sensor_bytes_read = instance->fifo_bytes_remaining;
      instance->sensor_len = instance->sensor_bytes_read;

      //if (instance->dump_raw_data)
      debug_log("reading %u bytes %u to %u of %u\n",
               instance->sensor_len,
               instance->fifo_bytes_so_far,
               instance->fifo_bytes_so_far + instance->sensor_len - 1,
               instance->fifo_bytes_so_far + instance->fifo_bytes_remaining);
      //time_delay_us(100);
      if (!i2c_blocking_read(instance->i2c_handle, start, instance->sensor_buf, instance->sensor_len))
      {
         INSTANCE_ERROR(DE_I2C_ERROR);
         return FALSE;
      }

      process_fifo_chunk(instance, instance->sensor_bytes_read);

      instance->fifo_bytes_remaining -= instance->sensor_bytes_read;
      instance->fifo_bytes_so_far += instance->sensor_bytes_read;
      instance->total_bytes_transferred += instance->sensor_bytes_read;
   }
   if (instance->cur_sample.sensor != DST_NOP)
   {
      error_log("incomplete sample at end of FIFO: sensor ID:%u, index:%u, len:%u\n", instance->cur_sample.sensor, instance->cur_sample_idx, instance->cur_sample_len);
      instance->total_invalid_samples_received++;
   }

   instance->total_host_transfers++;

   if (done)
      *done = TRUE;
   return TRUE;
}



#endif



bool di_passthrough_enter(DI_INSTANCE_T *instance, I2C_HANDLE_T i2c_handle)
{
   //if (!di_standby_request(instance))
   //   return FALSE;

   if (!di_set_passthrough_mode(instance, TRUE))
      return FALSE;

   instance->passthrough_handle = i2c_handle;
   return TRUE;
}


bool di_passthrough_exit(DI_INSTANCE_T *instance)
{
   if (!di_set_passthrough_mode(instance, FALSE))
      return FALSE;

   instance->passthrough_handle = 0;

   return TRUE;
}


/** @}*/

