/**
 * \file    driver_ext.c
 *
 *
 * \brief  extended interface to the generic host driver, which provides
 *         additional functionality to make it easier to integrate the generic
 *         host driver core with an application.
 *
 * \copyright (C) 2013-2014 EM Microelectronic
 *
 */

#include <stdio.h>
#include <string.h> // will need conditionals to offer cross-platform version
#include <math.h>
#include "config.h"
#include "driver_ext.h"
#include "EEPROMImage.h"
#include "driver_util.h"

/** \addtogroup Driver_Ext
 *  @{
 */

#define QUERY_SENSOR_TIMEOUT_MS 1000                                 /**< timeout value for querying a sensor */
#define SINGLE_INSTANCE                                              /**< only one */

#if defined(SINGLE_INSTANCE)
static /*VOLATILE*/ DI_INSTANCE_T the_instance;                      /**< there is only one U718x; this is the driver-related data for it */
#else
/// \todo user: provide a mechanism for allocating one or more instances as needed
#endif

#define CONFIG_FILE_BUF_LEN 32                                       /**< number of bytes to read from config file at a time while uploading to RAM; allocated on the stack; must be 4 */

/**
 *  \brief in driver ID order, a table of human-readable names for sensor
 *         drivers */
struct driver_lookup
{
   u8 id;                                                            /**< the driver id corresponding to a name */
   const char *name;                                                 /**< the name of the driver; usually consists of model number plus sensor type (accel, gyro, mag, etc.) */
};

#if defined(__LPC13UXX__)
static const struct driver_lookup driver_names[] =
{
   {0x00, "none"},                                                   // 0
   {0, NULL}                                                         //
};
#else
static const struct driver_lookup driver_names[] =
{
   {0x00, "none"},                                                   // 0
   {0x01, "BMX055 old"},                                             // 1
   {0x02, "RM3100 mag"},                                             // 2
   {0x03, "AK8963 mag"},                                             // 3
   {0x04, "AK8975 mag"},                                             // 4
   {0x05, "LSM330DLC accel"},                                        // 5
   {0x06, "LSM330 gyro"},                                            // 6
   {0x07, "LSM330 accel"},                                           // 7
   {0x08, "BMX055 mag"},                                             // 8
   {0x09, "BMX055 accel"},                                           // 9
   {0x0a, "BMX055 gyro"},                                            // 10
   {0x0b, "n/a"},                                                    // 11
   {0x0c, "LSM9SD0 accel"},                                          // 12
   {0x0d, "LSM9SD0 mag"},                                            // 13
   {0x0e, "LSM9SD0 gyro"},                                           // 14
   {0x0f, "MPU6500 accel"},                                          // 15
   {0x10, "MPU6500 gyro"},                                           // 16
   {0x11, "MPU9250 accel"},                                          // 17
   {0x12, "MPU9250 gyro"},                                           // 18
   {0x13, "MPU9250 mag"},                                            // 19
   {0x14, "AK09911 mag"},                                            // 20
   {0x15, "BMP280P baro"},                                           // 21
   {0x1b, "BMP280 baro"},                                            // 27
   {0x20, "BMI160P accel"},                                          // 32
   {0x21, "BMI160P gyro"},                                           // 33
   {0x22, "LSM6DS3 accel"},                                          // 34
   {0x23, "LSM6DS3 gyro"},                                           // 35
   {0x24, "LSM303ARG accel"},                                        // 36
   {0x25, "LSM303ARG mag"},                                          // 37
   {0x2d, "BMI160 sigmot"},                                          // 45
   {0x2e, "BMI160 stepdet"},                                         // 46
   {0x2f, "BMI160 stepcnt"},                                         // 47
   {0x30, "BMI160 accel"},                                           // 48
   {0x31, "BMI160 gyro"},                                            // 49
   {0x40, "TMP112 temp"},                                            // 64
   {0x63, "LPS25H baro"},                                            // 99
   {0x7f, "Virt SP kalman"},                                         // 127
   {0x80, "Virt SP T1"},                                             // 128
   {0x81, "Virt SP accel"},                                          // 129
   {0x82, "Virt SP gyro"},                                           // 130
   {0x83, "Virt SP mag"},                                            // 131
   {0x86, "Virt SP stepdet"},                                        // 134
   {0x87, "Virt SP stepcnt"},                                        // 135
   {0x89, "Virt SP smt calc"},                                       // 137
   {0x8a, "Virt SP rotation"},                                       // 138
   {0x8b, "Virt SP gamerot"},                                        // 139
   {0x8c, "Virt SP georot"},                                         // 140
   {0x8d, "Virt SP orient"},                                         // 141
   {0x8f, "Virt SP gyro uncal"},                                     // 143
   {0x90, "Virt SP mag uncal"},                                      // 144
   {0x91, "Virt accel"},                                             // 145
   {0x92, "Virt gyro"},                                              // 146
   {0x93, "Virt mag"},                                               // 147
   {0x94, "Virt SP accel calc"},                                     // 148
   {0x95, "Virt SP gyro calc"},                                      // 149
   {0x96, "Virt SP mag calc"},                                       // 150
   {0x97, "Virt SP tiltdet"},                                        // 151
   {0x98, "Virt SP sigmot"},                                         // 152
   {0xA0, "Virt SP linacc"},                                         // 160
   {0xA1, "Virt SP gravity"},                                        // 161
   {0xA2, "Virt SP Rotation MA"},                                    // 162
   {0xA3, "Virt SP Orient MA"},                                      // 163
   {0xA4, "Virt SP Motion Stat Meas"},                               // 164
   {0xA5, "Virt SP Gesture Pickup"},                                 // 165
   {0xA6, "Virt SP Gesture Shake"},                                  // 166
   {0xA7, "Virt SP Gesture Turn Over"},                              // 167
   {0xA8, "Virt SP Cal Status"},                                     // 168
   {0xA9, "Virt SP Motion Classifier"},                              // 169
   {0xC8, "Virt SP cal status"},                                     // 200
   {0xC9, "Jerk Example"},                                           // 201
   {0xCA, "Mouse Example"},                                          // 202
   {0xe0, "Virt hang det"},                                          // 224
   {0xe4, "Virt BSX baro"},                                          // 228
   {0xe8, "Virt BSX wakegest"},                                      // 232
   {0xe9, "Virt BSX pickupgest"},                                    // 233
   {0xea, "Virt BSX glancegest"},                                    // 234
   {0xeb, "Virt BSX activity"},                                      // 235
   {0xec, "Virt BSX tilt"},                                          // 236
   {0xed, "Virt bmi160 stepdet"},                                    // 237
   {0xee, "Virt bmi160 stepcnt"},                                    // 238
   {0xef, "Virt bmi160 sigmot"},                                     // 239
   {0xf0, "Virt BSX"},                                               // 240
   {0xf1, "Virt BSX accel"},                                         // 241
   {0xf2, "Virt BSX mag"},                                           // 242
   {0xf3, "Virt BSX gyro"},                                          // 243
   {0xf4, "Virt BSX gyro uncal"},                                    // 244
   {0xf5, "Virt BSX mag uncal"},                                     // 245
   {0xf6, "Virt BSX linacc"},                                        // 246
   {0xf7, "Virt BSX gravity"},                                       // 247
   {0xf8, "Virt BSX stepdet"},                                       // 248
   {0xf9, "Virt BSX stepcnt"},                                       // 249
   {0xfa, "Virt BSX sigmot"},                                        // 250
   {0xfb, "Virt BSX rotation"},                                      // 251
   {0xfc, "Virt BSX gamerot"},                                       // 252
   {0xfd, "Virt BSX georot"},                                        // 253
   {0xfe, "Virt BSX orient"},                                        // 254
   {0, NULL}                                                         //
};
#endif

/**
 *  \brief order must match DI_SENSOR_TYPE enumeration in driver_interface.h
 */
#define NUM_SENSOR_NAMES DST_NUM_SENSOR_TYPES
#if !defined(__LPC13UXX__)
static const char *sensor_names[255] =
{
   "Nop",
   "Accelerometer", "Geomagnetic Field", "Orientation", "Gyroscope", "Light",
   "Pressure", "Temperature", "Proximity", "Gravity", "Linear Acceleration",
   "Rotation Vector", "Relative Humidity", "Ambient Temperature", "Magnetic Field Uncalibrated", "Game Rotation Vector",
   "Gyroscope Uncalibrated", "Significant Motion", "Step Detector", "Step Counter", "Geomagnetic Rotation Vector",
   "Heart Rate", "Tilt Detector", "Wake Gesture", "Glance Gesture", "Pickup Gesture",
   "", "", "", "Jerk Example", "Cal Status", "Activity",
};
#endif

/**
 *  \brief order must match DI_SENSOR_TYPE enumeration in driver_interface.h
 */
static const char *sensor_short_names[255] =
{
   "Nop",
   "Accel", "MagField", "Orient", "Gyro", "Light",
   "Pressure", "Temp", "Prox", "Grav", "LinAccel",
   "RotVect", "Humid", "AmbTemp", "MagUncal", "GameRotVect",
   "GyroUncal", "SigMot", "StepDet", "StepCnt", "MagRotVect",
   "HrtRte", "Tilt", "WkGest", "GlGest", "PuGest",
   "", "", "", "Jerk", "CalStat", "Act",
};
#if defined(__LPC13UXX__)
#define sensor_names sensor_short_names
#endif

/**
 * extra event names
 */
#define NUM_EXTRA_EVENTS (DST_LAST_EXTRA_SENSOR - DST_FIRST_EXTRA_SENSOR + 1)
#if !defined(__LPC13UXX__)
static const char *extra_event_names[NUM_EXTRA_EVENTS] =
{
#if !defined(DI_SLIM)
   "Debug", "Wakeup Timestamp LSW", "Wakeup Timestamp MSW", "Wakeup Meta Event",
#endif
   "Raw Debug Output Gyro", "Raw Debug Output Mag", "Raw Debug Output Accel",
   "Timestamp LSW", "Timestamp MSW", "Meta Event"
};
#else
static const char *extra_event_names[NUM_EXTRA_EVENTS] =
{
#if !defined(DI_SLIM)
   "DBG", "WTSLSW", "WTSMSW", "WMetaEvent",
#endif
   "RAWG", "RAWM", "RAWA", "TSLSW", "TSMSW", "MetaEvent"
};
#endif

/**
 * meta event names
 */
#define NUM_META_NAMES DME_NUM_META_EVENTS
#if !defined(__LPC13UXX__)
static const char *meta_names[NUM_META_NAMES] =
{
   "None", "Flush Complete", "Sample Rate Changed", "Power Mode Changed", "Error", "Algorithm Event",
   "Cal Change", "Stillness Change", "Alg Slowdown", "Cal Stable", "Host IRQ Timestamp",
   "Sensor Error", "Fifo Overflow", "Dynamic Range Changed", "Fifo Watermark", "Sensor Self Test Results",
   "Initialized", "Transfer Cause", "Sensor Framework"
};
#else
static const char *meta_names[NUM_META_NAMES] =
{
   "None", "Flush", "RateCh", "PowerCh", "Err", "AlgEvent",
   "CalStat", "StillCh", "AlgSlow", "CalStbl", "HostIRQ",
   "SensErr", "FifoOF", "RngCh", "FifoMrk", "SlfTst",
   "Init", "Cause", "SnsFrmwrk"
};
#endif

/**
 *  \brief memory for sample data
 */
#if !defined(__LPC13UXX__)
#define SENSOR_BUF_SIZE 32750 // make it a multiple of 50 so multiple reads start at register 0
#else
#define SENSOR_BUF_SIZE 150 // make it a multiple of 50 so multiple reads start at register 0
#endif

static u8 sensor_buf[SENSOR_BUF_SIZE];

/**
 * \brief transfer completion callback type
 * \param handle - abstract handle to U718x via I2C
 * \param complete - status of transfer
 * \param len_transferred - the number of bytes read or written
 * \param user_param - the same value specified by the caller to
 *                   the original i2c_read_start() or
 *                   i2c_write_start() functions
 * \return bool indicating not sure what yet
 **/
bool i2c_callback(I2C_HANDLE_T handle, TransferStatus complete, u16 len_transferred, void *user_param);

/**
 * \brief IRQ callback type
 * \param handle - the host-specific handle to the IRQ that
 *               generated the callback
 * \param os_param - a host-specific additional value
 * \param user_param - the value specified on the call to
 *                   irq_register()
 */
bool irq_callback(IRQ_HANDLE_T handle, u32 os_param, void *user_param);


DI_INSTANCE_T *di_init(I2C_HANDLE_T i2c_handle, IRQ_HANDLE_T irq_handle, bool reset)
{
   DI_INSTANCE_T *instance = &the_instance;

   memset(instance, 0, sizeof(DI_INSTANCE_T));

   if (!i2c_handle || !irq_handle)
   {
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }

   if (!i2c_init(i2c_handle))
   {
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   if (!i2c_register(i2c_handle, i2c_callback, (void *)instance))
   {
      i2c_deinit(i2c_handle);
      INSTANCE_ERROR(DE_I2C_ERROR);
      return FALSE;
   }

   if (!irq_register(irq_handle, irq_callback, (void *)instance))
   {
      i2c_deinit(i2c_handle);
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }

   info_log("GHD FIFO buffer size: %u bytes\n", SENSOR_BUF_SIZE);
#if defined(TIMESTAMP_STATS)
   info_log("timestamp stats enabled\n");
#endif
   if (di_init_core(instance, sensor_buf, SENSOR_BUF_SIZE, i2c_handle, irq_handle, reset))
      return instance;
   else
      return NULL;
}

bool di_deinit(DI_INSTANCE_T *instance)
{
   bool ret;
   I2C_HANDLE_T thandle;

   INSTANCE_ERROR(DE_NONE);
   thandle = instance->i2c_handle;

   ret = di_deinit_core(instance);

   // release resources
   if (thandle)
      i2c_deinit(thandle);

   instance->initialized = FALSE;
   return ret;
}


bool di_upload_firmware(DI_INSTANCE_T *instance, char *firmware_filename, bool force_anyrom, UPLOAD_CALLBACK callback)
{
   u32 ofs;
   s32 olen;
   s32 flen;
   u16 rlen;
   u16 wlen;
   FILE_HANDLE_T file;
   EEPROMHeader header;
   u32 wbuf[CONFIG_FILE_BUF_LEN / 4];
   s32 percent;
   s32 prev_percent = -1;
   bool fail = FALSE;

   info_log("open firmware file %s\n", firmware_filename);

   // read the file header
   flen = file_size(firmware_filename);

   file = file_open(firmware_filename);
   if (file == NULL)
   {
      INSTANCE_ERROR(DE_FILE_OPEN_ERROR);
      return FALSE;
   }

   ofs = 0;
   info_log("read header...\n");
   if (!file_read(file, (u8 *)&header, sizeof(EEPROMHeader), &rlen))
   {
      file_close(file);
      INSTANCE_ERROR(DE_FILE_READ_ERROR);
      return FALSE;
   }
   if (rlen != sizeof(EEPROMHeader))
   {
      file_close(file);
      INSTANCE_ERROR(DE_FILE_READ_ERROR);
      return FALSE;
   }

   if (force_anyrom)
      header.flags.bits.ROMVerExp = ROM_VERSION_ANY;

   if (!di_upload_firmware_start(instance, &header))
      return FALSE;

   // upload the rest of the file
   flen -= rlen;
   olen = flen;
   ofs += rlen;

   while (flen > 0)
   {
      percent = (100 * ofs) / olen;
      if (percent != prev_percent)
      {
         prev_percent = percent;
         if (callback)
            callback((int)percent);
         info_log("%d%%\r", percent);
      }
      if (flen > CONFIG_FILE_BUF_LEN / 4)
         wlen = CONFIG_FILE_BUF_LEN / 4;
      else
         wlen = (u16)flen;
      if (!file_read(file, (u8 *)wbuf, wlen, &rlen))
      {
         INSTANCE_ERROR(DE_FILE_READ_ERROR);
         fail = TRUE;
         break;
      }
      if (rlen != wlen)
      {
         INSTANCE_ERROR(DE_FILE_READ_ERROR);
         fail = TRUE;
         break;
      }
      if (!di_upload_firmware_data(instance, wbuf, wlen / 4))
      {
         fail = TRUE;
         break;
      }
      flen -= rlen;
      ofs += rlen;
   }
   if (callback && !fail)
      callback(100);

   file_close(file);

   if (!di_upload_firmware_finish(instance))
      fail = TRUE;

   return !fail;
}


bool di_upload_eeprom(DI_INSTANCE_T *instance, I2C_HANDLE_T eeprom_handle, char *firmware_filename, bool force_anyrom, UPLOAD_CALLBACK callback)
{
   u32 ofs;
   s32 olen;
   s32 flen;
   u16 rlen;
   u16 wlen;
   FILE_HANDLE_T file;
   EEPROMHeader header;
   u32 wbuf[CONFIG_FILE_BUF_LEN / 4];
   s32 percent;
   s32 prev_percent = -1;
   bool fail = FALSE;

   // prepare to communicate with the EEPROM via the same I2C bus as U718x
   if (!i2c_init(eeprom_handle))
   {
      INSTANCE_ERROR(DE_I2C_PASSTHRU_ERROR);
      return FALSE;
   }
   if (!i2c_register(eeprom_handle, NULL, 0))
   {
      INSTANCE_ERROR(DE_I2C_PASSTHRU_ERROR);
      return FALSE;
   }

   info_log("open firmware file %s\n", firmware_filename);

   // read the file header
   flen = file_size(firmware_filename);

   file = file_open(firmware_filename);
   if (file == NULL)
   {
      INSTANCE_ERROR(DE_FILE_OPEN_ERROR);
      return FALSE;
   }

   ofs = 0;
   info_log("read header...\n");
   if (!file_read(file, (u8 *)&header, sizeof(EEPROMHeader), &rlen))
   {
      file_close(file);
      INSTANCE_ERROR(DE_FILE_READ_ERROR);
      return FALSE;
   }
   if (rlen != sizeof(EEPROMHeader))
   {
      file_close(file);
      INSTANCE_ERROR(DE_FILE_READ_ERROR);
      return FALSE;
   }

   if (force_anyrom)
      header.flags.bits.ROMVerExp = ROM_VERSION_ANY;

   info_log("start eeprom upload\n");
   if (!di_upload_eeprom_start(instance, eeprom_handle, &header))
      return FALSE;

   // upload the rest of the file
   flen -= rlen;
   olen = flen;
   ofs += rlen;

   while (flen > 0)
   {
      percent = (100 * ofs) / olen;
      if (percent != prev_percent)
      {
         prev_percent = percent;
         if (callback)
            callback((int)percent);
         info_log("%d%%\r", percent);
      }
      if (flen > CONFIG_FILE_BUF_LEN / 4)
         wlen = CONFIG_FILE_BUF_LEN / 4;
      else
         wlen = (u16)flen;
      if (!file_read(file, (u8 *)wbuf, wlen, &rlen))
      {
         INSTANCE_ERROR(DE_FILE_READ_ERROR);
         fail = TRUE;
         break;
      }
      if (rlen != wlen)
      {
         error_log("Bytes read does not match bytes requested: %u not %u\n", rlen, wlen);
         INSTANCE_ERROR(DE_FILE_READ_ERROR);
         fail = TRUE;
         break;
      }
      if (!di_upload_eeprom_data(instance, eeprom_handle, wbuf, wlen / 4))
      {
         fail = TRUE;
         break;
      }
      flen -= rlen;
      ofs += rlen;
   }
   if (callback && !fail)
      callback(100);

   info_log("close file\n");
   file_close(file);

   info_log("finish eeprom upload\n");
   if (!di_upload_eeprom_finish(instance))
      fail = TRUE;

   return !fail;
}

bool isSensorValid(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   bool valid;
   if ((sensor >= DST_FIRST) && (sensor <= di_max_sensor_id(instance)))
   {
      valid = instance->sensor_info[sensor].valid;
   }
#if !defined(DI_SLIM)
   else if ((sensor >= DST_RAW_DEBUG_OUTPUT_GYRO) && (sensor <= DST_RAW_DEBUG_OUTPUT_ACCEL))
   {
      valid = instance->sensor_info_raw[sensor - DST_RAW_DEBUG_OUTPUT_GYRO].valid;
   }
#endif
   else
   {
      valid = FALSE;
   }
   return valid;
}

void scale3axisScalePar(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                        void *vi3, void *vp3, bool raw, bool cpSensor, float scaleFact)
{
   float scale;
   bool valid = isSensorValid(instance, sensor);
   DI_3AXIS_INT_DATA_T *i3 = (DI_3AXIS_INT_DATA_T *)vi3;
   DI_3AXIS_DATA_T *p3  = (DI_3AXIS_DATA_T *)vp3;
   if (valid)
   {
      scale = (float)(raw ? 1.0 : scaleFact);
      if (fabs(scale) <= 0.000001)
         debug_log("scale factor is zero for sensor %u!\n", sensor);
      if (cpSensor)
         p3->sensor = i3->sensor;
      p3->x = ((float)i3->x) * scale;
      p3->y = ((float)i3->y) * scale;
      p3->z = ((float)i3->z) * scale;
      p3->status = i3->status;
      p3->t = i3->t;
   }
   p3->valid = valid;
}

void scale3axis(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                void *vi3, void *vp3, bool raw, bool cpSensor)
{
   u8 wakeup = (instance->hi_id == HIID_KITKAT) ? 0 : di_wake_sensor_start(instance);
   float scale_factor = instance->sensor_info[sensor].scale_factor;
   if (fabs(scale_factor) <= 0.000001)
      debug_log("scale factor is zero for sensor %u!\n", sensor);
   if ((sensor == DST_ACCELEROMETER) ||
       (sensor == DST_LINEAR_ACCELERATION) ||
       (sensor == DST_GRAVITY) ||
       (sensor == (DST_ACCELEROMETER | wakeup)) ||
       (sensor == (DST_LINEAR_ACCELERATION | wakeup)) ||
       (sensor == (DST_GRAVITY | wakeup)))
      scale_factor *= (float)9.81;  // convert to meters per second squared
   else if (
            (sensor == DST_GYROSCOPE) ||
            (sensor == DST_GYROSCOPE_UNCALIBRATED) ||
            (sensor == (DST_GYROSCOPE | wakeup)) ||
            (sensor == (DST_GYROSCOPE_UNCALIBRATED | wakeup)))
      scale_factor *=  (float)(2 * 3.1415926 / 360); // convert to radians per second

   scale3axisScalePar(instance, sensor, vi3, vp3, raw, cpSensor,
                      scale_factor);
}

void scale3axisOrient(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                      void *vi3, void *vp3, bool raw, bool cpSensor)
{
   scale3axisScalePar(instance, sensor, vi3, vp3, raw, cpSensor, (float)SENSOR_SCALE_ORIENT);
}

void scale3axisRAW(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                   void *vi3, void *vp3, bool raw, bool cpSensor)
{
   bool valid = isSensorValid(instance, sensor);
   DI_3AXIS_RAW_INT_DATA_T *b3 = (DI_3AXIS_RAW_INT_DATA_T *)vi3;
   DI_3AXIS_RAW_DATA_T *o3  = (DI_3AXIS_RAW_DATA_T *)vp3;
   if (valid)
   {
      if (cpSensor)
         o3->sensor = b3->sensor;
      o3->x = b3->x;
      o3->y = b3->y;
      o3->z = b3->z;
      o3->t = b3->t;
   }
   o3->valid = valid;
}

void scale3axisRAW_F(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                     void *vi3, void *vp3, bool raw, bool cpSensor)
{
   bool valid = isSensorValid(instance, sensor);
   DI_3AXIS_RAW_FL_DATA_T *b3 = (DI_3AXIS_RAW_FL_DATA_T *)vi3;
   DI_3AXIS_RAW_DATA_F_T *o3  = (DI_3AXIS_RAW_DATA_F_T *)vp3;
   if (valid)
   {
      if (cpSensor)
         o3->sensor = b3->sensor;
      o3->x = b3->x;
      o3->y = b3->y;
      o3->z = b3->z;
      o3->t = b3->t;
   }
   o3->valid = valid;
}


void scale3axisUncal(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                     void *vi3, void *vp3, bool raw, bool cpSensor)
{
   float scale;
   bool valid = isSensorValid(instance, sensor);
   DI_3AXIS_UNCAL_INT_DATA_T *iu = (DI_3AXIS_UNCAL_INT_DATA_T *)vi3;
   DI_3AXIS_UNCAL_DATA_T *ou  = (DI_3AXIS_UNCAL_DATA_T *)vp3;
   if (valid)
   {
      u8 wakeup = (instance->hi_id == HIID_KITKAT) ? 0 : di_wake_sensor_start(instance);
      float scale_factor = instance->sensor_info[sensor].scale_factor;

      if ((sensor == DST_ACCELEROMETER) ||
          (sensor == DST_LINEAR_ACCELERATION) ||
          (sensor == DST_GRAVITY) ||
          (sensor == (DST_ACCELEROMETER | wakeup)) ||
          (sensor == (DST_LINEAR_ACCELERATION | wakeup)) ||
          (sensor == (DST_GRAVITY | wakeup)))
         scale_factor *= (float)9.81; // convert to meters per second squared
      else if (
               (sensor == DST_GYROSCOPE) ||
               (sensor == DST_GYROSCOPE_UNCALIBRATED) ||
               (sensor == (DST_GYROSCOPE | wakeup)) ||
               (sensor == (DST_GYROSCOPE_UNCALIBRATED | wakeup)))
         scale_factor *=  (float)(2 * 3.1415926 / 360); // convert to radians per second


      scale = (float)(raw ? 1.0 : scale_factor);
      if (fabs(scale) <= 0.000001)
         debug_log("scale factor is zero for sensor %u!\n", sensor);
      if (cpSensor)
         ou->sensor = iu->sensor;
      ou->x_uncal = ((float)iu->x_uncal) * scale;
      ou->y_uncal = ((float)iu->y_uncal) * scale;
      ou->z_uncal = ((float)iu->z_uncal) * scale;
      ou->x_bias = ((float)iu->x_bias) * scale;
      ou->y_bias = ((float)iu->y_bias) * scale;
      ou->z_bias = ((float)iu->z_bias) * scale;
      ou->status = iu->status;
      ou->t = iu->t;
   }
   ou->valid = valid;
}

void scale4axis(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                void *viq, void *voq, bool raw, bool cpSensor, float acu)
{
   bool valid = isSensorValid(instance, sensor);
   DI_QUATERNION_INT_DATA_T *iq = (DI_QUATERNION_INT_DATA_T *)viq;
   DI_QUATERNION_DATA_T *oq = (DI_QUATERNION_DATA_T *)voq;
   float xyzwDiv = 1;
   float acuracyMult = 1;
   if (valid)
   {
      if (cpSensor)
         oq->sensor = iq->sensor;
      if (!raw)
      {
         xyzwDiv = 16384;
         acuracyMult = acu;
      }

      oq->x = ((float)iq->x) / xyzwDiv;
      oq->y = ((float)iq->y) / xyzwDiv;
      oq->z = ((float)iq->z) / xyzwDiv;
      oq->w = ((float)iq->w) / xyzwDiv;
      oq->accuracy_estimate = (float)(iq->accuracy_estimate * acuracyMult);

      oq->t = iq->t;
   }
   oq->valid = valid;
}

void scale4axisAcu1(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                    void *viq, void *voq, bool raw, bool cpSensor)
{
   scale4axis(instance, sensor, viq, voq, raw, cpSensor, 1);
}

void scale4axisAcuFloat(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                        void *viq, void *voq, bool raw, bool cpSensor)
{
   scale4axis(instance, sensor, viq, voq, raw, cpSensor, (float)(3.14159 / 32767));
}

void scaleSingle(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                 void *vi3, void *vp3, bool raw, bool cpSensor)
{
   bool valid = isSensorValid(instance, sensor);
   DI_SINGLETON_INT_DATA_T *int_data = (DI_SINGLETON_INT_DATA_T *)vi3;
   DI_SINGLETON_DATA_T *data         = (DI_SINGLETON_DATA_T *)vp3;
   if (valid)
   {
      if (cpSensor)
      {
         data->sensor = int_data->sensor;
      }
      data->t = int_data->t;
   }
   data->valid = valid;
}

void scaleSingleDatum(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                      void *vi3, void *vp3, bool raw, bool cpSensor)
{
   bool valid = isSensorValid(instance, sensor);
   DI_USCALAR_INT_DATA_T *int_data = (DI_USCALAR_INT_DATA_T *)vi3;
   DI_UINT_SCALAR_DATA_T *data     = (DI_UINT_SCALAR_DATA_T *)vp3;
   if (valid)
   {
      if (cpSensor)
         data->sensor = int_data->sensor;
      data->datum = int_data->datum;
      data->t = int_data->t;
   }
   data->valid = valid;
}

void scaleFloatDatum(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                      void *vi3, void *vp3, bool raw, bool cpSensor)
{
   bool valid = isSensorValid(instance, sensor);
   DI_USCALAR_INT_DATA_T *int_data = (DI_USCALAR_INT_DATA_T *)vi3;
   DI_SCALAR_INT_DATA_T *sint_data = (DI_SCALAR_INT_DATA_T *)vi3;
   DI_LUSCALAR_INT_DATA_T *lint_data = (DI_LUSCALAR_INT_DATA_T *)vi3;
   DI_SCALAR_DATA_T *data     = (DI_SCALAR_DATA_T *)vp3;
   if (valid)
   {
      if (cpSensor)
         data->sensor = int_data->sensor;
      switch(sensor)
      {
         case DST_PRESSURE:
            data->datum = (((u32)(lint_data->datum_lsw)) + (((u32)(lint_data->datum_msb)) << 16)) * SENSOR_SCALE_BAROM;
            data->t = lint_data->t;
            break;
         case DST_LIGHT:
            data->datum = int_data->datum * SENSOR_SCALE_LIGHT;
            data->t = int_data->t;
            break;
         case DST_RELATIVE_HUMIDITY:
            data->datum = int_data->datum * SENSOR_SCALE_HUMID;
            data->t = int_data->t;
            break;
         case DST_PROXIMITY:
            data->datum = int_data->datum * SENSOR_SCALE_PROX;
            data->t = int_data->t;
            break;
         case DST_TEMPERATURE:
         case DST_AMBIENT_TEMPERATURE:
            data->datum = sint_data->datum * SENSOR_SCALE_TEMP + SENSOR_OFFSET_TEMP;
            data->t = sint_data->t;
            break;
      }
   }
   data->valid = valid;
}

/* TODO It must correspond to data format - use fcnt parameter acu insted 50  */
void scaleCalStatus(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                    void *viq, void *voq, bool raw, bool cpSensor, float acu)
{
   bool valid = isSensorValid(instance, sensor);
   DI_CALSTATUS_INT_DATA_T *iq = (DI_CALSTATUS_INT_DATA_T *)viq;
   DI_CALSTATUS_DATA_T *oq = (DI_CALSTATUS_DATA_T *)voq;
   float calStatusDiv = 1;
   float calStatusMult = 1;
   if (valid)
   {
      if (cpSensor)
         oq->sensor = iq->sensor;
      if (!raw)
      {
         calStatusDiv = 1638.4;
         calStatusMult = 50;                                         // TODO: should use variable acu
      }

      oq->transientCompensation = iq->transientCompensation;
      oq->mcalStatus = iq->mcalStatus;
      oq->mcalScore1 = ((float)iq->mcalScore1) / calStatusDiv;
      oq->mcalSIHI9 = (((float)iq->mcalSIHI9) / calStatusDiv) * calStatusMult;
      oq->mcalSIHI10 = (((float)iq->mcalSIHI10) / calStatusDiv) * calStatusMult;
      oq->mcalSIHI11 = (((float)iq->mcalSIHI11) / calStatusDiv) * calStatusMult;
      oq->t = iq->t;
   }
   oq->valid = valid;
}

void *getIntDataPtr_private(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *int_data)
{
   switch (sensor)
   {
      case DST_ACCELEROMETER:
         return &int_data->accel;
      case DST_GEOMAGNETIC_FIELD:
         return &int_data->mag;
      case DST_ORIENTATION:
         return &int_data->orientation;
      case DST_GYROSCOPE:
         return &int_data->gyro;
      case DST_LIGHT:
         return &int_data->light;
      case DST_PRESSURE:
         return &int_data->barometer;
      case DST_TEMPERATURE:
         return &int_data->temperature;
      case DST_PROXIMITY:
         return &int_data->proximity;
      case DST_GRAVITY:
         return &int_data->gravity;
      case DST_LINEAR_ACCELERATION:
         return &int_data->linear_acceleration;
      case DST_ROTATION_VECTOR:
         return &int_data->rotation_vector;
      case DST_RELATIVE_HUMIDITY:
         return &int_data->humidity;
      case DST_AMBIENT_TEMPERATURE:
         return &int_data->ambient_temperature;
      case DST_MAGNETIC_FIELD_UNCALIBRATED:
         return &int_data->mag_uncal;
      case DST_GAME_ROTATION_VECTOR:
         return &int_data->game_rotation_vector;
      case DST_GYROSCOPE_UNCALIBRATED:
         return &int_data->gyro_uncal;
      case DST_SIGNIFICANT_MOTION:
         return &int_data->significant_motion;
      case DST_STEP_DETECTOR:
         return &int_data->step_detector;
      case DST_STEP_COUNTER:
         return &int_data->step_counter;
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         return &int_data->geomag_rotation_vector;
      case DST_HEART_RATE:
         return &int_data->heart_rate;
      case DST_TILT_DETECTOR:
         return &int_data->tilt_detector;
      case DST_WAKE_GESTURE:
         return &int_data->wake_gesture;
      case DST_GLANCE_GESTURE:
         return &int_data->glance_gesture;
      case DST_PICKUP_GESTURE:
         return &int_data->pickup_gesture;
      case DST_ACTIVITY:
         return &int_data->activity;

      case DST_RAW_DEBUG_OUTPUT_ACCEL:
         if (instance->alg_id == AID_SPACE_POINT)
            return &int_data->raw_f_accel;
         return &int_data->raw_accel;
      case DST_RAW_DEBUG_OUTPUT_MAG:
         if (instance->alg_id == AID_SPACE_POINT)
            return &int_data->raw_f_mag;
         return &int_data->raw_mag;
      case DST_RAW_DEBUG_OUTPUT_GYRO:
         if (instance->alg_id == AID_SPACE_POINT)
            return &int_data->raw_f_gyro;
         return &int_data->raw_gyro;

#if !defined(DI_SLIM)
      case DST_DEBUG:
         return &int_data->debug;
      case DST_WAKEUP_TIMESTAMP_LSW:
         return &int_data->timestamp_lsw;
      case DST_WAKEUP_TIMESTAMP_MSW:
         return &int_data->timestamp_msw;
      case DST_WAKEUP_META_EVENT:
         return &int_data->meta;
#endif
      case DST_TIMESTAMP_LSW:
         return &int_data->timestamp_lsw;
      case DST_TIMESTAMP_MSW:
         return &int_data->timestamp_msw;
      case DST_META_EVENT:
         return &int_data->meta;

      case DST_CAL_STATUS:
         return &int_data->cal_status;

      case DST_JERK_EXAMPLE:
         return &int_data->jerk_example;

      default:
         // todo report this at least once for unknown sensor
         // error_log("getIntDataPtr: Sensor data for sensor %d (%s) was not found in struct DI_SENSOR_INT_DATA_T\n",sensor,di_query_sensor_name(instance, sensor));
         return NULL;
   }
}

bool is_wakeup_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   // Note we can not use is_wakeup_event, because some function simplifies code in a way
   // that wakeup sensors maps to non wakeup and since DST_WAKEUP_TIMESTAMP_LSW has different
   // shift it would not work
   if (instance->hi_id == HIID_KITKAT)
      return FALSE;
   if ((sensor >= di_wake_sensor_start(instance)) && (sensor <= di_max_sensor_id(instance)))
   {
      return TRUE;
   }
   return FALSE;
}

void *getIntDataPtr_knownSensorType(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *int_data)
{
   DI_SENSOR_TYPE_T idxSensor;
   void *ret;
   // do not use is_wakeup_event()
#if defined(DI_SLIM)
   idxSensor = sensor;
#else
   idxSensor = is_wakeup_sensor(instance, sensor) ? sensor - di_wake_sensor_start(instance) : sensor;
#endif
   ret = getIntDataPtr_private(instance, idxSensor, int_data);
   if (ret == NULL)
   {
      //error_log("getIntDataPtr: Sensor data for sensor %d (%s) was not found in struct DI_SENSOR_INT_DATA_T\n",
      //   sensor,di_query_sensor_name(instance, sensor));
   }
   return ret;
}

void *getIntDataPtr(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T int_data[2])
{
#if defined(DI_SLIM)
   int idx = 0;
#else
   int idx = is_wakeup_event(instance, sensor) ? 1 : 0;
#endif
   return getIntDataPtr_knownSensorType(instance, sensor, &(int_data[idx]));
}


void *getDataPtr_private(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_DATA_T *data)
{
   switch (sensor)
   {
      case DST_ACCELEROMETER:
         return &data->accel;
      case DST_GEOMAGNETIC_FIELD:
         return &data->mag;
      case DST_ORIENTATION:
         return &data->orientation;
      case DST_GYROSCOPE:
         return &data->gyro;
      case DST_LIGHT:
         return &data->light;
      case DST_PRESSURE:
         return &data->barometer;
      case DST_TEMPERATURE:
         return &data->temperature;
      case DST_PROXIMITY:
         return &data->proximity;
      case DST_GRAVITY:
         return &data->gravity;
      case DST_LINEAR_ACCELERATION:
         return &data->linear_acceleration;
      case DST_ROTATION_VECTOR:
         return &data->rotation_vector;
      case DST_RELATIVE_HUMIDITY:
         return &data->humidity;
      case DST_AMBIENT_TEMPERATURE:
         return &data->ambient_temperature;
      case DST_MAGNETIC_FIELD_UNCALIBRATED:
         return &data->mag_uncal;
      case DST_GAME_ROTATION_VECTOR:
         return &data->game_rotation_vector;
      case DST_GYROSCOPE_UNCALIBRATED:
         return &data->gyro_uncal;
      case DST_SIGNIFICANT_MOTION:
         return &data->significant_motion;
      case DST_STEP_DETECTOR:
         return &data->step_detector;
      case DST_STEP_COUNTER:
         return &data->step_counter;
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         return &data->geomag_rotation_vector;
      case DST_HEART_RATE:
         return &data->heart_rate;
      case DST_TILT_DETECTOR:
         return &data->tilt_detector;
      case DST_WAKE_GESTURE:
         return &data->wake_gesture;
      case DST_GLANCE_GESTURE:
         return &data->glance_gesture;
      case DST_PICKUP_GESTURE:
         return &data->pickup_gesture;
      case DST_ACTIVITY:
         return &data->activity;

      case DST_RAW_DEBUG_OUTPUT_ACCEL:
         if (instance->alg_id == AID_SPACE_POINT)
            return &data->raw_f_accel;
         return &data->raw_accel;
      case DST_RAW_DEBUG_OUTPUT_MAG:
         if (instance->alg_id == AID_SPACE_POINT)
            return &data->raw_f_mag;
         return &data->raw_mag;
      case DST_RAW_DEBUG_OUTPUT_GYRO:
         if (instance->alg_id == AID_SPACE_POINT)
            return &data->raw_f_gyro;
         return &data->raw_gyro;

#if !defined(DI_SLIM)
      case DST_DEBUG:
         return &data->debug;
      case DST_WAKEUP_TIMESTAMP_LSW:
         return &data->timestamp_lsw;
      case DST_WAKEUP_TIMESTAMP_MSW:
         return &data->timestamp_msw;
      case DST_WAKEUP_META_EVENT:
         return &data->meta;
#endif

      case DST_TIMESTAMP_LSW:
         return &data->timestamp_lsw;
      case DST_TIMESTAMP_MSW:
         return &data->timestamp_msw;
      case DST_META_EVENT:
         return &data->meta;

      case DST_CAL_STATUS:
         return &data->cal_status;

      case DST_JERK_EXAMPLE:
         return &data->jerk_example;


      default:
         return NULL;
   }
}

void *getDataPtr_knownSensorType(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_DATA_T *data)
{
   DI_SENSOR_TYPE_T idxSensor;
   void *ret;
   // do not use is_wakeup_event()
#if defined(DI_SLIM)
   idxSensor = sensor;
#else
   idxSensor = is_wakeup_sensor(instance, sensor) ? (sensor - di_wake_sensor_start(instance)) : sensor;
#endif
   ret = getDataPtr_private(instance, idxSensor, data);
   if (ret == NULL)
   {
#if 0
      error_log("getDataPtr: Sensor data for sensor %d (%s) was not found in struct DI_SENSOR_DATA_T\n",
                sensor,di_query_sensor_name(instance, sensor));
#endif
   }
   return ret;
}

void *getDataPtr(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_DATA_T data[2])
{
#if defined(DI_SLIM)
   int idx = 0;
#else
   int idx = is_wakeup_event(instance, sensor) ? 1 : 0;
#endif
   return getDataPtr_knownSensorType(instance, sensor, &(data[idx]));
}

bool isDebugSensor(DI_SENSOR_TYPE_T sensor)
{
   if ((sensor >= DST_RAW_DEBUG_OUTPUT_GYRO) &&
       (sensor <= DST_RAW_DEBUG_OUTPUT_ACCEL))
   {
      return TRUE;
   }
   return FALSE;
}


void *getScaleFunct(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   // sensor2 will map all wakeup sensor to non wakeup as they are using smae functions
   DI_SENSOR_TYPE_T sensor2 = sensor;
   if ((sensor >= di_wake_sensor_start(instance)) && (sensor <= di_max_sensor_id(instance)))
   {
      sensor2 -= di_wake_sensor_start(instance);
   }

   switch (di_query_sensor_type(instance, sensor))
   {
      case E_DI_3AXIS_DATA_T:
         if (DST_ORIENTATION == sensor2)
         {
            return scale3axisOrient;
         }
         return scale3axis;
      case E_DI_3AXIS_UNCAL_DATA_T:
         return scale3axisUncal;
      case E_DI_QUATERNION_DATA_T:
         if (DST_GAME_ROTATION_VECTOR == sensor2)
         {
            return scale4axisAcu1;
         }
         return scale4axisAcuFloat;
      case E_DI_3AXIS_RAW_DATA_T:
         return scale3axisRAW;
      case E_DI_3AXIS_RAW_DATA_F_T:
         return scale3axisRAW_F;
      case E_DI_SINGLETON_DATA_T:
         return scaleSingle;
      case E_DI_UINT_SCALAR_DATA_T:
         return scaleSingleDatum;
      case E_DI_SCALAR_DATA_T:
         return scaleFloatDatum;
      case E_DI_CALSTATUS_DATA_T:
         return scaleCalStatus;
      case E_SENS_DATA_TYPE_UNKNOWN:
      default:
         // TODO this may be interesting log - question what to do for new sensor - perhaps we shall log it at least once for unknown sensor
         //error_log("getScaleFunct: Scale function for sensor %d (%s) not found!\n",
         //   sensor, di_query_sensor_name(instance, sensor));
         return NULL;
   }
}

bool di_convert_sensor_data(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                            DI_SENSOR_INT_DATA_T *int_data, DI_SENSOR_DATA_T *data, bool raw)
{
   void *vpData = NULL;
   void *vpDataInt = NULL;
   void (*funct)(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                 void *vi3, void *vp3, bool raw, bool cpSensor);
/*
   if ((sensor == DST_META_EVENT) || (sensor == DST_WAKEUP_META_EVENT))
   {
      data->meta.event_id = int_data->meta.event_id;
      data->meta.extra_info = int_data->meta.extra_info;
      data->meta.sensor = int_data->meta.sensor;
      data->meta.sensor_id = int_data->meta.sensor_id;
      data->meta.t = int_data->meta.t;
      data->meta.valid = TRUE;
      return TRUE;
   } */
   if ((sensor > di_max_sensor_id(instance)) && !((sensor >= DST_RAW_DEBUG_OUTPUT_GYRO) && (sensor <= DST_RAW_DEBUG_OUTPUT_ACCEL)))
   {
      return FALSE;
   }
   funct     = getScaleFunct(instance, sensor);
   if (funct == NULL)
   {
      return FALSE;
   }
   vpDataInt = getIntDataPtr_knownSensorType(instance, sensor, int_data);
   if (vpDataInt == NULL)
   {
      return FALSE;
   }
   vpData    = getDataPtr_knownSensorType(instance, sensor, data);
   if (vpData == NULL)
   {
      return FALSE;
   }
   funct(instance, sensor, vpDataInt, vpData, raw, TRUE);

   return TRUE;
}

void *getIntUnionPtr_private(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_UNION_T *int_data)
{
   switch (sensor)
   {
      case DST_ACCELEROMETER:
         return &int_data->accel;
      case DST_GEOMAGNETIC_FIELD:
         return &int_data->mag;
      case DST_ORIENTATION:
         return &int_data->orientation;
      case DST_GYROSCOPE:
         return &int_data->gyro;
      case DST_LIGHT:
         return &int_data->light;
      case DST_PRESSURE:
         return &int_data->barometer;
      case DST_TEMPERATURE:
         return &int_data->temperature;
      case DST_PROXIMITY:
         return &int_data->proximity;
      case DST_GRAVITY:
         return &int_data->gravity;
      case DST_LINEAR_ACCELERATION:
         return &int_data->linear_acceleration;
      case DST_ROTATION_VECTOR:
         return &int_data->rotation_vector;
      case DST_RELATIVE_HUMIDITY:
         return &int_data->humidity;
      case DST_AMBIENT_TEMPERATURE:
         return &int_data->ambient_temperature;
      case DST_MAGNETIC_FIELD_UNCALIBRATED:
         return &int_data->mag_uncal;
      case DST_GAME_ROTATION_VECTOR:
         return &int_data->game_rotation_vector;
      case DST_GYROSCOPE_UNCALIBRATED:
         return &int_data->gyro_uncal;
      case DST_SIGNIFICANT_MOTION:
         return &int_data->significant_motion;
      case DST_STEP_DETECTOR:
         return &int_data->step_detector;
      case DST_STEP_COUNTER:
         return &int_data->step_counter;
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         return &int_data->geomag_rotation_vector;
      case DST_HEART_RATE:
         return &int_data->heart_rate;
      case DST_TILT_DETECTOR:
         return &int_data->tilt_detector;
      case DST_WAKE_GESTURE:
         return &int_data->wake_gesture;
      case DST_GLANCE_GESTURE:
         return &int_data->glance_gesture;
      case DST_PICKUP_GESTURE:
         return &int_data->pickup_gesture;
      case DST_ACTIVITY:
         return &int_data->activity;

      case DST_RAW_DEBUG_OUTPUT_ACCEL:
         if (instance->alg_id == AID_SPACE_POINT)
            return &int_data->raw_f_accel;
         return &int_data->raw_accel;
      case DST_RAW_DEBUG_OUTPUT_MAG:
         if (instance->alg_id == AID_SPACE_POINT)
            return &int_data->raw_f_mag;
         return &int_data->raw_mag;
      case DST_RAW_DEBUG_OUTPUT_GYRO:
         if (instance->alg_id == AID_SPACE_POINT)
            return &int_data->raw_f_gyro;
         return &int_data->raw_gyro;
#if !defined(DI_SLIM)
      case DST_DEBUG:
         return &int_data->debug;
      case DST_WAKEUP_TIMESTAMP_LSW:
         return &int_data->timestamp_lsw;
      case DST_WAKEUP_TIMESTAMP_MSW:
         return &int_data->timestamp_msw;
      case DST_WAKEUP_META_EVENT:
         return &int_data->meta;
#endif
      case DST_TIMESTAMP_LSW:
         return &int_data->timestamp_lsw;
      case DST_TIMESTAMP_MSW:
         return &int_data->timestamp_msw;
      case DST_META_EVENT:
         return &int_data->meta;

      case DST_CAL_STATUS:
         return &int_data->cal_status;

      default:
         // TODO error this at lest once for unknown sensor
         //error_log("getIntDataPtr: Sensor data for sensor %d (%s) was not found in struct DI_SENSOR_INT_DATA_T\n",sensor,di_query_sensor_name(instance, sensor));
         return NULL;
   }
}

void *getIntUnionPtr_knownSensorType(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_UNION_T *int_data)
{
   DI_SENSOR_TYPE_T idxSensor;
   void *ret;
   // do not use is_wakeup_event (won't work for timestamps)
   idxSensor = is_wakeup_sensor(instance, sensor) ? sensor - di_wake_sensor_start(instance) : sensor;
   ret = getIntUnionPtr_private(instance, idxSensor, int_data);
   if (ret == NULL)
   {
      error_log("getIntDataPtr: Sensor data for sensor %d (%s) was not found in struct DI_SENSOR_INT_DATA_T\n",
                sensor, di_query_sensor_name(instance, sensor));
   }
   return ret;
}

void *getUnionPtr_private(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_UNION_T *data)
{
   switch (sensor)
   {
      case DST_ACCELEROMETER:
         return &data->accel;
      case DST_GEOMAGNETIC_FIELD:
         return &data->mag;
      case DST_ORIENTATION:
         return &data->orientation;
      case DST_GYROSCOPE:
         return &data->gyro;
      case DST_LIGHT:
         return &data->light;
      case DST_PRESSURE:
         return &data->barometer;
      case DST_TEMPERATURE:
         return &data->temperature;
      case DST_PROXIMITY:
         return &data->proximity;
      case DST_GRAVITY:
         return &data->gravity;
      case DST_LINEAR_ACCELERATION:
         return &data->linear_acceleration;
      case DST_ROTATION_VECTOR:
         return &data->rotation_vector;
      case DST_RELATIVE_HUMIDITY:
         return &data->humidity;
      case DST_AMBIENT_TEMPERATURE:
         return &data->ambient_temperature;
      case DST_MAGNETIC_FIELD_UNCALIBRATED:
         return &data->mag_uncal;
      case DST_GAME_ROTATION_VECTOR:
         return &data->game_rotation_vector;
      case DST_GYROSCOPE_UNCALIBRATED:
         return &data->gyro_uncal;
      case DST_SIGNIFICANT_MOTION:
         return &data->significant_motion;
      case DST_STEP_DETECTOR:
         return &data->step_detector;
      case DST_STEP_COUNTER:
         return &data->step_counter;
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         return &data->geomag_rotation_vector;
      case DST_HEART_RATE:
         return &data->heart_rate;
      case DST_TILT_DETECTOR:
         return &data->tilt_detector;
      case DST_WAKE_GESTURE:
         return &data->wake_gesture;
      case DST_GLANCE_GESTURE:
         return &data->glance_gesture;
      case DST_PICKUP_GESTURE:
         return &data->pickup_gesture;
      case DST_ACTIVITY:
         return &data->activity;

      case DST_RAW_DEBUG_OUTPUT_ACCEL:
         if (instance->alg_id == AID_SPACE_POINT)
            return &data->raw_f_accel;
         return &data->raw_accel;
      case DST_RAW_DEBUG_OUTPUT_MAG:
         if (instance->alg_id == AID_SPACE_POINT)
            return &data->raw_f_mag;
         return &data->raw_mag;
      case DST_RAW_DEBUG_OUTPUT_GYRO:
         if (instance->alg_id == AID_SPACE_POINT)
            return &data->raw_f_gyro;
         return &data->raw_gyro;
#if !defined(DI_SLIM)
      case DST_DEBUG:
         return &data->debug;
      case DST_WAKEUP_TIMESTAMP_LSW:
         return &data->timestamp_lsw;
      case DST_WAKEUP_TIMESTAMP_MSW:
         return &data->timestamp_msw;
      case DST_WAKEUP_META_EVENT:
         return &data->meta;
#endif
      case DST_TIMESTAMP_LSW:
      case DST_TIMESTAMP_MSW:
      case DST_META_EVENT:

      case DST_CAL_STATUS:
         return &data->cal_status;

      default:
         return NULL;
   }
}

void *getUnionPtr_knownSensorType(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_UNION_T *data)
{
   DI_SENSOR_TYPE_T idxSensor;
   void *ret;
   // do not use is_wakeup_event (won't work for timestamps)
   idxSensor = is_wakeup_sensor(instance, sensor) ? sensor - di_wake_sensor_start(instance) : sensor;
   ret = getUnionPtr_private(instance, idxSensor, data);
   if (ret == NULL)
   {
      error_log("getDataPtr: Sensor data for sensor %d (%s) was not found in struct DI_SENSOR_DATA_T\n",
                sensor, di_query_sensor_name(instance, sensor));
   }
   return ret;
}


bool di_convert_sensor_union(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                             DI_SENSOR_INT_UNION_T *int_data, DI_SENSOR_UNION_T *data, bool raw)
{
   void *vpData;
   void *vpDataInt;
   void (*funct)(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
                 void *vi3, void *vp3, bool raw, bool cpSensor);

   funct = getScaleFunct(instance, sensor);
   if (funct == NULL)
      return TRUE;
   vpDataInt = getIntUnionPtr_knownSensorType(instance, sensor, int_data);
   vpData    = getUnionPtr_knownSensorType(instance, sensor, data);
   funct(instance, sensor, vpDataInt, vpData, raw, FALSE);

   return TRUE;
}

bool di_query_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_UNION_T *data)
{
   u32 start;
   DI_SENSOR_INT_UNION_T int_data;
   bool done;

   // wait until finished
   start = time_ms();
   for (;;)
   {
      if (!di_task_loop(instance, &done))
         return FALSE;
      if (di_query_sensor_most_recent_sample(instance, sensor, &int_data, sizeof(DI_SENSOR_INT_UNION_T)))
         break;
      if (time_ms() > (start + QUERY_SENSOR_TIMEOUT_MS))
      {
         INSTANCE_ERROR(DE_SENSOR_SAMPLE_TIMEOUT);
         return FALSE;
      }
   }

   // convert to floating point data
   di_convert_sensor_union(instance, sensor, &int_data, data, FALSE);

   INSTANCE_ERROR(DE_NONE);
   return TRUE;
}

t_sensor_data_types di_query_sensor_type(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   // sensor2 will map all wakeup sensor to non wakeup as they are using smae functions
   DI_SENSOR_TYPE_T sensor2 = sensor;
#if !defined(DI_SLIM)
   if ((sensor >= di_wake_sensor_start(instance)) && (sensor <= di_max_sensor_id(instance)))
   {
      sensor2 -= di_wake_sensor_start(instance);
   }
#endif
   switch (sensor2)
   {
      case DST_GEOMAGNETIC_FIELD:
      case DST_ACCELEROMETER:
      case DST_LINEAR_ACCELERATION:
      case DST_GRAVITY:
      case DST_GYROSCOPE:
      case DST_ORIENTATION:
      case DST_JERK_EXAMPLE:
         return E_DI_3AXIS_DATA_T;
      case DST_MAGNETIC_FIELD_UNCALIBRATED:
      case DST_GYROSCOPE_UNCALIBRATED:
         return E_DI_3AXIS_UNCAL_DATA_T;
      case DST_ROTATION_VECTOR:
      case DST_GAME_ROTATION_VECTOR:
      case DST_GEOMAGNETIC_ROTATION_VECTOR:
         return E_DI_QUATERNION_DATA_T;
      case DST_RAW_DEBUG_OUTPUT_ACCEL:
      case DST_RAW_DEBUG_OUTPUT_MAG:
      case DST_RAW_DEBUG_OUTPUT_GYRO:
         if (instance->alg_id == AID_SPACE_POINT)
            return E_DI_3AXIS_RAW_DATA_F_T;
         return E_DI_3AXIS_RAW_DATA_T;
      case DST_SIGNIFICANT_MOTION:
      case DST_STEP_DETECTOR:
      case DST_TILT_DETECTOR:
      case DST_WAKE_GESTURE:
      case DST_GLANCE_GESTURE:
      case DST_PICKUP_GESTURE:
         return E_DI_SINGLETON_DATA_T;
      case DST_STEP_COUNTER:
      case DST_HEART_RATE:
      case DST_ACTIVITY:
         return E_DI_UINT_SCALAR_DATA_T;
      case DST_PRESSURE:
      case DST_LIGHT:
      case DST_PROXIMITY:
      case DST_RELATIVE_HUMIDITY:
      case DST_AMBIENT_TEMPERATURE:
      case DST_TEMPERATURE:
         return E_DI_SCALAR_DATA_T;

      case DST_CAL_STATUS:
         return E_DI_CALSTATUS_DATA_T;

      default:
         return E_SENS_DATA_TYPE_UNKNOWN;
   }
}

const char *di_query_driver_name(u8 driver_id)
{
   u16 i;

   for (i = 0; i < 0x100; i++)
   {
      if (!driver_names[i].name)
         break;
      if (driver_names[i].id == driver_id)
         return driver_names[i].name;
   }
   return "unknown";
}


const char *di_query_sensor_name(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   u8 wake_sensor_start;
   u8 max_sensor_id;

   if (instance)
   {
      wake_sensor_start = di_wake_sensor_start(instance);
      max_sensor_id = di_max_sensor_id(instance);
   }
   else                                                              // make an assumption so we can process command line options, which occur before we have an instance
   {
      wake_sensor_start = 32;
      max_sensor_id = 63;
   }

   if (sensor > max_sensor_id)
   {
      return di_query_extra_event_name(sensor);
   }

   if (sensor >= wake_sensor_start && sensor_names[sensor - wake_sensor_start])
   {

      static char wakename[128] = "Wakeup ";                         // FIXME... no ideal..
      sensor -= wake_sensor_start;                                   // TODO: prepend with Wake

      strncpy(wakename + sizeof("Wakeup"), sensor_names[sensor], sizeof(wakename) - sizeof("Wakeup"));

      return wakename;
   }

   return sensor_names[sensor];
}

const char *di_query_sensor_short_name(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if (sensor > di_max_sensor_id(instance))
   {
      return NULL;
   }

   if (sensor >= di_wake_sensor_start(instance))
   {
      static char wakename[32] = "W";                                // FIXME... not ideal..
      sensor -= di_wake_sensor_start(instance);                      // TODO: prepend with Wake
      strncpy(wakename + sizeof("W") - 1, sensor_short_names[sensor], sizeof(wakename) - sizeof("W") - 1);
      return wakename;
   }

   return sensor_short_names[sensor];
}


u32 di_set_buffer_max_size(DI_INSTANCE_T *instance, u32 buffer_size)
{
   if (buffer_size > SENSOR_BUF_SIZE)
      buffer_size = SENSOR_BUF_SIZE;
   instance->sensor_buf_max_xfer_size = buffer_size;
   return instance->sensor_buf_max_xfer_size;
}


bool display_driver_info(DI_INSTANCE_T *instance)
{
   DI_SENSOR_TYPE_T sensor;
   SENSOR_INFORMATION info;
   char *sensor_type;

   info_log("Driver version: %u.%02u.%04u, %s %s\n", DRIVER_MAJOR_VERSION, DRIVER_MINOR_VERSION, DRIVER_BUILD, __DATE__, __TIME__);

   info_log("Sensor ID,                 name, drvID, name, rev,   mA, range, res, max rate, FIFO rvd, FIFO max, event size, scale factor, type");
   if (instance->hi_id != HIID_KITKAT)
      info_log(", min rate\n");                                      // min rate only supported on lollipop, lollipop ex
   else
      info_log("\n");
   for (sensor = DST_FIRST; sensor <= di_max_sensor_id(instance); sensor++)
   {
      if (!di_has_sensor(instance, sensor))
         continue;
      if (!di_query_sensor_info(instance, sensor, &info))
      {
         error_log("unable to query sensor info for sensor %d\n", sensor);
         return FALSE;
      }
      else
      {
         if (di_is_sensor_continuous(instance, sensor))
            sensor_type = "cont";
         else if (di_is_sensor_on_change(instance, sensor))
            sensor_type = "onch";
         else if (di_is_sensor_one_shot(instance, sensor))
            sensor_type = "1sht";
         else
            sensor_type = "spcl";
         info_log("% 2u, %27.27s, % 3u, %19s, % 2u",
                  sensor, di_query_sensor_name(instance, sensor), info.driver_id, di_query_driver_name(info.driver_id), info.driver_version);
         info_log(", %2.2f, % 5u, % 2u, % 4u, % 5u, % 5u, % 2u, %3.8f, %s",
                  info.power * 0.1, info.max_range, info.resolution, info.max_rate, info.fifo_reserved, info.fifo_max, info.event_size, instance->sensor_info[sensor].scale_factor, sensor_type);
         if (instance->hi_id != HIID_KITKAT)
            info_log(", % 3u\n", info.min_rate);
         else
            info_log("\n");
      }
   }
   return TRUE;
}


const char *di_query_extra_event_name(DI_SENSOR_TYPE_T event)
{
   if ((event >= DST_FIRST_EXTRA_SENSOR) && (event <= DST_LAST_EXTRA_SENSOR))
      return extra_event_names[event - DST_FIRST_EXTRA_SENSOR];
   else
      return "unknown";
}


const char *di_query_meta_event_name(DI_META_EVENT_T event)
{
   if (event < DME_NUM_META_EVENTS)
      return meta_names[event];
   else
      return "unknown";
}


void display_meta_event(DI_INSTANCE_T *instance, DI_META_EVENT_INT_DATA_T *meta)
{
   const char *name = di_query_meta_event_name(meta->event_id);
   if(meta->event_id == DME_ALGORITHM_EVENT && instance->alg_id == AID_SPACE_POINT)
   {
       // soecial case to rename Algorithm event on Spacepoint.
       name = "Mag Transient";
   }
   info_log("%s meta % 2u %24.24s: ", (meta->sensor == DST_META_EVENT) ? "nonwake" : "wakeup ", meta->event_id, name);
   switch (meta->event_id)
   {
      case DME_FLUSH_COMPLETE:
         info_log("sensor %u %s cnt %u", meta->sensor_id, di_query_sensor_name(instance, meta->sensor_id), meta->extra_info);
         break;
      case DME_SAMPLE_RATE_CHANGED:
         info_log("sensor %u %s", meta->sensor_id, di_query_sensor_name(instance, meta->sensor_id));
         break;
      case DME_POWER_MODE_CHANGED:
         info_log("sensor %u %s, power mode %u", meta->sensor_id, di_query_sensor_name(instance, meta->sensor_id), meta->extra_info);
         break;
      case DME_ERROR:
         info_log("error reg 0x%02X, debug state 0x%02X", meta->sensor_id, meta->extra_info);
         break;
      case DME_ALGORITHM_EVENT:
      case DME_CAL_STATUS_CHANGED:
      case DME_STILLNESS_CHANGED:
      case DME_ALGORITHM_SLOWDOWN:
      case DME_CAL_STABLE:
         info_log("first payload byte %u, second payload byte %u", meta->sensor_id, meta->extra_info);
         break;
      case DME_HOST_IRQ_TIMESTAMP:
         info_log("timestamp %u", meta->sensor_id + meta->extra_info * 256);
         break;
      case DME_SENSOR_ERROR:
         info_log("sensor %u %s, status bits 0x%02X", meta->sensor_id, di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)meta->sensor_id), meta->extra_info);
         break;
      case DME_FIFO_OVERFLOW:
         info_log("bytes lost %u", meta->sensor_id + meta->extra_info * 256);
         break;
      case DME_DYNAMIC_RANGE_CHANGED:
         info_log("sensor %u %s", meta->sensor_id, di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)meta->sensor_id));
         break;
      case DME_FIFO_WATERMARK:
         info_log("bytes remaining %u", meta->sensor_id + meta->extra_info * 256);
         break;
      case DME_SELF_TEST_RESULTS:
         info_log("sensor %u %s, self test results %u", meta->sensor_id, di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)meta->sensor_id), meta->extra_info);
         break;
      case DME_INITIALIZED:
         info_log("firmware rev %u initialized", meta->sensor_id + meta->extra_info * 256);
         break;
      case DME_TRANSFER_CAUSE:
         info_log("transfer caused by sensor %u %s, extra %u", meta->sensor_id, di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)meta->sensor_id), meta->extra_info);
         break;
      case DME_SENSOR_FRAMEWORK:
         info_log("sensor %u %s: 0x%02X", meta->sensor_id, di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)meta->sensor_id), meta->extra_info);
         break;
      default:
         info_log("unknown meta event %u, %u, %u", meta->event_id, meta->sensor_id, meta->extra_info);
         break;
   }
   info_log(", timestamp %u\n", meta->t);
}


void display_sensor_status_bytes(DI_INSTANCE_T *instance, bool only_present)
{
   SENSOR_STATUS sensor_status;
   DI_SENSOR_TYPE_T sensor;

   info_log("Sensor ID,                 name, data avail, I2C NACK, devID err, trans err, data lost, power mode\n");
   for (sensor = DST_FIRST; sensor <= di_max_sensor_id(instance); sensor++)
   {
      if (di_read_sensor_status(instance, sensor, &sensor_status))
      {
         if ((sensor_status.power_mode != SensorNotPresent) || !only_present)
            info_log("% 2u, %27.27s, % 9u , % 7u , % 8u , % 8u , % 8u , % 8u\n",
                     sensor, di_query_sensor_name(instance, sensor),
                     sensor_status.data_available, sensor_status.i2c_nack, sensor_status.device_id_error, sensor_status.transient_error, sensor_status.data_lost, sensor_status.power_mode);
      }
   }
}


void display_error_info(DI_INSTANCE_T *instance)
{
   bool executing;
   bool sensing;
   u8 regs[32];
   u8 chipctrl;

   if (read_chip_error_registers(instance))
      info_log("Error: ChipStatus:0x%02X   HostStatus:0x%02X  IntStatus:0x%02X     ErrorReg:0x%02X\n",
               instance->error.chip_status.reg, instance->error.host_status.reg, instance->error.int_status.reg, instance->error.error_register & 0x0ff);
   if (di_read_registers(instance, 0x51, 0x55, regs) && di_read_registers(instance, 0x34, 0x34, &chipctrl))
   {
      info_log("         IntState:0x%02X     DebugVal:0x%02X DebugState:0x%02X HostIntfCtrl:0x%02X ChipCtrl:0x%02X\n        ParamPage:0x%02X  ",
               regs[0], regs[1], regs[2], regs[4], chipctrl, regs[3]);
   }
   if (di_read_registers(instance, 0x64, 0x64, regs))
   {
      info_log("   ParamReq:0x%02X  ",
               regs[0]);
   }
   if (di_read_registers(instance, 0x38, 0x3A, regs))
   {
      info_log(" ParamAck:0x%02X\n         BytesRem:0x%04X ",
              (unsigned)regs[2], (unsigned)(((u16)regs[1]) << 8 + (u16)regs[0]) & 0xffff);
   }
   if ((instance->hi_id == HIID_KITKAT) && di_read_registers(instance, 0x4B, 0x4C, regs))
   {
      info_log("I2CSlRdLoc:0x%02X,   BufCtrl:0x%02X",
               regs[0], regs[1]);
   }
   if (di_read_registers(instance, 0x4b, 0x4e, regs))
   {
      info_log("\n       Stack Used:% 4d       Free:% 4d\n", (((u16)regs[3]) << 8u) + regs[2], (((u16)regs[1]) << 8u) + regs[0]);
   }
   if (instance->error.driver_error != DE_NONE)
      info_log("       DriverError:%d @%s line %d\n", instance->error.driver_error,
               instance->error.driver_error_func, instance->error.driver_error_aux);
   if (!di_query_status(instance, &executing, &sensing))
      error_log("\nerror querying status to display error info\n");
   else
      info_log("\nexecuting: %d, sensing: %d\n", executing, sensing);
}


bool display_actual_rates(DI_INSTANCE_T *instance)
{
   DI_SENSOR_TYPE_T i;
   SENSOR_CONFIG config;

   info_log("Sensor ID,                 name, rate Hz, range , chg sns, latency ms\n");
   for (i = DST_FIRST; i <= di_max_sensor_id(instance); i++)
   {
      if (!di_has_sensor(instance, i))
         continue;
      info_log("% 2u, %27.27s", i, di_query_sensor_name(instance, i));
      if (!di_query_sensor_config(instance, i, &config))
      {
         error_log("unable to read parameter: %d to display sensor info\n", i);
         return FALSE;
      }
      else
      {
         instance->sensor_info[i].actual_rate = config.sample_rate;
         info_log(", % 6u , % 5u ,  % 5u , % 5u\n", config.sample_rate, config.dynamic_range, config.change_sensitivity, config.max_report_latency);
      }
   }
   return TRUE;
}


bool dump_all_registers(DI_INSTANCE_T *instance)
{
   u8 regs[0xa2];
   int i;

   if (di_read_registers(instance, 0x32, 0xA0, regs))
   {
      for (i = 0x32; i <= 0xa0; i++)
      {
         info_log("0x%02X: 0x%02X\n", i, regs[i]);
      }
   }
   else
   {
      error_log("error dumping registers\n");
      return FALSE;
   }
   return TRUE;
}

// print and clear basic sensors counters
void printGAM(DI_INSTANCE_T *instance)
{
   u8 wake = (instance->hi_id == HIID_KITKAT) ? 0 : di_wake_sensor_start(instance);
   info_log("samples read: %d ", instance->last_chunk_samples_rec);
   info_log("bytes read: %d", instance->sensor_bytes_read);
   info_log("acel    : % 3d ", instance->sensor_info[DST_ACCELEROMETER].samples_received);
   info_log("gyro    : % 3d ", instance->sensor_info[DST_GYROSCOPE].samples_received);
   info_log("mag     : % 3d \n", instance->sensor_info[DST_GEOMAGNETIC_FIELD].samples_received);
   if (instance->hi_id != HIID_KITKAT)
   {
      info_log("acel W  : % 3d ",  instance->sensor_info[DST_ACCELEROMETER | wake].samples_received);
      info_log("gyro W  : % 3d ",  instance->sensor_info[DST_GYROSCOPE | wake].samples_received);
      info_log("mag  W  : % 3d \n", instance->sensor_info[DST_GEOMAGNETIC_FIELD | wake].samples_received);
      instance->sensor_info[DST_ACCELEROMETER     | wake].samples_received = 0;
      instance->sensor_info[DST_GYROSCOPE         | wake].samples_received = 0;
      instance->sensor_info[DST_GEOMAGNETIC_FIELD | wake].samples_received = 0;
   }
   instance->sensor_info[DST_ACCELEROMETER].samples_received = 0;
   instance->sensor_info[DST_GYROSCOPE].samples_received = 0;
   instance->sensor_info[DST_GYROSCOPE].samples_received = 0;
   info_log("== chunk end =============================================\n");
}

// print time and time difference
// s = sensor = to distinguish time W/NW
void prn_time_LSW(DI_INSTANCE_T *di, DI_SENSOR_TYPE_T s)
{
   if ((DST_TIMESTAMP_LSW == s)
#if !defined(DI_SLIM)
       || (DST_WAKEUP_TIMESTAMP_LSW == s)
#endif
      )
   {
      TS_T num;
      int idx = is_wakeup_event(di, s) ? 1 : 0;
      info_log(" time: ");
      num = di->cur_timestamp[idx];
      prn_num_sep(num, 9);
      info_log(" [us] diff: ");
      num = di->cur_timestamp[idx] - di->prev_timestamp[idx];
      prn_num_sep(num, 9);
      info_log(" [us]\n");
   }
}

// reverse string
void str_rev(char *inout)
{
   char t;
   int beg = 0;
   int end = strlen(inout) - 1;
   while (beg < end)
   {
      t = inout[beg];
      inout[beg] = inout[end];
      inout[end] = t;
      beg++;
      end--;
   }
}

// add separator to text ie 123456 -> 123'456
// in: in string
// out: out string
// left2right: if separator will gbe added from left to right or in opposite direction
// len: lenght of block ie 3
// sep: separator character to put at the end of each block
void add_sep(char *in, char *out, bool left2right, int len, char sep)
{
   int sz  = strlen(in);
   int cnt = 0;
   int ii  = left2right ? 0 : sz - 1;
   int io  = 0;
   int add = left2right ? 1 : -1;

   while (sz > 0)
   {
      sz--;
      cnt++;
      out[io++] = in[ii];
      ii += add;
      if ((cnt % len) == 0)
         out[io++] = sep;
   }
   if ((cnt % len) == 0)
      io--;
   out[io] = 0;
   if (!left2right)
      str_rev(out);
}
// print number with fixed size and separator ie "  1'234'567"
// len fixed size of numbers (will be filled with spaces at begining)
// num: number to print
void prn_num_sep(TS_T num, int len)
{
   char txt[50];
   char txt2[50];
#ifdef _WIN32
   sprintf_s(txt, 50, "% *I64u", len, num);
#else
   snprintf(txt,50,"% *I64u", len, num);
#endif
   add_sep(txt, txt2, FALSE, 3, ',');
   info_log("%s", txt2);
}


/** @}*/

