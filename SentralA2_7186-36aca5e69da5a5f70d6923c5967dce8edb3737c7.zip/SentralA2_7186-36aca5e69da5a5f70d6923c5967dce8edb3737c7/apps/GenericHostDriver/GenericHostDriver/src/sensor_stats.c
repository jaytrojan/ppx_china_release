/**
 * \file    sensor_stats.c
 *
 *
 * \brief   routines to gather and display sensor statistics
 *
 * \copyright (C) 2013-2014 EM Microelectronic
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include <limits.h>
#include <float.h>
#include "driver_ext.h"
#include "driver_util.h"
#include "sensor_handling.h"
#include "sensor_stats.h"

/** \addtogroup Sensor_Stats
 *  @{
 */

// uncomment to add extra sanity checking to float values prior to printing
//#define CHECK_FLOATS

// sensor data acquisition variables
#if defined(_MSC_VER)
#define MEMORY_SECTION  /**< location in RAM to store this data */
#else
#define MEMORY_SECTION __attribute__((section (".data.$RAM3"))) /**< location in RAM to store this data */
#endif

#if defined(DI_SLIM)
#define NUM_FIFOS 1
#else
#define NUM_FIFOS 2
#endif
MEMORY_SECTION DI_SENSOR_DATA_T sensor_data_min[NUM_FIFOS];   // Sensor Data Min [0] is standard sensor set, [1] is wakeup sensor set
/*MEMORY_SECTION*/ DI_SENSOR_DATA_T sensor_data_max[NUM_FIFOS];   // Sensor Data Max [0] is standard sensor set, [1] is wakeup sensor set
/*MEMORY_SECTION*/ DI_SENSOR_DATA_T sensor_data_ave[NUM_FIFOS];   // Sensor Data Ave [0] is standard sensor set, [1] is wakeup sensor set
/*MEMORY_SECTION*/ DI_SENSOR_DATA_T sensor_data_prv[NUM_FIFOS];   // Sensor Data Prv [0] is standard sensor set, [1] is wakeup sensor set

#if defined(DI_SLIM)
#define STATS_SIZE DST_NUM_SENSOR_TYPES
#else
#define STATS_SIZE 255
#endif

static u32 sample_counts[STATS_SIZE];                                // firmware tests, normal main
static u32 duplicate_counts[STATS_SIZE];                             // number of samples with identical data
static float measured_sample_rates[STATS_SIZE];
static u32 event_count;
static float measured_event_rate;
u32 stats_start_time;                                         // firmware tests, normal main


static LOG_LEVEL_T log_level = LL_INFO;

void stats_set_log_level(LOG_LEVEL_T level)
{
   log_level = level;
}


static void stats_3axis_min(DI_3AXIS_DATA_T *out, DI_3AXIS_DATA_T *in)
{
   if (out->x > in->x)
      out->x = in->x;
   if (out->y > in->y)
      out->y = in->y;
   if (out->z > in->z)
      out->z = in->z;
   if (out->t > in->t)
      out->t = in->t;
}

static void stats_3axis_max(DI_3AXIS_DATA_T *out, DI_3AXIS_DATA_T *in)
{
   if (out->x < in->x)
      out->x = in->x;
   if (out->y < in->y)
      out->y = in->y;
   if (out->z < in->z)
      out->z = in->z;
   if (out->t < in->t)
      out->t = in->t;
}

static void stats_3axis_ave(DI_3AXIS_DATA_T *out, DI_3AXIS_DATA_T *in)
{
   out->x += in->x;
   out->y += in->y;
   out->z += in->z;
   out->t += in->t;
}

static bool stats_3axis_prv(DI_3AXIS_DATA_T *prev_data, DI_3AXIS_DATA_T *new_data)
{
   bool ret;

   if ((prev_data->x == new_data->x) && (prev_data->y == new_data->y) && (prev_data->z == new_data->z))
      ret = TRUE;
   else
      ret = FALSE;

   prev_data->x = new_data->x;
   prev_data->y = new_data->y;
   prev_data->z = new_data->z;
   prev_data->t = new_data->t;
   return ret;
}

static void stats_3axis_calc(DI_3AXIS_DATA_T *stat, u32 count)
{
   if (count)
   {
      stat->x /= count;
      stat->y /= count;
      stat->z /= count;
      stat->t /= count;
   }
}

static void stats_3axis_raw_min(DI_3AXIS_RAW_DATA_T *out, DI_3AXIS_RAW_DATA_T *in)
{
   if (out->x > in->x)
      out->x = in->x;
   if (out->y > in->y)
      out->y = in->y;
   if (out->z > in->z)
      out->z = in->z;
   if (out->t > in->t)
      out->t = in->t;
}

static void stats_3axis_raw_max(DI_3AXIS_RAW_DATA_T *out, DI_3AXIS_RAW_DATA_T *in)
{
   if (out->x < in->x)
      out->x = in->x;
   if (out->y < in->y)
      out->y = in->y;
   if (out->z < in->z)
      out->z = in->z;
   if (out->t < in->t)
      out->t = in->t;
}

static void stats_3axis_raw_ave(DI_3AXIS_RAW_DATA_T *out, DI_3AXIS_RAW_DATA_T *in)
{
   out->x += in->x;
   out->y += in->y;
   out->z += in->z;
   out->t += in->t;
}

static bool stats_3axis_raw_prv(DI_3AXIS_RAW_DATA_T *prev_data, DI_3AXIS_RAW_DATA_T *new_data)
{
   bool ret;

   if ((prev_data->x == new_data->x) && (prev_data->y == new_data->y) && (prev_data->z == new_data->z))
      ret = TRUE;
   else
      ret = FALSE;

   prev_data->x = new_data->x;
   prev_data->y = new_data->y;
   prev_data->z = new_data->z;
   prev_data->t = new_data->t;
   return ret;
}

static void stats_3axis_raw_calc(DI_3AXIS_RAW_DATA_T *stat, u32 count)
{
   if (count)
   {
      stat->x /= count;
      stat->y /= count;
      stat->z /= count;
      stat->t /= count;
   }
}

static void stats_3axis_raw_float_min(DI_3AXIS_RAW_DATA_F_T *out, DI_3AXIS_RAW_DATA_F_T *in)
{
   if (out->x > in->x)
      out->x = in->x;
   if (out->y > in->y)
      out->y = in->y;
   if (out->z > in->z)
      out->z = in->z;
   if (out->t > in->t)
      out->t = in->t;
}

static void stats_3axis_raw_float_max(DI_3AXIS_RAW_DATA_F_T *out, DI_3AXIS_RAW_DATA_F_T *in)
{
   if (out->x < in->x)
      out->x = in->x;
   if (out->y < in->y)
      out->y = in->y;
   if (out->z < in->z)
      out->z = in->z;
   if (out->t < in->t)
      out->t = in->t;
}

static void stats_3axis_raw_float_ave(DI_3AXIS_RAW_DATA_F_T *out, DI_3AXIS_RAW_DATA_F_T *in)
{
   out->x += in->x;
   out->y += in->y;
   out->z += in->z;
   out->t += in->t;
}

static bool stats_3axis_raw_float_prv(DI_3AXIS_RAW_DATA_F_T *prev_data, DI_3AXIS_RAW_DATA_F_T *new_data)
{
   bool ret;

   if ((prev_data->x == new_data->x) && (prev_data->y == new_data->y) && (prev_data->z == new_data->z))
      ret = TRUE;
   else
      ret = FALSE;

   prev_data->x = new_data->x;
   prev_data->y = new_data->y;
   prev_data->z = new_data->z;
   prev_data->t = new_data->t;
   return ret;
}

static void stats_3axis_raw_float_calc(DI_3AXIS_RAW_DATA_F_T *stat, u32 count)
{
   if (count)
   {
      stat->x /= count;
      stat->y /= count;
      stat->z /= count;
      stat->t /= count;
   }
}

static void stats_3axis_uncal_min(DI_3AXIS_UNCAL_DATA_T *out, DI_3AXIS_UNCAL_DATA_T *in)
{
   if (out->x_uncal > in->x_uncal)
      out->x_uncal = in->x_uncal;
   if (out->y_uncal > in->y_uncal)
      out->y_uncal = in->y_uncal;
   if (out->z_uncal > in->z_uncal)
      out->z_uncal = in->z_uncal;
   if (out->x_bias > in->x_bias)
      out->x_bias = in->x_bias;
   if (out->y_bias > in->y_bias)
      out->y_bias = in->y_bias;
   if (out->z_bias > in->z_bias)
      out->z_bias = in->z_bias;
   if (out->t > in->t)
      out->t = in->t;
}

static void stats_3axis_uncal_max(DI_3AXIS_UNCAL_DATA_T *out, DI_3AXIS_UNCAL_DATA_T *in)
{
   if (out->x_uncal < in->x_uncal)
      out->x_uncal = in->x_uncal;
   if (out->y_uncal < in->y_uncal)
      out->y_uncal = in->y_uncal;
   if (out->z_uncal < in->z_uncal)
      out->z_uncal = in->z_uncal;
   if (out->x_bias < in->x_bias)
      out->x_bias = in->x_bias;
   if (out->y_bias < in->y_bias)
      out->y_bias = in->y_bias;
   if (out->z_bias < in->z_bias)
      out->z_bias = in->z_bias;
   if (out->t < in->t)
      out->t = in->t;
}

static void stats_3axis_uncal_ave(DI_3AXIS_UNCAL_DATA_T *out, DI_3AXIS_UNCAL_DATA_T *in)
{
   out->x_uncal += in->x_uncal;
   out->y_uncal += in->y_uncal;
   out->z_uncal += in->z_uncal;
   out->x_bias += in->x_bias;
   out->y_bias += in->y_bias;
   out->z_bias += in->z_bias;
   out->t += in->t;
}

static bool stats_3axis_uncal_prv(DI_3AXIS_UNCAL_DATA_T *prev_data, DI_3AXIS_UNCAL_DATA_T *new_data)
{
   bool ret;

   if ((prev_data->x_uncal == new_data->x_uncal) && (prev_data->y_uncal == new_data->y_uncal) && (prev_data->z_uncal == new_data->z_uncal) &&
       (prev_data->x_bias == new_data->x_bias) && (prev_data->y_bias == new_data->y_bias) && (prev_data->z_bias == new_data->z_bias))
      ret = TRUE;
   else
      ret = FALSE;

   prev_data->x_uncal = new_data->x_uncal;
   prev_data->y_uncal = new_data->y_uncal;
   prev_data->z_uncal = new_data->z_uncal;
   prev_data->x_bias = new_data->x_bias;
   prev_data->y_bias = new_data->y_bias;
   prev_data->z_bias = new_data->z_bias;
   prev_data->t = new_data->t;
   return ret;
}

static void stats_3axis_uncal_calc(DI_3AXIS_UNCAL_DATA_T *stat, u32 count)
{
   if (count)
   {
      stat->x_uncal /= count;
      stat->y_uncal /= count;
      stat->z_uncal /= count;
      stat->x_bias /= count;
      stat->y_bias /= count;
      stat->z_bias /= count;
      stat->t /= count;
   }
}

// firmware tests
float magnitude_3axis(DI_3AXIS_DATA_T *v)
{
   return sqrtf(v->x * v->x + v->y * v->y + v->z * v->z);
}

float magnitude_3axis_uncal(DI_3AXIS_UNCAL_DATA_T *v)
{
   return magnitude_3axis((DI_3AXIS_DATA_T *)v);
}

float get_3axis_ave_magnitude(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   void *dt;                                                         //data
   dt = getDataPtr(instance, sensor, sensor_data_ave);

   switch (di_query_sensor_type(instance, sensor))
   {
      case E_DI_3AXIS_DATA_T     :
         return magnitude_3axis((DI_3AXIS_DATA_T *)dt);
      case E_DI_3AXIS_UNCAL_DATA_T:
         return magnitude_3axis_uncal((DI_3AXIS_UNCAL_DATA_T *)dt);
      default:
         return 0;
   }
}

// none
float magnitude_quat(DI_QUATERNION_DATA_T *v)
{
   return sqrtf(v->x * v->x + v->y * v->y + v->z * v->z + v->w * v->w);
}

static void stats_quat_min(DI_QUATERNION_DATA_T *out, DI_QUATERNION_DATA_T *in)
{
   if (out->x > in->x)
      out->x = in->x;
   if (out->y > in->y)
      out->y = in->y;
   if (out->z > in->z)
      out->z = in->z;
   if (out->w > in->w)
      out->w = in->w;
   if (out->t > in->t)
      out->t = in->t;
}

static void stats_quat_max(DI_QUATERNION_DATA_T *out, DI_QUATERNION_DATA_T *in)
{
   if (out->x < in->x)
      out->x = in->x;
   if (out->y < in->y)
      out->y = in->y;
   if (out->z < in->z)
      out->z = in->z;
   if (out->w < in->w)
      out->w = in->w;
   if (out->t < in->t)
      out->t = in->t;
}

static void stats_quat_ave(DI_QUATERNION_DATA_T *out, DI_QUATERNION_DATA_T *in)
{
   out->x += in->x;
   out->y += in->y;
   out->z += in->z;
   out->w += in->w;
   out->t += in->t;
}

static bool stats_quat_prv(DI_QUATERNION_DATA_T *prev_data, DI_QUATERNION_DATA_T *new_data)
{
   bool ret;
   if ((prev_data->x == new_data->x) && (prev_data->y == new_data->y) && (prev_data->z == new_data->z) && (prev_data->w == new_data->w))
      ret = TRUE;
   else
      ret = FALSE;

   prev_data->x = new_data->x;
   prev_data->y = new_data->y;
   prev_data->z = new_data->z;
   prev_data->t = new_data->t;
   return ret;
}

static void stats_quat_calc(DI_QUATERNION_DATA_T *stat, u32 count)
{
   if (count)
   {
      stat->x /= count;
      stat->y /= count;
      stat->z /= count;
      stat->w /= count;
      stat->t /= count;
   }
}

static void stats_scalar_calc(DI_SCALAR_DATA_T *stat, u32 count)
{
   if (count)
   {
      stat->datum /= count;
      stat->t /= count;
   }
}

static void stats_bscalar_calc(DI_BYTE_SCALAR_DATA_T *stat, u32 count)
{
   if (count)
   {
      stat->datum /= count;
      stat->t /= count;
   }
}

static void stats_uscalar_calc(DI_UINT_SCALAR_DATA_T *stat, u32 count)
{
   if (count)
   {
      stat->datum /= count;
      stat->t /= count;
   }
}



void reset_stats_int(DI_SENSOR_DATA_T *sensor_data_min_l, DI_SENSOR_DATA_T *sensor_data_max_l)
{
   sensor_data_min_l->accel.x = 160.0;
   sensor_data_min_l->accel.y = 160.0;
   sensor_data_min_l->accel.z = 160.0;
   sensor_data_min_l->accel.t = ULONG_MAX;
   sensor_data_min_l->gyro.x = 5000.0;
   sensor_data_min_l->gyro.y = 5000.0;
   sensor_data_min_l->gyro.z = 5000.0;
   sensor_data_min_l->gyro.t = ULONG_MAX;
   sensor_data_min_l->mag.x = 10000.0;
   sensor_data_min_l->mag.y = 10000.0;
   sensor_data_min_l->mag.z = 10000.0;
   sensor_data_min_l->mag.t = ULONG_MAX;
   sensor_data_min_l->gyro_uncal.x_uncal = 5000.0;
   sensor_data_min_l->gyro_uncal.y_uncal = 5000.0;
   sensor_data_min_l->gyro_uncal.z_uncal = 5000.0;
   sensor_data_min_l->gyro_uncal.x_bias = 5000.0;
   sensor_data_min_l->gyro_uncal.y_bias = 5000.0;
   sensor_data_min_l->gyro_uncal.z_bias = 5000.0;
   sensor_data_min_l->gyro_uncal.t = ULONG_MAX;
   sensor_data_min_l->mag_uncal.x_uncal = 10000.0;
   sensor_data_min_l->mag_uncal.y_uncal = 10000.0;
   sensor_data_min_l->mag_uncal.z_uncal = 10000.0;
   sensor_data_min_l->mag_uncal.x_bias = 10000.0;
   sensor_data_min_l->mag_uncal.y_bias = 10000.0;
   sensor_data_min_l->mag_uncal.z_bias = 10000.0;
   sensor_data_min_l->mag_uncal.t = ULONG_MAX;
   sensor_data_min_l->rotation_vector.x = 1.0;
   sensor_data_min_l->rotation_vector.y = 1.0;
   sensor_data_min_l->rotation_vector.z = 1.0;
   sensor_data_min_l->rotation_vector.w = 1.0;
   sensor_data_min_l->rotation_vector.t = ULONG_MAX;
   sensor_data_min_l->game_rotation_vector.x = 1.0;
   sensor_data_min_l->game_rotation_vector.y = 1.0;
   sensor_data_min_l->game_rotation_vector.z = 1.0;
   sensor_data_min_l->game_rotation_vector.w = 1.0;
   sensor_data_min_l->game_rotation_vector.t = ULONG_MAX;
   sensor_data_min_l->geomag_rotation_vector.x = 1.0;
   sensor_data_min_l->geomag_rotation_vector.y = 1.0;
   sensor_data_min_l->geomag_rotation_vector.z = 1.0;
   sensor_data_min_l->geomag_rotation_vector.w = 1.0;
   sensor_data_min_l->geomag_rotation_vector.t = ULONG_MAX;
   sensor_data_min_l->linear_acceleration.x = 160.0;
   sensor_data_min_l->linear_acceleration.y = 160.0;
   sensor_data_min_l->linear_acceleration.z = 160.0;
   sensor_data_min_l->linear_acceleration.t = ULONG_MAX;
   sensor_data_min_l->gravity.x = 160.0;
   sensor_data_min_l->gravity.y = 160.0;
   sensor_data_min_l->gravity.z = 160.0;
   sensor_data_min_l->gravity.t = ULONG_MAX;
   sensor_data_min_l->orientation.x = 360.0;
   sensor_data_min_l->orientation.y = 360.0;
   sensor_data_min_l->orientation.z = 360.0;
   sensor_data_min_l->orientation.t = ULONG_MAX;
   sensor_data_min_l->step_counter.datum = 32767;
   sensor_data_min_l->heart_rate.datum = 255;
   sensor_data_min_l->activity.datum = 32767;
   sensor_data_min_l->raw_accel.x = LONG_MAX;
   sensor_data_min_l->raw_accel.y = LONG_MAX;
   sensor_data_min_l->raw_accel.z = LONG_MAX;
   sensor_data_min_l->raw_accel.t = ULONG_MAX;
   sensor_data_min_l->raw_mag.x = LONG_MAX;
   sensor_data_min_l->raw_mag.y = LONG_MAX;
   sensor_data_min_l->raw_mag.z = LONG_MAX;
   sensor_data_min_l->raw_mag.t = ULONG_MAX;
   sensor_data_min_l->raw_gyro.x = LONG_MAX;
   sensor_data_min_l->raw_gyro.y = LONG_MAX;
   sensor_data_min_l->raw_gyro.z = LONG_MAX;
   sensor_data_min_l->raw_gyro.t = ULONG_MAX;
   sensor_data_min_l->raw_f_accel.x = FLT_MAX;
   sensor_data_min_l->raw_f_accel.y = FLT_MAX;
   sensor_data_min_l->raw_f_accel.z = FLT_MAX;
   sensor_data_min_l->raw_f_accel.t = ULONG_MAX;
   sensor_data_min_l->raw_f_mag.x = FLT_MAX;
   sensor_data_min_l->raw_f_mag.y = FLT_MAX;
   sensor_data_min_l->raw_f_mag.z = FLT_MAX;
   sensor_data_min_l->raw_f_mag.t = ULONG_MAX;
   sensor_data_min_l->raw_f_gyro.x = FLT_MAX;
   sensor_data_min_l->raw_f_gyro.y = FLT_MAX;
   sensor_data_min_l->raw_f_gyro.z = FLT_MAX;
   sensor_data_min_l->raw_f_gyro.t = ULONG_MAX;
   sensor_data_min_l->barometer.datum = FLT_MAX;
   sensor_data_min_l->barometer.t = ULONG_MAX;
   sensor_data_min_l->light.datum = FLT_MAX;
   sensor_data_min_l->light.t = ULONG_MAX;
   sensor_data_min_l->proximity.datum = FLT_MAX;
   sensor_data_min_l->proximity.t = ULONG_MAX;
   sensor_data_min_l->humidity.datum = FLT_MAX;
   sensor_data_min_l->humidity.t = ULONG_MAX;
   sensor_data_min_l->temperature.datum = FLT_MAX;
   sensor_data_min_l->temperature.t = ULONG_MAX;
   sensor_data_min_l->ambient_temperature.datum = FLT_MAX;
   sensor_data_min_l->ambient_temperature.t = ULONG_MAX;

   sensor_data_max_l->accel.x = -160.0;
   sensor_data_max_l->accel.y = -160.0;
   sensor_data_max_l->accel.z = -160.0;
   sensor_data_max_l->accel.t = 0;
   sensor_data_max_l->gyro.x = -5000.0;
   sensor_data_max_l->gyro.y = -5000.0;
   sensor_data_max_l->gyro.z = -5000.0;
   sensor_data_max_l->gyro.t = 0;
   sensor_data_max_l->mag.x = -10000.0;
   sensor_data_max_l->mag.y = -10000.0;
   sensor_data_max_l->mag.z = -10000.0;
   sensor_data_max_l->mag.t = 0;
   sensor_data_max_l->gyro_uncal.x_uncal = -5000.0;
   sensor_data_max_l->gyro_uncal.y_uncal = -5000.0;
   sensor_data_max_l->gyro_uncal.z_uncal = -5000.0;
   sensor_data_max_l->gyro_uncal.x_bias = -5000.0;
   sensor_data_max_l->gyro_uncal.y_bias = -5000.0;
   sensor_data_max_l->gyro_uncal.z_bias = -5000.0;
   sensor_data_max_l->gyro_uncal.t = 0;
   sensor_data_max_l->mag_uncal.x_uncal = -10000.0;
   sensor_data_max_l->mag_uncal.y_uncal = -10000.0;
   sensor_data_max_l->mag_uncal.z_uncal = -10000.0;
   sensor_data_max_l->mag_uncal.x_bias = -10000.0;
   sensor_data_max_l->mag_uncal.y_bias = -10000.0;
   sensor_data_max_l->mag_uncal.z_bias = -10000.0;
   sensor_data_max_l->mag_uncal.t = 0;
   sensor_data_max_l->rotation_vector.x = 0.0;
   sensor_data_max_l->rotation_vector.y = 0.0;
   sensor_data_max_l->rotation_vector.z = 0.0;
   sensor_data_max_l->rotation_vector.w = 0.0;
   sensor_data_max_l->rotation_vector.t = 0;
   sensor_data_max_l->game_rotation_vector.x = 0.0;
   sensor_data_max_l->game_rotation_vector.y = 0.0;
   sensor_data_max_l->game_rotation_vector.z = 0.0;
   sensor_data_max_l->game_rotation_vector.w = 0.0;
   sensor_data_max_l->game_rotation_vector.t = 0;
   sensor_data_max_l->geomag_rotation_vector.x = 0.0;
   sensor_data_max_l->geomag_rotation_vector.y = 0.0;
   sensor_data_max_l->geomag_rotation_vector.z = 0.0;
   sensor_data_max_l->geomag_rotation_vector.w = 0.0;
   sensor_data_max_l->geomag_rotation_vector.t = 0;
   sensor_data_max_l->linear_acceleration.x = -160.0;
   sensor_data_max_l->linear_acceleration.y = -160.0;
   sensor_data_max_l->linear_acceleration.z = -160.0;
   sensor_data_max_l->linear_acceleration.t = 0;
   sensor_data_max_l->gravity.x = -160.0;
   sensor_data_max_l->gravity.y = -160.0;
   sensor_data_max_l->gravity.z = -160.0;
   sensor_data_max_l->gravity.t = 0;
   sensor_data_max_l->orientation.x = -360.0;
   sensor_data_max_l->orientation.y = -360.0;
   sensor_data_max_l->orientation.z = -360.0;
   sensor_data_max_l->orientation.t = 0;
   sensor_data_max_l->step_counter.datum = -32767;
   sensor_data_max_l->heart_rate.datum = 0;
   sensor_data_max_l->activity.datum = 0;
   sensor_data_max_l->raw_accel.x = LONG_MIN;
   sensor_data_max_l->raw_accel.y = LONG_MIN;
   sensor_data_max_l->raw_accel.z = LONG_MIN;
   sensor_data_max_l->raw_accel.t = 0;
   sensor_data_max_l->raw_mag.x = LONG_MIN;
   sensor_data_max_l->raw_mag.y = LONG_MIN;
   sensor_data_max_l->raw_mag.z = LONG_MIN;
   sensor_data_max_l->raw_mag.t = 0;
   sensor_data_max_l->raw_gyro.x = LONG_MIN;
   sensor_data_max_l->raw_gyro.y = LONG_MIN;
   sensor_data_max_l->raw_gyro.z = LONG_MIN;
   sensor_data_max_l->raw_gyro.t = 0;
   sensor_data_max_l->raw_f_accel.x = -FLT_MAX;
   sensor_data_max_l->raw_f_accel.y = -FLT_MAX;
   sensor_data_max_l->raw_f_accel.z = -FLT_MAX;
   sensor_data_max_l->raw_f_accel.t = 0;
   sensor_data_max_l->raw_f_mag.x = -FLT_MAX;
   sensor_data_max_l->raw_f_mag.y = -FLT_MAX;
   sensor_data_max_l->raw_f_mag.z = -FLT_MAX;
   sensor_data_max_l->raw_f_mag.t = 0;
   sensor_data_max_l->raw_f_gyro.x = -FLT_MAX;
   sensor_data_max_l->raw_f_gyro.y = -FLT_MAX;
   sensor_data_max_l->raw_f_gyro.z = -FLT_MAX;
   sensor_data_max_l->raw_f_gyro.t = 0;
   sensor_data_max_l->barometer.datum = 0;
   sensor_data_max_l->barometer.t = 0;
   sensor_data_min_l->light.datum = -FLT_MAX;
   sensor_data_min_l->light.t = 0;
   sensor_data_min_l->proximity.datum = -FLT_MAX;
   sensor_data_min_l->proximity.t = 0;
   sensor_data_min_l->humidity.datum = -FLT_MAX;
   sensor_data_min_l->humidity.t = 0;
   sensor_data_min_l->temperature.datum = -FLT_MAX;
   sensor_data_min_l->temperature.t = 0;
   sensor_data_min_l->ambient_temperature.datum = -FLT_MAX;
   sensor_data_min_l->ambient_temperature.t = 0;
}

// firmware tests, normal main
void reset_stats(void)
{
   static bool first_run = TRUE;
   int i;
   memset(sample_counts, 0, sizeof(sample_counts));
   memset(duplicate_counts, 0, sizeof(duplicate_counts));
   memset(&sensor_data_ave, 0, sizeof(sensor_data_ave));
   if (first_run)
   {
      memset(&sensor_data_prv, 0xff, sizeof(sensor_data_prv));       // make sure it will be different from any normal data
      first_run = FALSE;                                             // but otherwise, keep track of last sample even from previous stats set
   }

   for (i = 0; i < NUM_FIFOS; i++)
   {
      reset_stats_int(&(sensor_data_min[i]), &(sensor_data_max[i]));
   }

   event_count = 0;
   memset(measured_sample_rates, 0, sizeof(measured_sample_rates));
   //stats_start_time = time_ms();
   //do_log(log_level, "reset_stats: %u\n", stats_start_time);
}

void restart_stats_time(void)
{
   stats_start_time = time_ms();
}

#define MIN_MAX_AVE_PARAMS DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, bool verbose, void *dt, void *dt_min, void *dt_max, void *dt_ave, void *dt_prv
#define MIN_MAX_AVE_PARAMS_CALL instance, sensor, verbose, dt, dt_min, dt_max, dt_ave, dt_prv

bool chkValidClrAndAdd(DI_SENSOR_TYPE_T sensor, bool *v)
{
   if (*v == FALSE)
   {
      error_log("update_sensor_stats asked for sensor %d which has no valid data", sensor);
      return FALSE;
   }
   *v = FALSE;
   event_count++;
   if (sensor < STATS_SIZE)
      sample_counts[sensor]++;
   return TRUE;
}
#define TEXT_XYZ_PREFIX 0
#if(TEXT_XYZ_PREFIX==1)
#define PRN_QUAT        " %s: x:%f, y:%f, z:%f, w:%f, acur:%f, tm:%I64u, mag:%f\n"
#define PRN_3AXES       " %s: x:%f, y:%f, z:%f, stat: %u, tm: %I64u, mag:%f\n"
#define PRN_3AXES_UNCAL " %s: x:%f, y:%f, z:%f, ux:%f, uy:%f, uz:%f, st:%u, tm:%I64u, mag:%f\n"
#define PRN_3AXES_RAW   " %s: x:%d, y:%d, z:%d, ts:%I64u\n"
#define PRN_3AXES_RAW_F " %s: x:%f, y:%f, z:%f, ts:%I64u\n"
#define PRN_SCAL        " %s: datum:%f, tm:%I64u\n"
#define PRN_BSCAL       " %s: datum:%u, tm:%I64u\n"
#define PRN_ACTIVITY    " %s: datum:0x%04X %s, tm:%I64u\n"
#define PRN_SINGLETON   " %s: tm:%u\n"
#define PRN_CALSTAT     " %s, SIHI 9:%f, 10:%f, 11:%f, score:%f, st:%u, transComp:%u, tm:%I64u\n"
#else
#define PRN_QUAT        " %s, %f, %f, %f, %f, %f, %I64u, %f\n"
#define PRN_3AXES       " %s, %f, %f, %f, %u, %I64u, %f\n"
#define PRN_3AXES_UNCAL " %s, %f, %f, %f, %f, %f, %f, %u, %I64u, %f\n"
#define PRN_3AXES_RAW   "     %s, %d, %d, %d, %I64u\n"
#define PRN_3AXES_RAW_F "     %s, %f, %f, %f, %I64u\n"
#define PRN_SCAL        " %s, %f, %I64u\n"
#define PRN_BSCAL       " %s, %u, %I64u\n"
#define PRN_ACTIVITY    " %s, 0x%04X %s, %I64u\n"
#define PRN_SINGLETON   " %s, %I64u\n"
#define PRN_CALSTAT     " %s, %f, %f, %f, %f, %u, %u, %I64u\n"
#endif

bool minMaxAveQuat(MIN_MAX_AVE_PARAMS)
{
   DI_QUATERNION_DATA_T *data;
   data = (DI_QUATERNION_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_QUATERNION_DATA_T *)dt_prv)->t; // do stats on delta-T
      stats_quat_min((DI_QUATERNION_DATA_T *)dt_min, data);
      stats_quat_max((DI_QUATERNION_DATA_T *)dt_max, data);
      stats_quat_ave((DI_QUATERNION_DATA_T *)dt_ave, data);
      data->t = old_t;
   }
   if (stats_quat_prv((DI_QUATERNION_DATA_T *)dt_prv, data))
   {
      if (sensor < STATS_SIZE)
         duplicate_counts[sensor]++;
   }
   if (verbose)
   {
      do_log(log_level, PRN_QUAT,
               di_query_sensor_name(instance, sensor), data->x, data->y, data->z, data->w,
               data->accuracy_estimate, data->t, magnitude_quat(data));
   }
   return TRUE;
}

bool minMaxAve3Axes(MIN_MAX_AVE_PARAMS)
{
   DI_3AXIS_DATA_T *data;
   data = (DI_3AXIS_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_3AXIS_DATA_T *)dt_prv)->t; // do stats on delta-T
      stats_3axis_min((DI_3AXIS_DATA_T *)dt_min, data);
      stats_3axis_max((DI_3AXIS_DATA_T *)dt_max, data);
      stats_3axis_ave((DI_3AXIS_DATA_T *)dt_ave, data);
      data->t = old_t;
   }
   if (stats_3axis_prv((DI_3AXIS_DATA_T *)dt_prv, data))
   {
      if (sensor < STATS_SIZE)
         duplicate_counts[sensor]++;
   }
   if (verbose)
   {
      do_log(log_level, PRN_3AXES,
               di_query_sensor_name(instance, sensor), data->x, data->y, data->z,
               data->status, data->t, magnitude_3axis(data));
   }
   return TRUE;
}

bool minMaxAve3AxesUncal(MIN_MAX_AVE_PARAMS)
{
   DI_3AXIS_UNCAL_DATA_T *data;
   data = (DI_3AXIS_UNCAL_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_3AXIS_UNCAL_DATA_T *)dt_prv)->t; // do stats on delta-T
      stats_3axis_uncal_min((DI_3AXIS_UNCAL_DATA_T *)dt_min, data);
      stats_3axis_uncal_max((DI_3AXIS_UNCAL_DATA_T *)dt_max, data);
      stats_3axis_uncal_ave((DI_3AXIS_UNCAL_DATA_T *)dt_ave, data);
      data->t = old_t;
   }
   if (stats_3axis_uncal_prv((DI_3AXIS_UNCAL_DATA_T *)dt_prv, data))
   {
      if (sensor < STATS_SIZE)
         duplicate_counts[sensor]++;
   }
   if (verbose)
   {
      do_log(log_level, PRN_3AXES_UNCAL,
               di_query_sensor_name(instance, sensor), data->x_uncal, data->y_uncal, data->z_uncal,
               data->x_bias, data->y_bias, data->z_bias,
               data->status, data->t, magnitude_3axis_uncal(data));
   }
   return TRUE;
}

bool minMaxAve3AxesRAW(MIN_MAX_AVE_PARAMS)
{
   DI_3AXIS_RAW_DATA_T *data;
   data = (DI_3AXIS_RAW_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_3AXIS_RAW_DATA_T *)dt_prv)->t; // do stats on delta-T
      stats_3axis_raw_min((DI_3AXIS_RAW_DATA_T *)dt_min, data);
      stats_3axis_raw_max((DI_3AXIS_RAW_DATA_T *)dt_max, data);
      stats_3axis_raw_ave((DI_3AXIS_RAW_DATA_T *)dt_ave, data);
      data->t = old_t;
   }
   if (stats_3axis_raw_prv((DI_3AXIS_RAW_DATA_T *)dt_prv, data))
   {
      if (sensor < STATS_SIZE)
         duplicate_counts[sensor]++;
   }
   if (verbose)
   {
      do_log(log_level, PRN_3AXES_RAW, di_query_sensor_name(instance, sensor), data->x, data->y, data->z, data->t);
   }
   return TRUE;
}

bool minMaxAve3AxesRAW_F(MIN_MAX_AVE_PARAMS)
{
   DI_3AXIS_RAW_DATA_F_T *data;
   data = (DI_3AXIS_RAW_DATA_F_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_3AXIS_RAW_DATA_F_T *)dt_prv)->t; // do stats on delta-T
      stats_3axis_raw_float_min((DI_3AXIS_RAW_DATA_F_T *)dt_min, data);
      stats_3axis_raw_float_max((DI_3AXIS_RAW_DATA_F_T *)dt_max, data);
      stats_3axis_raw_float_ave((DI_3AXIS_RAW_DATA_F_T *)dt_ave, data);
      data->t = old_t;
   }
   if (stats_3axis_raw_float_prv((DI_3AXIS_RAW_DATA_F_T *)dt_prv, data))
   {
      if (sensor < STATS_SIZE)
         duplicate_counts[sensor]++;
   }
   if (verbose)
   {
      do_log(log_level, PRN_3AXES_RAW_F, di_query_sensor_name(instance, sensor), data->x, data->y, data->z, data->t);
   }
   return TRUE;
}

bool minMaxAveScal(MIN_MAX_AVE_PARAMS)
{
   DI_SCALAR_DATA_T *data;
   data = (DI_SCALAR_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_SCALAR_DATA_T *)dt_prv)->t; // do stats on delta-T
      if (((DI_SCALAR_DATA_T *)dt_min)->t > data->t)
         ((DI_SCALAR_DATA_T *)dt_min)->t = data->t;
      if (((DI_SCALAR_DATA_T *)dt_min)->datum > data->datum)
         ((DI_SCALAR_DATA_T *)dt_min)->datum = data->datum;
      if (((DI_SCALAR_DATA_T *)dt_max)->t < data->t)
         ((DI_SCALAR_DATA_T *)dt_max)->t = data->t;
      if (((DI_SCALAR_DATA_T *)dt_max)->datum < data->datum)
         ((DI_SCALAR_DATA_T *)dt_max)->datum = data->datum;
      ((DI_SCALAR_DATA_T *)dt_ave)->t += data->t;
      ((DI_SCALAR_DATA_T *)dt_ave)->datum += data->datum;
      data->t = old_t;
   }
   if (verbose)
   {
      do_log(log_level, PRN_SCAL, di_query_sensor_name(instance, sensor), data->datum, data->t);
   }
   return TRUE;
}

bool minMaxAveBScal(MIN_MAX_AVE_PARAMS)
{
   DI_BYTE_SCALAR_DATA_T *data;
   data = (DI_BYTE_SCALAR_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_BYTE_SCALAR_DATA_T *)dt_prv)->t; // do stats on delta-T
      if (((DI_BYTE_SCALAR_DATA_T *)dt_min)->t > data->t)
         ((DI_BYTE_SCALAR_DATA_T *)dt_min)->t = data->t;
      if (((DI_BYTE_SCALAR_DATA_T *)dt_min)->datum > data->datum)
         ((DI_BYTE_SCALAR_DATA_T *)dt_min)->datum = data->datum;
      if (((DI_BYTE_SCALAR_DATA_T *)dt_max)->t < data->t)
         ((DI_BYTE_SCALAR_DATA_T *)dt_max)->t = data->t;
      if (((DI_BYTE_SCALAR_DATA_T *)dt_max)->datum < data->datum)
         ((DI_BYTE_SCALAR_DATA_T *)dt_max)->datum = data->datum;
      ((DI_BYTE_SCALAR_DATA_T *)dt_ave)->t += data->t;
      ((DI_BYTE_SCALAR_DATA_T *)dt_ave)->datum += data->datum;
      data->t = old_t;
   }
   if (verbose)
   {
      do_log(log_level, PRN_BSCAL, di_query_sensor_name(instance, sensor), data->datum, data->t);
   }
   return TRUE;
}

bool minMaxAveUIScal(MIN_MAX_AVE_PARAMS)
{
   DI_UINT_SCALAR_DATA_T *data;
   data = (DI_UINT_SCALAR_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_UINT_SCALAR_DATA_T *)dt_prv)->t; // do stats on delta-T
      if (((DI_UINT_SCALAR_DATA_T *)dt_min)->t > data->t)
         ((DI_UINT_SCALAR_DATA_T *)dt_min)->t = data->t;
      if (((DI_UINT_SCALAR_DATA_T *)dt_min)->datum > data->datum)
         ((DI_UINT_SCALAR_DATA_T *)dt_min)->datum = data->datum;
      if (((DI_UINT_SCALAR_DATA_T *)dt_max)->t < data->t)
         ((DI_UINT_SCALAR_DATA_T *)dt_max)->t = data->t;
      if (((DI_UINT_SCALAR_DATA_T *)dt_max)->datum < data->datum)
         ((DI_UINT_SCALAR_DATA_T *)dt_max)->datum = data->datum;
      ((DI_UINT_SCALAR_DATA_T *)dt_ave)->t += data->t;
      ((DI_UINT_SCALAR_DATA_T *)dt_ave)->datum += data->datum;
      data->t = old_t;
   }
   if (verbose)
   {
      if (sensor != DST_ACTIVITY)
      {
         do_log(log_level, PRN_BSCAL, di_query_sensor_name(instance, sensor), data->datum, data->t);
      }
      else
      {
         char tmp[] = "S0 W0 R0 B0 V0 T0 X0 X0 S0 W0 R0 B0 V0 T0 X0 X0";
         int i;
         for (i = 0; i < 16; i++)
         {
            if (((data->datum >> i) & 1) == 1)
            {
               tmp[i * 3 + 1] = '1';
            }
         }
         do_log(log_level, PRN_ACTIVITY, di_query_sensor_name(instance, sensor), data->datum, tmp, data->t);
      }

   }
   return TRUE;

}

bool minMaxAveSingleton(MIN_MAX_AVE_PARAMS)
{
   DI_SINGLETON_DATA_T *data;
   data = (DI_SINGLETON_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_SINGLETON_DATA_T *)dt_prv)->t; // do stats on delta-T
      if (((DI_SINGLETON_DATA_T *)dt_min)->t > data->t)
         ((DI_SINGLETON_DATA_T *)dt_min)->t = data->t;
      if (((DI_SINGLETON_DATA_T *)dt_max)->t < data->t)
         ((DI_SINGLETON_DATA_T *)dt_max)->t = data->t;
      ((DI_SINGLETON_DATA_T *)dt_ave)->t += data->t;
      data->t = old_t;
   }
   if (verbose)
      do_log(log_level, PRN_SINGLETON, di_query_sensor_name(instance, sensor), data->t);
   return TRUE;
}

bool minMaxAveCalStat(MIN_MAX_AVE_PARAMS)
{
   DI_CALSTATUS_DATA_T *data;
   data = (DI_CALSTATUS_DATA_T *)dt;
   if (!chkValidClrAndAdd(sensor, &(data->valid)))
      return FALSE;
   if (data->t)
   {
      TS_T old_t = data->t;
      data->t = data->t - ((DI_CALSTATUS_DATA_T *)dt_prv)->t; // do stats on delta-T
      if (((DI_CALSTATUS_DATA_T *)dt_min)->t > data->t)
         ((DI_CALSTATUS_DATA_T *)dt_min)->t = data->t;
      if (((DI_CALSTATUS_DATA_T *)dt_max)->t < data->t)
         ((DI_CALSTATUS_DATA_T *)dt_max)->t = data->t;
      ((DI_CALSTATUS_DATA_T *)dt_ave)->t += data->t;
      data->t = old_t;
   }
   if (verbose)
   {
      do_log(log_level, PRN_CALSTAT,
               di_query_sensor_name(instance, sensor), data->mcalSIHI9, data->mcalSIHI10, data->mcalSIHI11,
               data->mcalScore1, data->mcalStatus, data->transientCompensation, data->t);
   }
   return TRUE;
}

// this pretend that exists sensor class which has virtual function minMaxAvg and it is done using correct child function
//  only it operates on global structs sensor_data_min,sensor_data_max,sensor_data_ave,sensor_data which is not very nice...
bool virtFunctTbl_fncSensorMinMaxAve(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, bool verbose)
{
   void *dt;
   void *dt_min;
   void *dt_max;
   void *dt_ave;
   void *dt_prv;
#if !defined(DI_SLIM)
   if (is_wakeup_event(instance, sensor))
   {
      dt = getDataPtr_knownSensorType(instance, sensor, (DI_SENSOR_DATA_T *)&sensor_data_w);
   }
   else
#endif
   {
      dt = getDataPtr_knownSensorType(instance, sensor, (DI_SENSOR_DATA_T *)&sensor_data);
   }
   dt_min = getDataPtr(instance, sensor, sensor_data_min);
   dt_max = getDataPtr(instance, sensor, sensor_data_max);
   dt_ave = getDataPtr(instance, sensor, sensor_data_ave);
   dt_prv = getDataPtr(instance, sensor, sensor_data_prv);
   if ((dt == NULL) || (dt_min == NULL) || (dt_max == NULL) || (dt_ave == NULL) || (dt_prv == NULL))
   {
      error_log("sensor_data[_min|max|avg] was not found in structure DI_SENSOR_DATA_T for sensor %d (%s)\n", sensor, di_query_sensor_name(instance, sensor));
      return FALSE;
   }
   switch (di_query_sensor_type(instance, sensor))
   {
      case E_DI_QUATERNION_DATA_T:
         return minMaxAveQuat(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_3AXIS_DATA_T     :
         return minMaxAve3Axes(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_3AXIS_UNCAL_DATA_T:
         return minMaxAve3AxesUncal(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_3AXIS_RAW_DATA_T  :
         return minMaxAve3AxesRAW(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_3AXIS_RAW_DATA_F_T:
         return minMaxAve3AxesRAW_F(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_SCALAR_DATA_T      :
         return minMaxAveScal(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_BYTE_SCALAR_DATA_T :
         return minMaxAveBScal(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_UINT_SCALAR_DATA_T :
         return minMaxAveUIScal(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_SINGLETON_DATA_T   :
         return minMaxAveSingleton(MIN_MAX_AVE_PARAMS_CALL);
      case E_DI_CALSTATUS_DATA_T   :
         return minMaxAveCalStat(MIN_MAX_AVE_PARAMS_CALL);
      case E_SENS_DATA_TYPE_UNKNOWN:
      default:
         return FALSE;
   }
}

// firmware tests, normal main
bool update_sensor_stats(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, bool verbose)
{
   bool ret;
   if ((sensor > di_max_sensor_id(instance)) && !((sensor >= DST_RAW_DEBUG_OUTPUT_GYRO) && (sensor <= DST_RAW_DEBUG_OUTPUT_ACCEL)))
   {
      return FALSE;
   }
   //do_log(log_level, "update_sensor_stats1: %u\n", stats_start_time);
   ret = virtFunctTbl_fncSensorMinMaxAve(instance, sensor, verbose);
   //do_log(log_level, "update_sensor_stats2: %u\n", stats_start_time);
   return ret;
}

static bool validate_3axis(DI_3AXIS_DATA_T *data)
{
   if (!data)
      return FALSE;
#if defined(CHECK_FLOATS)
   if (isnan(data->x))
      return FALSE;
   if (isnan(data->y))
      return FALSE;
   if (isnan(data->z))
      return FALSE;
   if (isinf(data->x))
      return FALSE;
   if (isinf(data->y))
      return FALSE;
   if (isinf(data->z))
      return FALSE;
#endif
   return TRUE;
}

static bool validate_3axis_uncal(DI_3AXIS_UNCAL_DATA_T *data)
{
   return validate_3axis((DI_3AXIS_DATA_T *)data);
}

static bool validate_quat(DI_QUATERNION_DATA_T *data)
{
   if (!data)
      return FALSE;
#if defined(CHECK_FLOATS)
   if (isnan(data->x))
      return FALSE;
   if (isnan(data->y))
      return FALSE;
   if (isnan(data->z))
      return FALSE;
   if (isnan(data->w))
      return FALSE;
   if (isinf(data->x))
      return FALSE;
   if (isinf(data->y))
      return FALSE;
   if (isinf(data->z))
      return FALSE;
   if (isinf(data->w))
      return FALSE;
#endif
   return TRUE;
}

bool virtFunctTbl_fncCalcAvg(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   void *dt;
   if (sensor < STATS_SIZE)
   {
      dt = getDataPtr(instance, sensor, sensor_data_ave);
      switch (di_query_sensor_type(instance, sensor))
      {
         case E_DI_QUATERNION_DATA_T:
            stats_quat_calc((DI_QUATERNION_DATA_T *)dt, sample_counts[sensor]);
            break;
         case E_DI_3AXIS_DATA_T     :
            stats_3axis_calc((DI_3AXIS_DATA_T *)dt, sample_counts[sensor]);
            break;
         case E_DI_3AXIS_UNCAL_DATA_T:
            stats_3axis_uncal_calc((DI_3AXIS_UNCAL_DATA_T *)dt, sample_counts[sensor]);
            break;
         case E_DI_3AXIS_RAW_DATA_F_T:
            stats_3axis_raw_float_calc((DI_3AXIS_RAW_DATA_F_T *)dt, sample_counts[sensor]);
            break;
         case E_DI_3AXIS_RAW_DATA_T:
            stats_3axis_raw_calc((DI_3AXIS_RAW_DATA_T *)dt, sample_counts[sensor]);
            break;
         case E_DI_SCALAR_DATA_T:
            stats_scalar_calc((DI_SCALAR_DATA_T *)dt, sample_counts[sensor]);
            break;
         case E_DI_BYTE_SCALAR_DATA_T:
            stats_bscalar_calc((DI_BYTE_SCALAR_DATA_T *)dt, sample_counts[sensor]);
            break;
         case E_DI_UINT_SCALAR_DATA_T:
            stats_uscalar_calc((DI_UINT_SCALAR_DATA_T *)dt, sample_counts[sensor]);
            break;
         default:
            return FALSE;
      }
   }
   return TRUE;
}

void calc_periodic_stats(DI_INSTANCE_T *instance)
{
   u32 time = time_ms();
   u32 delta_t = time - stats_start_time;
   int i;
   stats_start_time = time; // assume sensors are still on; make sure we include full time elapsed from one calc to another
   for (i = 0; i <= di_max_sensor_id(instance); i++)
   {
      virtFunctTbl_fncCalcAvg(instance, (DI_SENSOR_TYPE_T)i);
   }
   if (STATS_SIZE >= DST_RAW_DEBUG_OUTPUT_GYRO)
   {
      virtFunctTbl_fncCalcAvg(instance, (DI_SENSOR_TYPE_T)DST_RAW_DEBUG_OUTPUT_GYRO);
      virtFunctTbl_fncCalcAvg(instance, (DI_SENSOR_TYPE_T)DST_RAW_DEBUG_OUTPUT_MAG);
      virtFunctTbl_fncCalcAvg(instance, (DI_SENSOR_TYPE_T)DST_RAW_DEBUG_OUTPUT_ACCEL);
   }

   if (delta_t)
   {
      int limit = di_max_sensor_id(instance);
      if (limit > STATS_SIZE)
         limit = STATS_SIZE;
      for (i = 0; i < limit; i++)
      {
         //do_log(log_level, "calc: sns %u, cnt %u, delta_t %u, time %u, start_tm %u\n", i, sample_counts[i], delta_t, time, stats_start_time);
         measured_sample_rates[i] = (1000.0f * sample_counts[i]) / delta_t;
      }
      if (STATS_SIZE >= DST_RAW_DEBUG_OUTPUT_GYRO)
      {
         measured_sample_rates[DST_RAW_DEBUG_OUTPUT_GYRO] = (1000.0f * sample_counts[DST_RAW_DEBUG_OUTPUT_GYRO]) / delta_t;
         measured_sample_rates[DST_RAW_DEBUG_OUTPUT_MAG] = (1000.0f * sample_counts[DST_RAW_DEBUG_OUTPUT_MAG]) / delta_t;
         measured_sample_rates[DST_RAW_DEBUG_OUTPUT_ACCEL] = (1000.0f * sample_counts[DST_RAW_DEBUG_OUTPUT_ACCEL]) / delta_t;
      }

      measured_event_rate = (1000.0f * event_count) / delta_t;
   }
   else
   {
      do_log(log_level, "delta_t = 0, event count = %u!\n", event_count);
      memset(measured_sample_rates, 0, sizeof(measured_sample_rates));
      measured_event_rate = 0;
   }
}


#define DISP_SENSOR_STAT_PARAM DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,bool verbose, void *dt_min, void *dt_max, void *dt_ave
#define DISP_SENSOR_STAT_PARAM_CALL instance, sensor,verbose,dt_min, dt_max, dt_ave
static void display_3axis_sensor_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_3AXIS_DATA_T *data_min;
   DI_3AXIS_DATA_T *data_ave;
   DI_3AXIS_DATA_T *data_max;

   data_min = (DI_3AXIS_DATA_T *)dt_min;
   data_max = (DI_3AXIS_DATA_T *)dt_max;
   data_ave = (DI_3AXIS_DATA_T *)dt_ave;

   if (!validate_3axis(data_min) || !validate_3axis(data_ave) || !validate_3axis(data_max))
   {
      do_log(log_level, "INVALID DATA\n");
      return;
   }

   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, %u dups, ave(%f, %f, %f, %I64u)=%f, rate: %3.3f Hz",
               di_query_sensor_name(instance, sensor), sample_counts[sensor], duplicate_counts[sensor],
               data_ave->x, data_ave->y, data_ave->z, data_ave->t,
               magnitude_3axis(data_ave),
               measured_sample_rates[sensor]);
      if (verbose)
      {
         do_log(log_level, "| min(%f, %f, %f, %I64u)=%f,  max(%f, %f, %f, %I64u)=%f",
                  data_min->x, data_min->y, data_min->z, data_min->t, magnitude_3axis(data_min),
                  data_max->x, data_max->y, data_max->z, data_max->t, magnitude_3axis(data_max));
      }
      do_log(log_level, "\n");
   }
}

static void display_3axis_raw_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_3AXIS_RAW_DATA_T *data_min;
   DI_3AXIS_RAW_DATA_T *data_ave;
   DI_3AXIS_RAW_DATA_T *data_max;

   data_min = (DI_3AXIS_RAW_DATA_T *)dt_min;
   data_max = (DI_3AXIS_RAW_DATA_T *)dt_max;
   data_ave = (DI_3AXIS_RAW_DATA_T *)dt_ave;

   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, %u dups, ave(%d, %d, %d, %I64u), rate: %3.3f Hz",
               di_query_sensor_name(instance, sensor), sample_counts[sensor], duplicate_counts[sensor],
               data_ave->x, data_ave->y, data_ave->z, data_ave->t,
               measured_sample_rates[sensor]);
      if (verbose)
      {
         do_log(log_level, "| min(%d, %d, %d, %I64u),  max(%d, %d, %d, %I64u)",
                  data_min->x, data_min->y, data_min->z, data_min->t,
                  data_max->x, data_max->y, data_max->z, data_max->t);
      }
      do_log(log_level, "\n");
   }
}

static void display_3axis_raw_float_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_3AXIS_RAW_DATA_F_T *data_min;
   DI_3AXIS_RAW_DATA_F_T *data_ave;
   DI_3AXIS_RAW_DATA_F_T *data_max;

   data_min = (DI_3AXIS_RAW_DATA_F_T *)dt_min;
   data_max = (DI_3AXIS_RAW_DATA_F_T *)dt_max;
   data_ave = (DI_3AXIS_RAW_DATA_F_T *)dt_ave;

   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, %u dups, ave(%f, %f, %f, %I64u), rate: %3.3f Hz",
               di_query_sensor_name(instance, sensor), sample_counts[sensor], duplicate_counts[sensor],
               data_ave->x, data_ave->y, data_ave->z, data_ave->t,
               measured_sample_rates[sensor]);
      if (verbose)
      {
         do_log(log_level, "| min(%f, %f, %f, %I64u),  max(%f, %f, %f, %I64u)",
                  data_min->x, data_min->y, data_min->z, data_min->t,
                  data_max->x, data_max->y, data_max->z, data_max->t);
      }
      do_log(log_level, "\n");
   }
}

static void display_3axis_uncal_sensor_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_3AXIS_UNCAL_DATA_T *data_min;
   DI_3AXIS_UNCAL_DATA_T *data_ave;
   DI_3AXIS_UNCAL_DATA_T *data_max;

   data_min = (DI_3AXIS_UNCAL_DATA_T *)dt_min;
   data_max = (DI_3AXIS_UNCAL_DATA_T *)dt_max;
   data_ave = (DI_3AXIS_UNCAL_DATA_T *)dt_ave;

   if (!validate_3axis_uncal(data_min) || !validate_3axis_uncal(data_ave) || !validate_3axis_uncal(data_max))
   {
      do_log(log_level, "INVALID DATA\n");
      return;
   }
   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, %u dups, ave(%f, %f, %f, %f, %f, %f, %I64u)=%f, rate: %3.3f Hz",
               di_query_sensor_name(instance, sensor), sample_counts[sensor], duplicate_counts[sensor],
               data_ave->x_uncal, data_ave->y_uncal, data_ave->z_uncal, data_ave->x_bias, data_ave->y_bias, data_ave->z_bias, data_ave->t,
               magnitude_3axis_uncal(data_ave), measured_sample_rates[sensor]);
      if (verbose)
      {
         do_log(log_level, "| min(%f, %f, %f, %f, %f, %f, %I64u)=%f, max(%f, %f, %f, %f, %f, %f, %I64u)=%f",
                  data_min->x_uncal, data_min->y_uncal, data_min->z_uncal, data_min->x_bias, data_min->y_bias, data_min->z_bias, data_min->t, magnitude_3axis_uncal(data_min),
                  data_max->x_uncal, data_max->y_uncal, data_max->z_uncal, data_max->x_bias, data_max->y_bias, data_max->z_bias, data_max->t, magnitude_3axis_uncal(data_max));
      }
      do_log(log_level, "\n");
   }
}


static void display_quat_sensor_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_QUATERNION_DATA_T *data_min;
   DI_QUATERNION_DATA_T *data_ave;
   DI_QUATERNION_DATA_T *data_max;

   data_min = (DI_QUATERNION_DATA_T *)dt_min;
   data_max = (DI_QUATERNION_DATA_T *)dt_max;
   data_ave = (DI_QUATERNION_DATA_T *)dt_ave;

   if (!validate_quat(data_min) || !validate_quat(data_ave) || !validate_quat(data_max))
   {
      do_log(log_level, "INVALID DATA\n");
      return;
   }
   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, %u dups, ave(%f, %f, %f, %f, %I64u)=%f, rate: %3.3f Hz",
               di_query_sensor_name(instance, sensor), sample_counts[sensor], duplicate_counts[sensor],
               data_ave->x, data_ave->y, data_ave->z, data_ave->w, data_ave->t,
               magnitude_quat(data_ave), measured_sample_rates[sensor]);
      if (verbose)
      {
         do_log(log_level, "| min(%f, %f, %f, %f, %I64u)=%f, max(%f, %f, %f, %f, %I64u)=%f",
                  data_min->x, data_min->y, data_min->z, data_min->w, data_min->t, magnitude_quat(data_min),
                  data_max->x, data_max->y, data_max->z, data_max->w, data_max->t, magnitude_quat(data_max));
      }
      do_log(log_level, "\n");
   }
}

static void display_scal_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_SCALAR_DATA_T *data_ave = (DI_SCALAR_DATA_T *)dt_ave;
   DI_SCALAR_DATA_T *data_min = (DI_SCALAR_DATA_T *)dt_min;
   DI_SCALAR_DATA_T *data_max = (DI_SCALAR_DATA_T *)dt_max;
   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, ave %f, rate %3.3f Hz",
               di_query_sensor_name(instance, sensor), sample_counts[sensor],
               data_ave->datum, measured_sample_rates[sensor]);
      if (verbose)
      {
         do_log(log_level, "| min(%f, %I64u), max(%f, %I64u)",
                  data_min->datum, data_min->t,
                  data_max->datum, data_max->t);
      }
      do_log(log_level, "\n");
   }
}

static void display_uint_scal_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_UINT_SCALAR_DATA_T *data_ave = (DI_UINT_SCALAR_DATA_T *)dt_ave;
   DI_UINT_SCALAR_DATA_T *data_min = (DI_UINT_SCALAR_DATA_T *)dt_min;
   DI_UINT_SCALAR_DATA_T *data_max = (DI_UINT_SCALAR_DATA_T *)dt_max;
   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, ave %u, rate %3.3f Hz",
               di_query_sensor_name(instance, sensor), sample_counts[sensor],
               data_ave->datum, measured_sample_rates[sensor]);
      if (verbose)
      {
         do_log(log_level, "| min(%u, %I64u), max(%u, %I64u)",
                  data_min->datum, data_min->t,
                  data_max->datum, data_max->t);
      }
      do_log(log_level, "\n");
   }
}

static void display_byte_scal_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_BYTE_SCALAR_DATA_T *data_ave = (DI_BYTE_SCALAR_DATA_T *)dt_ave;
   DI_BYTE_SCALAR_DATA_T *data_min = (DI_BYTE_SCALAR_DATA_T *)dt_min;
   DI_BYTE_SCALAR_DATA_T *data_max = (DI_BYTE_SCALAR_DATA_T *)dt_max;
   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, ave %u, rate %3.3f Hz\n",
               di_query_sensor_name(instance, sensor), sample_counts[sensor],
               data_ave->datum, measured_sample_rates[sensor]);
      if (verbose)
      {
         do_log(log_level, "| min(%u, %I64u), max(%u, %I64u)",
                  data_min->datum, data_min->t,
                  data_max->datum, data_max->t);
      }
      do_log(log_level, "\n");
   }
}

static void display_singleton_stats(DISP_SENSOR_STAT_PARAM)
{
   DI_SINGLETON_DATA_T *data_ave;
   data_ave = (DI_SINGLETON_DATA_T *)dt_ave;
   if ((sensor < STATS_SIZE) && sample_counts[sensor])
   {
      do_log(log_level, "%28.28s: %u samples, rate %3.3f Hz\n",
               di_query_sensor_name(instance, sensor), sample_counts[sensor], measured_sample_rates[sensor]);
   }
}

// virtual function table
bool display_sensor_stat(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, bool verbose)
{
   void *dt_min;
   void *dt_ave;
   void *dt_max;
   dt_min = getDataPtr(instance, sensor, sensor_data_min);
   dt_max = getDataPtr(instance, sensor, sensor_data_max);
   dt_ave = getDataPtr(instance, sensor, sensor_data_ave);
   if ((dt_min == NULL) || (dt_max == NULL) || (dt_ave == NULL))
   {
      //error_log("display_sensor_stat: Can not find data for sensor %d (%s) using function getDataPtr()",sensor, di_query_sensor_name(instance, sensor));
      return FALSE;
   }

   switch (di_query_sensor_type(instance, sensor))
   {
      case E_DI_QUATERNION_DATA_T :
         display_quat_sensor_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      case E_DI_3AXIS_DATA_T      :
         display_3axis_sensor_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      case E_DI_3AXIS_UNCAL_DATA_T:
         display_3axis_uncal_sensor_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      case E_DI_BYTE_SCALAR_DATA_T:
         display_byte_scal_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      case E_DI_UINT_SCALAR_DATA_T:
         display_uint_scal_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      case E_DI_SCALAR_DATA_T:
         display_scal_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      case E_DI_SINGLETON_DATA_T  :
         display_singleton_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      case E_DI_3AXIS_RAW_DATA_F_T:
         display_3axis_raw_float_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      case E_DI_3AXIS_RAW_DATA_T:
         display_3axis_raw_stats(DISP_SENSOR_STAT_PARAM_CALL);
         break;
      default:
         return FALSE;
   }
   return TRUE;
}



void display_periodic_stats(DI_INSTANCE_T *instance, bool verbose)
{
   int i;
   for (i = 0; i <= di_max_sensor_id(instance); i++)
   {
      display_sensor_stat(instance, i, verbose);
   }
   display_sensor_stat(instance, DST_RAW_DEBUG_OUTPUT_ACCEL, verbose);
   display_sensor_stat(instance, DST_RAW_DEBUG_OUTPUT_GYRO, verbose);
   display_sensor_stat(instance, DST_RAW_DEBUG_OUTPUT_MAG, verbose);
   do_log(log_level, "                  event rate: %3.3f Hz\n", measured_event_rate);
}


u16 get_measured_sample_rate(DI_SENSOR_TYPE_T sensor)
{
   if (sensor < STATS_SIZE)
      return (u16)(floor(measured_sample_rates[sensor] + 0.5));
   else
      return 0;
}


float get_measured_sample_rate_float(DI_SENSOR_TYPE_T sensor)
{
   if (sensor < STATS_SIZE)
      return measured_sample_rates[sensor];
   else
      return 0;
}


void clear_measured_sample_rates(void)
{
   memset(measured_sample_rates, 0, sizeof(measured_sample_rates));
}


u16 get_event_rate(void)
{
   return (u16)(floor(measured_event_rate + 0.5));
}

/** @}*/

