/**
 * \file    sensor_handling.c
 *
 *
 * \brief   useful routines for managing sensor data
 *
 * \copyright (C) 2013-2014 EM Microelectronic
 *
 */

#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdint.h>
#include <math.h>
#include "driver_ext.h"
#include "driver_util.h"
#include "sensor_stats.h"
#include "sensor_handling.h"

/** \addtogroup Sensor_Handling
 *  @{
 */

// sensor data acquisition variables
#if defined(_MSC_VER)
#define MEMORY_SECTION  /**< location in RAM to store this data */
#else
#define MEMORY_SECTION __attribute__((section (".data.$RAM3"))) /**< location in RAM to store this data */
#endif
MEMORY_SECTION volatile DI_SENSOR_DATA_T sensor_data;               // sensor_hid, main, firmware tests
#if !defined(DI_SLIM)
MEMORY_SECTION volatile DI_SENSOR_DATA_T sensor_data_w;               // sensor_hid, main, firmware tests
#endif

static volatile bool sensor_ready[255];             // sensor_hid, data_callback
static volatile u32 sensor_data_received = 0;
static bool verbose_data = FALSE;
static bool raw_data = FALSE;


// firmware tests, main
u32 get_sensor_data_received_count(void)
{
   return sensor_data_received;
}

// sensor_hid
bool check_sensor_ready(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if (sensor <= di_max_sensor_id(instance))
      return sensor_ready[sensor];
   else
      return FALSE;
}


// none
void clear_sensor_ready(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor)
{
   if (sensor <= di_max_sensor_id(instance))
      sensor_ready[sensor] = FALSE;
}

void set_verbose_sensor_data(bool verbose)
{
   verbose_data = verbose;
}

void set_raw_data(bool raw)
{
   raw_data = raw;
}

// firmware tests, normal main
bool data_callback(DI_INSTANCE_T * instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T * data, void *user_param)
{
    bool converted;
#if 0
   DI_SENSOR_TYPE_T sensor_base;

   if ((sensor >= di_wake_sensor_start(instance)) && (sensor < DST_NUM_SENSOR_TYPES))
      sensor_base = sensor - di_wake_sensor_start(instance);
   else
      sensor_base = sensor;
#endif

   // convert from integer to floating point
#if !defined(DI_SLIM)
   if( is_wakeup_event(instance, sensor) )
   {
      converted = di_convert_sensor_data(instance, sensor, data, (DI_SENSOR_DATA_T*)&sensor_data_w, raw_data);
   }
   else
#endif
   {
      converted = di_convert_sensor_data(instance, sensor, data, (DI_SENSOR_DATA_T*)&sensor_data, raw_data);
   }

   if (sensor <= di_max_sensor_id(instance))
   {
      instance->sensor_info[sensor].valid = FALSE;
      sensor_ready[sensor] = TRUE;
   }
   else if ((sensor >= DST_RAW_DEBUG_OUTPUT_GYRO) && (sensor <= DST_RAW_DEBUG_OUTPUT_ACCEL))
   {
      instance->sensor_info_raw[sensor - DST_RAW_DEBUG_OUTPUT_GYRO].valid = FALSE;
      sensor_ready[sensor] = TRUE;
   }
   sensor_data_received++;
   if(converted) update_sensor_stats(instance, sensor, verbose_data);
   return TRUE;
}

/** @}*/

