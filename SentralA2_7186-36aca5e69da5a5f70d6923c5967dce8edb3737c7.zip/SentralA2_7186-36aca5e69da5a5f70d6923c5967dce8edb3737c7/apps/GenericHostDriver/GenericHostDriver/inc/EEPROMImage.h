////////////////////////////////////////////////////////////////////////////////
///
/// \file   EEPROMImage.h
///
/// \brief  EEPROM firmware image.
///
////////////////////////////////////////////////////////////////////////////////
///
////////////////////////////////////////////////////////////////////////////////
///
/// \copyright (C) EM Microelectronic US Inc.
///
/// \copyright Disclosure to third parties or reproduction in any form
///   whatsoever, without prior written consent, is strictly forbidden
///
////////////////////////////////////////////////////////////////////////////////

#ifndef EEPROM_IMAGE_H
#define EEPROM_IMAGE_H

#include <types.h>


/* EEPROM Image File format
 * 2bytes   MagicNumber
 * 2bytes   Flags
 * 4bytes   Text CRC32-CCITT
 * 4bytes   Data CRC32-CCITT
 * 2bytes   Text Length
 * 2bytes   Data Length
 * Nbytes   Text
 * Nbytes   Data
 */


#define EEPROM_MAGIC_VALUE 0x652A /**< special value that must be present in the magic field of the EEPROMHeader structure */

/** \brief values of the ROMVerExp field */
#define ROM_VERSION_ANY 0 /**< the file is compatible with any ROM version */
#define ROM_VERSION_DI01 1 /**< this file requires ROM di01 */
#define ROM_VERSION_DI02 2 /**< this file requires ROM di02 */
#define ROM_VERSION_DI03 3 /**< this file requires ROM di03 */
#define ROM_VERSION_DI04 4 /**< this file requires ROM di04 */

/** \brief product ID values */
#define PRODUCT_ID_7180 0x80 /**< product ID register value for the u7180 */
#define PRODUCT_ID_7181 0x81 /**< product ID register value for the u7181 */
#define PRODUCT_ID_7183 0x83 /**< product ID register value for the u7183 */
#define PRODUCT_ID_7184 0x84 /**< product ID register value for the u7184 */

/** \brief corresponding values of the ROM Version register for the 7180 */
#define ROM_VER_REG_7180_DI01 0x7A8 /**< this value corresponds to 7180 ROM di01 */
#define ROM_VER_REG_7180_DI02 0x9E6 /**< this value corresponds to ROM di02 */

/** \brief ROM version for 7181 */
#define ROM_VER_REG_7181_DI01 0xF36  /**< this value corresponds to 7181 ROM di01 */
#define ROM_VER_REG_7181_DI02 0x1848 /**< this value corresponds to ROM di02 (2.0.6216) */
#define ROM_VER_REG_7181_DI03 0x1E8B /**< this value corresponds to ROM di03 */

/** \brief ROM versions for 7183 */
#define ROM_VER_REG_7183_DI01 0x2112 /**< this value corresponds to 7183 ROM di01 */

/** \brief ROM versions for 7184 */
#define ROM_VER_REG_7184_DI01 0x1F9D /**< this value corresponds to the ROM di01 */


/**
 * \brief EEPROM boot flags.
 */
PREPACK typedef union MIDPACK {
   /**
    * \brief Direct access to all flags.
    */
   u16 value;                                                     /**< the 16 bit register value for the EEPROM flags register */
   struct
   {
      /** \brief Do not execute the EEPROM image immediately after upload */
      u16   EEPROMNoExec:1;
      /** \brief Reserved */
      u16   Reserved:7;
      /** \brief The clock speed to upload the firmware at */
      u16   I2CClockSpeed:3;
      /** \brief Rom version expected */
      u16   ROMVerExp:4;
      /** \brief Reserved */
      u16   reserved1:1;
   }
   bits;                                                             /**< the bit fields within the EEPROM flags register */
}
EEPROMFlags;                                                         /**< typedef for storing EEPROM flags values */
POSTPACK

/**
 * \brief EEPROM header format
 *
 * NOTE: a ROM version may also be useful to ensure that an
 * incorrect ram binary is not used. This is currently not
 * implemented, however the RAM / EEPROM start code can double
 * check this before it starts if needed.
 */
PREPACK typedef struct MIDPACK {
   /** \brief The firmware magic number */
   u16 magic;                                                     // Already read
   /** \brief Flags used to notify and control the boot process */
   EEPROMFlags flags;
   /** \brief The CRC32-CCITT of the firmware text segment */
   u32 text_CRC;
   /** \brief reserved 32 bit area 1 */
   u32 reserved1;
   /** \brief The number of program bytes to upload */
   u16 text_length;
   /** \brief reserved 16 bit area 2 */
   u16 reserved2;
}
EEPROMHeader;                                                        /**< typedef for storing EEPROM headers */
POSTPACK

#endif /* EEPROM_IMAGE_H */

