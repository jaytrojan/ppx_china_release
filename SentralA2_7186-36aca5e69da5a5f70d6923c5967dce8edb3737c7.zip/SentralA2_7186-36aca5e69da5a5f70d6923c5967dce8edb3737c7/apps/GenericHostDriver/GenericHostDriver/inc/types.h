////////////////////////////////////////////////////////////////////////////////
///
/// \file   types.h
///
///
/// \brief  Standard datatypes
///
////////////////////////////////////////////////////////////////////////////////
///
////////////////////////////////////////////////////////////////////////////////
///
/// \copyright (C) EM Microelectronic US Inc.
///
/// \copyright Disclosure to third parties or reproduction in any form
///   whatsoever, without prior written consent, is strictly forbidden
///
////////////////////////////////////////////////////////////////////////////////

#ifndef TYPES_H
#define TYPES_H

#include "portable.h"

#if !defined(__KERNEL__)
#include <stdint.h>
typedef int8_t     s8;                                       /**< Signed 8 bit integer. */
typedef uint8_t    u8;                                       /**< Unsigned 8 bit integer. */
typedef int16_t    s16;                                      /**< Signed 16 bit integer. */
typedef uint16_t   u16;                                      /**< Unsigned 16 bit integer. */
typedef int32_t    s32;                                      /**< Signed 32 bit integer. */
#define S32_MIN (-2147483648)
#define S32_MAX (+2147483647)
#define U16_MAX (+65535)
#define U32_MAX (+4294967295)
typedef uint32_t   u32;                                      /**< Unsigned 32 bit integer. */
typedef int64_t    s64;                                      /**< Signed 64 bit integer. */
typedef uint64_t   u64;                                      /**< Unsigned 64 bit integer. */
#else
#include <linux/types.h>
#endif

#if !defined(__cplusplus)
typedef char         bool;                                           /**< Boolean. */
#endif

#ifndef TRUE
#define TRUE         1     /**< True */
#endif /* !TRUE */

#ifndef FALSE
#define FALSE        0     /**< False */
#endif /* !FALSE */

#ifndef NULL
#define NULL         ((void*)0)  /**< Null pointer */
#endif /* NULL */

// TODO remove when debugging is finished
//#define VBE_DBG
#ifdef VBE_DBG
//#define VBE_DBG_SCRN
//#define VBE_DBG_EACH_EVNT
//#define VBE_DBG_EACH_EVNT_TIME
//#define VBE_DO_NOT_PRN_CONSOLE_FOR_SPEED
//#define VBE_DBG_FIFO_READ
#endif

#endif /* TYPES_H */
