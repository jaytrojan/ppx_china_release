/**
 * \file    U718x_parameters.h
 *
 *
 * \brief   parameter numbers for load/save
 *
 * \copyright  (C) 2013-2014 EM Microelectronic
 *
 */


#ifndef _U718X_PARAMETERS_H_
#define _U718X_PARAMETERS_H_

#include "types.h"
#include "portable.h"


/** \brief parameter page numbers */
typedef enum ParameterPage
{
   PP_OFF,                                                           /**< no parameter page being accessed; modification to algorithm settings complete */
   PP_SYSTEM,                                                        /**< system-related parameters */
   PP_ALGORITHM,                                                     /**< parameters that affect the sensor algorithms */
   PP_SENSORS,                                                       /**< parameters that affect or obtain information about the sensors */
   PP_SENSOR_INFO_LEX = PP_SENSORS,
   PP_SENSOR_CONFIG_LEX = PP_SENSOR_INFO_LEX + 2,
   PP_MAX_PAGE = PP_SENSOR_CONFIG_LEX,
} ParameterPage;

/** \brief maximum parameter value */
#define MAX_PARAM_PAGE 16                                            /**< largest parameter page allowed */
#define MAX_PARAM_NUMBER 127                                         /**< largest parameter number allowed */
#define PARAM_SAVE_SIZE 16                                           /**< number of bytes we read per parameter */
#define PARAM_LOAD_SIZE 8                                            /**< number of bytes we write per parameter */

/**************************************************************
*  System Page                                                *
*                                                             *
***************************************************************/
#define SYSP_META_EVENT_CONTROL     1                                /**< control the enabled state and interrupt generation ability for each meta event */
#define SYSP_FIFO_CONTROL           2                                /**< control the watermark or determine the FIFO size; both in bytes */
#define SYSP_SENSOR_STATUS_BANK_0   3                                /**< access 8 bits of status for sensors 1-16 */
#define SYSP_SENSOR_STATUS_BANK_1   4                                /**< access 8 bits of status for sensors 17-32 */
#define SYSP_SENSOR_STATUS_BANK_2   5                                /**< access 8 bits of status for sensors 33-48 */
#define SYSP_SENSOR_STATUS_BANK_3   6                                /**< access 8 bits of status for sensors 49-64 */
#define SYSP_SENSOR_STATUS_BANK_4   7                                /**< access 8 bits of status for sensors 65-80 */
#define SYSP_SENSOR_STATUS_BANK_5   8                                /**< access 8 bits of status for sensors 81-96 */
#define SYSP_SENSOR_STATUS_BANK_6   9                                /**< access 8 bits of status for sensors 97-112 */
#define SYSP_SENSOR_STATUS_BANK_7   10                                /**< access 8 bits of status for sensors 113-128 */

#define SYSP_MAX_PARAMETER          10                                /**< highest official parameter in sequence */
#define SYSP_META_EVENT_CONTROL_WAKEUP_FIFO 29                       /**< control meta events in the wakeup FIFO (future Android L product only) */
#define SYSP_HOST_IRQ_TIMESTAMP     30                               /**< parameter to read the system time of the last host interrupt */
#define SYSP_PHYS_SENS_STATUS       31                               /**< debug info to give us a way to see what the physical sensors are doing */
#define SYSP_LAST_PARAMETER         31                               /**< last actual parameter */

/**
 * \brief structure to access control bits for each possible meta event
 */
PREPACK typedef struct MIDPACK META_EVENT_CONTROL_PARAM
{
   u64 me1 : 2;                                                      /**< meta event 1 control */
   u64 me2 : 2;                                                      /**< meta event 2  control */
   u64 me3 : 2;                                                      /**< meta event 3  control */
   u64 me4 : 2;                                                      /**< meta event 4  control */
   u64 me5 : 2;                                                      /**< meta event 5  control */
   u64 me6 : 2;                                                      /**< meta event 6  control */
   u64 me7 : 2;                                                      /**< meta event 7  control */
   u64 me8 : 2;                                                      /**< meta event 8  control */
   u64 me9 : 2;                                                      /**< meta event 9  control */
   u64 me10 : 2;                                                     /**< meta event 10 control */
   u64 me11 : 2;                                                     /**< meta event 11 control */
   u64 me12 : 2;                                                     /**< meta event 12 control */
   u64 me13 : 2;                                                     /**< meta event 13 control */
   u64 me14 : 2;                                                     /**< meta event 14 control */
   u64 me15 : 2;                                                     /**< meta event 15 control */
   u64 me16 : 2;                                                     /**< meta event 16 control */
   u64 me17 : 2;                                                     /**< meta event 17 control */
   u64 me18 : 2;                                                     /**< meta event 18 control */
   u64 me19 : 2;                                                     /**< meta event 19 control */
   u64 me20 : 2;                                                     /**< meta event 20 control */
   u64 me21 : 2;                                                     /**< meta event 21 control */
   u64 me22 : 2;                                                     /**< meta event 22 control */
   u64 me23 : 2;                                                     /**< meta event 23 control */
   u64 me24 : 2;                                                     /**< meta event 24 control */
   u64 me25 : 2;                                                     /**< meta event 25 control */
   u64 me26 : 2;                                                     /**< meta event 26 control */
   u64 me27 : 2;                                                     /**< meta event 27 control */
   u64 me28 : 2;                                                     /**< meta event 28 control */
   u64 me29 : 2;                                                     /**< meta event 29 control */
   u64 me30 : 2;                                                     /**< meta event 30 control */
   u64 me31 : 2;                                                     /**< meta event 31 control */
   u64 me32 : 2;                                                     /**< meta event 32 control */
}
META_EVENT_CONTROL_PARAM;
POSTPACK

#define ME_INTERRUPT 0x01                                            /**< LSB enables interrupt to host when this event occurs */
#define ME_ENABLE    0x02                                            /**< MSB enables generation of this meta event */

/**
 * \brief parameter for controlling the FIFO watermark
 */
PREPACK typedef struct MIDPACK FIFO_CONTROL_PARAM
{
   u16 watermark;                                                    /**< number of bytes the FIFO needs to accumulate before the host interrupt is triggered */
   u16 fifo_size;                                                    /**< size of the FIFO in bytes */
   u16 nonwakeup_watermark;                                          /**< for future Android L product: number of bytes the FIFO needs to accumulate before the host interrupt is triggered (nonwakeup events) */
   u16 nonwakeup_fifo_size;                                          /**< for future Android L product: size of the FIFO in bytes (nonwakeup events) */
}
FIFO_CONTROL_PARAM;
POSTPACK

/**
 * \brief sensor status byte
 */
PREPACK typedef struct MIDPACK SENSOR_STATUS
{
   u8 data_available : 1;                                            /**< one or more samples from this sensor are in the output buffer */
   u8 i2c_nack : 1;                                                  /**< this sensor did not acknowledge an I2C request */
   u8 device_id_error : 1;                                           /**< device identification mismatch; wrong driver loaded? */
   u8 transient_error : 1;                                           /**< magnetic or other sensor transient error */
   u8 data_lost : 1;                                                 /**< FIFO overflow resulted in a loss of data from this sensor */
   u8 power_mode : 3;                                                /**< current power mode for this sensor */
}
SENSOR_STATUS;
POSTPACK

/**
 * \brief possible power mode values for the \ref SENSOR_STATUS power_mode
 *        field.
 */
typedef enum SENSOR_POWER_MODE
{
   SensorNotPresent = 0,                                             /**< The current system does not contain or support this sensor type */
   SensorPowerModePowerDown = 1,                                     /**< Shut down the sensor. The sensor should not be performing conversions. */
   SensorPowerModeSuspend = 2,                                       /**< Enter a low power state, sensor should only detect movement. */
   SensorPowerModeSelfTest = 3,                                      /**< Enter a self-test state in the sensor. The sensor should transition to the SensorPowerModePowerDown mode once the self test is complete. Additionally, reportSelfTestResult(sensor, status) should be called to report the result. */
   SensorPowerModeInteruptMotion = 4,                                /**< Enter a low power state where the sensor interrupts when motion has occured */
   SensorPowerModeOneShot = 5,                                       /**< Begin a single sensor measurement. SensorPowerModeSuspend or lower should be entered automaticaly afterwards. */
   SensorPowerModeLowPowerActive = 6,                                /**< Enter a low power, high noise sensor state. */
   SensorPowerModeActive = 7                                         /**< Enter a high power, low noise sensor state. */
}
SENSOR_POWER_MODE;


/**
 * \brief sensor status page
 */
PREPACK typedef struct MIDPACK SENSOR_STATUS_PARAM
{
   SENSOR_STATUS status[16];                                         /**< array of 16 SENSOR_STATUS bytes; index is (sensor ID - 1) + (page - 3) * 16 */
}
SENSOR_STATUS_PARAM;
POSTPACK

/**
 * \brief Host IRQ Timestamp -- determine time of last host
 *        interrupt, as well as current time; both in units of
 *        32KHz ticks
 */
PREPACK typedef struct MIDPACK HOST_IRQ_TS_PARAM
{
   u32 host_irq_timestamp;                                           /**< time in 32KHz ticks of last host interrupt */
   u32 current_timestamp;                                            /**< current system time */
}
HOST_IRQ_TS_PARAM;
POSTPACK

/**
 * \brief FIFO test page (write to this to generate test
 *        patterns in the FIFO)
 */
PREPACK typedef struct MIDPACK FIFO_TEST_PARAM
{
   u16 EventCount;                                                   /**< number of events to generate total */
   u16 EventRate;                                                    /**< rate at which to generate them, in Hz; 0 means immediately */
   u32 SensorEventFlags;                                             /**< set a bit to cause an event from that sensor to be generated */
}
FIFO_TEST_PARAM;
POSTPACK

/**
 * \brief physical sensor status parameter
 */
PREPACK typedef struct MIDPACK PHYS_SENSOR_STATUS
{
   u16 AccelRate;                                                    /**< actual physical sample rate for the accel */
   u16 AccelRange;                                                   /**< actual dynamic range for the accel */
   u8  AccelIRQ:1;                                                   /**< actual IRQ state (1 = enabled) for the accel */
   u8  AccelRsvd:4;                                                  /**< reserved */
   u8  AccelPowerMode:3;                                             /**< actual power state for the accel (same encoding as SENSOR_POWER_MODE) */
   u16 GyroRate;                                                     /**< actual physical sample rate for the gyro */
   u16 GyroRange;                                                    /**< actual dynamic range for the gyro */
   u8  GyroIRQ:1;                                                    /**< actual IRQ state (1 = enabled) for the gyro */
   u8  GyroRsvd:4;                                                   /**< reserved */
   u8  GyroPowerMode:3;                                              /**< actual power state for the gyro (same encoding as SENSOR_POWER_MODE) */
   u16 MagRate;                                                      /**< actual physical sample rate for the mag */
   u16 MagRange;                                                     /**< actual dynamic range for the mag */
   u8  MagIRQ:1;                                                     /**< actual IRQ state (1 = enabled) for the mag */
   u8  MagRsvd:4;                                                    /**< reserved */
   u8  MagPowerMode:3;                                               /**< actual power state for the mag (same encoding as SENSOR_POWER_MODE) */
}
PHYS_SENSOR_STATUS;
POSTPACK

/**************************************************************
*  SP Algorithm Page                                          *
* parameters 1 to 73 subject to change                        *
***************************************************************/
#define PAP_STOP                      0                              /**< terminate the parameter procedure */
#define PAP_PARAM_START               1                              /**< first param (coefficient) in the set of params */
#define PAP_PARAM_END                35                              /**< last param */
#define PAP_KNOB_START               51                              /**< first knob in the set of knobs */
#define PAP_KNOB_END                 73                              /**< last knob */
#define PAP_INPUT_DATA              127
#define RAW_INPUT_DATA              127

/**************************************************************
*  BST Algorithm Page                                         *
*  TBD                                                        *
***************************************************************/
#define BAP_STOP                      0                              /**< terminate the parameter procedure */
#define BAP_FIRST                     1                              /**< first valid parameter number */
/* X1, X2 */
#define BAP_SIC_MATRIX_0_1      1
/* X3, Y1 */
#define BAP_SIC_MATRIX_2_3      2
/* Y2, Y2 */
#define BAP_SIC_MATRIX_4_5      3
/* Z1, Z2 */
#define BAP_SIC_MATRIX_6_7      4
/* Z3,    */
#define BAP_SIC_MATRIX_8        5
/* query or set accel offset and radius */
#define BAP_ACC_OFFSET          6
/* query or set mag offset and radius */
#define BAP_MAG_OFFSET          7
/* query or set gyro offset and radius */
#define BAP_GYRO_OFFSET         8
/* query or set the enabled working modes */
#define BAP_WORKING_MODE_EN     9
/* query or set the output data rate and operating mode index */
#define BAP_OPR_MODE            10
/* enable input data output; byte 0 = accel = BSX_A, byte 1 = mag = BSX_B, byte 2 = gyro = BSX_C */
#define BAP_INPUT_DATA          127
#define BAP_LAST                127                                  /**< last valid parameter number */


/**************************************************************
*  Sensors Page                                               *
*  This page provides access to sensor information and        *
*  configuration.                                             *
***************************************************************/
#define SP_SENSOR_INFO_START          1                              /**< sensor information parameters are this plus the sensor ID */
#define SP_SENSOR_CONFIG_START       32                              /**< sensor configuration parameters are this plus the sensor ID */
#define SP_MAX_PARAMETER             64                              /**< largest supported parameter */

#define SP_SENSOR_CONFIG_START_L     64                              /**< for Android L products: sensor configuration parameters are this plus the sensor ID */
#define SP_MAX_PARAMETER_L          127                              /**< for Android L products: largest supported parameter */

#define SP_SENSOR_INTO_PAGE_LEX       3                              /**< for Android L Extended products: sensor information page is 3 */
#define SP_SENSOR_CONFIG_PAGE_LEX     5                              /**< for Android L Extended products: sensor configuration page is 3 */
#define SP_SENSOR_INFO_START_LEX      0                              /**< for Android L Extended products: sensor information parameters are the sensor ID */
#define SP_SENSOR_CONFIG_START_LEX    0                              /**< for Android L Extended products: sensor configuration parameters are the sensor ID */
#define SP_MAX_PARAMETER_LEX        127                              /**< for Android L Extended products: largest supported parameter */


PREPACK typedef struct MIDPACK SENSOR_INFORMATION                    /**< static information about each sensor */
{
   u8 sensor_type;                                                   /**< type of requested sensor */
   u8 driver_id;                                                     /**< official U718x driver ID for the driver that controls this sensor */
   u8 driver_version;                                                /**< driver-creator-assigned version number */
   u8 power;                                                         /**< maximum power drawn by this sensor */
   u16 max_range;                                                    /**< maximum value possible from this sensor, in SI units (Android units) */
   u16 resolution;                                                   /**< number of bits of resolution */
   u16 max_rate;                                                     /**< maximum sample rate, in Hz */
   u16 fifo_reserved;                                                /**< FIFO size in bytes reserved for just this sensor / data packet size in bytes; 0 for single shared FIFO */
   u16 fifo_max;                                                     /**< FIFO size in bytes divided by this sensor's data packet size in bytes; e.g., the maximum number of samples of this sensor that could possibly fit */
   u8 event_size;                                                    /**< size of data packet */
   u8 min_rate;                                                      /**< minimum sample rate, in Hz; only available in future Android L product */
}
SENSOR_INFORMATION;                                                  /**< typedef corresponding to SENSOR_INFORMATION struct */
POSTPACK

PREPACK typedef struct MIDPACK SENSOR_CONFIG                         /**< configuration of sensor and actual runtime settings */
{
   u16 sample_rate;                                                  /**< rate in Hz, = 1 / Android sample period; reads back as actual sample rate */
   u16 max_report_latency;                                           /**< 0 for non-batch mode; if nonzero, sample_rate must also be nonzero; in milliseconds; reads back actual latency */
   u16 change_sensitivity;                                           /**< amount by which this senor's data must change before it is reported; in same units as sensor data samples; for Win8; 0 means all samples */
   u16 dynamic_range;                                                /**< control sensor's range of measurement if possible; affects max_range in \ref SENSOR_INFORMATION; in same units as sensor data samples */
}
SENSOR_CONFIG;                                                       /**< typedef corresponding to SENSOR_CONFIG struct */
POSTPACK


#endif


