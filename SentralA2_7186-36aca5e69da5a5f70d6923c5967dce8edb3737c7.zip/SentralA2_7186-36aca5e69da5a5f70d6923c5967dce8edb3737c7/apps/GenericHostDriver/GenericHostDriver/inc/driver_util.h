/**
 * \file    driver_util.h
 *
 * \brief   utility functions
 *
 * \copyright (C) 2013-2014 EM Microelectronic
 *
 */

/** \defgroup Driver_Util Utility functions
 *  \brief This defines functions used by the Generic host driver to do its
 *         work.
 * @{ */

#ifndef _DRIVER_UTIL_H_
#define _DRIVER_UTIL_H_

#include "types.h"
#include "host_services.h"
#include "driver_core.h"
#include "EEPROMImage.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * \brief request the start of a non-blocking I2C read
 * \param handle - the device to read from
 * \param reg_addr - which register address to write, then
 *                 perform an I2C RESTART, then read
 * \param buffer - where to store the data read
 * \param len - the number of bytes required
 * \return bool - false if parameters are invalid
 */
   extern bool i2c_blocking_read(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len);

/**
 * \brief request the start of a non-blocking I2C write
 * \param handle - the device to write to
 * \param reg_addr - the register address to write first
 * \param buffer - the data to write after that
 * \param len - the number of bytes to write
 * \return bool - false if parameters are invalid
 */
   extern bool i2c_blocking_write(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len);

/**
 * \brief request the start of a non-blocking I2C write
 * \param handle - the device to write to
 * \param wbuffer - the data to write after that
 * \param wlen - the number of bytes to write
 * \param rbuffer - the data to read after that
 * \param rlen - the number of bytes to read
 * \return bool - false if parameters are invalid
 */
   extern bool i2c_blocking_write_read(I2C_HANDLE_T handle, u8 *wbuffer, u16 wlen, u8 *rbuffer, u16 rlen);

/**
 * \brief read a line of text from a file
 * \param f - file handle
 * \param line - pointer to caller's buffer to store the line into
 * \param max_len - the size of the buffer
 * \return int number of characters read
 */

   extern int read_line(FILE_HANDLE_T f, char *line, int max_len);

/**
 * \brief convert 16 bit register's signed 16 bit equivalent
 *        value to floating point
 * \param buf - pointer to buffer containing the two bytes of
 *            the register, LSB first
 * \return float - the value
 */
   extern float uint16_reg_to_float(u8 *buf);

/**
 * \brief convert an array of 4 bytes known to be in floating
 *        point format to a floating point value
 * \param buf - pointer to the 4 bytes, LSB first
 * \return float - the value
 */
   extern float uint32_reg_to_float(u8 *buf);

   /**
    * \brief stores error information and logs it
    * \param instance - the driver instance
    * \param error - the error code
    * \param line - the source code line number the error occurred on
    * \param fn - the name of the function in which the error occurred
    * \param file - the source file in which the function is located
    */
   extern void record_error(DI_INSTANCE_T *instance, DI_ERROR_CODE_T error, int line, const char *fn, const char *file);


#ifdef __cplusplus
}
#endif

#endif

/** @}*/

