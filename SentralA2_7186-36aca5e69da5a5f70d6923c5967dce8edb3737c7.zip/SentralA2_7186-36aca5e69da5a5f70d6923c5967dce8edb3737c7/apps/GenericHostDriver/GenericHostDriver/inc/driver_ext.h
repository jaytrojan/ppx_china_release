/**
 * \file    driver_ext.h
 *
 * \brief  abstract interface to the extended portions of the generic host
 *         driver, with entry points to manage all aspects of detecting,
 *         configuring, and transferring data with U718x
 *
 * \copyright  (C) 2013-2014 EM Microelectronic
 *
 */

/** \defgroup Driver_Ext Extended generic host driver abstract interface
 *  \brief    This defines additional API entry points to help make integrating
 *  the generic host driver into an application easier. @{
 */

#ifndef _DRIVER_EXT_H_
#define _DRIVER_EXT_H_

#include "host_services.h"
#include "u718x_registers.h"
#include "u718x_parameters.h"
#include "driver_core.h"

#ifdef __cplusplus
extern "C"
{
#endif

#if defined(LEGACY)
// legacy host interface
#define SENSOR_SCALE_MAG      (30.5e-3)                        /**< convert U718x Mag value to uT */
#define SENSOR_SCALE_ACCEL    (4.79e-3)                        /**< convert U718x Accel value to m/s^2 */
#define SENSOR_SCALE_GYRO     (2.663e-3)                       /**< convert U718x Gyro value to radians per second */
#define SENSOR_SCALE_BAROM    (3.0 / 100)                      /**< convert U718x Barom value to hPa */
#define SENSOR_SCALE_HUMID    (1.0 / 512)                      /**< convert U718x Humid value to % relative humidity */
#define SENSOR_SCALE_TEMP     (1.0 / 500)                      /**< convert U718x Temp value to degrees C */
#define SENSOR_SCALE_TIME_NUM 16000                            /**< convert U718x Timestamp to time in microseconds (numerator) */
#define SENSOR_SCALE_TIME_DEN 512                              /**< convert U718x Timestamp to time in microseconds (denomenator) */
#define SENSOR_TIMESTAMP_OVERFLOW_US 2048000ul                 /**< amount of time between U718x sensor timestamp overflows */


/** \brief maximum number allowed */
#define MAX_FEATURE_SENSORS 3

/** \brief a data structure containing all information for a
 *         quaternion data sample */
   struct DI_QUATERNION
   {
      float x;                                                       /**<  the x value */
      float y;                                                       /**<  the y value */
      float z;                                                       /**<  the z value */
      float w;                                                       /**<  the w value */
      u32 t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool hpr;                                                      /**<  a flag to indicate that the heading/pitch/roll is stored in x, y, and z, with w unused; false if this is really a quaternion */
      bool valid;                                                    /**<  true if this sample is valid */
   };
/** \brief a typedef wrapping the DI_QUATERNION structure */
   typedef struct DI_QUATERNION DI_QUATERNION_T;

/** \brief a structure representing a sample from a 3 axis
 *         sensor */
   struct DI_3AXIS_DATA
   {
      float x;                                                       /**<  the x value */
      float y;                                                       /**<  the y value */
      float z;                                                       /**<  the z value */
      u32 t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   };
/** \brief a typedef wrapping the DI_3AXIS_DATA structure */
   typedef struct DI_3AXIS_DATA DI_3AXIS_DATA_T;

/** \brief a structure containing all possible data samples
 *         available from an interrupt */
   struct DI_SENSOR_DATA
   {
      DI_QUATERNION_T quaternion;                                    /**<  the quaternion sample; each element ranges from 0.0 to 1.0 */
      DI_3AXIS_DATA_T mag;                                           /**<  the magnetometer sample, in milli-Gauss, range +/-10000 */
      DI_3AXIS_DATA_T accel;                                         /**<  the accelerometer sample, in gs (standard Earth gravities), range +/- 16 */
      DI_3AXIS_DATA_T gyro;                                          /**<  the gyroscope sample, in degrees per second, range +/- 5000 */
      DI_FEATURE_DATA_T feature[MAX_FEATURE_SENSORS];                /**<  data for all feature sensors, if present */
   };
/** \brief a typedef wrapping the DI_SENSOR_DATA structure */
   typedef struct DI_SENSOR_DATA DI_SENSOR_DATA_T;

#else

   /* scale factors */
#define SENSOR_SCALE_MAG      (1000.0f / ((1 << 15) - 1))          /**< convert U718x Mag value to micro Tesla (1000uT range) */
#define SENSOR_SCALE_ACCEL    (16.0f * 9.8066f / ((1 << 15) - 1))   /**< convert U718x Accel value to m/s^2 (16g range) */
#define SENSOR_SCALE_GYRO     (17.453f / ((1 << 15) - 1))          /**< convert U718x Gyro value to radians per second (1000 degrees/second range) */
#define SENSOR_SCALE_BAROM    ((1.0f / 128) / 100)                 /**< convert U718x Barom value to hectoPascals (1311hPa range) */
#define SENSOR_SCALE_HUMID    (1.0f)                               /**< convert U718x Humid value to % relative humidity */
#define SENSOR_SCALE_TEMP     (1.0f / 500)                         /**< convert U718x Temp value to degrees C; multiply 16 bit signed data by this */
#define SENSOR_OFFSET_TEMP    24.0f                                /**< convert U718x Temp value to degrees C; add this to value after scaling */
#define SENSOR_SCALE_LIGHT    (10000.0f / ((1 << 16) - 1))         /**< convert U718x Light value to Lux (10000 Lux range) */
#define SENSOR_SCALE_PROX     (100.0f / ((1 << 16) - 1))           /**< convert U718x Proximity value to distance in cm (1 meter range) */
#define SENSOR_SCALE_ORIENT   (360.0f / ((1 << 15) - 1))           /**< convert U718x Orientation value to degrees */

   /* data scaled and converted data */

   /**
    * \brief vector data for use by DST_ROTATION_VECTOR, DST_GAME_ROTATION_VECTOR,
    *        and DST_GEOMAGNETIC_ROTATION_VECTOR
    */
   typedef struct DI_QUATERNION_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      float x;                                                       /**< the x value */
      float y;                                                       /**< the y value */
      float z;                                                       /**< the z value */
      float w;                                                       /**< the w value */
      float accuracy_estimate;                                       /**< accuracy (radians) */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_QUATERNION_DATA_T;

   /**
    * \brief 3 axis data for use by DST_ACCELEROMETER, DST_GEOMAGNETIC_FIELD,
    *        DST_ORIENTATION, DST_GYROSCOPE, DST_GRAVITY, DST_LINEAR_ACCELERATION
    */
   typedef struct DI_3AXIS_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      float x;                                                       /**<  the x value */
      float y;                                                       /**<  the y value */
      float z;                                                       /**<  the z value */
      u8 status;                                                     /**<  accuracy of measurement (low, medium, high, unreliable) */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_3AXIS_DATA_T;

   /**
    * \brief raw data output for RAW_A/M/G sensors for alg_id != AIS_SPACE_POINT
    */
   PREPACK typedef struct MIDPACK DI_3AXIS_RAW_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      s32 x;                                                         /**<  the x value */
      s32 y;                                                         /**<  the y value */
      s32 z;                                                         /**<  the z value */
      TS_T t;                                                        /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_3AXIS_RAW_DATA_T;
   POSTPACK

   /**
    * \brief raw data output for RAW_A/M/G sensors for alg_id == AIS_SPACE_POINT
    */
   PREPACK typedef struct MIDPACK DI_3AXIS_RAW_DATA_F
   {
      u8 sensor;                                                     /**<  the sensor ID */
      float x;                                                         /**<  the x value */
      float y;                                                         /**<  the y value */
      float z;                                                         /**<  the z value */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_3AXIS_RAW_DATA_F_T;
   POSTPACK

   /**
    * \brief single floating point scalar value, for use by DST_LIGHT,
    *        DST_PROXIMITY, DST_RELATIVE_HUMIDITY, DST_PRESSURE,
    *        DST_TIMESTAMP_LSW, DST_TIMESTAMP_MSW
    */
   typedef struct DI_SCALAR_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      float datum;                                                   /**<  the floating point value */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_SCALAR_DATA_T;

   /**
    * \brief single byte scalar value, for use by DST_HEART_RATE
    */
   typedef struct DI_BYTE_SCALAR_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      u8 datum;                                                      /**<  the unsigned 8 bit value */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_BYTE_SCALAR_DATA_T;

   /**
    * \brief single integer scalar value, for use by DST_STEP_COUNTER
    */
   typedef struct DI_UINT_SCALAR_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      u16 datum;                                                     /**<  the unsigned 16 bit value */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_UINT_SCALAR_DATA_T;

   /**
    * \brief singleton type -- just represents an event such as
    *        DST_SIGNIFICANT_MOTION, DST_STEP_DETECTOR, DST_NOP
    */
   typedef struct DI_SINGLETON_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_SINGLETON_DATA_T;

   /**
    * \brief 3 axis uncalibrated data for use by DST_MAGNETIC_FIELD_UNCALIBRATED,
    * DST_GYROSCOPE_UNCALIBRATED
    */
   typedef struct DI_3AXIS_UNCAL_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      float x_uncal;                                                 /**<  the uncorrected x value */
      float y_uncal;                                                 /**<  the uncorrected y value */
      float z_uncal;                                                 /**<  the uncorrected z value */
      float x_bias;                                                  /**<  the x bias value */
      float y_bias;                                                  /**<  the y bias value */
      float z_bias;                                                  /**<  the z bias value */
      u8 status;                                                     /**<  accuracy of measurement (low, medium, high, unreliable) */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_3AXIS_UNCAL_DATA_T;

   /**
    * \brief spacepoint diagnostic data for use by DST_CALSTATUS,
    * DST_CALSTATUS
    */
   typedef struct DI_CALSTATUS_DATA  //RL
   {
       u8 sensor;                                                     /**<  the sensor ID */
	   float    mcalSIHI9;
	   float    mcalSIHI10;
	   float    mcalSIHI11;
	   float    mcalScore1;
	   u8       mcalStatus;
	   u8       transientCompensation;
	   TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
	   bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_CALSTATUS_DATA_T;

   /**
    * \brief meta event descriptor, for DST_META_EVENT
    */
   typedef struct DI_META_EVENT_DATA
   {
      u8 sensor;                                                     /**<  the sensor ID */
      u8 event_id;                                                   /**<  which meta event occurred */
      u8 sensor_id;                                                  /**<  what sensor it was associated with */
      u8 extra_info;                                                 /**<  additional meta-event-specific data */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_META_EVENT_DATA_T;

   /**
    * \brief Debug payload, for DST_DEBUG
    */
   typedef struct DI_DEBUG_DATA_T
   {
      u8 sensor;                                                     /**<  the sensor ID */
      char payload[13];                                                   /**<  which meta event occurred */
      TS_T t;                                                         /**<  the sample timestamp, in microseconds, range 0 to 32 bit overflow (71.58 minutes) */
      bool valid;                                                    /**<  true if this sample is valid */
   }
   DI_DEBUG_DATA_T;

   /** \brief a structure containing all possible data samples
    *         available from an interrupt
    */
   typedef struct DI_SENSOR_DATA
   {
      DI_QUATERNION_DATA_T rotation_vector;                          /**<  the quaternion sample */
      DI_QUATERNION_DATA_T game_rotation_vector;                     /**<  the quaternion sample */
      DI_QUATERNION_DATA_T geomag_rotation_vector;                   /**<  the quaternion sample */
      DI_3AXIS_DATA_T accel;                                         /**<  the accelerometer sample */
      DI_3AXIS_DATA_T mag;                                           /**<  the magnetometer sample */
      DI_3AXIS_DATA_T gyro;                                          /**<  the gyroscope sample */
      DI_3AXIS_DATA_T orientation;                                   /**<  the orientation sample */
      DI_3AXIS_DATA_T gravity;                                       /**<  the gravity sample */
      DI_3AXIS_DATA_T linear_acceleration;                           /**<  the linear acceleration sample */
      DI_3AXIS_RAW_DATA_T raw_accel;                                 /**<  the raw accel sample */
      DI_3AXIS_RAW_DATA_T raw_mag;                                   /**<  the raw mag sample */
      DI_3AXIS_RAW_DATA_T raw_gyro;                                  /**<  the raw gyro sample */
      DI_3AXIS_RAW_DATA_F_T raw_f_accel;                             /**<  the raw float accel sample */
      DI_3AXIS_RAW_DATA_F_T raw_f_mag;                               /**<  the raw float mag sample */
      DI_3AXIS_RAW_DATA_F_T raw_f_gyro;                              /**<  the raw float gyro sample */
      DI_SCALAR_DATA_T light;                                        /**<  the light sample */
      DI_SCALAR_DATA_T proximity;                                    /**<  the proximity sample */
      DI_SCALAR_DATA_T humidity;                                     /**<  the humidity sample */
      DI_BYTE_SCALAR_DATA_T heart_rate;                              /**<  the Android L heart rate sample */
      DI_UINT_SCALAR_DATA_T step_counter;                            /**<  the step_counter sample */
      DI_UINT_SCALAR_DATA_T activity;                                /**<  the Android L activity sample */
      DI_SCALAR_DATA_T temperature;                                  /**<  the temperature sample */
      DI_SCALAR_DATA_T ambient_temperature;                          /**<  the ambient temperature sample */
      DI_3AXIS_UNCAL_DATA_T mag_uncal;                               /**<  the mag uncalibrated sample */
      DI_3AXIS_UNCAL_DATA_T gyro_uncal;                              /**<  the gyro uncalibrated sample */
      DI_SINGLETON_DATA_T significant_motion;                        /**<  the significant motion sample */
      DI_SINGLETON_DATA_T step_detector;                             /**<  the step_detector sample */
      DI_SINGLETON_DATA_T tilt_detector;                             /**<  the Android L tilt_detector sample */
      DI_SINGLETON_DATA_T wake_gesture;                              /**<  the Android L wake_gesture sample */
      DI_SINGLETON_DATA_T glance_gesture;                            /**<  the Android L glance_gesture sample */
      DI_SINGLETON_DATA_T pickup_gesture;                            /**<  the Android L pickup_gesture sample */
      DI_SCALAR_DATA_T barometer;                                    /**<  the barometer sample */
      DI_DEBUG_DATA_T debug;                                         /**<  the debug sample */
      DI_TIMESTAMP_DATA_T timestamp_lsw;                             /**<  the most recent lower word of the timestamp (multiples of 1/32000) */
      DI_TIMESTAMP_DATA_T timestamp_msw;                             /**<  the most recent upper word of the timstamp (overflows of lower word) */
      DI_META_EVENT_DATA_T meta;                                     /**<  the meta sample */
      DI_CALSTATUS_DATA_T cal_status;                                /**<  the spacepoint diagnostic data */
      DI_3AXIS_DATA_T jerk_example;                                  /**<  the jerk sample */
   }
   DI_SENSOR_DATA_T;

   typedef enum sensor_data_types
   {	E_DI_QUATERNION_DATA_T,
		E_DI_3AXIS_DATA_T,
		E_DI_3AXIS_UNCAL_DATA_T,
		E_DI_3AXIS_RAW_DATA_T,
        E_DI_3AXIS_RAW_DATA_F_T,
		E_DI_SCALAR_DATA_T,
		E_DI_BYTE_SCALAR_DATA_T,
		E_DI_UINT_SCALAR_DATA_T,
		E_DI_SINGLETON_DATA_T,
		E_DI_CALSTATUS_DATA_T,
		E_SENS_DATA_TYPE_UNKNOWN
   } t_sensor_data_types;

   /** \brief a structure containing all possible data samples
    *         available from an interrupt
    */
   typedef union DI_SENSOR_UNION
   {
      u8 sensor;                                                     /**<  first byte is the sensor type */
      DI_QUATERNION_DATA_T rotation_vector;                          /**<  the quaternion sample */
      DI_QUATERNION_DATA_T game_rotation_vector;                     /**<  the quaternion sample */
      DI_QUATERNION_DATA_T geomag_rotation_vector;                   /**<  the quaternion sample */
      DI_3AXIS_DATA_T accel;                                         /**<  the accelerometer sample */
      DI_3AXIS_DATA_T mag;                                           /**<  the magnetometer sample */
      DI_3AXIS_DATA_T gyro;                                          /**<  the gyroscope sample */
      DI_3AXIS_DATA_T orientation;                                   /**<  the orientation sample */
      DI_3AXIS_DATA_T gravity;                                       /**<  the gravity sample */
      DI_3AXIS_DATA_T linear_acceleration;                           /**<  the linear acceleration sample */
      DI_3AXIS_RAW_DATA_T raw_accel;                                 /**<  the raw accel sample */
      DI_3AXIS_RAW_DATA_T raw_mag;                                   /**<  the raw mag sample */
      DI_3AXIS_RAW_DATA_T raw_gyro;                                  /**<  the raw gyro sample */
      DI_3AXIS_RAW_DATA_F_T raw_f_accel;                             /**<  the raw float accel sample */
      DI_3AXIS_RAW_DATA_F_T raw_f_mag;                               /**<  the raw float mag sample */
      DI_3AXIS_RAW_DATA_F_T raw_f_gyro;                              /**<  the raw float gyro sample */
      DI_SCALAR_DATA_T light;                                        /**<  the light sample */
      DI_SCALAR_DATA_T proximity;                                    /**<  the proximity sample */
      DI_SCALAR_DATA_T humidity;                                     /**<  the humidity sample */
      DI_BYTE_SCALAR_DATA_T heart_rate;                              /**<  the Android L heart rate sample */
      DI_UINT_SCALAR_DATA_T step_counter;                            /**<  the step_counter sample */
      DI_UINT_SCALAR_DATA_T activity;                                /**<  the Android L activity sample */
      DI_SCALAR_DATA_T temperature;                                  /**<  the temperature sample */
      DI_SCALAR_DATA_T ambient_temperature;                          /**<  the ambient temperature sample */
      DI_3AXIS_UNCAL_DATA_T mag_uncal;                               /**<  the mag uncalibrated sample */
      DI_3AXIS_UNCAL_DATA_T gyro_uncal;                              /**<  the gyro uncalibrated sample */
      DI_SINGLETON_DATA_T significant_motion;                        /**<  the significant motion sample */
      DI_SINGLETON_DATA_T step_detector;                             /**<  the step_detector sample */
      DI_SINGLETON_DATA_T tilt_detector;                             /**<  the Android L tilt_detector sample */
      DI_SINGLETON_DATA_T wake_gesture;                              /**<  the Android L wake_gesture sample */
      DI_SINGLETON_DATA_T glance_gesture;                            /**<  the Android L glance_gesture sample */
      DI_SINGLETON_DATA_T pickup_gesture;                            /**<  the Android L pickup_gesture sample */
      DI_SCALAR_DATA_T barometer;                                    /**<  the barometer sample */
      DI_DEBUG_DATA_T debug;                                         /**<  the debug payload */
      DI_TIMESTAMP_DATA_T timestamp_lsw;                             /**<  the most recent lower word of the timestamp (multiples of 1/32000) */
      DI_TIMESTAMP_DATA_T timestamp_msw;                             /**<  the most recent upper word of the timstamp (overflows of lower word) */
      DI_META_EVENT_DATA_T meta;                                     /**<  the meta sample */
      DI_CALSTATUS_DATA_T cal_status;                                /**<  the spacepoint diagnostic data */
      DI_3AXIS_DATA_T jerk_example;                                  /**<  the jerk sample */
   }
   DI_SENSOR_UNION_T;

#endif

   typedef bool (*UPLOAD_CALLBACK)(int percent_complete);


/**
 * \brief initialize the driver
 * \param i2c_handle - an abstract handle used to access the
 *                   U718x chip via the host I2C services
 *                   (defined in host_services.h); the operating
 *                   system's driver configuration mechanism is
 *                   responsible for knowing how to reach the
 *                   U718x chip (which bus and slave address,
 *                   etc.)
 * \param irq_handle - an abstract handle used to represent the
 *                   data ready IRQ from the U718x chip; it is
 *                   up to the operating system's driver
 *                   configuration mechanism to know how to
 *                   create this
 * \param reset -    set TRUE to force reset of U718x, FALSE
 *                   to leave it running as is
 * \return DI_INSTANCE_T *- pointer to a structure representing
 *         this driver instance
 */
   extern DI_INSTANCE_T *di_init(I2C_HANDLE_T i2c_handle, IRQ_HANDLE_T irq_handle, bool reset);

   /**
    * \brief change the maximum number of bytes to read from the
    *        FIFO in one I2C transfer (useful for testing)
    * \param instance - the driver instance data
    * \param buffer_size - number of bytes
    * \return u32 - actual size (won't let you set it larger than
    *         the allocated buffer size)
    */
   extern u32 di_set_buffer_max_size(DI_INSTANCE_T *instance, u32 buffer_size);

/**
 * \brief shutdown the driver
 * \param instance - which instance to close
 * \return bool - true if succeeded, false if the instance was
 *         never initialized
 */
   extern bool di_deinit(DI_INSTANCE_T *instance);

/**
 * \brief upload firmware to the U718x chip's RAM
 * \param instance - the driver instance
 * \param firmware_filename - an externally-specified string
 *                          representing the firmware file to
 *                          load into RAM in 718x
 * \param force_anyrom - set true to tell loader to ignore chip's ROM version
 * \param callback - if not null, call this for each percent
 *        complete
 * \return bool - false if 718x could not be reached; call
 *         di_query_error() to determine the cause
 */
   extern bool di_upload_firmware(DI_INSTANCE_T *instance, char *firmware_filename, bool force_anyrom, UPLOAD_CALLBACK callback);

/**
 * \brief upload firmware to the EEPROM attached to the U718x
 *        chip; we check the header, but rather than striping it
 *        as we do when uploading to RAM, we pass it as is;
 *        blocks
 * \param instance - the driver instance
 * \param eeprom_handle - I2C handle (host-specific) to reach
 *                      the EEPROM at slave address 0x50
 *                      (NOTE: 718x assumes this address as
 *                      well as a register layout the same as a
 *                      Microchip 24LC256 EEPROM)
 * \param firmware_filename - an externally-specified string
 *                          representing the firmware file to
 *                          load into EEPROM
 * \param force_anyrom - set true to tell loader to ignore chip's ROM version
 * \param callback - if not null, call this for each percent
 *        complete
 * \return bool - false if 718x could not be reached; call
 *         di_query_error() to determine the cause
 */
   extern bool di_upload_eeprom(DI_INSTANCE_T *instance, I2C_HANDLE_T eeprom_handle, char *firmware_filename, bool force_anyrom, UPLOAD_CALLBACK callback);

   /**
    * \brief convert from integer (core) data to real-world unit floating point
    * \param instance - the driver instance
    * \param sensor - which sensor (or DST_ALL)
    * \param int_data - the integer data as input
    * \param data - the floating point data as output
    * \param raw - true if data is not to be scaled
    * \return bool
    */
   extern bool di_convert_sensor_data(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
      DI_SENSOR_INT_DATA_T *int_data, DI_SENSOR_DATA_T *data, bool raw);

   // return true if sensor is debug sensor, false otherwise
   // sensor: sensor number
   extern bool isDebugSensor(DI_SENSOR_TYPE_T sensor);
   // note works only for sensors, does not work for other events
   //   there is also driver_core.h is_wakeup_event() which works also for other than sensor events
   bool is_wakeup_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor);
   extern void *getIntDataPtr_knownSensorType(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *int_data);
   extern void *getIntDataPtr(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T int_data[2]);
   extern void *getDataPtr_knownSensorType(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_DATA_T *data);
   extern void *getDataPtr(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_DATA_T data[2]);


   /**
    * \brief convert from integer (core) data to real-world unit floating point
    * \param instance - the driver instance
    * \param sensor - which sensor (or DST_ALL)
    * \param int_data - the integer data as input
    * \param data - the floating point data as output
    * \param raw - true if data is not to be scaled
    * \return bool
    */
   extern bool di_convert_sensor_union(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor,
      DI_SENSOR_INT_UNION_T *int_data, DI_SENSOR_UNION_T *data, bool raw);
   extern void *getIntUnionPtr_knownSensorType(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_UNION_T *int_data);
   extern void *getUnionPtr_knownSensorType(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_UNION_T *data);

/**
 *  \brief for KitKat, this is not directly possible; instead, one needs to
 *         enable the sensor, disable batching on it, then wait for a sample to
 *         arrive from the buffer
 *  \param instance - the driver instance
 *  \param sensor - the sensor type to query
 *  \param data - a pointer to a data structure to which the
 *              sensor data will be stored
 * \return bool - false if the instance is invalid or if U718x
 *         could not be reached
*/
   extern bool di_query_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_UNION_T *data);

   extern t_sensor_data_types di_query_sensor_type(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor);

/**
 * \brief returns the human-readable name for the driver
 * \param driver_id - the id as reported by di_save_parameters()
 * \return const char* or NULL if not found
 */
   extern const char *di_query_driver_name(u8 driver_id);

/**
 * \brief returns the human-readable name for the sensor (also can return non sensor event name)
 * \param sensor - the sensor type
 * \return const char* or NULL if not found
 */
   extern const char *di_query_sensor_name(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor);

/**
 * \brief returns the short human-readable name for the sensor
 * \param sensor - the sensor type
 * \return const char* or NULL if not found
 */
   extern const char *di_query_sensor_short_name(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor);

/**
 * \brief using parameter transfer, query the current sensor
 *        drivers and display to the log
 * \param instance
 * \return bool
 */
   extern bool display_driver_info(DI_INSTANCE_T *instance);

/**
 * \brief queries and displays error info from both 718x and the
 * Generic Host Driver itself
 * \param instance
 */
   extern void display_error_info(DI_INSTANCE_T *instance);

/**
 * \brief show what the current sensor sample rates are
 * \param instance - instance to query
 * \return TRUE if succeeded
 */
   extern bool display_actual_rates(DI_INSTANCE_T *instance);

/**
 * \brief show current values of all 718x registers
 * \param instance
 * \return TRUE if succeeded
 */
   extern bool dump_all_registers(DI_INSTANCE_T *instance);

/**
 * \brief look up name of non-sensor event
 * \param event
 * \return string
 */
   extern const char *di_query_extra_event_name(DI_SENSOR_TYPE_T event);

/**
 * \brief look up name of a meta event
 */
   extern const char *di_query_meta_event_name(DI_META_EVENT_T event);

/**
 * \brief decode meta events
 * \param meta - the event
 */
   extern void display_meta_event(DI_INSTANCE_T* instance, DI_META_EVENT_INT_DATA_T *meta);

/**
 * \brief display sensor status bits
 * \param instance
 * \param only_present
 // !!! NOTE di_query_sensor_status has to be called before !!!
 */
   extern void display_sensor_status_bytes(DI_INSTANCE_T *instance, bool only_present);

// may not be necessary to make these public...
/** \brief define the driver's instance of its IRQ_CALLBACK */
   extern IRQ_CALLBACK di_irq_callback;
/** \brief define the driver's instance of its I2C_CALLBACK */
   extern I2C_CALLBACK di_i2c_callback;

   extern void printGAM(DI_INSTANCE_T *instance);

   extern void prn_time_LSW(DI_INSTANCE_T *di,DI_SENSOR_TYPE_T s);

   extern void add_sep(char *in,char *out,bool left2right,int len,char sep);

   void prn_num_sep(TS_T num,int len);

   void str_rev(char *inout);

#ifdef __cplusplus
}
#endif

#endif

/** @}*/

