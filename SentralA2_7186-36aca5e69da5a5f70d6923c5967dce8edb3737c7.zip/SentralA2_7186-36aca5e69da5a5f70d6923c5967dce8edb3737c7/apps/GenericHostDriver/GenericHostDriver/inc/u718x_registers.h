/**
 * \file    U718x_registers.h
 *
 *
 * \brief      I2C register addresses, bit structures, and
 *       enumerations used by the generic U718x host driver.
 *
 * \copyright  (C) 2013-2014 EM Microelectronic
 *
 */


#ifndef _U718X_REGISTERS_H_
#define _U718X_REGISTERS_H_

#include "types.h"

/** \brief RO = read only; RW = read/write; U32 = unsigned 32
 *       bit register; U16 = unsigned 16 bit register; I16 =
 *       signed 16 bit register; U8 = unsigned 8 bit
 *       register */
#define SR_BUFFER_OUT_START      0x00 /**< RO; start of FIFO buffer */
#define SR_BUFFER_OUT_END        0x31 /**< RO; end of FIFO buffer */

#define SR_FIFO_FLUSH            0x32 /**< RW; U8; request immediate transfer of a sensor's data */

// unused                        0x33 /**< RW; U8 */
#define SR_CHIP_CONTROL          0x34 /**< RW; U8; bit flags; see RegChipControl below */
#define SR_HOST_STATUS           0x35 /**< RO; U8; bit flags; see RegHostStatus below */
#define SR_INT_STATUS            0x36 /**< RO; U8; bit flags; see RegIntStatus below */
#define SR_CHIP_STATUS           0x37 /**< RO; U8; bit flags; see RegChipStatus below */
#define SR_BYTES_REMAINING_LSB   0x38 /**< RO; U8; LSB of number of bytes in the main batch FIFO */
#define SR_BYTES_REMAINING_MSB   0x39 /**< RO; U8; MSB of "" */

#define SR_PARAMETER_ACKNOWLEDGE 0x3A /**< RO: U8: echos back SR_PARAMETER_REQUEST */
#define SR_SAVED_PARAM_B0        0x3B /**< RO: U8/U16/U32: byte 0 of parameter being read back */
#define SR_SAVED_PARAM_B1        0x3C /**< RO: U8: byte 1 of parameter being read back */
#define SR_SAVED_PARAM_B2        0x3D /**< RO: U8: byte 2 of parameter being read back */
#define SR_SAVED_PARAM_B3        0x3E /**< RO: U8: byte 3 of parameter being read back */
#define SR_SAVED_PARAM_B4        0x3F /**< RO: U8: byte 4 of parameter being read back */
#define SR_SAVED_PARAM_B5        0x40 /**< RO: U8: byte 5 of parameter being read back */
#define SR_SAVED_PARAM_B6        0x41 /**< RO: U8: byte 6 of parameter being read back */
#define SR_SAVED_PARAM_B7        0x42 /**< RO: U8: byte 7 of parameter being read back */
#define SR_SAVED_PARAM_B8        0x43 /**< RO: U8: byte 8 of parameter being read back */
#define SR_SAVED_PARAM_B9        0x44 /**< RO: U8: byte 9 of parameter being read back */
#define SR_SAVED_PARAM_B10       0x45 /**< RO: U8: byte 10 of parameter being read back */
#define SR_SAVED_PARAM_B11       0x46 /**< RO: U8: byte 11 of parameter being read back */
#define SR_SAVED_PARAM_B12       0x47 /**< RO: U8: byte 12 of parameter being read back */
#define SR_SAVED_PARAM_B13       0x48 /**< RO: U8: byte 13 of parameter being read back */
#define SR_SAVED_PARAM_B14       0x49 /**< RO: U8: byte 14 of parameter being read back */
#define SR_SAVED_PARAM_B15       0x4A /**< RO: U8: byte 15 of parameter being read back */

#define SR_I2C_SLVRD_INT_LOC     0x4B /**< RO: U8: for new buffer control hardware; location (0x00->0x35) */
#define SR_BUFFER_CONTROL        0x4C /**< RO: U8: for new buffer control hardware; auto-prop, rd ptr auto-reset, transparent */

#define SR_ERROR_REGISTER        0x50 /**< RO; U8; enumeration; see RegErrorValues below */
#define SR_INTERRUPT_STATE       0x51 /**< RO: U8: internal use only */
#define SR_DEBUG_VALUE           0x52 /**< RO: U8: internal use only */
#define SR_DEBUG_STATE           0x53 /**< RO: U8: internal use only */

#define SR_PARAMETER_PAGE_SEL    0x54 /**< RW; U8; bit fields; see RegParameterPageSel below */
#define SR_HOST_INTF_CONTROL     0x55 /**< RW; U8; bit fields; see RegHostIntfControl below */

#define SR_LOAD_PARAM_B0         0x5C /**< R/W: U8/U16/U32: byte 0 of parameter to be set */
#define SR_LOAD_PARAM_B1         0x5D /**< R/W: U8: byte 1 of parameter */
#define SR_LOAD_PARAM_B2         0x5E /**< R/W: U8: byte 2 of parameter */
#define SR_LOAD_PARAM_B3         0x5F /**< R/W: U8: byte 3 of parameter */
#define SR_LOAD_PARAM_B4         0x60 /**< R/W: U8: byte 4 of parameter */
#define SR_LOAD_PARAM_B5         0x61 /**< R/W: U8: byte 5 of parameter */
#define SR_LOAD_PARAM_B6         0x62 /**< R/W: U8: byte 6 of parameter */
#define SR_LOAD_PARAM_B7         0x63 /**< R/W: U8: byte 7 of parameter */
#define SR_PARAMETER_REQUEST     0x64 /**< R/W: U8: parameter to access */

#define SR_HOST_IRQ_TIMESTAMP    0x6C /**< RO; U32; EM7183 time stamp of host IRQ */
#define SR_ROM_VERSION           0x70 /**< RO; U32; U718x ROM version (defined in hardware) */
#define SR_PRODUCT_ID            0x90 /**< RO; U8; U718x Product ID */
#define SR_REVISION_ID           0x91 /**< RO; U8; U718x Revision ID */

#define SR_UPLOAD_ADDR_H         0x94 /**< RW; U8; upper 5 bits of upload register's address; init to 0 when retrying */
#define SR_UPLOAD_ADDR_L         0x95 /**< RW; U8; lower 8 bits of upload register's address */
#define SR_UPLOAD_DATA           0x96 /**< RW; U8; a byte in the configuration file */
#define SR_CRC_HOST              0x97 /**< RO; U32; CRC-32 of previous host-uploaded configuration block as calculated by U718x */

#define SR_RESET_REQ             0x9B /**< RW; U8; request a hard reset; bit flags; see RegResetRequest below */

#define SR_PASSTHRU_STATUS       0x9E /**< RO; U8; bit flags; see RegPassthruStatus below */
#define SR_SCL_LOW_CYCLES        0x9F /**< RW; U8; clock stretching control for passthru; enumeration; see RegSCLLowCyclesValues below */
#define SR_PASSTHRU_CONTROL      0xA0 /**< RW; U8; bit flags; see RegPassthruControl below */

/**
 * \brief Host writable register for setting hardware states.
 */
PREPACK typedef union MIDPACK RegChipControl
{
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.
    */
   struct
   {
      u8 CPURunReq:1;                                                /**< bit 0: The host has requested that the firmware continue executing. Note: the CPU may not enter a halt state */
      u8 HostUpload:1;                                               /**< bit 1: The host has enabled upload of firmware directly to program RAM. */
   }
   bits;
}
RegChipControl;                                                      /**< typedef for storing Chip Control register values */
POSTPACK

/**
 * \brief Number of previous pending bytes; reset flag
 */
PREPACK typedef union MIDPACK RegHostStatus
{
   // NOTE: This register needs to be cleared *after* an
   // I2C read of the register.
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.
    */
   struct
   {
      u8 CPUReset:1;                                                 /**<  bit 0: The CPU reset event has triggered */
      u8 AlgorithmStandby:1;                                         /**<  bit 1: the algorithm is stopped */
      u8 HostInterfaceID:3;                                          /**<  bits 2-4: Host Interface ID; 0 = KitKat, 1 = Lollipop */
      u8 AlgorithmID:3;                                              /**<  bits 5-7: Algorithm ID; 0 = BSX, 1 = SpacePoint */
   }
   bits;
}
RegHostStatus;                                                       /**< typedef for storing Host Status register values */
POSTPACK

/**
 * \brief Algorithm IDs.
 */
typedef enum AlgID
{
   AID_BSX = 0x00,                                                   /**< algorithm ID for BSX */
   AID_SPACE_POINT = 0x01,                                           /**< algorithm ID for SpacePoint */
}
AlgIDValues;                                                         /**< typedef for algorithm ID values */


/**
 * \brief Host Interface IDs.
 */
typedef enum HostIntfID
{
   HIID_KITKAT = 0x00,                                               /**< host interface ID for KitKat */
   HIID_LOLLIPOP = 0x01,                                             /**< host interface ID for Lollipop */
   HIID_LOLLIPOP_EX = 0x02,                                          /**< host interface ID for Lollipop extended */
}
HIIDValues;                                                          /**< typedef for Host Interface ID values */

/**
 * \brief Number of previous pending bytes; reset flag
 */
PREPACK typedef union MIDPACK RegIntStatus
{
   // NOTE: This register needs to be cleared *after* an
   // I2C read of the register.
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.   NOTE:
    *        bits 1-6 are only available in the future Android L
    *        product.
    */
   struct
   {
      u8 HostInterrupt:1;                                            /**< bit 0: shadow of the host interrupt GPIO line */
		u8 WakeupWatermark:1;                                          /**< Android L: bit 1: interrupt generated because the watermark on the wakeup FIFO was exceeded */
		u8 WakeupLatency:1;                                            /**< Android L: bit 2: interrupt generated because the latency timer on the wakeup FIFO expired */
		u8 WakeupImmediate:1;                                          /**< Android L: bit 3: interrupt generated because a zero-latency sensor generated an event in the wakeup FIFO */
		u8 NonWakeupWatermark:1;                                       /**< Android L: bit 4: interrupt generated because the watermark on the nonwakeup FIFO was exceeded */
		u8 NonWakeupLatency:1;                                         /**< Android L: bit 5: interrupt generated because the latency timer on the nonwakeup FIFO expired */
		u8 NonWakeupImmediate:1;                                       /**< Android L: bit 6: interrupt generated because a zero-latency sensor generated an event in the nonwakeup FIFO */
		u8 rsvd:1;                                                     /**< bit 7: reserved */
   }
   bits;
}
RegIntStatus;                                                        /**< typedef for storing Int Status register values */
POSTPACK

/**
 * \brief Chip state.
 */
PREPACK typedef union MIDPACK RegChipStatus
{
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.
    */
   struct
   {
      u8 EEPROMDetected:1;                                           /**<  bit 0: EEPROM with firmware has been detected */
      u8 EEUploadDone:1;                                             /**<  bit 1: EEPROM upload has compelted */
      u8 EEUploadError:1;                                            /**<  bit 2: EEPROM upload has failed */
      u8 FirmwareHalted:1;                                           /**<  bit 3: The system is in standby */
      u8 NoEEPROM:1;                                                 /**<  bit 4: no eeprom was detected */
   }
   bits;
}
RegChipStatus;                                                       /**< typedef for storing Chip Status register values */
POSTPACK

/**
 * \brief Host selection of parameter page and desired size
 */
PREPACK typedef union MIDPACK RegParameterPageSel
{
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.
    */
   struct
   {
      u8 ParameterPage:4;                                            /**<  bits 0-3: Host selects the parameter page to read or write from */
      u8 ParameterSize:4;                                            /**<  bits 4-7: Number of bytes to read/write; 0 means default of 16 for read, 8 for write */
   }
   bits;
}
RegParameterPageSel;                                                 /**< typedef for storing Parameter Page Select register values */
POSTPACK

/**
 * \brief Error register values.
 * NOTE: it is possible to receive values not in this
 * enumeration; these are classified as internal errors
 * requiring contacting EM Microelectronic for assistance.
 */
typedef enum RegErrorValues
{
   RE_NO_ERROR = 0x00,                                               /**< no error has occurred */
   RE_INVALID_SAMPLE_RATE = 0x80,                                    /**< check sensor rate settings */
   RE_MATH_ERROR = 0x30,                                             /**< check for software updates */
   RE_MAG_INIT_FAILED = 0x21,                                        /**< bad sensor physical connection, wrong driver, or incorrect I2C address */
   RE_ACCEL_INIT_FAILED = 0x22,                                      /**< bad sensor physical connection, wrong driver, or incorrect I2C address */
   RE_GYRO_INIT_FAILED = 0x24,                                       /**< bad sensor physical connection, wrong driver, or incorrect I2C address */
   RE_MAG_RATE_FAILURE = 0x11,                                       /**< sensor is unreliable and stops producing data */
   RE_ACCEL_RATE_FAILURE = 0x12,                                     /**< sensor is unreliable and stops producing data */
   RE_GYRO_RATE_FAILURE = 0x14,                                      /**< sensor is unreliable and stops producing data */
}
RegErrorValues;                                                      /**< typedef for storing Error register values */

/**
 * \brief Host interface control
 */
PREPACK typedef union MIDPACK RegHostIntfControl
{
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.
    */
   struct
   {
      u8 AlgorithmStandbyRequest:1;                                  /**< bit 0: ask U718x to stop the algorithm and shutdown sensors */
      u8 AbortTransfer:1;                                            /**< bit 1: stop the host transfer(?) */
      u8 UpdateBytesRemaining:1;                                     /**< bit 2: refresh the value of the SR_BYTES_REMAINING registers */
      u8 HostIntDisable:1;                                           /**< bit 3: master enable bit for host interrupt */
      u8 NED:1;                                                      /**< bit 4: use North East Down instead of the Android default East North Up */
      u8 APSuspended:1;                                              /**< bit 5: when true, only certain sensor events may wake the processor */
      u8 SensorSelfTest:1;                                           /**< bit 6: request sensors to self-test; will report results as meta event */
      u8 NonWakeupFIFOIntDisable:1;                                  /**< bit 7: Android K: host interface test mode; only available in future Android L product; set to disable interrupts to host on non-wakeup events */
   }
   bits;
}
RegHostIntfControl;                                                  /**< typedef for storing Host Interface Control register values */
POSTPACK

/**
 * \brief Reset request flags.
 */
PREPACK typedef union MIDPACK RegResetRequest
{
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.
    */
   struct
   {
      u8 ResetRequest:1;                                             /**< bit 0: reset the chip; mimics a full hardware reset */
   }
   bits;
}
RegResetRequest;                                                     /**< typedef for storing Reset Request register values */
POSTPACK

/**
 * \brief I2C slave bus to master bus passthrough status.
 */
PREPACK typedef union MIDPACK RegPassthruStatus
{
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.
    */
   struct
   {
      u8 PassthruReady:1;                                            /**< bit 0: passthrough state is enabled / ready */
   }
   bits;
}
RegPassthruStatus;                                                   /**< typedef for storing Passthru Status register values */
POSTPACK

/**
 * \brief Suggested passthrough clock stretch values.
 */
typedef enum RegSCLLowCyclesValues
{
   /** \brief */
   RS_NONE = 0x00,                                                   /**< no clock stretching*/
   RS_STANDARD_I2C_CYCLES = 46,                                      /**< rate for 100KHz I2C slaves */
   RS_FAST_I2C_CYCLES = 12,                                          /**< rate for 400KHz I2C slaves */
   RS_HIGHSPEED_I2C_CYCLES = 4,                                      /**< rate for 1MHz I2C slaves */
}
RegSCLLowCyclesValues;                                               /**< typedef for storing SCL Low Cycles values */

/**
 * \brief Passthrough control.
 */
PREPACK typedef union MIDPACK RegPassthruControl
{
   /**
    * \brief Direct access to the complete 8bit register
    */
   u8 reg;
   /**
    * \brief Access to individual bits in the register.
    */
   struct
   {
      u8 PassthroughEn:1;                                            /**< bit 0: enable sensor to host connection */
      u8 ClockStretchEn:1;                                           /**< bit 1: enable clock stretching */
   }
   bits;
}
RegPassthruControl;                                                  /**< typedef for storing Passthru Control register values */
POSTPACK

#endif

