#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#ifdef WIN32
#include <conio.h>
#endif
#ifdef _MSC_VER
#pragma warning(disable : 4996)
#endif


#include "driver_ext.h"
#include "host_services.h"
#include "host_definitions.h"
//#include "firmware_tests.h"
#include "driver_util.h"
#include "sensor_handling.h"
#include "sensor_stats.h"
#include "test_config.h"
#include "main.h"

#if !defined(VERSION)
#define VERSION 6
#endif

//#define USE_TASK_LOOP
#define INITIALIZED_TIMEOUT_MS 2000
#define STATS_PERIOD_MS 5000

typedef struct sensor_control
{
   char *option;
   u16 sample_rate;
   u16 wake_sample_rate;
   u16 latency;
   u16 wake_latency;
   u16 dynamic_range;
   bool enabled;
} SENSOR_CONTROL;


SENSOR_CONTROL sensors[255] =
{
   {""},                                                             // DST_NOP = "",
   {"a"},                                                            // DST_ACCELEROMETER = 1,
   {"m"},                                                            // DST_GEOMAGNETIC_FIELD = 2,
   {"O"},                                                            // DST_ORIENTATION = 3,
   {"g"},                                                            // DST_GYROSCOPE = 4,
   {""},                                                             // DST_LIGHT = 5,
   {"p"},                                                            // DST_PRESSURE = 6,
   {""},                                                             // DST_TEMPERATURE = 7,
   {""},                                                             // DST_PROXIMITY = 8,
   {"G"},                                                            // DST_GRAVITY = 9,
   {"L"},                                                            // DST_LINEAR_ACCELERATION = 10,
   {"q"},                                                            // DST_ROTATION_VECTOR = 11,
   {""},                                                             // DST_RELATIVE_HUMIDITY = 12,
   {""},                                                             // DST_AMBIENT_TEMPERATURE = 13,
   {"mu"},                                                           // DST_MAGNETIC_FIELD_UNCALIBRATED = 14,
   {"M"},                                                            // DST_GAME_ROTATION_VECTOR = 15,
   {"gu"},                                                           // DST_GYROSCOPE_UNCALIBRATED = 16,
   {"I"},                                                            // DST_SIGNIFICANT_MOTION = 17,
   {"R"},                                                            // DST_STEP_DETECTOR = 18,
   {"S"},                                                            // DST_STEP_COUNTER = 19,
   {"E"},                                                            // DST_GEOMAGNETIC_ROTATION_VECTOR = 20,
   {""},                                                             // DST_HEART_RATE = 21,
   {"i"},                                                            // DST_TILT_DETECTOR = 22,
   {"gw"},                                                           // DST_WAKE_GESTURE = 23,
   {"gg"},                                                           // DST_GLANCE_GESTURE = 24,
   {"gp"},                                                           // DST_PICKUP_GESTURE = 25,
   {""},                                                             // ,
   {""},                                                             // ,
   {""},                                                             // ,
   {"j"},                                                            // DST_JERK_EXAMPLE = 29,
   {"J"},                                                            // DST_CAL_STATUS = 30,
   {"V"},                                                            // DST_ACTIVITY = 31,
   {0},
};
#define NUM_OPTIONS 255 // (sizeof(sensors) / sizeof(SENSOR_CONTROL))

DI_INSTANCE_T *instance = NULL;
bool sigmotion_test = FALSE;
bool ap_suspended = FALSE;
bool got_sigmotion = FALSE;
AlgIDValues alg_id;
HIIDValues host_intf_id;


void print_signon(void)
{
   info_log("U718x Sensor Output Logger v1.0.%d, %s, %s\n\n", VERSION, __DATE__, __TIME__);
}

// this is because config is tailored for test functions. We need to implement this finctions it want's to call if cfg is selecting some tests
int get_num_tests(void)
{
   return 0;
}
struct test_desc *find_test(const char *name)
{
   return NULL;
}
struct test_desc *get_test(int index)
{
   return NULL;
}
void set_all_tests_loop(int loops)
{
}

void display_status(DI_INSTANCE_T *instance)
{
   PHYS_SENSOR_STATUS phys_sensor_status;
   bool host_interrupt;

   // display actual sample rates implemented by the drivers
   info_log("\nDetermine actual rates for sensors:\n");
   if (!display_actual_rates(instance))
   {
   }

   if (!di_query_sensor_status(instance))
      error_log("error querying sensor status bits\n");
   else
   {
      info_log("\nSensor status bits:\n");
      display_sensor_status_bytes(instance, TRUE);
   }

   if (!di_save_parameter(instance, PP_SYSTEM, SYSP_PHYS_SENS_STATUS, (u8 *)&phys_sensor_status, sizeof(phys_sensor_status)))
      error_log("error requesting physical sensor status\n");
   else
   {
      info_log("\nPhysical sensor info:\nPhysical sensor, rate, range, IRQ en, power mode\n");
      info_log("          Accel, % 4u, % 5u, % 6u, %u\n", phys_sensor_status.AccelRate, phys_sensor_status.AccelRange, phys_sensor_status.AccelIRQ, phys_sensor_status.AccelPowerMode);
      info_log("           Gyro, % 4u, % 5u, % 6u, %u\n", phys_sensor_status.GyroRate, phys_sensor_status.GyroRange, phys_sensor_status.GyroIRQ, phys_sensor_status.GyroPowerMode);
      info_log("            Mag, % 4u, % 5u, % 6u, %u\n\n", phys_sensor_status.MagRate, phys_sensor_status.MagRange, phys_sensor_status.MagIRQ, phys_sensor_status.MagPowerMode);
   }

   display_error_info(instance);
   if (di_poll_host_interrupt(instance, &host_interrupt))
      info_log("Host interrupt: %s\n", host_interrupt ? "ASSERTED" : "deasserted");
   else
      error_log("error polling host interrupt\n");
}

bool configure_sensor(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, bool always_set, u16 max_latency)
{
   bool status = TRUE;
   SENSOR_CONFIG sensor_config;

   sensor_config.sample_rate = sensors[sensor].enabled ? sensors[sensor].sample_rate : 0;
   sensor_config.max_report_latency = sensors[sensor].latency ? sensors[sensor].latency : max_latency;
   sensor_config.change_sensitivity = 0;
   sensor_config.dynamic_range = sensors[sensor].dynamic_range;

   if (sensor_config.sample_rate || always_set)                      // always set the rate if nonzero, or, we started up without resetting the chip
   {
      info_log("% 2u, %27s, ", sensor, di_query_sensor_name(instance, sensor));
      if (!di_configure_sensor(instance, sensor, &sensor_config))
      {
         error_log("error setting rate\n");
         status = FALSE;
      }
      else
         info_log("% 4u, %u\n", sensor_config.sample_rate, sensor_config.max_report_latency);
   }
   if (instance->hi_id != HIID_KITKAT)
   {
      sensor_config.sample_rate = sensors[sensor].enabled ? sensors[sensor].wake_sample_rate : 0;
      sensor_config.max_report_latency = sensors[sensor].wake_latency ? sensors[sensor].wake_latency : max_latency;
      sensor_config.change_sensitivity = 0;
      sensor_config.dynamic_range = sensors[sensor].dynamic_range;

      if ((sensor == DST_SIGNIFICANT_MOTION) && (sensor_config.sample_rate != 0) && ap_suspended)
      {
         sigmotion_test = TRUE;
         info_log("enabling sigmotion_test\n");
      }

      if (sensor_config.sample_rate || always_set)                   // always set the rate if nonzero, or, we started up without resetting the chip
      {
         int wake_sensor = sensor + di_wake_sensor_start(instance);
         //time_delay_ms(55);
         info_log("% 2u, %27s, ", wake_sensor, di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)wake_sensor));
         if (!di_configure_sensor(instance, (DI_SENSOR_TYPE_T)wake_sensor, &sensor_config))
         {
            error_log("error setting rate\n");
            status = FALSE;
         }
         else
            info_log("% 4u, %u\n", sensor_config.sample_rate, sensor_config.max_report_latency);
      }
   }
   else
   {
      if ((sensor == DST_SIGNIFICANT_MOTION) && (sensor_config.sample_rate != 0) && ap_suspended)
      {
         sigmotion_test = TRUE;
         info_log("enabling sigmotion_test\n");
      }
   }
   return status;
}

bool configure_sensors(DI_INSTANCE_T *instance, bool always_set, u16 max_latency)
{
   bool status = TRUE;
   DI_SENSOR_TYPE_T i;

   info_log("\nConfiguring sensors:\n");
   info_log("Sensor ID,                 name, rate\n");
   // configure each sensor
   for (i = DST_FIRST; i <= di_max_sensor_id(instance); i++)
   {
      if ((instance->hi_id == HIID_KITKAT) && (i > DST_ACTIVITY))
         break;
      if (!di_has_sensor(instance, i))
      {
         if (instance->sensor_info[i].status.device_id_error || instance->sensor_info[i].status.i2c_nack)
         {
            error_log("% 2u, %27s, Device ID Error=%u, I2C NACK=%u\n", i, di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)i), instance->sensor_info[i].status.device_id_error, instance->sensor_info[i].status.i2c_nack);
            status = FALSE;
         }
         continue;
      }
      if (!sensors[i].option)
         break;
      if (sensors[i].option[0])
      {
         status &= configure_sensor(instance, i, always_set, max_latency);
      }
   }
   return status;
}

void dump_bmi160_odr(DI_INSTANCE_T *instance, char *unique_id)
{
   static I2C_HANDLE_T bmi_handle = NULL;

   u8 buf[2] = {0};

   if (!bmi_handle)
   {
      bmi_handle = i2c_setup(0x68, unique_id);
      if (!bmi_handle)
      {
         error_log("no i2c handles left\n");
         return;
      }
   }
   if (i2c_init(bmi_handle))
   {
      if (di_passthrough_enter(instance, bmi_handle))
      {
         if (di_read_registers_with_handle(instance, bmi_handle, 0x40, 0x40, buf))
         {
            info_log("BMI160 ODR = 0x%02X\n", buf[0]);
         }
         di_passthrough_exit(instance);
      }
   }
}


bool rt_data_callback(DI_INSTANCE_T *instance, DI_SENSOR_TYPE_T sensor, DI_SENSOR_INT_DATA_T *data, void *user_param)
{
   bool ret = data_callback(instance, sensor, data, user_param);  // convert raw to scaled outputs, and perform statistics

   if (sensor == DST_SIGNIFICANT_MOTION)
   {
      info_log("NONWAKE SIG MOTION at t=%u.  Int Status = 0x%02X\n", data->significant_motion.t, instance->error.int_status.reg);
      got_sigmotion = TRUE;
   }
   else if (sensor == (DST_SIGNIFICANT_MOTION + di_wake_sensor_start(instance)))
   {
      info_log("WAKE SIG MOTION at t=%u. Int Status = 0x%02X\n", data->significant_motion.t, instance->error.int_status.reg);
      got_sigmotion = TRUE;
   }
   return ret;
}


extern bool irq_callback(IRQ_HANDLE_T handle, u32 os_param, void *user_param);

bool rt_irq_callback(IRQ_HANDLE_T handle, u32 os_param, void *user_param)
{
   bool ret;

   if (sigmotion_test && ap_suspended)
   {
      ap_suspended = FALSE;
      if (!di_set_ap_suspended_mode(instance, ap_suspended))
         error_log("Unable to resume\n");
      else
         info_log("Resume\n");
   }
   ret = irq_callback(handle, os_param, user_param);
   return ret;
}


void reenable_sigmotion(DI_INSTANCE_T *instance)
{
   SENSOR_CONFIG sensor_config;
   u16 rate = 1;
   u16 latency = 0;
   bool wake = FALSE;

   if (sensors[DST_SIGNIFICANT_MOTION].sample_rate)
   {
      rate = sensors[DST_SIGNIFICANT_MOTION].sample_rate;
      latency = sensors[DST_SIGNIFICANT_MOTION].latency;
   }
   else if (host_intf_id != HIID_KITKAT)
   {
      rate = sensors[DST_SIGNIFICANT_MOTION].wake_sample_rate;
      latency = sensors[DST_SIGNIFICANT_MOTION].wake_latency;
      wake = TRUE;
   }
   sensor_config.sample_rate = rate;
   sensor_config.max_report_latency = latency;
   sensor_config.change_sensitivity = 0;
   sensor_config.dynamic_range = 0;
   if (!di_configure_sensor(instance, DST_SIGNIFICANT_MOTION + (wake ? di_wake_sensor_start(instance) : 0), &sensor_config))
      error_log("Error enabling %s significant motion\n", wake ? "wake" : "non-wake");
   else
      info_log("Re-enabled %s significant motion\n", wake ? "wake" : "non-wake");
}


int main(int argc, char *argv[])
{
   char config_file[1024];
   char log_file[1024];
   I2C_HANDLE_T i2c_handle = NULL;
   I2C_HANDLE_T eeprom_i2c_handle = NULL;
   IRQ_HANDLE_T irq_handle = NULL;
   OUT_HANDLE_T out_handle = NULL;
   u8 product_id;
   u8 revision_id;
   u16 rom_version;
   u16 ram_version;
   bool eeprom_present;
   bool append_log = FALSE;
   int i;
   int j;
   u16 max_latency = 0;
   u16 watermark = 0;
   u16 wake_watermark = 0;
   u16 new_output_rate = 200;
   int test_mode = 0;
   int run_duration_seconds = 0;
   int start_time_seconds = 0;
   bool done;
   bool verbose = FALSE;
   bool data_verbose = FALSE;
   bool force_upload = FALSE;
   bool force_reset = TRUE;
   bool force_anyrom = FALSE;
   bool power_down = FALSE;
   bool raw_data = FALSE;
   bool all_raw_data = FALSE;
   bool quiet_stats = FALSE;
   bool quiet_meta = FALSE;
   bool quiet_timestamps = FALSE;
   bool quiet_info = FALSE;
   bool had_events = FALSE;
   bool dump_raw_data = FALSE;
   bool simple_setup = FALSE;
   bool enable_meta_events = FALSE;
   bool disable_meta_events = FALSE;
   bool wake_interrupt_en = TRUE;
   bool interrupt_en = TRUE;
   bool host_interrupt;
   bool executing;
   bool sensing;
   struct tm *ltime;
   time_t now;
   char normal_firmware[CONF_MAX_STRING + 1] = "";
   u32 sensor_data_received;
   u8 buf[256];
   u32 output_timeout;
   u32 buf_size = 0;
   u32 response_delay_ms = 0;
   //u32 last_dynamic_rate_changed_count = 0;
   SENSOR_CONFIG sensor_config;
   FIFO_CONTROL_PARAM fifo_control_param;
#ifdef WIN32
   DI_SENSOR_TYPE_T flush_sensor = 0xFF;
#endif
   char option;
   char second_option;
   bool wake_sensor;
   char *param;
   char *second_param;
   char *third_param;
   char *unique_id = NULL;

   // log the name of the test
   print_signon();

   // process command line
   strcpy(config_file, "READ_TEST.CFG");
   log_file[0] = '\0';

   if (argc > 1)
   {
      for (i = 1; i < argc; i++)
      {
         if ((argv[i][0] == '-') || (argv[i][0] == '/'))
         {
            option = argv[i][1];
            second_option = argv[i][2];
            second_param = strchr(argv[i], ',');
            if (second_param)
            {
               second_param++;                                       // skip the comma
               third_param = strchr(second_param, ',');
               if (third_param)
                  third_param++;                                     // skip the comma
            }
            if (option == 'w')                                       // wake sensor
            {
               option = argv[i][2];
               second_option = argv[i][3];
               param = &argv[i][3];
               wake_sensor = TRUE;
            }
            else
            {
               param = &argv[i][2];
               wake_sensor = FALSE;
            }
            switch (option)
            {
               case 'U':
                  unique_id = _strdup(param);
                  info_log("will search for device with unique id = %s\n", unique_id);
                  break;
               case 'C':
                  strcpy(config_file, param);
                  info_log("using config file: %s\n", config_file);
                  break;
               case 'v':
                  verbose = TRUE;
                  info_log("will log FIFO data transfer info\n");
                  break;
               case 'D':
                  raw_data = TRUE;
                  all_raw_data = (second_option == 'A');
                  info_log("will log %s raw sensor input data\n", all_raw_data ? "all" : "appropriate");
                  break;
               case 'd':
                  data_verbose = TRUE;
                  info_log("will log each data sample\n");
                  break;
               case 'A':
                  append_log = TRUE;
                  info_log("will append to log\n");
                  break;
               case 'x':
                  force_anyrom = TRUE;
                  info_log("will run on any ROM\n");
                  break;
               case 'l':
                  strcpy(log_file, param);
                  info_log("using log file: %s\n", log_file);
                  break;
               case 'f':
                  force_upload = TRUE;
                  strcpy(normal_firmware, param);
                  info_log("using normal firmware file: %s\n", normal_firmware);
                  break;
               case 'X':
                  for (j = DST_FIRST; j < NUM_OPTIONS; j++)
                  {
                     sensors[j].enabled = TRUE;
                     if (wake_sensor)
                        sensors[j].wake_sample_rate = atoi(param);
                     else
                        sensors[j].sample_rate = atoi(param);
                  }
                  info_log("set all sensors to %u Hz\n", atoi(param));
                  break;
               case 'F':
                  force_upload = TRUE;
                  info_log("forcing upload of firmware at start\n");
                  break;
               case 'r':
                  force_reset = FALSE;
                  info_log("will not reset em718x at start\n");
                  break;
               case 'P':
                  power_down = TRUE;
                  info_log("power down at the end\n");
                  break;
               case 't':
                  max_latency = atoi(param);
                  info_log("set timeout (max latency) to %u ms\n", max_latency);
                  break;
               case 'T':
                  test_mode = atoi(param);
                  info_log("setting test mode to %d\n", test_mode);
                  break;
               case 'W':
                  if (wake_sensor)
                  {
                     wake_watermark = atoi(param);
                     info_log("set Wakeup FIFO watermark to %u bytes\n", wake_watermark);
                  }
                  else
                  {
                     watermark = atoi(param);
                     info_log("set Nonwakeup FIFO watermark to %u bytes\n", watermark);
                  }
                  break;
               case 'n':
                  if (wake_sensor)
                  {
                     wake_interrupt_en = (atoi(param) != 0);
                     info_log("set Wakeup interrupt enable to %u\n", wake_interrupt_en);
                  }
                  else
                  {
                     interrupt_en = (atoi(param) != 0);
                     info_log("set Nonwakeup interrupt enable to %u\n", interrupt_en);
                  }
                  break;
               case 'z':
                  if (param[0] == 'r')
                  {
                     response_delay_ms = atoi(&param[1]);
                     info_log("will delay response to interrupt by %u ms\n", response_delay_ms);
                  }
                  else
                  {
                     run_duration_seconds = atoi(param);
                     info_log("will run for %u seconds then stop and exit\n", run_duration_seconds);
                  }
                  break;
               case 'b':
                  buf_size = atoi(param);
                  buf_size = (buf_size / 50) * 50;
                  if (buf_size)
                     info_log("changing max FIFO transfer buffer size to %u bytes\n", buf_size);
                  break;
               case 'Z':
                  new_output_rate = atoi(param);
                  info_log("sensors toggled on at runtime will run at %u Hz\n", new_output_rate);
                  break;
               case 'Q':
                  if (param[0] == 's')
                     quiet_stats = TRUE;
                  else if (param[0] == 'm')
                     quiet_meta = TRUE;
                  else if (param[0] == 't')
                     quiet_timestamps = TRUE;
                  else if (param[0] == 'i')
                     quiet_info = TRUE;
                  else
                     quiet_info = quiet_stats = quiet_meta = quiet_timestamps = TRUE;
                  info_log("will turn off meta event, timestamp analysis, and statistics\n");
                  break;
               case 'Y':
                  dump_raw_data = TRUE;
                  info_log("will dump raw binary data from host interface; if logging to file, only send it there\n");
                  break;
               case 'B':
                  simple_setup = TRUE;
                  info_log("do not modify settings for any sensors not set on the command line -- including the watermarks\n");
                  break;
               case 'e':
                  if (second_option == 'N')
                  {
                     disable_meta_events = TRUE; // disable all
                     info_log("turn off all meta events for both FIFOs\n");
                  }
                  else
                  {
                     enable_meta_events = TRUE;
                     info_log("turn on all meta events for both FIFOs\n");
                  }
                  break;
               case 's':
                  ap_suspended = TRUE;
                  info_log("going into AP Suspended mode\n");
                  break;
               case 'h':
               case '?':
                  print_signon();
                  info_log("Usage: %s {-ffile}{-Uid}{-aN}{-gN}{-guN}{-mN}{-muN}{-qN}{-LN}{-GN}{-ON}{-MN}{-EN}{-SN}{-RN}{-IN}{-iN}{-VN}{-Cfile}{-p}{-XN}{-wXN}{-WN}{-tN}{-TN}{-s}{-zN}{-Q}{-Y}{-B}{-e}{-v}{-d}{-D}{-bN}{-x}{-A}{-llog}{-r}{-F}{-P}\n", argv[0]);
                  info_log("-Uid   select I2C interface with unique ID = id\n");
                  info_log("-Cfile set config file name to 'file'\n");
                  info_log("-XN    set all (non-wake) sensors to N Hz\n");
                  info_log("-wXN   set all wakeup sensors to N Hz\n");
                  for (i = DST_FIRST; i < NUM_OPTIONS; i++)
                  {
                     if (!sensors[i].option)
                        break;
                     if (sensors[i].option[0])
                        info_log("-{w}%sN{,M{,O}} set sensor %s sample rate to N, optionally the latency to M, and optionally dynamic range to O; prepend 'w' to set wake sensor, otherwise default or nonwake sensor\n", sensors[i].option, di_query_sensor_name(instance, i));
                  }
                  info_log("-WN    set Nonwakeup FIFO watermark to N bytes (default 0)\n");
                  info_log("-wWN   set Wakeup FIFO watermark to N bytes (default 0)\n");
                  info_log("-tN    set timeout (max latency) for all sensors to N milliseconds (default 0)\n");
                  info_log("-TN    set test pattern mode (0 = none; 1 = all sensor outputs replaced with patterns; 2 = sensor test mode\n");
                  info_log("-s     start in AP Suspended mode\n");
                  info_log("-zN    set run time to N seconds; stops automatically\n");
                  info_log("-zrN   delay response to interrupts by %u ms\n");
                  info_log("-QN    quiet the info, stats, meta events, and timestamp error logging; optional N values: i = info, s = stats, m = meta, t = timestamps\n");
                  info_log("-Y     dump raw FIFO data\n");
                  info_log("-B     set settings for sensors not specified on the command line, including the watermarks\n");
                  info_log("-e     turn on all meta events\n");
                  info_log("-v     set verbose output\n");
                  info_log("-d     display all data samples\n");
                  info_log("-D[A]  request raw sensor data (data as input to fusion algorithm) for enabled sensors; append 'A' to request all 3 debug sources\n");
                  info_log("-bN    set maximum I2C transfer buffer size to N bytes (defaults to 32750); must be multiple of 50\n");
                  info_log("-nN    set interrupt enable for the FIFO to N (0 = disabled, 1 = enabled); prefix with 'w' for wakeup FIFO\n");
                  info_log("-ZN    set new sensor rate (when turned on at run time) to N (default 200 Hz)\n");
                  info_log("-x     run on any ROM\n");
                  info_log("-A     append to log\n");
                  info_log("-llog  log output to file 'log'\n");
                  info_log("-r     do not reset em718x at start\n");
                  info_log("-ffile override config file normal_firmware field (set the em718x firmware filename here)\n");
                  info_log("-F     force upload of firmware at start\n");
                  info_log("-P     power down at end\n");
                  return 0;
               default:
                  for (j = DST_FIRST; j < NUM_OPTIONS; j++)
                  {
                     if (
                         (option == sensors[j].option[0])
                         &&
                         (
                          (
                           (isdigit(second_option) || !second_option || (second_option == ' '))
                           &&
                           !sensors[j].option[1]
                          )
                          ||
                          (second_option == sensors[j].option[1])
                         )
                        )
                     {
                        if ((second_option == sensors[j].option[1]) && sensors[j].option[1])
                           param++;
                        sensors[j].enabled = TRUE;
                        if (wake_sensor)
                        {
                           sensors[j].wake_sample_rate = atoi(param);
                           info_log("set wake sensor %s to sample rate %u Hz", di_query_sensor_name(instance, j), sensors[j].wake_sample_rate);
                           if (second_param)
                           {
                              sensors[j].wake_latency = atoi(second_param);
                              info_log(", latency %u ms", sensors[j].wake_latency);
                              if (third_param)
                              {
                                 sensors[j].dynamic_range = atoi(third_param);
                                 info_log(", dynamic range %u", sensors[j].dynamic_range);
                              }
                           }
                           info_log("\n");
                        }
                        else
                        {
                           sensors[j].sample_rate = atoi(param);
                           info_log("set nonwake sensor %s to sample rate %u Hz", di_query_sensor_name(instance, j), sensors[j].sample_rate);
                           if (second_param)
                           {
                              sensors[j].latency = atoi(second_param);
                              info_log(", latency %u ms", sensors[j].latency);
                              if (third_param)
                              {
                                 sensors[j].dynamic_range = atoi(third_param);
                                 info_log(", dynamic range %u", sensors[j].dynamic_range);
                              }
                           }
                           info_log("\n");
                        }
                        break;
                     }
                     if (sensors[j].option == 0)
                     {
                        error_log("unrecognized option '%c'!\n", option);
                        return 0;
                     }
                  }
                  break;
            }
         }
      }
   }

   // log to file if requested
   if (log_file[0] != '\0')
   {
      debug_set_log_file(log_file, append_log);
      info_log("Command line: ");
      for (i = 0; i < argc; i++)
         info_log("%s ", argv[i]);
      info_log("\n");
   }

   // set whether to log lots of stuff
   if (verbose)
      set_logging_level(LL_DEBUG);
   else
      set_logging_level(LL_INFO);

   // indicate to sensor handler whether we want to see all data
   set_verbose_sensor_data(data_verbose);

   // when logging all raw FIFO bytes and also decoding all sensor events, use the debug log, so they only go to the file
   if (data_verbose && dump_raw_data)
      stats_set_log_level(LL_DEBUG);

   // display test start date / time
   time(&now);
   ltime = localtime(&now);
   info_log("current date and time: %s\n", asctime(ltime));

   read_test_config(config_file);
   if (verbose)
      dump_config();

   //if (!strlen(normal_firmware))
   //   strcpy(normal_firmware, config.normal_firmware);

   /**************************************************************
   * set up I2C and Data Ready IRQ                               *
   ***************************************************************/
   i2c_handle = i2c_setup(0x28, unique_id);                   // handle for em718x I2C access
   if (!i2c_init(i2c_handle))
   {
      error_log("I2C init error\n");
      goto error_exit;
   }
   eeprom_i2c_handle = i2c_setup(0x50, unique_id);
   if (!i2c_init(eeprom_i2c_handle))
   {
      error_log("I2C init error\n");
      goto error_exit;
   }
   if (!i2c_handle || !eeprom_i2c_handle)
   {
      error_log("I2C setup error\n");
      goto error_exit;
   }

   irq_handle = irq_setup(5, unique_id);                      // the SPI /SS line on the Aardvark
   if (!irq_handle)
   {
      error_log("IRQ setup error\n");
      goto error_exit;
   }

   out_handle = out_setup(4, unique_id);
   if (!out_handle)
      info_log("no debug output pin available\n");

   /**************************************************************
   * initialize em718x                                          *
   ***************************************************************/
   info_log("\n--------------------------------------------\nINITIALIZING...\n");
   instance = di_init(i2c_handle, irq_handle, force_reset);
   if (!instance)
   {
      info_log("Driver setup error\n");
      goto error_exit;
   }

   // register our own local handler; we'll chain to the GHD one
   if (!irq_register(irq_handle, rt_irq_callback, (void *)instance))
   {
      i2c_deinit(i2c_handle);
      INSTANCE_ERROR(DE_INVALID_PARAMETERS);
      return FALSE;
   }

   if (buf_size)
      di_set_buffer_max_size(instance, buf_size);
   else
   {
      uint16_t buf_size = i2c_get_max_read_length(i2c_handle); // ask driver what max size it supports
      info_log("GHD FIFO buffer size reduced to: %u\n", buf_size);
      di_set_buffer_max_size(instance, buf_size); // limit to this size
   }

   // control error displays
   di_control_logging(instance, FALSE, quiet_meta, quiet_timestamps, dump_raw_data);

   // find out what device is there
   if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
   {
      error_log("error detecting u718x\n");
      goto error_exit;
   }
   info_log("U718x detected.  Product id: u71%02X, revision id: %u, rom version: %u, ram version: %u, eeprom present: %u\n",
            product_id, revision_id, rom_version, ram_version, eeprom_present);

   /**************************************************************
   * load firmware if needed                                     *
   ***************************************************************/
   if (!eeprom_present || force_upload)
   {
#if defined(LOAD_TO_RAM)
      if (eeprom_present)
      {
         info_log("erasing EEPROM...\n");
         if (!di_erase_eeprom(instance, eeprom_i2c_handle))
         {
            error_log("error erasing EEPROM\n");
         }
      }
      if (strlen(normal_firmware) > 0)
      {
         info_log("Uploading to RAM...\n");
         if (!di_upload_firmware(instance, normal_firmware, force_anyrom, NULL))
         {
            error_log("error uploading firmware\n");
            goto error_exit;
         }
      }
#else
      info_log("Uploading to EEPROM...\n");
      if (!di_upload_eeprom(instance, eeprom_i2c_handle, normal_firmware, NULL))
      {
         error_log("error uploading firmware\n");
         goto error_exit;
      }
#endif
   }

   /**************************************************************
   * set up all sensors                                          *
   ***************************************************************/
   if (!di_set_sensor_self_test_mode(instance, test_mode == 2))      // must be called before we run
   {
      error_log("error requesting sensor self test mode\n");
      goto error_exit;
   }

   if (!di_run_request(instance))
   {
      error_log("error starting\n");
      goto error_exit;
   }

   // now that we're running, we can check the ram version
   if (!di_detect_chip(instance, &product_id, &revision_id, &rom_version, &ram_version, &eeprom_present))
   {
      error_log("error detecting em718x\n");
      goto error_exit;
   }
   info_log("RAM version is now: %u\n", ram_version);

   if (di_read_registers(instance, SR_PASSTHRU_STATUS, SR_PASSTHRU_STATUS + 1, buf))
   {
      u8 fpga_version = (buf[0] >> 1) & 0x7f;
      info_log("FPGA version: 0x%02X\n", fpga_version);
      // apply timing correction to u7180_jtag_v37, u7180_jtag_v38, u7183_jtag_v39, u7180_jtag_v41, u7183_jtag_v43, u7183_jtag_v45 (10MHz), u7183_jtag_v47 (15MHz)
      if ((fpga_version == 0x37) || (fpga_version == 0x38) || (fpga_version == 0x39) || (fpga_version == 0x41) || (fpga_version == 0x43) || (fpga_version == 0x45) || (fpga_version == 0x47) || (fpga_version == 0x49))
      {
         if (di_read_registers(instance, 0xB6, 0xB6, buf))
         {
            info_log("TimoscDivCount was: %u\n", buf[0]);
            buf[0] = 66;
            if (di_write_registers(instance, 0xB6, 0xB6, buf))
            {
               info_log("Set TimoscDivCount to %u\n", buf[0]);
            }
         }
      }
   }

   // start the algorithm running
   if (!di_normal_exec_request(instance))
      error_log("error running\n");

   // wait for initialized event -- after that, it is safe to talk to the device
   if (force_reset)
   {
      info_log("\nWaiting for initialization complete...\n");

      output_timeout = time_ms() + INITIALIZED_TIMEOUT_MS;
      instance->meta_events[DME_INITIALIZED] = 0;
      do
      {
         if (instance->state == DS_IDLE)
         {
            if (!i2c_blocking_read(instance->i2c_handle, SR_ERROR_REGISTER, (u8 *)&instance->error.error_register, 1))
            {
               INSTANCE_ERROR(DE_I2C_ERROR);
               return FALSE;
            }
            if (instance->error.error_register)
            {
               display_error_info(instance);
            }
         }
         if (!di_task_loop(instance, NULL))
         {
            display_error_info(instance);
            break;
         }
#if defined(DI_SLIM)
         if (instance->meta_events[DME_INITIALIZED])
#else
         if (instance->meta_events[DME_INITIALIZED] || instance->meta_events_wakeup[DME_INITIALIZED])
#endif
         {
            info_log("Initialized event received; device is ready\n");
            break;
         }
      }
      while (time_ms() < output_timeout);
#if defined(DI_SLIM)
      if (!instance->meta_events[DME_INITIALIZED])
#else
      if (!instance->meta_events[DME_INITIALIZED] && !instance->meta_events_wakeup[DME_INITIALIZED])
#endif
         info_log("Timeout!\n");
      di_pause_task_loop(instance);
      display_error_info(instance);
   }
   else
   {
      info_log("skipping waiting for initialized event (not resetting)\n");
   }

   alg_id = di_get_algorithm_id(instance);
   if (alg_id == AID_BSX)
      info_log("\nRunning BSX fusion algorithm\n");
   else
      info_log("\nRunning SpacePoint fusion algorithm\n");

   host_intf_id = di_get_host_interface_id(instance);
   if (host_intf_id == HIID_KITKAT)
      info_log("Running Android KitKat host interface\n");
   else if (host_intf_id == HIID_LOLLIPOP)
      info_log("Running Android Lollipop host interface\n");
   else if (host_intf_id == HIID_LOLLIPOP_EX)
      info_log("Running Android Lollipop host interface\n");
   else
      info_log("Running unknown host interface\n");

   info_log("\n--------------------------------------------\nCONFIGURING...\n");
   if (enable_meta_events || disable_meta_events)
   {
      info_log("\n%sabling meta events:\n", enable_meta_events ? "En" : "Dis");
      for (i = DME_FLUSH_COMPLETE; i < DME_NUM_META_EVENTS; i++)
      {
         if ((host_intf_id == HIID_LOLLIPOP) || (host_intf_id == HIID_LOLLIPOP_EX))
         {
            // -> interrupt host on wakeup FIFO overflow: if (!di_enable_meta_event_ex(instance, (DI_META_EVENT_T)i, TRUE, i == DME_FIFO_OVERFLOW, TRUE))
            if (!di_enable_meta_event_ex(instance, (DI_META_EVENT_T)i, enable_meta_events, FALSE, TRUE))
            {
               error_log("error changing %s wakeup meta event\n", di_query_meta_event_name((DI_META_EVENT_T)i));
               goto error_exit;
            }
            else
               info_log("Wakeup %s, ", di_query_meta_event_name((DI_META_EVENT_T)i));
         }
         if (!di_enable_meta_event_ex(instance, (DI_META_EVENT_T)i, enable_meta_events, FALSE, FALSE))
         {
            error_log("error changing %s meta event\n", di_query_meta_event_name((DI_META_EVENT_T)i));
            goto error_exit;
         }
         else
            info_log("%s%s, ", ((host_intf_id == HIID_LOLLIPOP) || (host_intf_id == HIID_LOLLIPOP_EX)) ? "Non-Wakeup " : "", di_query_meta_event_name((DI_META_EVENT_T)i));
         if (!(i % 3))
            info_log("\n");
      }
      info_log("\n");
   }
   else
   {
      bool enable;
      bool int_enable;
      info_log("\nAlready enabled meta events:\n");
      for (i = DME_FLUSH_COMPLETE; i < DME_NUM_META_EVENTS; i++)
      {
         if ((host_intf_id == HIID_LOLLIPOP) || (host_intf_id == HIID_LOLLIPOP_EX))
         {
            if (di_query_meta_event_ex(instance, (DI_META_EVENT_T)i, &enable, &int_enable, TRUE))
            {
               if (enable)
               {
                  info_log("Wakeup %s: %s\n", di_query_meta_event_name((DI_META_EVENT_T)i), int_enable ? "INT_EN" : "no_int");
               }
            }
            else
            {
               error_log("error querying %s wakeup meta event\n", di_query_meta_event_name((DI_META_EVENT_T)i));
               goto error_exit;
            }
         }
         if (di_query_meta_event_ex(instance, (DI_META_EVENT_T)i, &enable, &int_enable, FALSE))
         {
            if (enable)
            {
               info_log("%s%s: %s\n", ((host_intf_id == HIID_LOLLIPOP) || (host_intf_id == HIID_LOLLIPOP_EX)) ? "Non-Wakeup " : "", di_query_meta_event_name((DI_META_EVENT_T)i), int_enable ? "INT_EN" : "no_int");
            }
         }
         else
         {
            error_log("error querying %s meta event\n", di_query_meta_event_name((DI_META_EVENT_T)i));
            goto error_exit;
         }
      }
      info_log("\n");
   }

   // find out what sensors are there
   if (!di_query_features(instance))
   {
      error_log("error detecting sensors\n");
      goto error_exit;
   }

   // display info about the sensor drivers
   info_log("\nInformation about detected sensors:\n");
   if (!display_driver_info(instance))
   {
      error_log("error displaying driver info\n");
      goto error_exit;
   }

   // set AP suspend mode
   if (!di_set_ap_suspended_mode(instance, ap_suspended))
   {
      error_log("error setting ap suspended\n");
      goto error_exit;
   }

#if 0
   // request test patterns if the command line requests it
   if (!di_set_host_test_mode(instance, test_mode == 1))
   {
      error_log("error setting test mode\n");
      goto error_exit;
   }
#endif

   // in host test mode, sample data is a test pattern
   if (test_mode  == 1)
      set_raw_data(TRUE);

   di_fifo_flush(instance, 0xF8); // reset stats

   // configure sensors
   if (!configure_sensors(instance, !force_reset && !simple_setup, max_latency))
   {
      error_log("error configuring sensors\n");
      goto error_exit;
   }
   restart_stats_time();

   if ((alg_id == AID_BSX) || (ram_version >= 8819))
   {
      memset(buf, 0, sizeof(buf));
      if (raw_data && !all_raw_data)
      {
         PHYS_SENSOR_STATUS phys_sensor_status;
         // find out which physical sensors are on, regardless of host request -- this lets us monitor raw data even if it is only a derived sensor that is on
         if (!di_save_parameter(instance, PP_SYSTEM, SYSP_PHYS_SENS_STATUS, (u8 *)&phys_sensor_status, sizeof(phys_sensor_status)))
         {
            error_log("error requesting physical sensor status\n");
            memset(&phys_sensor_status, 0, sizeof(phys_sensor_status));
         }
         // accel, wake gesture, and tilt detector all share BSX_A raw output
         if (sensors[DST_ACCELEROMETER].sample_rate ||
             sensors[DST_ACCELEROMETER].wake_sample_rate ||
             phys_sensor_status.AccelRate)
         {
            if (alg_id == AID_BSX)
               buf[0] = 1;
            else
               buf[0] |= 1;
         }
         else if (sensors[DST_WAKE_GESTURE].sample_rate || sensors[DST_WAKE_GESTURE].wake_sample_rate)
         {
            if (alg_id == AID_BSX)
               buf[3] = 1;
         }
         else if (sensors[DST_TILT_DETECTOR].sample_rate || sensors[DST_TILT_DETECTOR].wake_sample_rate)
         {
            if (alg_id == AID_BSX)
               buf[6] = 1;
         }

         // mag, glance gesture, and activity all share BSX_B raw output
         if (sensors[DST_GEOMAGNETIC_FIELD].sample_rate ||
             sensors[DST_GEOMAGNETIC_FIELD].wake_sample_rate ||
             phys_sensor_status.MagRate)
         {
            if (alg_id == AID_BSX)
               buf[1] = 1;
            else
               buf[0] |= 2;
         }
         else if (sensors[DST_GLANCE_GESTURE].sample_rate || sensors[DST_GLANCE_GESTURE].wake_sample_rate)
         {
            if (alg_id == AID_BSX)
               buf[4] = 1;
         }
         else if (sensors[DST_ACTIVITY].sample_rate || sensors[DST_ACTIVITY].wake_sample_rate)
         {
            if (alg_id == AID_BSX)
               buf[7] = 1;
         }

         // gyro and pickup gesture share BSX_C raw output
         if (sensors[DST_GYROSCOPE].sample_rate ||
             sensors[DST_GYROSCOPE].wake_sample_rate ||
             phys_sensor_status.GyroRate)
         {
            if (alg_id == AID_BSX)
               buf[2] = 1;
            else
               buf[0] |= 4;
         }
         else if (sensors[DST_PICKUP_GESTURE].sample_rate || sensors[DST_PICKUP_GESTURE].wake_sample_rate)
         {
            if (alg_id == AID_BSX)
               buf[5] = 1;
         }
      }
      else if (raw_data && all_raw_data) // force all base raw sensor logging on
      {
         if (alg_id == AID_BSX)
         {
            buf[0] = 1;
            buf[1] = 1;
            buf[2] = 1;
         }
         else
         {
            buf[0] |= 7;
         }
      }
      if (!di_load_parameter(instance, PP_ALGORITHM, RAW_INPUT_DATA, buf, 8))
         error_log("error requesting raw sensors\n");
      else
      {
         if (alg_id == AID_BSX)
            info_log("\nRaw sensors requested: Accel=%u Mag=%u Gyro=%u WakeGest=%u GlanceGest=%u PickupGest=%u Tilt=%u AR=%u\n",
                  buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7]);
         else
            info_log("\nRaw sensors requested: Accel=%u Mag=%u Gyro=%u\n",
                  (buf[0] & 1) != 0, (buf[0] & 2) != 0, (buf[0] & 4) != 0);
      }
   }

   /**************************************************************
   * start acquiring data                                        *
   ***************************************************************/
   // tell driver to call us when data arrives
   if (!di_register(instance, rt_data_callback, (void *)instance))
      error_log("error registering data callback\n");

   time_delay_ms(100);

   info_log("\n--------------------------------------------\nCONFIGURATION\n\n");

   // confirm all is well
   if (!di_query_status(instance, &executing, &sensing))
      error_log("error reading status\n");
   info_log("executing: %d, sensing: %d\n", executing, sensing);

   reset_stats();

   // update the scale factors now that it is running
   if (!di_query_features(instance))
   {
      error_log("error detecting sensors\n");
      goto error_exit;
   }

   if (!quiet_info)
   {
      display_status(instance);
      if (alg_id == AID_BSX)
      {
         if (!di_save_parameter(instance, PP_ALGORITHM, BAP_WORKING_MODE_EN, buf, 2))
            error_log("error requesting working mode en\n");
         else
            info_log("\nBSX working mode en: 0x%04X\n", buf[0] + 256 * buf[1]);

         if (!di_save_parameter(instance, PP_ALGORITHM, BAP_OPR_MODE, buf, 2))
            error_log("error requesting operating mode\n");
         else
            info_log("BSX update rate: %u\nBSX operating mode index: %u\n", buf[0], buf[1]);
      }
   }

   if (!simple_setup)
   {
      if ((host_intf_id == HIID_LOLLIPOP) || (host_intf_id == HIID_LOLLIPOP_EX))
      {
         info_log("\nEnable Host Interrupt and set Nonwakeup FIFO watermark to %u, Wakeup FIFO watermark to %u\n", watermark, wake_watermark);
         if (!di_configure_interrupts_ex(instance, interrupt_en, wake_interrupt_en, watermark, wake_watermark))
            error_log("error configuring interrupts\n");
      }
      else
      {
         info_log("\nEnable Host Interrupt and set FIFO watermark to %u\n", watermark);
         if (!di_configure_interrupts(instance, interrupt_en, watermark))
            error_log("error configuring interrupts\n");
      }
   }

   if (!quiet_info)
   {
      info_log("\nFIFO configuration:\n");
      if (di_save_parameter(instance, PP_SYSTEM, SYSP_FIFO_CONTROL, (u8 *)&fifo_control_param, sizeof(fifo_control_param)))
      {
         if ((host_intf_id == HIID_LOLLIPOP) || (host_intf_id == HIID_LOLLIPOP_EX))
         {
            info_log("        Wakeup FIFO size: %u\n", fifo_control_param.fifo_size);
            info_log("     Nonwakeup FIFO size: %u\n", fifo_control_param.nonwakeup_fifo_size);
            info_log("   Wakeup FIFO watermark: %u\n", fifo_control_param.watermark);
            info_log("Nonwakeup FIFO watermark: %u\n\n", fifo_control_param.nonwakeup_watermark);
         }
         else
         {
            info_log("FIFO size: %u\n", fifo_control_param.fifo_size);
            info_log("FIFO watermark: %u\n\n", fifo_control_param.watermark);
         }
      }

      if (di_poll_host_interrupt(instance, &host_interrupt))
         info_log("Host interrupt: %s\n", host_interrupt ? "ASSERTED" : "deasserted");
      else
         error_log("error polling host interrupt\n");
   }

   if ((test_mode == 1) && (host_intf_id == HIID_KITKAT))
   {
      info_log("Turning on host interface test mode\n");
      instance->host_intf_control.bits.NonWakeupFIFOIntDisable = TRUE;
      if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
         info_log("Error writing host test mode bit\n");
   }

   info_log("\n--------------------------------------------\nRUNNING...\n\n");
   start_time_seconds = time_ms() / 1000;
   output_timeout = 5000 + time_ms();
#ifdef WIN32
   info_log("Hit 's' to toggle AP Suspend mode; 'd' to toggle data dumping; 'I' to re-enable significant motion; 'f' to flush FIFO; 'D' to discard FIFO; ' ' (space) to query sensor status\n'Y' toggle raw dump; '+' double rates; '-' halve rates; sensor parameter letter to toggle enable; any other key to quit\n\n");
#endif

/**********************************************************************************************/
/*                                       MAIN LOOP                                            */
/**********************************************************************************************/
   while (1)
   {
#if defined(USE_TASK_LOOP)
      if (!di_task_loop(instance, &done))
      {
         //out_set(out_handle, TRUE); // provide trigger for fatal error
         display_error_info(instance);
         goto error_exit;
      }
#else
      if (!di_read_fifo(instance, &done, 1000, response_delay_ms))
      {
         //out_set(out_handle, TRUE); // provide trigger for fatal error
         display_error_info(instance);
         goto error_exit;
      }
#endif
#if 0
      if (instance->meta_events[DME_ERROR] || instance->meta_events[DME_SENSOR_ERROR] || instance->error.error_register)
      {
         info_log("\n\n--------------------------------------------\n\n");
         error_log("ABORTING RUN: received error meta event!\n\n");
         break;
      }
#endif
      //out_set(out_handle, done); // output a bit which should reflect when each host transfer is complete
      if (output_timeout < time_ms())
      {
         output_timeout = STATS_PERIOD_MS + time_ms();
         calc_periodic_stats(instance);
         restart_stats_time();
         if (!quiet_stats)
         {
            display_periodic_stats(instance, verbose);
            info_log("    total bytes transferred = %u\n", instance->total_bytes_transferred);
            info_log("       total host transfers = %u; bytes per = %u\n", instance->total_host_transfers,
                     instance->total_host_transfers ? instance->total_bytes_transferred / instance->total_host_transfers : 0);
            time(&now);
            ltime = localtime(&now);
            info_log("       current date and time: %s\n", asctime(ltime));
            if (!get_event_rate() && had_events)
            {
               info_log("NO OUTPUT!\n");
            }
            had_events = (get_event_rate() != 0);
            reset_stats();
         }
      }
      if (run_duration_seconds && ((time_ms() / 1000) >= (u32)(run_duration_seconds + start_time_seconds)))
      {
         info_log("completed specified run time; stopping\n");
         break;
      }

      if (sigmotion_test && !ap_suspended && got_sigmotion)
      {
         got_sigmotion = FALSE;
         di_pause_task_loop(instance);
         if (di_read_registers(instance, SR_INT_STATUS, SR_INT_STATUS, &instance->error.int_status.reg))
            info_log("Int Status = 0x%02X\n", instance->error.int_status.reg);
         reenable_sigmotion(instance);
         if (di_read_registers(instance, SR_INT_STATUS, SR_INT_STATUS, &instance->error.int_status.reg))
            info_log("Int Status = 0x%02X\n", instance->error.int_status.reg);
         ap_suspended = TRUE;
         if (!di_set_ap_suspended_mode(instance, ap_suspended))
            error_log("Unable to suspend\n");
         else
            info_log("Suspend\n");
         if (di_read_registers(instance, SR_INT_STATUS, SR_INT_STATUS, &instance->error.int_status.reg))
            info_log("Int Status = 0x%02X\n", instance->error.int_status.reg);
      }

#ifdef WIN32
      if (_kbhit())
      {
         char sel = getch();
         di_pause_task_loop(instance);
         if (sel == 's')
         {
            ap_suspended = !ap_suspended;
            // set AP suspend mode
            if (!di_set_ap_suspended_mode(instance, ap_suspended))
            {
               error_log("error setting ap suspended\n");
               goto error_exit;
            }
            else
            {
               info_log("set AP Suspend mode to %u\n", ap_suspended);
               if (ap_suspended && !sigmotion_test)
                  reenable_sigmotion(instance);
            }
         }
         else if (sel == 'd')
         {
            data_verbose = !data_verbose;
            info_log("set data_verbose to %u\n", data_verbose);
         }
         else if (sel == 'I')                                        // just enable sig motion
         {
            reenable_sigmotion(instance);
         }
         else if (sel == 'w')                                        // just enable wake gesture
         {
            sensor_config.sample_rate = sensors[DST_WAKE_GESTURE].sample_rate;
            sensor_config.max_report_latency = max_latency;
            sensor_config.change_sensitivity = 0;
            sensor_config.dynamic_range = 0;
            if (!di_configure_sensor(instance, DST_WAKE_GESTURE, &sensor_config))
               error_log("error enabling wake gesture\n");
            else
               info_log("re-enabled wake gesture\n");
         }
         else if (sel == 'f')
         {
            if (!di_fifo_flush(instance, flush_sensor))
            {
               error_log("error requesting fifo flush\n");
            }
            else
            {
               info_log("requested flush of all sensors\n");
            }
         }
         else if (sel == 'D')
         {
            if (!di_fifo_flush(instance, DST_DISCARD_ALL))
            {
               error_log("error requesting fifo discard\n");
            }
            else
            {
               info_log("requested fifo discard\n");
            }
         }
         else if (sel == ' ')                                        // space displays current power settings, etc.
         {
            di_fifo_flush(instance, 0xF9); // output trigger list stats
            // display actual sample rates implemented by the drivers
            //if (di_read_registers(instance, 0x4D, 0x4F, buf))
            //   info_log("AR_GP22: 0x%02X, AR_GP23: 0x%02X, AR_GP24: 0x%02X\n", buf[0], buf[1], buf[2]);
            display_status(instance);
            if (alg_id == AID_BSX)
            {
               if (!di_save_parameter(instance, PP_ALGORITHM, BAP_WORKING_MODE_EN, buf, 2))
                  error_log("error requesting working mode en\n");
               else
                  info_log("\nBSX working mode en: 0x%04X\n", buf[0] + 256 * buf[1]);

               if (!di_save_parameter(instance, PP_ALGORITHM, BAP_OPR_MODE, buf, 2))
                  error_log("error requesting operating mode\n");
               else
                  info_log("BSX update rate: %u\nBSX operating mode index: %u\n", buf[0], buf[1]);
               //dump_bmi160_odr(instance, unique_id);
            }
         }
         else if (sel == 'Y')
         {
            dump_raw_data = !dump_raw_data;
            di_control_logging(instance, FALSE, quiet_meta, quiet_timestamps, dump_raw_data);
         }
         else if ((sel == '+') || (sel == '='))                      // double all rates < 200 Hz (accept = since it is unshifted +)
         {
            u32 start;
            info_log("doubling sample rates for all sensors\n");
            start = time_ms();
            for (i = DST_FIRST; i <= di_max_sensor_id(instance); i++)
            {
               if (di_has_sensor(instance, i) && di_is_sensor_continuous(instance, i))
               {
                  if (sensors[i].sample_rate < 200)
                     sensors[i].sample_rate *= 2;
                  if (sensors[i].wake_sample_rate < 200)
                     sensors[i].wake_sample_rate *= 2;
               }
            }
            configure_sensors(instance, TRUE, max_latency);
            info_log("switching time %u ms\n", time_ms() - start);
            info_log("last timestamps before switch: w=%u, nw=%u\n", instance->cur_timestamp[1], instance->cur_timestamp[0]);
         }
         else if (sel == '-')                                        // halve all rates
         {
            u32 start;
            info_log("halving sample rates for all sensors\n");
            start = time_ms();
            for (i = DST_FIRST; i <= di_max_sensor_id(instance); i++)
            {
               if (di_has_sensor(instance, i) && di_is_sensor_continuous(instance, i))
               {
                  if (sensors[i].sample_rate > 1)                       // don't divide 1 in half, or we end up at 0
                     sensors[i].sample_rate /= 2;
                  if (sensors[i].wake_sample_rate > 1)
                     sensors[i].wake_sample_rate /= 2;
               }
            }
            configure_sensors(instance, TRUE, max_latency);
            info_log("switching time %u ms\n", time_ms() - start);
            info_log("last timestamps before switch: w=%u, nw=%u\n", instance->cur_timestamp[1], instance->cur_timestamp[0]);
         }
         else
         {
            bool found = FALSE;
            SENSOR_CONFIG config;

            for (i = DST_FIRST; i < NUM_OPTIONS; i++)
            {
               if (sensors[i].option && (sel == sensors[i].option[0]))
               {
                  if (!sensors[i].sample_rate)                       // user wants sensor on, but the rate is zero, so set it to something
                  {
                     sensors[i].sample_rate = new_output_rate;
                     sensors[i].enabled = TRUE;
                  }
                  else
                  {
                     sensors[i].enabled = !sensors[i].enabled;
                  }
                  info_log("request rate: %u\n", sensors[i].sample_rate);
                  info_log("Sensor ID,                 name, rate\n");
                  configure_sensor(instance, i, TRUE, max_latency);
                  di_query_sensor_config(instance, i, &config);
                  found = TRUE;
                  break;
               }
            }
            if (!found)
            {
               info_log("\nCancelled by user\n");
               break;
            }
         }
      }
#else
      // implement for other OS
#endif
   }
/**********************************************************************************************/
/*                                     END OF LOOP                                            */
/**********************************************************************************************/

   error_exit:
   if (instance)
   {
      if (instance->executing && instance->ram_version)
      {
         di_pause_task_loop(instance);
         info_log("--------------------------------------------\n");
         info_log("FINAL STATE\n\nRan for %u seconds\n\nFinal error register values:\n", time_ms() / 1000 - start_time_seconds);
         display_error_info(instance);
         if (di_poll_host_interrupt(instance, &host_interrupt))
            info_log("Host interrupt is %s\n", host_interrupt ? "ASSERTED" : "deasserted");
         else
            error_log("error polling host interrupt\n");

         if ((test_mode == 1) && (host_intf_id == HIID_KITKAT))
         {
            info_log("Turning off host interface test mode\n");
            instance->host_intf_control.bits.NonWakeupFIFOIntDisable = FALSE;
            if (!i2c_blocking_write(instance->i2c_handle, SR_HOST_INTF_CONTROL, &instance->host_intf_control.reg, 1))
               info_log("Error writing host test mode bit\n");
         }

         if (!quiet_info)
         {
            if (alg_id == AID_BSX)
            {
               if (!di_save_parameter(instance, PP_ALGORITHM, BAP_WORKING_MODE_EN, buf, 2))
                  error_log("error requesting working mode en\n");
               else
                  info_log("\nBSX working mode en: 0x%04X\n", buf[0] + 256 * buf[1]);

               if (!di_save_parameter(instance, PP_ALGORITHM, BAP_OPR_MODE, buf, 2))
                  error_log("error requesting operating mode\n");
               else
                  info_log("BSX update rate: %u\nBSX operating mode index: %u\n", buf[0], buf[1]);
            }

            info_log("\nFinal sensor statistics:\n");
            display_periodic_stats(instance, verbose);
            display_status(instance);
         }

         info_log("--------------------------------------------\n");
         info_log("CLEANING UP...\n\nTurning off sensors:\n");
         info_log("Sensor ID,                 name, rate\n");
         // configure each sensor
         sensor_config.sample_rate = 0;
         sensor_config.max_report_latency = 0;
         sensor_config.change_sensitivity = 0;
         sensor_config.dynamic_range = 0;
         for (i = DST_FIRST; i <= di_max_sensor_id(instance); i++)
         {
            if ((instance->hi_id == HIID_KITKAT) && (i > DST_TILT_DETECTOR))
               break;
            if (!di_has_sensor(instance, i))
               continue;
            if (instance->sensor_info[i].rate)
            {
               info_log("% 2u, %27s, ", i, di_query_sensor_name(instance, (DI_SENSOR_TYPE_T)i));
               if (!di_configure_sensor(instance, (DI_SENSOR_TYPE_T)i, &sensor_config))
                  error_log("error setting rate\n");
               else
                  info_log("% 4u\n", instance->sensor_info[i].rate);
            }
         }

         if (!quiet_info)
         {
            info_log("\nFlushing and Emptying FIFO:\n");
            di_fifo_flush(instance, 0xff);
            output_timeout = time_ms() + 2000;
            do
            {
               if (!di_task_loop(instance, NULL))
               {
                  display_error_info(instance);
                  break;
               }
#ifdef WIN32
               if (_kbhit())
                  break;
#endif
            }
            while (time_ms() < output_timeout);
         }
         di_pause_task_loop(instance);

         //display_status(instance);

         if (!di_abort_transfer(instance))
            error_log("error trying to abort the transfer\n");
         else
            info_log("transfer aborted\n");
         if (di_poll_host_interrupt(instance, &host_interrupt))
            info_log("Host interrupt is %s\n", host_interrupt ? "ASSERTED" : "deasserted");
         else
            error_log("error polling host interrupt\n");
      }

      info_log("\n--------------------------------------------\n");
      info_log("SUMMARY\n\nSensor events:\n");
      sensor_data_received = 0;
      info_log("Sensor ID,                  name, samples, slips, dups, gaps\n");
      for (i = 0; i <= di_max_sensor_id(instance); i++)
      {
         if ((instance->hi_id == HIID_KITKAT) && (i > DST_TILT_DETECTOR))
            break;
         // don't display if nothing happened with this sensor
         if (verbose || instance->sensor_info[i].samples_received
#if !defined(DI_SLIM)
            || instance->sensor_info[i].timestamp_slips || instance->sensor_info[i].timestamp_dups || instance->sensor_info[i].timestamp_gaps
#endif
         )
         {
#if !defined(DI_SLIM)
            info_log("% 3u, %27s, % 7u,  % 4u, % 4u, % 4u\n", i, di_query_sensor_name(instance, i), instance->sensor_info[i].samples_received,
                     instance->sensor_info[i].timestamp_slips, instance->sensor_info[i].timestamp_dups, instance->sensor_info[i].timestamp_gaps);
#else
            info_log("% 3u, %27s, % 7u\n", i, di_query_sensor_name(instance, i), instance->sensor_info[i].samples_received);
#endif
         }
         sensor_data_received += instance->sensor_info[i].samples_received;
      }
      if (alg_id == AID_BSX)
         i = DST_FIRST_EXTRA_SENSOR;
      else
         i = DST_TIMESTAMP_LSW;
      for (; i <= DST_LAST_EXTRA_SENSOR; i++)
      {
         // don't display if none
         if (verbose || instance->other_events[i - DST_FIRST_EXTRA_SENSOR])
            info_log("% 3u, %27s, %u\n", i, di_query_extra_event_name(i), instance->other_events[i - DST_FIRST_EXTRA_SENSOR]);
      }
      info_log("\nNon-Wakeup Meta events:\n");
      for (i = 0; i < DME_NUM_META_EVENTS; i++)
      {
         // don't display if none
         if (verbose || instance->meta_events[i])
            info_log("% 2u, %27s, %u\n", i, di_query_meta_event_name((DI_META_EVENT_T)i), instance->meta_events[i]);
      }
#if !defined(DI_SLIM)
      if ((host_intf_id == HIID_LOLLIPOP) || (host_intf_id == HIID_LOLLIPOP_EX))
      {
         info_log("\nWakeup Meta events:\n");
         for (i = 0; i < DME_NUM_META_EVENTS; i++)
         {
            // don't display if none
            if (verbose || instance->meta_events_wakeup[i])
               info_log("% 2u, %27s, %u\n", i, di_query_meta_event_name((DI_META_EVENT_T)i), instance->meta_events_wakeup[i]);
         }
      }
#endif

      info_log("\nHost interface FIFO data transfer statistics:\n");
      info_log("    total bytes transferred, %u\n", instance->total_bytes_transferred);
      info_log("       total host transfers, %u, bytes per, %u\n", instance->total_host_transfers,
               instance->total_host_transfers ? instance->total_bytes_transferred / instance->total_host_transfers : 0);
      info_log("     total samples received, %u\n", instance->total_samples_received);
      info_log("          non-sensor events, %u\n", instance->total_samples_received - sensor_data_received);
      info_log("      total invalid samples, %u\n", instance->total_invalid_samples_received);
      info_log("   total pad bytes received, %u\n", instance->total_pad_bytes_received);
      info_log("           total time slips, %u\n", instance->total_timeslips);
      info_log("            total time dups, %u, dup rate, %E\n", instance->total_timedups,
               instance->total_samples_received ? (float)instance->total_timedups / (float)instance->total_samples_received : 0.0);
      info_log("            total time gaps, %u, loss rate, %E\n", instance->total_timegaps,
               instance->total_samples_received ? (float)instance->total_timegaps / (float)instance->total_samples_received : 0.0);

      di_deregister(instance);
      if (power_down)
      {
         di_standby_request(instance);
         di_shutdown_request(instance);
         info_log("em718x has been shutdown\n");
      }
      di_deinit(instance);
   }
   // display test start date / time
   time(&now);
   ltime = localtime(&now);
   info_log("current date and time: %s\n", asctime(ltime));
   debug_set_log_file(NULL, FALSE);
   return 0;
}


