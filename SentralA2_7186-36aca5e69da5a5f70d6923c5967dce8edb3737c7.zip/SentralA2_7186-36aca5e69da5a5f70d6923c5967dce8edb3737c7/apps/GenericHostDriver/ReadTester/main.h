#ifndef _MAIN_H_
#define _MAIN_H_

#include "types.h"
#include "host_services.h"
#include "driver_ext.h"


// test application configuration flags
#define SENSORS_PRESENT_SIZE 32

// these defines affect non-firmware-test mode
#define LOAD_TO_RAM                       // upload file to RAM (else to EEPROM)
#define ACCEL_RATE_HZ      50            // 125
#define GYRO_RATE_HZ       50            // 200
#define MAG_RATE_HZ        50
#define QUATERNION_RATE_HZ 50            // 200

#define TRUE 1
#define FALSE 0

#endif

