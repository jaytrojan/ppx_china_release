/**
 * \file i2chid_services.c
 *
 *
 * \brief I2CHID host interface
 *
 * \copyright  (C) 2014 EM Microelectronic
 *
 */

#ifdef _MSC_VER
#include <windows.h>
#include <direct.h>
#define STAT_STRUCT _stat
#define THREADED
#else
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#define BOOL bool
#define STAT_STRUCT stat
#define _getcwd getcwd
#define GetLastError() errno
#endif
#include <sys/stat.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include "types.h"
#include "host_services.h"
#include "host_definitions.h"
#include <stdlib.h>
#include <hidapi.h>
#include "i2chid.h"


#define PLATFORM_I2C_MAX_READ_LEN      1500
#define PLATFORM_I2C_MAX_WRITE_LEN     56

static volatile I2CHID_FEATURE_REPORT feature_report;
static volatile I2CHID_OUTPUT_REPORT output_report;
static volatile I2CHID_INPUT_REPORT input_report;
static volatile u32 i2c_bytes_received = 0;
static volatile u16 i2c_last_offset_received = 0;
static volatile u32 i2c_input_reports_received = 0;
static volatile u32 i2c_input_report_errors = 0;
static volatile u32 i2c_input_reports_invalid = 0;
static volatile u32 i2c_feature_reports_sent = 0;
static volatile u32 i2c_feature_reports_received = 0;
static volatile u32 i2c_feature_report_errors = 0;
static volatile u32 i2c_output_reports_sent = 0;
static volatile u32 i2c_output_report_errors = 0;
static volatile u32 i2c_premature_end = 0;
static volatile u32 i2c_dropped_blocks = 0;
static volatile u32 i2c_backwards_blocks = 0;
static volatile u32 i2c_repeated_reports = 0;
static volatile u32 i2c_wrong_packets = 0;
static volatile u32 i2c_good_transactions = 0;
static volatile u32 i2c_failed_transactions = 0;
static volatile u32 i2c_lost_bytes = 0;
static volatile u32 i2c_interrupts = 0;
static volatile u8 packet_count = 1;
bool i2chid_open = FALSE;
static volatile bool i2c_status_pending = FALSE;
static volatile bool irq_pending = FALSE;
I2C_FULL_HANDLE_T last_i2c_handle = NULL;
bool i2c_initialized = FALSE;
bool irq_initialized = FALSE;
struct IRQ_HANDLE irq_handle = {0, 0};
extern PLATFORM_DRIVER_T ih_driver;

#define HID_READ_TIMEOUT 0

#if defined(THREADED)
HANDLE h_thread = NULL;
DWORD thread_id = 0;
DWORD WINAPI ih_worker_thread(LPVOID param);
#define NUM_HANDLES 3
typedef struct _thread_param_
{
   HANDLE h_mutex;
   hid_device *hid_handle;
   IRQ_FULL_HANDLE_T rhandle;
   I2C_FULL_HANDLE_T ihandle_array[NUM_HANDLES];
} THREAD_PARAM_T;
THREAD_PARAM_T thread_param;
bool ih_exit_requested = FALSE;
#define TAKE_MUTEX(x)  { \
   DWORD res; \
   if ((x) != NULL) \
   { \
      if ((res = WaitForSingleObject((x), INFINITE)) != WAIT_OBJECT_0) \
         info_log("Error waiting for mutex: %u, last error: %u!\n", res, GetLastError()); \
   } \
}
#define RELEASE_MUTEX(x) { \
   if ((x) != NULL) \
   { \
      if (!ReleaseMutex(x)) \
         info_log("Error releasing mutex: %u\n", GetLastError()); \
   } \
}
#else
#define TAKE_MUTEX(x)
#define RELEASE_MUTEX(x)
#endif

bool ih_process_input_report(IRQ_FULL_HANDLE_T rhandle, I2C_FULL_HANDLE_T ihandle, bool *irq_asserted);


#if defined(THREADED)
bool ih_thread_init(hid_device *hid_handle, IRQ_FULL_HANDLE_T rhandle, I2C_FULL_HANDLE_T ihandle)
{
   if (h_thread == NULL)
   {
      memset(&thread_param, 0, sizeof(thread_param));
      thread_param.ihandle_array[0] = ihandle;
      thread_param.rhandle = rhandle;
      thread_param.hid_handle = hid_handle;
      thread_param.h_mutex = CreateMutex(NULL, FALSE, "HidMutex");
      if (thread_param.h_mutex == NULL)
      {
         error_log("Unable to create mutex!\n");
         exit(-1);
      }
      h_thread = CreateThread(NULL, 0, ih_worker_thread, &thread_param, CREATE_SUSPENDED, &thread_id);
      if (h_thread == NULL)
      {
         error_log("Unable to create HID worker thread!\n");
         exit(-1);
      }
      return TRUE;
   }
   else
   {
      int i;
      // remember whatever data we are passed, if it is not NULL
      if (hid_handle != NULL)
      {
         if ((hid_handle != thread_param.hid_handle) && (thread_param.hid_handle != NULL))
         {
            error_log("We do not support more than one hid handle!\n");
            exit(-1);
         }
         thread_param.hid_handle = hid_handle;
      }
      if (rhandle != NULL)
      {
         if ((rhandle != thread_param.rhandle) && (thread_param.rhandle != NULL))
         {
            error_log("We do not support more than one IRQ!\n");
            exit(-1);
         }
         thread_param.rhandle = rhandle;
      }
      if (ihandle != NULL)
      {
         for (i = 0; i < NUM_HANDLES; i++)
         {
            if (ihandle == thread_param.ihandle_array[i])   // already in table
               break;
            if (thread_param.ihandle_array[i] == NULL)      // found empty slot
            {
               thread_param.ihandle_array[i] = ihandle;
               break;
            }
         }
      }
      return TRUE;
   }
}

DWORD WINAPI ih_worker_thread(LPVOID param)
{
   THREAD_PARAM_T *p_param = (THREAD_PARAM_T *)param;
   IRQ_FULL_HANDLE_T rhandle = p_param->rhandle;
   I2C_FULL_HANDLE_T *ihandle_array = p_param->ihandle_array; // pointer to array of I2C handles
   I2C_FULL_HANDLE_T ihandle;
   hid_device *hid_handle = p_param->hid_handle;
   HANDLE h_mutex = p_param->h_mutex;
   int res;
   bool asserted;
   int i;

   info_log("entering worker thread\n");
   for (;;)
   {
      if (ih_exit_requested)
         break;
      if (0)// !ih_read_enabled)
      {
         Sleep(1);
         continue;
      }
      memset(&input_report, 0, sizeof(input_report));
      TAKE_MUTEX(h_mutex);
      res = hid_read_timeout(hid_handle, (unsigned char *)&input_report, sizeof(input_report), HID_READ_TIMEOUT);
      RELEASE_MUTEX(h_mutex);
      if (res == -1)
      {
         info_log("Error reading input report\n");
         i2c_input_report_errors++;
         continue;
      }
      if (!res) // nothing read
      {
         time_delay_ms(1);
         continue;
      }
      i2c_input_reports_received++;
      // find which I2C slave this might be for
      ihandle = NULL;
      for (i = 0; i < NUM_HANDLES; i++)
      {
         if (ihandle_array[i] && (ihandle_array[i]->slave_7bit_slave_addr == input_report.slave_7bit_addr))
         {
            ihandle = ihandle_array[i];
            break;
         }
      }
      if (ih_process_input_report(rhandle, ihandle, &asserted))
      {
         i2c_status_pending = TRUE;
         //ih_read_enabled = FALSE; // turn off
      }
   }
   info_log("leaving worker thread\n");
   ih_exit_requested = FALSE;
   return TRUE;
}

void ih_thread_exit(void)
{
   if (h_thread != NULL)
   {
      ih_exit_requested = TRUE;
      while (ih_exit_requested)
         Sleep(1);

      if (thread_param.h_mutex)
      {
         CloseHandle(thread_param.h_mutex);
         thread_param.h_mutex = NULL;
      }
      h_thread = NULL;
      memset(&thread_param, 0, sizeof(thread_param));
   }
}

#endif


void ih_print_statistics(void)
{
   if (!i2chid_open)
      return;
   info_log("I2CHID Statistics\n");
   info_log("  input reports received, %u\n", i2c_input_reports_received);
   info_log("     input report errors, %u\n", i2c_input_report_errors);
   info_log("   input reports invalid, %u\n", i2c_input_reports_invalid);
   info_log("    feature reports sent, %u\n", i2c_feature_reports_sent);
   info_log("feature reports received, %u\n", i2c_feature_reports_received);
   info_log("    feature reports sent, %u\n", i2c_feature_report_errors);
   info_log("     output reports sent, %u\n", i2c_output_reports_sent);
   info_log("    output report errors, %u\n", i2c_output_report_errors);
   info_log("   premature end of read, %u\n", i2c_premature_end);
   info_log("          dropped blocks, %u\n", i2c_dropped_blocks);
   info_log("        backwards blocks, %u\n", i2c_backwards_blocks);
   info_log("        repeated reports, %u\n", i2c_repeated_reports);
   info_log("           wrong packets, %u\n", i2c_wrong_packets);
   info_log("              lost bytes, %u\n", i2c_lost_bytes);
   info_log("   good I2C transactions, %u\n", i2c_good_transactions);
   info_log(" failed I2C transactions, %u\n", i2c_failed_transactions);
   info_log("              interrupts, %u\n", i2c_interrupts);
}


/**
 * \brief set up the SAB I2C HID
 * \return bool
 */
hid_device *i2chid_init(bool verbose, char *unique_id)
{
   static hid_device *the_hid_handle = NULL;
   #define MAX_STR 255
   int res;
   wchar_t wstr[MAX_STR];
   wchar_t *puid = NULL;

   if (!i2chid_open)
   {
      // find the device and open it
      // Initialize the hidapi library
      res = hid_init();
      if (res)
      {
         info_log("error on hid_init()\n");
         return NULL;
      }

      // Open the device using the VID, PID,
      // and optionally the Serial number.
      if (unique_id)
      {
         memset(wstr, 0, sizeof(wstr));
         mbstowcs(wstr, unique_id, strlen(unique_id));
         puid = wstr;
      }
      the_hid_handle = hid_open(0x1fc9, 0xfa77, puid);
      if (the_hid_handle == NULL)
      {
         info_log("SABv2: not found\n");
         the_hid_handle = hid_open(0x1fc9, 0xfa76, puid);
         if (the_hid_handle == NULL)
         {
            info_log("SABv1: not found\n");
            hid_exit();
            return NULL;
         }
         else
            info_log("SABv1 connected\n");
      }
      else
         info_log("SABv2 connected\n");

      hid_set_nonblocking(the_hid_handle, 1);

      if (verbose)
      {
         // Read the Manufacturer String
         res = hid_get_manufacturer_string(the_hid_handle, wstr, MAX_STR);
         wprintf(L"Manufacturer String, %s\n", wstr);

         // Read the Product String
         res = hid_get_product_string(the_hid_handle, wstr, MAX_STR);
         wprintf(L"Product String, %s\n", wstr);

         // Read the Serial Number String
         res = hid_get_serial_number_string(the_hid_handle, wstr, MAX_STR);
         wprintf(L"Serial Number String, %s\n", wstr);
      }
      i2chid_open = TRUE;
   }
   return the_hid_handle;
}


bool send_feature_report(hid_device *the_hid_handle, u16 i2c_rate_khz, u16 timeout_ms, bool pullup_enable)
{
   int res;

   // read feature report
   memset(&feature_report, 0, sizeof(feature_report));
   TAKE_MUTEX(thread_param.h_mutex);
   res = hid_get_feature_report(the_hid_handle, (unsigned char *)&feature_report, sizeof(feature_report));
   RELEASE_MUTEX(thread_param.h_mutex);
   if (res == -1)
   {
      info_log("Error reading feature report\n");
      return FALSE;
   }
   if (feature_report.i2chid_report_rev != I2CHID_REPORT_REV)
   {
      info_log("Wrong report revision byte; is this the correct firmware?\n");
      return FALSE;
   }
   info_log("\nFeature Report\nReport Rev: %u, i2c_rate_khz: %u, timeout_ms: %u, pullup_enable: %u, gpio_trigger: 0x%02X, gpio_state: %u\n",
          feature_report.i2chid_report_rev, feature_report.i2c_rate_khz, feature_report.timeout_ms, feature_report.pullup_enable, feature_report.gpio_trigger, feature_report.gpio_state);

   feature_report.i2c_rate_khz = i2c_rate_khz;
   feature_report.timeout_ms = timeout_ms;
   feature_report.pullup_enable = pullup_enable;
   TAKE_MUTEX(thread_param.h_mutex);
   i2c_feature_reports_sent++;
   res = hid_send_feature_report(the_hid_handle, (unsigned char *)&feature_report, sizeof(feature_report));
   RELEASE_MUTEX(thread_param.h_mutex);
   if (res == -1)
   {
      info_log("Error writing feature report\n");
      i2c_feature_report_errors++;
      return FALSE;
   }
   time_delay_ms(100);
   TAKE_MUTEX(thread_param.h_mutex);
   res = hid_get_feature_report(the_hid_handle, (unsigned char *)&feature_report, sizeof(feature_report));
   RELEASE_MUTEX(thread_param.h_mutex);
   if (res == -1)
   {
      info_log("Error reading feature report\n");
      i2c_feature_report_errors++;
      return FALSE;
   }
   i2c_feature_reports_received++;
   if ((feature_report.i2c_rate_khz != i2c_rate_khz) ||
       (feature_report.timeout_ms != timeout_ms) ||
       (feature_report.pullup_enable != pullup_enable))
      info_log("Warning: feature report changes did not take hold\n");
   return TRUE;
}


bool ih_i2c_init(I2C_HANDLE_T handle, char *unique_id)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   hid_device *the_hid_handle = NULL;
   last_i2c_handle = fhandle;

   // set bit rate, pullups, timeout
   if (!i2c_initialized)
   {
      the_hid_handle = i2chid_init(TRUE, unique_id);
      if (!the_hid_handle)
         return FALSE;

      // no need to deal with mutex here -- no worker thread running
      if (!send_feature_report(the_hid_handle, DEFAULT_I2CHID_BITRATE_KHZ, DEFAULT_TIMEOUT_MS, TRUE))
         return FALSE;

      fhandle->i2c_rate_khz = feature_report.i2c_rate_khz;
      fhandle->unique_id = unique_id;
      if (!fhandle->driver)
         fhandle->driver = &ih_driver;
      fhandle->driver->platform_data = (void *)the_hid_handle;
      irq_handle.driver = fhandle->driver;  // kludge... help out the irq subsystem
      i2c_initialized = TRUE;
   }
   else
   {
      the_hid_handle = i2chid_init(FALSE, fhandle->unique_id);
      if (!fhandle->driver)
         fhandle->driver = &ih_driver;
      fhandle->driver->platform_data = (void *)the_hid_handle;
   }
#if defined(THREADED)
   if (!ih_thread_init(the_hid_handle, NULL, last_i2c_handle))
   {
      info_log("Worker thread could not be created\n");
   }
#endif
   return TRUE;
}


bool ih_i2c_deinit(I2C_HANDLE_T handle)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   hid_device *hid_handle;

#if defined(THREADED)
   ih_thread_exit();
#endif

   if (fhandle && fhandle->driver)
   {
      hid_handle = (hid_device *)fhandle->driver->platform_data;

      if (hid_handle)
      {
         hid_close(hid_handle);
         hid_handle = NULL;
      }
      hid_exit();
      fhandle->driver->platform_data = NULL;
   }
   info_log("ih_i2c_deinit()\n");
   ih_print_statistics();
   i2c_initialized = FALSE;
   i2chid_open = FALSE;
   return TRUE;
}


bool ih_i2c_set_rate(I2C_HANDLE_T handle, u16 rate_khz)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   hid_device *hid_handle = (hid_device *)fhandle->driver->platform_data;
   bool res;

   if (!i2c_initialized)
      return FALSE;

   TAKE_MUTEX(thread_param.h_mutex);
   res = send_feature_report(hid_handle, rate_khz, DEFAULT_TIMEOUT_MS, TRUE);
   RELEASE_MUTEX(thread_param.h_mutex);
   return res;
}

bool ih_i2c_get_rate(I2C_HANDLE_T handle, u16 *rate_khz)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;

   if (!i2c_initialized || !rate_khz)
      return FALSE;
   *rate_khz = fhandle->i2c_rate_khz;
   return TRUE;
}

bool ih_i2c_read_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   int res;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   hid_device *hid_handle = (hid_device *)fhandle->driver->platform_data;
   u32 start_time;
   u32 take_mutex_time;
   u32 write_time;
   u32 write_wait_time;
   u32 rel_mutex_time;

   last_i2c_handle = fhandle;

   memset(&output_report, 0, sizeof(output_report));
   output_report.i2c_report_rev = I2CHID_REPORT_REV;
   output_report.slave_7bit_addr = (HID_UCHAR)fhandle->slave_7bit_slave_addr;
   output_report.bytes_to_read = len;
   output_report.bytes_to_write = 1;
   fhandle->reg_added = TRUE;
   fhandle->read_buffer = buffer;
   fhandle->read_len = len;
   fhandle->len_transferred = 0;
   memset(buffer, 0xff, len);
   fhandle->status = TS_I2C_IN_PROGRESS;
   output_report.packet_count = ++packet_count;
   output_report.write_data[0] = reg_addr;
   i2c_bytes_received = 0;
   i2c_last_offset_received = 0xffff;
   i2c_status_pending = FALSE;

   insane_log("i2c_read_start(reg = 0x%02x, len = %u)\n", reg_addr, len);
   start_time = time_us();
   TAKE_MUTEX(thread_param.h_mutex);
   take_mutex_time = time_us() - start_time;
   start_time = time_us();
   i2c_output_reports_sent++;
#if 0
   res = hid_write_start(hid_handle, (unsigned char *)&output_report, sizeof(output_report));
   write_time = time_us() - start_time;
   start_time = time_us();
   res = hid_write_end(hid_handle);
   write_wait_time = time_us() - start_time;
#else
   res = hid_write(hid_handle, (unsigned char *)&output_report, sizeof(output_report));
   write_time = time_us() - start_time;
   write_wait_time = 0;
#endif
   start_time = time_us();
   RELEASE_MUTEX(thread_param.h_mutex);
   rel_mutex_time = time_us() - start_time;
   insane_log("i2c_read_start: take_mutex: %u us\n", take_mutex_time);
   insane_log("i2c_read_start: hid_write_start: %u us\n", write_time);
   insane_log("i2c_read_start: hid_write_end: %u us\n", write_wait_time);
   insane_log("i2c_read_start: release_mutex: %u us\n", rel_mutex_time);
   if (res != sizeof(output_report))
   {
      info_log("Error writing output report: %d; expected %u\n", res, sizeof(output_report));
      i2c_output_report_errors++;
      return FALSE;
   }

   return TRUE;
}


bool ih_i2c_write_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   int res;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   hid_device *hid_handle = (hid_device *)fhandle->driver->platform_data;
   u32 start_time;
   u32 take_mutex_time;
   u32 write_time;
   u32 write_wait_time;
   u32 rel_mutex_time;

   last_i2c_handle = fhandle;

   if (len > sizeof(output_report.write_data))
   {
      info_log("write length exceeded!  given: %u, max is: %u\n", len, sizeof(output_report.write_data));
      return FALSE;
   }

   memset(&output_report, 0, sizeof(output_report));
   output_report.i2c_report_rev = I2CHID_REPORT_REV;
   output_report.slave_7bit_addr = (HID_UCHAR)fhandle->slave_7bit_slave_addr;
   output_report.bytes_to_read = 0;
   output_report.bytes_to_write = len + 1;
   fhandle->reg_added = TRUE;
   fhandle->read_buffer = NULL;
   fhandle->read_len = 0;
   fhandle->len_transferred = 0;
   fhandle->status = TS_I2C_IN_PROGRESS;
   output_report.packet_count = ++packet_count;
   output_report.write_data[0] = reg_addr;
   memcpy(&output_report.write_data[1], buffer, len);
   i2c_status_pending = FALSE;

   insane_log("i2c_write_start(reg = 0x%02x, len = %u)\n", reg_addr, len);

   start_time = time_us();
   TAKE_MUTEX(thread_param.h_mutex);
   take_mutex_time = time_us() - start_time;
   start_time = time_us();
   i2c_output_reports_sent++;
#if 0
   res = hid_write_start(hid_handle, (unsigned char *)&output_report, sizeof(output_report));
   write_time = time_us() - start_time;
   start_time = time_us();
   res = hid_write_end(hid_handle);
   write_wait_time = time_us() - start_time;
#else
   res = hid_write(hid_handle, (unsigned char *)&output_report, sizeof(output_report));
   write_time = time_us() - start_time;
   write_wait_time = 0;
#endif
   start_time = time_us();
   RELEASE_MUTEX(thread_param.h_mutex);
   rel_mutex_time = time_us() - start_time;
   insane_log("i2c_write_start: take_mutex: %u us\n", take_mutex_time);
   insane_log("i2c_write_start: hid_write_start: %u us\n", write_time);
   insane_log("i2c_write_start: hid_write_end: %u us\n", write_wait_time);
   insane_log("i2c_write_start: release_mutex: %u us\n", rel_mutex_time);
   if (res != sizeof(output_report))
   {
      info_log("Error writing output report: %d; expected %u\n", res, sizeof(output_report));
      i2c_output_report_errors++;
      return FALSE;
   }

   return TRUE;
}


bool ih_i2c_write_read_start(I2C_HANDLE_T handle, u8 *wbuffer, u16 wlen, u8 *rbuffer, u16 rlen)
{
   int res;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   hid_device *hid_handle = (hid_device *)fhandle->driver->platform_data;
   u32 start_time;
   u32 take_mutex_time;
   u32 write_time;
   u32 write_wait_time;
   u32 rel_mutex_time;

   last_i2c_handle = fhandle;

   if (wlen > sizeof(output_report.write_data))
   {
      info_log("write length exceeded!  given: %u, max is: %u\n", wlen, sizeof(output_report.write_data));
      return FALSE;
   }

   memset(&output_report, 0, sizeof(output_report));
   output_report.i2c_report_rev = I2CHID_REPORT_REV;
   output_report.slave_7bit_addr = (HID_UCHAR)fhandle->slave_7bit_slave_addr;
   output_report.bytes_to_read = (HID_UCHAR)rlen;
   output_report.bytes_to_write = (HID_UCHAR)wlen;
   fhandle->reg_added = FALSE;
   fhandle->read_buffer = rbuffer;
   fhandle->read_len = rlen;
   fhandle->len_transferred = 0;
   memset(rbuffer, 0xff, rlen);
   fhandle->status = TS_I2C_IN_PROGRESS;
   output_report.packet_count = ++packet_count;
   memcpy(output_report.write_data, wbuffer, wlen);
   i2c_bytes_received = 0;
   i2c_last_offset_received = 0xffff;
   i2c_status_pending = FALSE;

   insane_log("i2c_write_read_start(wlen = %u, wbuf[0] = 0x%02x, rlen = %u)\n", wlen, wbuffer[0], rlen);

   start_time = time_us();
   TAKE_MUTEX(thread_param.h_mutex);
   take_mutex_time = time_us() - start_time;
   start_time = time_us();
   i2c_output_reports_sent++;
#if 0
   res = hid_write_start(hid_handle, (unsigned char *)&output_report, sizeof(output_report));
   write_time = time_us() - start_time;
   start_time = time_us();
   res = hid_write_end(hid_handle);
   write_wait_time = time_us() - start_time;
#else
   res = hid_write(hid_handle, (unsigned char *)&output_report, sizeof(output_report));
   write_time = time_us() - start_time;
   write_wait_time = 0;
#endif
   start_time = time_us();
   RELEASE_MUTEX(thread_param.h_mutex);
   rel_mutex_time = time_us() - start_time;
   insane_log("i2c_write_read_start: take_mutex: %u us\n", take_mutex_time);
   insane_log("i2c_write_read_start: hid_write_start: %u us\n", write_time);
   insane_log("i2c_write_read_start: hid_write_end: %u us\n", write_wait_time);
   insane_log("i2c_write_read_start: release_mutex: %u us\n", rel_mutex_time);
   if (res != sizeof(output_report))
   {
      info_log("Error writing output report: %d; expected %u\n", res, sizeof(output_report));
      i2c_output_report_errors++;
      return FALSE;
   }

   return TRUE;
}


bool ih_i2c_check_status(I2C_HANDLE_T handle, TransferStatus *complete, u16 *len_transferred)
{
   TransferStatus stat;
#if !defined(THREADED)
   int res;
   bool asserted;
#endif
   I2C_FULL_HANDLE_T ihandle = (I2C_FULL_HANDLE_T)handle;
   hid_device *hid_handle = (hid_device *)ihandle->driver->platform_data;
   IRQ_FULL_HANDLE_T rhandle = (IRQ_FULL_HANDLE_T)&irq_handle;
   last_i2c_handle = ihandle;

   if (i2c_status_pending) // we received the end of a transfer when polling the interrupt, so just use that
   {
      i2c_status_pending = FALSE;
      if (ihandle->status != TS_I2C_IN_PROGRESS)
      {
         if ((input_report.packet_count < output_report.packet_count) && (input_report.slave_7bit_addr != 0))
         {
            info_log("warning: premature end of i2c transfer; input pc: %u, output pc: %u\n", input_report.packet_count, output_report.packet_count);
            i2c_premature_end++;
         }
         if (len_transferred)
            *len_transferred = ihandle->len_transferred;
         *complete = ihandle->status;
         return TRUE;
      }
   }

   stat = ihandle->status;
   if (complete && (stat != TS_I2C_COMPLETE))
      *complete = stat;

#if defined(THREADED)
#else
   memset(&input_report, 0, sizeof(input_report));
   res = hid_read_timeout(hid_handle, (unsigned char *)&input_report, sizeof(input_report), 100);
   if (res == -1)
   {
      info_log("Error reading input report\n");
      return FALSE;
   }
   if (!res) // nothing read
   {
      //info_log("Timeout reading input report\n");
      return FALSE;
   }
   i2c_input_reports_received++;
   if (ih_process_input_report(rhandle, ihandle, &asserted))
   {
      i2c_status_pending = FALSE;   // we are reporting it here; no need to remember it
      if (complete)
         *complete = ihandle->status;
      if (len_transferred)
         *len_transferred = ihandle->len_transferred;
      if (ihandle->status == TS_I2C_IN_PROGRESS)
         insane_log("bad status return\n");
      return TRUE;
   }
#endif
   return FALSE;
}


IRQ_HANDLE_T ih_irq_setup(u8 bit, char *unique_id)
{
   // set up GPIO trigger in feature report
   int res;
   GPIO_TRIGGER trigger;
   u8 val;
   hid_device *hid_handle;

   if (!irq_initialized)
   {
      if (bit > 7)
         return NULL;
      irq_handle.bit = bit;
      irq_handle.mask = 1 << bit;

      hid_handle = i2chid_init(TRUE, unique_id);
      if (!hid_handle)
         return NULL;

      // no need to deal with mutex here -- no worker thread running
      res = hid_get_feature_report(hid_handle, (unsigned char *)&feature_report, sizeof(feature_report));
      if (res == -1)
      {
         info_log("Error reading feature report\n");
         i2c_feature_report_errors++;
         return NULL;
      }
      i2c_feature_reports_received++;

      trigger.enable_int = TRUE;
      trigger.gpio_pin = bit;
      trigger.rising_edge = TRUE;
      trigger.falling_edge = FALSE;
      trigger.unused = FALSE;
      feature_report.gpio_trigger = val = *((u8 *)&trigger);
      i2c_feature_reports_sent++;
      res = hid_send_feature_report(hid_handle, (unsigned char *)&feature_report, sizeof(feature_report));
      if (res == -1)
      {
         info_log("Error writing feature report\n");
         i2c_feature_report_errors++;
         return NULL;
      }
      time_delay_ms(100);
      res = hid_get_feature_report(hid_handle, (unsigned char *)&feature_report, sizeof(feature_report));
      if (res == -1)
      {
         info_log("Error reading feature report\n");
         i2c_feature_report_errors++;
         return NULL;
      }
      i2c_feature_reports_received++;
      if (feature_report.gpio_trigger != val)
         info_log("Warning: feature report changes did not take hold\n");

      if (!irq_handle.driver)
         irq_handle.driver = &ih_driver;
      irq_handle.driver->platform_data = (void *)hid_handle;

#if defined(THREADED)
      irq_initialized = TRUE;
      if (!ih_thread_init(hid_handle, &irq_handle, NULL))
      {
         info_log("Worker thread could not be created\n");
      }
      else
      {
         if (i2c_initialized)
         {
            ResumeThread(h_thread);
         }
      }
#endif
   }
   return (IRQ_HANDLE_T)&irq_handle;
}


void ih_irq_acknowledge(IRQ_HANDLE_T handle)
{
   // nothing to do
}


bool ih_process_input_report(IRQ_FULL_HANDLE_T rhandle, I2C_FULL_HANDLE_T ihandle, bool *irq_asserted)
{
   if ((input_report.i2chid_report_rev & 0x7f) != I2CHID_REPORT_REV)
   {
      info_log("i2c_check_status: invalid input report rev 0x%02X\n", input_report.i2chid_report_rev);
      i2c_input_reports_invalid++;
      return FALSE;
   }

   if ((input_report.i2chid_report_rev & 0x80) != 0) // interrupt!
   {
      if (!irq_pending)             // only call the callback and report it asserted once, until someone calls irq_check which will allow another through
      {
         insane_log("got irq\n");
         i2c_interrupts++;
         *irq_asserted = TRUE;
         if (rhandle->callback)
            rhandle->callback((IRQ_HANDLE_T)rhandle, TRUE, rhandle->user_param);
         else
            irq_pending = TRUE;
      }
   }
   else
      *irq_asserted = FALSE;

   if (input_report.slave_7bit_addr) // must have also completed an I2C transfer as well
   {
      if (input_report.packet_count == output_report.packet_count)
      {
         // now copy the returned read data, if any
         if (input_report.actual_read_count && ihandle->read_buffer)
         {
            if (input_report.actual_read_count > output_report.bytes_to_read) // overflow check
               input_report.actual_read_count = output_report.bytes_to_read;
            if (input_report.actual_read_count > ihandle->read_len)
               input_report.actual_read_count = ihandle->read_len;

            if (i2c_last_offset_received != input_report.read_offset)
            {
               if (input_report.read_offset > i2c_bytes_received)
               {
                  info_log("IR: dropped block ofs:%u, exp:%u\n", input_report.read_offset, i2c_bytes_received);
                  i2c_dropped_blocks++;
               }
               else if (input_report.read_offset < i2c_bytes_received)
               {
                  info_log("IR: backwards block ofs:%u, exp:%u\n", input_report.read_offset, i2c_bytes_received);
                  i2c_backwards_blocks++;
               }
               i2c_last_offset_received = input_report.read_offset;
               i2c_bytes_received += input_report.cur_read_byte_count;
               memcpy(&ihandle->read_buffer[input_report.read_offset], input_report.read_data, input_report.cur_read_byte_count);
            }
            else
            {
               insane_log("IR: repeated report pc:%u, ofs:%u\n", input_report.packet_count, input_report.read_offset);
               i2c_repeated_reports++;
               return FALSE;
            }

            if ((input_report.read_offset + input_report.cur_read_byte_count) < input_report.actual_read_count)
            {
               insane_log("IR: partial ofs:%u, cur:%u, act:%u\n", input_report.read_offset, input_report.cur_read_byte_count, input_report.actual_read_count);
               return FALSE;
            }
            else
            {
               insane_log("IR: done ofs:%u, cur:%u, act:%u\n", input_report.read_offset, input_report.cur_read_byte_count, input_report.actual_read_count);
               if (i2c_bytes_received != input_report.actual_read_count)
               {
                  info_log("IR: lost %u bytes of %u\n", input_report.actual_read_count - i2c_bytes_received, input_report.actual_read_count);
                  i2c_lost_bytes += input_report.actual_read_count - i2c_bytes_received;
               }
            }
         }

         // the transfer is complete -- now a call to ih_i2c_check_status() will indicate it is done
         ihandle->status = (TransferStatus)input_report.i2c_status;
         if (input_report.i2c_status == TS_I2C_COMPLETE)
         {
            insane_log("i2c done\n");
            i2c_good_transactions++;
         }
         else if (input_report.i2c_status == TS_I2C_ERROR)
         {
            insane_log("i2c error\n");
            i2c_failed_transactions++;
         }
         if (output_report.bytes_to_read) // calculate len_transferred for I2C reads
         {
            if (output_report.bytes_to_write == input_report.actual_write_count) // completed transaction
               ihandle->len_transferred = input_report.actual_read_count;  // so return read count
            else if (input_report.actual_write_count) // failed transaction, but tried to write first
            {
               ihandle->len_transferred = input_report.actual_write_count; // this is how much got written
               if (ihandle->reg_added)
                  ihandle->len_transferred--;
            }
            else
               ihandle->len_transferred = 0; // nothing transferred
         }
         else  // calculate len_transferred for I2C writes
         {
            if (input_report.actual_write_count)
            {
               ihandle->len_transferred = input_report.actual_write_count;
               if (ihandle->reg_added)
                  ihandle->len_transferred--;
            }
            else
               ihandle->len_transferred = 0;
         }

         if (ihandle->callback)
            ihandle->callback((I2C_HANDLE_T)ihandle, ihandle->status, ihandle->len_transferred, ihandle->user_param);
         return TRUE;
      }
      else
      {
         //info_log("input report packet number %u != output report packet number %u\n", input_report.packet_count, output_report.packet_count);
         i2c_wrong_packets++;
      }
   }
   return FALSE;
}

bool ih_irq_check(IRQ_HANDLE_T handle)
{
#if !defined(THREADED)
   int res;
#endif

   // handle hid reports; extract interrupt bit from report_rev byte's MSB
   IRQ_FULL_HANDLE_T rhandle = (IRQ_FULL_HANDLE_T)handle;
   hid_device *hid_handle = (hid_device *)rhandle->driver->platform_data;
   bool asserted = FALSE;

   if (irq_pending) // we found out about the interrupt when checking for i2c transfer complete, so just use that
   {
      if (rhandle->callback)
      {
         rhandle->callback(handle, asserted, rhandle->user_param);
      }

      irq_pending = FALSE;
      return TRUE;
   }

#if defined(THREADED)
#else
   memset(&input_report, 0, sizeof(input_report));
   res = hid_read_timeout(hid_handle, (unsigned char *)&input_report, sizeof(input_report), 100);
   if (res == -1)
   {
      info_log("Error reading input report\n");
      i2c_input_report_errors++;
      return FALSE;
   }
   if (!res) // nothing read
   {
      //info_log("Timeout reading input report\n");
      return FALSE;
   }
   i2c_input_reports_received++;

   // potential race condition when using this with multiple i2c slaves at the same time
   if (ih_process_input_report(rhandle, last_i2c_handle, &asserted))
   {
      i2c_status_pending = TRUE;
   }
   if (asserted)
   {
      irq_pending = FALSE; // we are reporting it here, so no need to consider it pending
   }
#endif
   return asserted;
}


bool ih_irq_is_reliable(IRQ_HANDLE_T handle)
{
   return TRUE;
}



PLATFORM_DRIVER_T ih_driver =
{
   NULL,
   PLATFORM_I2C_MAX_READ_LEN,
   PLATFORM_I2C_MAX_WRITE_LEN,
   ih_i2c_init,
   ih_i2c_deinit,
   ih_i2c_set_rate,
   ih_i2c_get_rate,
   ih_i2c_read_start,
   ih_i2c_write_start,
   ih_i2c_write_read_start,
   ih_i2c_check_status,
   ih_irq_setup,
   ih_irq_acknowledge,
   ih_irq_check,
   ih_irq_is_reliable,
   NULL,
   NULL
};

