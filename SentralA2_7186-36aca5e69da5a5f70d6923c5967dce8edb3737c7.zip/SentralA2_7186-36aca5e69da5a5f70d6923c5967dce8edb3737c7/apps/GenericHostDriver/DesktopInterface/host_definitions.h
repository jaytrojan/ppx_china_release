/**
 * \file    host-definitions.h
 *
 *
 * \brief   host-specific definitions
 *
 * \copyright (C) 2013 EM Microelectronic
 *
 */

#include "types.h"
#include "config.h"

#ifndef _HOST_DEFINITIONS_H_
#define _HOST_DEFINITIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

//#define PROMIRA_NOT_AARDVARK 1

#if defined(PROMIRA_NOT_AARDVARK)
#define DEFAULT_BITRATE_KHZ 1000
#else
#define DEFAULT_BITRATE_KHZ 533 // 727
#endif
#define DEFAULT_I2CHID_BITRATE_KHZ 1000

#define DEFAULT_TIMEOUT_MS 1000

typedef struct I2C_HANDLE *I2C_FULL_HANDLE_T;                     /**< typedef to use instead of I2C_HANDLE_T to give full access to structure members */
typedef struct IRQ_HANDLE *IRQ_FULL_HANDLE_T;                     /**< typedef to use instead of IRQ_HANDLE_T to gain full access to structure members */
typedef struct OUT_HANDLE *OUT_HANDLE_T;                          /**< typedef to use instead of OUT_HANDLE_T to gain full access to structure members */

typedef struct PLATFORM_DRIVER
{
   void *platform_data;
   u16 max_read_len;
   u16 max_write_len;
   bool (*i2c_init)(I2C_HANDLE_T handle, char *unique_id);
   bool (*i2c_deinit)(I2C_HANDLE_T handle);
   bool (*i2c_set_transfer_rate)(I2C_HANDLE_T handle, u16 rate_khz);
   bool (*i2c_get_transfer_rate)(I2C_HANDLE_T handle, u16 *rate_khz);
   bool (*i2c_read_start)(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len);
   bool (*i2c_write_start)(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len);
   bool (*i2c_write_read_start)(I2C_HANDLE_T handle, u8 *wbuffer, u16 wlen, u8 *rbuffer, u16 rlen);
   bool (*i2c_check_status)(I2C_HANDLE_T handle, TransferStatus *complete, u16 *len_transferred);
   IRQ_HANDLE_T (*irq_setup)(u8 bit, char *unique_id);
   void (*irq_acknowledge)(IRQ_HANDLE_T handle);
   bool (*irq_check)(IRQ_HANDLE_T handle);
   bool (*irq_is_reliable)(IRQ_HANDLE_T handle);
   OUT_HANDLE_T (*output_init)(u8 bit, char *unique_id);
   void (*output_set)(OUT_HANDLE_T handle, bool value);
} PLATFORM_DRIVER_T;


/**
 * \brief I2C_HANDLE structure needs to be defined by the host
 *        OS; for some, it could be just the 7 bit slave
 *        address; for others, it could be a combination of I2C
 *        bus number and slave address, or low level driver file
 *        handle plus slave address, or some other combination
 */
   struct I2C_HANDLE
   {
      PLATFORM_DRIVER_T *driver;
      char *unique_id;                                               // some adapters need a string
      bool allocated;
      bool reg_added;                                                // true if we added 1 byte for the register address to the write count
      u8 slave_7bit_slave_addr;
      u16 i2c_rate_khz;
      I2C_CALLBACK callback;                                         // I2C_CALLBACK
      void *user_param;
      u8 *read_buffer;                                               // where to place read-back data if asynchronous
      u16 read_len;
      TransferStatus status;                                         // TransferStatus
      u16 len_transferred;
   };


/**
 * \brief get a handle to the specified slave device
 * \param slave_7bit_addr -- the slave address
 * \param port -- underlying device port number
 * \return NULL if no empty slots left
 */
   extern I2C_HANDLE_T i2c_setup(u8 slave_7bit_addr, char *unique_id);

/**
 * \brief stop using a handle to the specified slave device
 * \param slave_7bit_addr -- the slave address
 */
   extern void i2c_teardown(u8 slave_7bit_addr);
   extern void i2c_teardown_handle( I2C_HANDLE_T handle );

/**
 * \brief IRQ_HANDLE structure needs to be defined by the host
 * OS; for some, it could be just the GPIO pin number that
 * generated the interrupt; for others, an OS reference to an
 * interrupt object
 */
   struct IRQ_HANDLE
   {
      PLATFORM_DRIVER_T *driver;
      u8 bit;
      u8 mask;
      u8 prev_gpios;
      IRQ_CALLBACK callback;
      void *user_param;
   };


/**
 * \brief install the interrupt handler
 * \param bit
 * \param unique_id -- underlying device string
 * \return handle
 */
   extern IRQ_HANDLE_T irq_setup(u8 bit, char *unique_id);


   /**
 * \brief OUT_HANDLE structure needs to be defined by the host
 * OS; for some, it could be just the GPIO pin number that
 * generated the interrupt; for others, an OS reference to an
 * interrupt object
 */
   struct OUT_HANDLE
   {
      PLATFORM_DRIVER_T *driver;
      u8 bit;
      u8 mask;
      u8 prev_gpios;
   };

/**
 * \brief install the interrupt handler
 * \param bit
 * \param unique_id -- underlying device port string
 * \return handle
 */
   extern OUT_HANDLE_T out_setup(u8 bit, char *unique_id);


/**
 * \brief output a GPIO value
 * \param value
 * \return handle
 */
   extern void out_set(OUT_HANDLE_T handle, bool value);




/**
 * \brief enable logging of register access to console
 * \param fmt - printf format
 * \return previous setting
 */
   extern bool enable_reg_log(bool enable);

/**
 * \brief set filename to log output to
 * \param log_file -- file to log to, or NULL or zero length to close / disable
 * \param append -- if true, will append to the specified log file if it
 *        exists; otherwise, the log file will be overwritten
 * \return FALSE if file cannot be openned
 */
   extern bool debug_set_log_file(char *log_file, bool append);


   /**
    * \brief set threshold for log events
    * \param level
    */
   extern void set_logging_level(LOG_LEVEL_T level);


/**
 * \brief return a key from the console
 * \return the key
 */
   extern int get_key();


extern bool driver_is_com_bridge(void);

extern bool driver_is_aardvark(void);

extern bool driver_is_i2chid(void);

extern bool driver_is_ftdi4222(void);

#ifdef __cplusplus
}
#endif


#endif

