/**
 * \file aardvark_services.c
 *
 *
 * \brief Aardvark host interface
 *
 * \copyright  (C) 2014 EM Microelectronic
 *
 */

#ifdef _MSC_VER
#include <windows.h>
#include <direct.h>
#define STAT_STRUCT _stat
#else
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#define BOOL bool
#define STAT_STRUCT stat
#define _getcwd getcwd
#define GetLastError() errno
#endif
#include <sys/stat.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include "types.h"
#include "host_services.h"
#include "host_definitions.h"

#if defined(PROMIRA_NOT_AARDVARK)
#include "aa_pm.h"
#else
#include "aardvark.h"
#endif

#define AA_FIX_DELAY 10
#define PLATFORM_I2C_MAX_READ_LEN      65532
#define PLATFORM_I2C_MAX_WRITE_LEN     65532

static bool aardvark_open = FALSE;
/* handle to one Aardvark device; the rest of the code is written to allow for
future expansion to having more than one at runtime */
static int aardvark_port;
static int aardvark_unique_id;
static AardvarkExt aa_ext;
static aa_u16 devices[32];
static aa_u32 unique_ids[32];
static BOOL number_retrieved;
static int bus_number;
static int num_busses = 0;
static bool i2c_initialized = FALSE;
static struct IRQ_HANDLE irq_handle = {0, 0};
static struct OUT_HANDLE out_handle = {0, 0};
extern PLATFORM_DRIVER_T av_driver;


/**
 * \brief set up the Aardvark USB->I2C adapter
 * \return bool
 */
Aardvark aardvark_init(bool verbose, char *unique_id)
{
   static Aardvark the_aardvark = 0;
   int stat;
   int bus_num = 0;

   if (!aardvark_open)
   {
      the_aardvark = 0;
      aardvark_port = -1;
      aardvark_unique_id = 0;
      if (!number_retrieved)
      {
         num_busses = aa_find_devices_ext(32, devices, 32, unique_ids);
         number_retrieved = TRUE;
      }
      info_log("Aardvark: found %d devices\n", num_busses);
      info_log("IDs: ");
      for (bus_num = 0; bus_num < num_busses; bus_num++)
      {
         info_log("%u ", unique_ids[bus_num]);
      }
      info_log("\n");
      if (unique_id)
      {
         aa_u32 uid = 0;
         sscanf(unique_id, "%u", &uid);
         debug_log("searching for ID %s\n", unique_id);
         for (bus_num = 0; bus_num < num_busses; bus_num++)
         {
            debug_log("%u == %u? ", unique_ids[bus_num], uid);
            if (unique_ids[bus_num] == uid)
               break;
         }
         if (bus_num >= num_busses)
         {
            error_log("Aardvark: unable to find unique_id %s\n", unique_id);
            return FALSE;
         }
      }
      if (num_busses)
      {
         bus_number = bus_num;
         if (verbose)
            info_log("Aaardvark %d: device port = %d, unique id = %u\n", bus_num, devices[bus_num], unique_ids[bus_num]);
         aardvark_port = devices[bus_num];
         aardvark_unique_id = unique_ids[bus_num];
         the_aardvark = aa_open_ext(devices[bus_num], &aa_ext);
         if (the_aardvark >= 0)
         {
            if (verbose)
            {
               aa_log(the_aardvark, 2, AA_LOG_STDOUT);
               info_log("Aardvark %d: sw ver = %d.%02d, fw ver = %d.%02d, hw ver = %d.%02d, sw req by fw = %d.%02d, fw req by sw = %d.%02d api req by sw = %d.%02d, features = %02X\n",
                         bus_num,
                         (aa_ext.version.software >> 8) & 0xff, aa_ext.version.software & 0xff,
                         (aa_ext.version.firmware >> 8) & 0xff, aa_ext.version.firmware & 0xff,
                         (aa_ext.version.hardware >> 8) & 0xff, aa_ext.version.hardware & 0xff,
                         (aa_ext.version.sw_req_by_fw >> 8) & 0xff, aa_ext.version.sw_req_by_fw & 0xff,
                         (aa_ext.version.fw_req_by_sw >> 8) & 0xff, aa_ext.version.fw_req_by_sw & 0xff,
                         (aa_ext.version.api_req_by_sw >> 8) & 0xff, aa_ext.version.api_req_by_sw & 0xff,
                         aa_ext.features);
            }
         }
         else                                                        // got an error
         {
            info_log("Aardvark: not found: %d\n", the_aardvark); // made error less "intense" since we now search 2 other interfaces for an active mechanism
            return FALSE;
         }
         if ((stat = aa_configure(the_aardvark, AA_CONFIG_GPIO_I2C)) == AA_CONFIG_ERROR)
         {
            error_log("Aardvark: configure error %d: %s\n", stat, aa_status_string(stat));
            return FALSE;
         }
         aardvark_open = TRUE;
      }
   }
   return the_aardvark;
}


bool av_i2c_init(I2C_HANDLE_T handle, char *unique_id)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   int stat;
   int bitrate_khz = DEFAULT_BITRATE_KHZ;
   bool verbose = FALSE;
   Aardvark the_aardvark;

   if (!i2c_initialized)
   {
      the_aardvark = aardvark_init(verbose, unique_id);
      if (!the_aardvark)
         return FALSE;
      if ((stat = aa_i2c_pullup(the_aardvark, AA_I2C_PULLUP_BOTH)) == AA_INCOMPATIBLE_DEVICE)
         error_log("Aardvark: can't turn on pullups\n");
      else if (verbose)
         info_log("Aardvark: pullups on\n");
      if ((stat = aa_target_power(the_aardvark, AA_TARGET_POWER_BOTH)) == AA_INCOMPATIBLE_DEVICE)
         error_log("Aardvark: can't turn on target power\n");
      else if (verbose)
         info_log("Aardvark: target power on\n");
      aa_i2c_free_bus(the_aardvark);
      if ((stat = aa_i2c_bitrate(the_aardvark, bitrate_khz)) == bitrate_khz)
      {
         //if (verbose)
            info_log("Aardvark set bitrate to %d khz\n", stat);
      }
      else
         warn_log("Aardvark bitrate set to %d, not %d\n", stat, bitrate_khz);

      if (!fhandle->driver)
         fhandle->driver = &av_driver;
      fhandle->driver->platform_data = (void *)(intptr_t)the_aardvark;
      irq_handle.driver = fhandle->driver;  // kludge... help out the irq subsystem
      out_handle.driver = fhandle->driver;  // ditto for output subsystem
      i2c_initialized = TRUE;
   }
   else
   {
      the_aardvark = aardvark_init(FALSE, fhandle->unique_id);
      if (!fhandle->driver)
         fhandle->driver = &av_driver;
      fhandle->driver->platform_data = (void *)(intptr_t)the_aardvark;
   }
   return TRUE;
}


bool av_i2c_deinit(I2C_HANDLE_T handle)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Aardvark aardvark = (Aardvark)(intptr_t)fhandle->driver->platform_data;
   if (i2c_initialized)
   {
      //if (aa_target_power(aardvark, AA_TARGET_POWER_NONE) != AA_TARGET_POWER_NONE)
      //   error_log("Aardvark: can't turn off target power\n");
      aa_i2c_free_bus(aardvark);
      aa_close(aardvark);
      i2c_initialized = FALSE;
      fhandle->driver->platform_data = NULL;
   }
   return TRUE;
}


bool av_i2c_set_rate(I2C_HANDLE_T handle, u16 rate_khz)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Aardvark aardvark = (Aardvark)(intptr_t)fhandle->driver->platform_data;
   int stat;

   if (!i2c_initialized)
      return FALSE;

   if ((stat = aa_i2c_bitrate(aardvark, rate_khz)) == rate_khz)
   {
      //if (verbose)
         info_log("Aardvark set bitrate to %d khz\n", stat);
   }
   else
      warn_log("Aardvark bitrate set to %d, not %d\n", stat, rate_khz);

   fhandle->i2c_rate_khz = stat;
   return TRUE;
}

bool av_i2c_get_rate(I2C_HANDLE_T handle, u16 *rate_khz)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Aardvark aardvark = (Aardvark)(intptr_t)fhandle->driver->platform_data;
   if (!i2c_initialized || !rate_khz)
      return FALSE;

   fhandle->i2c_rate_khz = *rate_khz = aa_i2c_bitrate(aardvark, 0);
   return TRUE;
}

/**
 * NOTE: the Aardvark only supports blocking, so we block
 */
bool av_i2c_read_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   bool ret;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Aardvark aardvark = (Aardvark)(intptr_t)fhandle->driver->platform_data;
   int i;
   int stat;

   for (i = 0; i < 1; i++)
   {
      aa_u16 num_read = 0;
      aa_u16 num_written = 0;

      fhandle->status = TS_I2C_IN_PROGRESS;
      fhandle->len_transferred = 0;

      time_delay_us(AA_FIX_DELAY);
      stat = aa_i2c_write_read(aardvark, fhandle->slave_7bit_slave_addr, AA_I2C_NO_FLAGS,
                               1, (const aa_u08 *)&reg_addr, &num_written,
                               len, (aa_u08 *)buffer, &num_read);
      fhandle->len_transferred = num_read;
      if ((stat == AA_I2C_STATUS_OK) && (num_written == 1) && (num_read == len))
      {
         fhandle->status = TS_I2C_COMPLETE;
         ret = TRUE;
         break;
      }
      else if ((num_written != 1) || (num_read != 0))
      {
         fhandle->status = TS_I2C_ERROR;
         error_log("Aardvark: I2C error %d: %s, slave 0x%02X; write attempted %u, written %u; read %u attempted, read %u\n",
            (int)((signed char)(stat & 0xff)), aa_status_string(stat), fhandle->slave_7bit_slave_addr,
                  1, num_written, len, num_read);
         ret = FALSE;
      }
      else
      {
         aa_i2c_free_bus(aardvark);
         time_delay_us(100);
         info_log("FATAL AARDVARK FAILURE!\n");
		 ret = FALSE;
      }
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool av_i2c_write_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   bool ret;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Aardvark aardvark = (Aardvark)(intptr_t)fhandle->driver->platform_data;
   aa_u16 num_written = 0;
   int stat;
   u8 local_buffer[256];

   if (len > 255)
   {
      error_log("buffer overflow; write aborted\n");
      return FALSE;
   }
   local_buffer[0] = reg_addr;
   memcpy(&local_buffer[1], buffer, len);                            // need to add register address to start

   fhandle->status = TS_I2C_IN_PROGRESS;
   fhandle->len_transferred = 0;

   time_delay_us(AA_FIX_DELAY);
   stat = aa_i2c_write_ext(aardvark, fhandle->slave_7bit_slave_addr, AA_I2C_NO_FLAGS, len + 1, (const aa_u08 *)local_buffer, &num_written);
   if (num_written)
      num_written--;                                                 // remove register address
   fhandle->len_transferred = num_written;
   if ((stat == AA_I2C_STATUS_OK) && (num_written == len))
   {
      fhandle->status = TS_I2C_COMPLETE;
      ret = TRUE;
   }
   else if ((stat == AA_I2C_STATUS_DATA_NACK) && (num_written == len))
   {
      fhandle->status = TS_I2C_COMPLETE;
      ret = TRUE;
   }
   else
   {
      fhandle->status = TS_I2C_ERROR;
      //error_log("Aardvark: I2C error %d writing %d bytes to slave 0x%02X; wrote %d\n", stat, len, fhandle->slave_7bit_slave_addr, num_written);
      ret = FALSE;
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool av_i2c_write_read_start(I2C_HANDLE_T handle, u8 *wbuffer, u16 wlen, u8 *rbuffer, u16 rlen)
{
   bool ret;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Aardvark aardvark = (Aardvark)(intptr_t)fhandle->driver->platform_data;
   aa_u16 num_written = 0;
   aa_u16 num_read = 0;
   int stat;

   fhandle->status = TS_I2C_IN_PROGRESS;
   fhandle->len_transferred = 0;

   time_delay_us(AA_FIX_DELAY);
   stat = aa_i2c_write_read(aardvark, fhandle->slave_7bit_slave_addr, AA_I2C_NO_FLAGS,
                            wlen, (const aa_u08 *)wbuffer, &num_written,
                            rlen, (aa_u08 *)rbuffer, &num_read);
   fhandle->len_transferred = num_read;
   if ((stat == AA_I2C_STATUS_OK) && (num_written == wlen) && (num_read == rlen))
   {
      fhandle->status = TS_I2C_COMPLETE;
      ret = TRUE;
   }
   else if ((stat == AA_I2C_STATUS_DATA_NACK) && (num_written == wlen) && (num_read == rlen))
   {
      fhandle->status = TS_I2C_COMPLETE;
      ret = TRUE;
   }
   else
   {
      fhandle->status = TS_I2C_ERROR;
      error_log("Aardvark: I2C error %d: %s, slave 0x%02X; write attempted %u, written %u; read %u attempted, read %u\n",
         (int)((signed char)(stat & 0xff)), aa_status_string(stat), fhandle->slave_7bit_slave_addr,
               wlen, num_written, rlen, num_read);
      ret = FALSE;
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool av_i2c_check_status(I2C_HANDLE_T handle, TransferStatus *complete, u16 *len_transferred)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   if (complete)
      *complete = fhandle->status;
   if (len_transferred)
      *len_transferred = fhandle->len_transferred;
   return TRUE;
}


IRQ_HANDLE_T av_irq_setup(u8 bit, char *unique_id)
{
   int stat;
   Aardvark the_aardvark;

   if (bit > 7)
      return NULL;
   irq_handle.bit = bit;
   irq_handle.mask = 1 << bit;
   if (!i2c_initialized)
   {
      the_aardvark = aardvark_init(FALSE, unique_id);
      if (!the_aardvark)
         return NULL;
      if (!irq_handle.driver)
         irq_handle.driver = &av_driver;
      irq_handle.driver->platform_data = (void *)(intptr_t)the_aardvark;
   }
   else
      the_aardvark = (Aardvark)(intptr_t)irq_handle.driver->platform_data;
   if ((stat = aa_gpio_direction(the_aardvark, 0)) != AA_OK)
   {
      error_log("Aardvark: error setting GPIO bit %d direction; %d: %s\n", bit, stat, aa_status_string(stat));
      return NULL;
   }
   return (IRQ_HANDLE_T)&irq_handle;
}


void av_irq_acknowledge(IRQ_HANDLE_T handle)
{
   // nothing to do
}
/**< some hosts might need to be told to clear the interrupt condition before returning from the IRQ callback */


bool av_irq_check(IRQ_HANDLE_T handle)
{
   IRQ_FULL_HANDLE_T fhandle = (IRQ_FULL_HANDLE_T)handle;
   Aardvark aardvark = (Aardvark)(intptr_t)fhandle->driver->platform_data;
   int gpios;
#if defined(SIMULATE_EDGE_TRIGGERED_INTERRUPT)
   int prev_gpios;
#endif
   bool asserted;

   time_delay_us(AA_FIX_DELAY);
   gpios = aa_gpio_get(aardvark);
#if defined(SIMULATE_EDGE_TRIGGERED_INTERRUPT)
   prev_gpios = fhandle->prev_gpios;
#endif
   asserted = ((gpios & fhandle->mask) != 0);
   fhandle->prev_gpios = gpios;
#if defined(SIMULATE_EDGE_TRIGGERED_INTERRUPT)
   if (asserted && ((prev_gpios & fhandle->mask) == 0))              // host int went high
#else
   if (asserted)                                                     // host int is high
#endif
      {
         if (fhandle->callback)
         {
            fhandle->callback(handle, asserted, fhandle->user_param);
         }
      }
   return asserted;
}


bool av_irq_is_reliable(IRQ_HANDLE_T handle)
{
   return FALSE;
}

OUT_HANDLE_T av_output_init(u8 bit, char *unique_id)
{
   int stat;
   Aardvark the_aardvark;

   if (bit > 7)
      return NULL;
   out_handle.bit = bit;
   out_handle.mask = 1 << bit;
   if (!i2c_initialized)
   {
      the_aardvark = aardvark_init(FALSE, unique_id);
      if (!the_aardvark)
         return NULL;
      if (!out_handle.driver)
         out_handle.driver = &av_driver;
      out_handle.driver->platform_data = (void *)(intptr_t)the_aardvark;
   }
   else
      the_aardvark = (Aardvark)(intptr_t)out_handle.driver->platform_data;
   if ((stat = aa_gpio_direction(the_aardvark, out_handle.mask)) != AA_OK)
   {
      error_log("Aardvark: error setting GPIO bit %d direction; %d: %s\n", bit, stat, aa_status_string(stat));
      return NULL;
   }
   return (OUT_HANDLE_T)&out_handle;
}

void av_output_set(OUT_HANDLE_T handle, bool value)
{
   Aardvark aardvark = (Aardvark)(intptr_t)handle->driver->platform_data;
   int gpios;

   time_delay_us(AA_FIX_DELAY);
   gpios = aa_gpio_get(aardvark);
   handle->prev_gpios = gpios;
   time_delay_us(AA_FIX_DELAY);
   aa_gpio_set(aardvark, value ? handle->mask : 0);
}

PLATFORM_DRIVER_T av_driver =
{
   NULL,
   PLATFORM_I2C_MAX_READ_LEN,
   PLATFORM_I2C_MAX_WRITE_LEN,
   av_i2c_init,
   av_i2c_deinit,
   av_i2c_set_rate,
   av_i2c_get_rate,
   av_i2c_read_start,
   av_i2c_write_start,
   av_i2c_write_read_start,
   av_i2c_check_status,
   av_irq_setup,
   av_irq_acknowledge,
   av_irq_check,
   av_irq_is_reliable,
   av_output_init,
   av_output_set
};
