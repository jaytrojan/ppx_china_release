/**
 * \file host_services.c
 *
 *
 * \brief Transport-agnostic host services
 *
 * \copyright  (C) 2014 EM Microelectronic
 *
 */

#ifdef _MSC_VER
#include <windows.h>
#include <direct.h>
#define STAT_STRUCT stat
#define USE_I2CHID
//#define USE_FTDI4222
#else
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#define BOOL bool
#define STAT_STRUCT stat
#define _getcwd getcwd
#define GetLastError() errno
#endif
#include <sys/stat.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include "types.h"
#include "host_services.h"
#include "host_definitions.h"

LOG_LEVEL_T logging_level = LL_INFO;
bool reg_log_enabled = FALSE;
char *host_unique_id = NULL;

#define NUM_HANDLES 4
static struct I2C_HANDLE i2c_handles[NUM_HANDLES] = {{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};

extern PLATFORM_DRIVER_T cb_driver;
extern PLATFORM_DRIVER_T av_driver;
#if defined(USE_I2CHID)
extern PLATFORM_DRIVER_T ih_driver;
#endif
#if defined(USE_FTDI4222)
extern PLATFORM_DRIVER_T ft_driver;
#endif
PLATFORM_DRIVER_T *drivers[] =
{
#if defined(_MSC_VER)
    &av_driver,
#if defined(USE_I2CHID)
    &ih_driver,
#endif
    &cb_driver,
#if defined(USE_FTDI4222)
    &ft_driver,
#endif
    NULL             // declare them in priority order
#else
    &av_driver,
#if defined(USE_I2CHID)
    &ih_driver,
#endif
    &cb_driver,
    NULL                         // declare them in priority order
#endif
};
int cur_driver = -1;                                                 // set >= 0 when a good one found


I2C_FULL_HANDLE_T I2COpen(u8 slave_7bit_addr)
{
    int i;
    for (i = 0; i < NUM_HANDLES; i++)
    {
        if (!i2c_handles[i].allocated)
        {
            i2c_handles[i].allocated = TRUE;
            i2c_handles[i].slave_7bit_slave_addr = slave_7bit_addr;
            return (I2C_FULL_HANDLE_T)&i2c_handles[i];
        }
        else if (i2c_handles[i].slave_7bit_slave_addr == slave_7bit_addr)
        {
            return (I2C_FULL_HANDLE_T)&i2c_handles[i];
        }
    }
    return NULL;
}

I2C_FULL_HANDLE_T I2CFindHandle(u8 slave_7bit_addr)
{
    int i;
    for (i = 0; i < NUM_HANDLES; i++)
    {
        if (i2c_handles[i].allocated && (i2c_handles[i].slave_7bit_slave_addr == slave_7bit_addr))
        {
            return (I2C_FULL_HANDLE_T)&i2c_handles[i];
        }
    }
    return NULL;
}

void I2CClose(u8 slave_7bit_addr)
{
    I2C_FULL_HANDLE_T handle;
    handle = (I2C_FULL_HANDLE_T)I2CFindHandle(slave_7bit_addr);
    if (handle)
        handle->allocated = FALSE;
}

I2C_HANDLE_T i2c_setup(u8 slave_7bit_addr, char *unique_id)
{
    host_unique_id = unique_id;
    return I2COpen(slave_7bit_addr);
}

void i2c_teardown(u8 slave_7bit_addr)
{
    I2CClose(slave_7bit_addr);
}

bool i2c_register(I2C_HANDLE_T handle, I2C_CALLBACK callback, void *user_param)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    fhandle->callback = callback;
    fhandle->user_param = user_param;
    return TRUE;
}

bool i2c_deregister(I2C_HANDLE_T handle)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    fhandle->callback = NULL;
    fhandle->user_param = NULL;
    return TRUE;
}

bool irq_register(IRQ_HANDLE_T handle, IRQ_CALLBACK callback, void *user_param)
{
    IRQ_FULL_HANDLE_T fhandle = (IRQ_FULL_HANDLE_T)handle;
    fhandle->callback = callback;
    fhandle->user_param = user_param;
    return TRUE;
}

bool irq_deregister(IRQ_HANDLE_T handle)
{
    IRQ_FULL_HANDLE_T fhandle = (IRQ_FULL_HANDLE_T)handle;
    fhandle->callback = NULL;
    fhandle->user_param = NULL;
    return TRUE;
}

u16 i2c_get_max_read_length(I2C_HANDLE_T handle)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->max_read_len;
    else
        return 0;
}

u16 i2c_get_max_write_length(I2C_HANDLE_T handle)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->max_write_len;
    else
        return 0;
}

void i2c_teardown_handle(I2C_HANDLE_T handle)
{
    I2C_FULL_HANDLE_T h = (I2C_FULL_HANDLE_T)handle;
    if (!h || !h->allocated)
        return;

    i2c_teardown(h->slave_7bit_slave_addr);
}

bool i2c_init(I2C_HANDLE_T handle)
{
    // try each driver and return when we find one we can open
    if (cur_driver == -1)
    {
        for (cur_driver = 0; drivers[cur_driver] != NULL; cur_driver++)
            if (drivers[cur_driver]->i2c_init(handle, host_unique_id))               // driver will set handle->driver to point to itself
                return TRUE;
        cur_driver = -1;
        return FALSE;
    }
    else
        return drivers[cur_driver]->i2c_init(handle, host_unique_id);
}


bool driver_is_com_bridge(void)
{
    if (cur_driver != -1)
        return (drivers[cur_driver] == &cb_driver);
    else
        return FALSE;
}

bool driver_is_aardvark(void)
{
    if (cur_driver != -1)
        return (drivers[cur_driver] == &av_driver);
    else
        return FALSE;
}

#if defined(USE_I2CHID)
bool driver_is_i2chid(void)
{
    if (cur_driver != -1)
        return (drivers[cur_driver] == &ih_driver);
    else
        return FALSE;
}
#endif

#if defined(USE_FTDI4222)
bool driver_is_ftdi4222(void)
{
    if (cur_driver != -1)
        return (drivers[cur_driver] == &ft_driver);
    else
        return FALSE;
}
#endif

bool i2c_deinit(I2C_HANDLE_T handle)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->i2c_deinit(handle);
    else
        return FALSE;
}

bool i2c_read_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->i2c_read_start(handle, reg_addr, buffer, len);
    else
        return FALSE;
}

bool i2c_write_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->i2c_write_start(handle, reg_addr, buffer, len);
    else
        return FALSE;
}

bool i2c_write_read_start(I2C_HANDLE_T handle, u8 *wbuffer, u16 wlen, u8 *rbuffer, u16 rlen)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->i2c_write_read_start(handle, wbuffer, wlen, rbuffer, rlen);
    else
        return FALSE;
}

bool i2c_check_status(I2C_HANDLE_T handle, TransferStatus *complete, u16 *len_transferred)
{
    I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->i2c_check_status(handle, complete, len_transferred);
    else
        return FALSE;
}

IRQ_HANDLE_T irq_setup(u8 bit, char *unique_id)
{
    IRQ_HANDLE_T handle;

    if (cur_driver == -1)
    {
        for (cur_driver = 0; drivers[cur_driver] != NULL; cur_driver++)
        {
            handle = drivers[cur_driver]->irq_setup(bit, unique_id);
            if (handle)                                              // driver will set handle->driver to point to itself
                return handle;
        }
        cur_driver = -1;
        return NULL;
    }
    else
        return drivers[cur_driver]->irq_setup(bit, unique_id);
}

void irq_acknowledge(IRQ_HANDLE_T handle)
{
    IRQ_FULL_HANDLE_T fhandle = (IRQ_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        fhandle->driver->irq_acknowledge(handle);
    //else
    //   return FALSE;
}

bool irq_check(IRQ_HANDLE_T handle)
{
    IRQ_FULL_HANDLE_T fhandle = (IRQ_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->irq_check(handle);
    else
        return FALSE;
}

bool irq_is_reliable(IRQ_HANDLE_T handle)
{
    IRQ_FULL_HANDLE_T fhandle = (IRQ_FULL_HANDLE_T)handle;
    if (fhandle && fhandle->driver)
        return fhandle->driver->irq_is_reliable(handle);
    else
        return FALSE;
}

OUT_HANDLE_T out_setup(u8 bit, char *unique_id)
{
    OUT_HANDLE_T handle;

    if (cur_driver == -1)
    {
        for (cur_driver = 0; drivers[cur_driver] != NULL; cur_driver++)
        {
            if (drivers[cur_driver]->output_init != NULL)
            {
                handle = drivers[cur_driver]->output_init(bit, unique_id);
                if (handle)                                          // driver will set handle->driver to point to itself
                    return handle;
            }
        }
        cur_driver = -1;
        return NULL;
    }
    else if (drivers[cur_driver]->output_init != NULL)
        return drivers[cur_driver]->output_init(bit, unique_id);
    else
        return NULL;
}

void out_set(OUT_HANDLE_T handle, bool value)
{
    if (handle && handle->driver)
        handle->driver->output_set(handle, value);
}


u32 file_size(char *file_name)
{
    struct STAT_STRUCT status;
    if (stat(file_name, &status) == 0)
        return status.st_size;
    else
    {
        char buffer[128];
        _getcwd(buffer, 128);
        error_log("error getting filesize for %s; last error: %d; cwd: %s\r\n", file_name, GetLastError(), buffer);
        return 0;
    }
}


FILE_HANDLE_T file_open(char *file_name)
{
    return (FILE_HANDLE_T)fopen(file_name, "rb");
}


/**< read-only access is all that is needed */

bool file_read(FILE_HANDLE_T handle, u8 *buffer, u16 len, u16 *len_read)
{
    u16 num_read = (u16)fread(buffer, 1, len, (FILE *)handle);
    if (len_read)
        *len_read = num_read;
    if (num_read)                                                    // return TRUE if anything could be read at all
        return TRUE;
    return FALSE;
}


void file_close(FILE_HANDLE_T handle)
{
    fclose((FILE *)handle);
}



#ifdef _MSC_VER
static bool know_frequency = FALSE;
static LARGE_INTEGER freq;
#endif
static u32 time_ms_start = 0;


u32 time_ms(void)
{
#ifdef _MSC_VER
    u32 now_ms;

    if (!know_frequency)
        know_frequency = QueryPerformanceFrequency(&freq);

    if (!know_frequency)                                             // fake it with the system time, which is not very good due to week-rollover problems
    {
        SYSTEMTIME st;
        GetSystemTime(&st);
        now_ms = st.wMilliseconds + (st.wSecond + (st.wMinute + (st.wHour + st.wDay * 24) * 60) * 60) * 1000;
    }
    else
    {
        LARGE_INTEGER perf;
        QueryPerformanceCounter(&perf);
        now_ms = (u32)((1000 * perf.QuadPart) / freq.QuadPart);
    }

    if (!time_ms_start)
        time_ms_start = now_ms;

    return now_ms - time_ms_start;

#else

    struct timeval tv;
    u32 now_ms;

    gettimeofday(&tv, NULL);
    now_ms = (u32)(tv.tv_sec * 1000 + tv.tv_usec / 1000);

    if (!time_ms_start)
    time_ms_start = now_ms;

    return now_ms - time_ms_start;

#endif
}


u32 time_us(void)
{
#ifdef _MSC_VER

    if (!know_frequency)
        know_frequency = QueryPerformanceFrequency(&freq);

    if (!know_frequency)                                             // fake it with the system time, which is not very good due to week-rollover problems
    {
        SYSTEMTIME st;
        GetSystemTime(&st);
        return (st.wMilliseconds + (st.wSecond + (st.wMinute + (st.wHour + st.wDay * 24) * 60) * 60) * 1000) * 1000;
    }
    else
    {
        LARGE_INTEGER perf;
        QueryPerformanceCounter(&perf);
        return (u32)((1000000 * perf.QuadPart) / freq.QuadPart);
    }

#else

    struct timeval tv;

    gettimeofday(&tv, NULL);
    return (u32)(tv.tv_sec * 1000000ul + tv.tv_usec);

#endif
}


void time_delay_ms(u32 num_ms)
{
#ifdef _MSC_VER

    Sleep(num_ms);

#else

    struct timespec req;
    struct timespec rem;

    req.tv_sec = num_ms / 1000;
    num_ms -= req.tv_sec * 1000;
    req.tv_nsec = num_ms * 1000000ul;
    while (nanosleep(&req, &rem))
    {
        req.tv_sec = rem.tv_sec;                                     // interrupted by a signal; use time remaining and try again
        req.tv_nsec = rem.tv_nsec;
    }

#endif
}


void time_delay_us(u32 num_us)
{
    u32 start = time_us();
    while (time_us() < (start + num_us))
    {
    }
}


static FILE *logf = NULL;

bool debug_set_log_file(char *log_file, bool append)
{
    bool ret = TRUE;

    if (log_file && (log_file[0] != '\0'))
    {
        logf = fopen(log_file, append ? "a+" : "w");
        if (logf)
            info_log("opened log file: %s\n", log_file);
        else
        {
            error_log("error opening log file: %s\n", log_file);
            ret = FALSE;
        }
    }
    else
    {
        info_log("closed log file\n");
        if (logf)
        {
            fclose(logf);
            logf = NULL;
        }
    }
    return ret;
}

#ifndef _MSC_VER
#if __GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 6)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wformat-security"
#endif
__attribute__((format (printf, 2, 3)))
#endif
void do_log(LOG_LEVEL_T level, const char *fmt, ...)
{
    // don't print anything for log levels info or insane
    static char *levels[LL_NUM_LEVELS] = {"", "ERROR: ", "WARNING: ", "", "DEBUG: ", ""};
    char buf[2048];
    va_list ap;

    if ((level > LL_NUM_LEVELS) || (level <= LL_NONE))
        return;
    if (level <= logging_level)
    {
        va_start(ap, fmt);
        vsnprintf(buf, 2047, fmt, ap);
        va_end(ap);

#ifdef VBE_DBG_SCRN
        printf("%s%s", levels[level], buf);
#else
#ifndef VBE_DO_NOT_PRN_CONSOLE_FOR_SPEED
        if ((level < LL_DEBUG) || !logf)                             // if LL_DEBUG or higher, don't print to screen if logging to a file
        {
            printf("%s%s", levels[level], buf);
        }
#endif
#endif
        if (logf)
        {
            fprintf(logf, "%s%s", levels[level], buf);
        }
    }
}
#ifndef _MSC_VER
#if __GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ >= 6)
#pragma GCC diagnostic pop
#endif
#endif


void set_logging_level(LOG_LEVEL_T level)
{
    if ((level > LL_NUM_LEVELS) || (level < LL_NONE))
        return;
    logging_level = level;
}


bool enable_reg_log(bool enable)
{
    static LOG_LEVEL_T old_level = LL_INFO;
    bool old = reg_log_enabled;
    if (enable == old)                                               // no change
        return old;
    reg_log_enabled = enable;
    if (enable)
    {
        old_level = logging_level;
        logging_level = LL_INSANE;
    }
    else
    {
        logging_level = old_level;
    }
    return old;
}


int get_key()
{
    return getchar();
}


