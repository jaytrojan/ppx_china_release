/**
 * \file ftdi4222_services.c
 *
 *
 * \brief FTDI4222 host interface
 *
 * \copyright  (C) 2015 EM Microelectronic
 *
 */

#ifdef _MSC_VER
#include <windows.h>
#include <direct.h>
#define STAT_STRUCT _stat
#else
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#define BOOL bool
#define STAT_STRUCT stat
#define _getcwd getcwd
#define GetLastError() errno
#endif
#include <sys/stat.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include "types.h"
#include "host_services.h"
#include "host_definitions.h"

#include "ftd2xx/ftd2xx.h"
#include "LibFT4222/inc/LibFT4222.h"

#define PLATFORM_I2C_MAX_READ_LEN      65532
#define PLATFORM_I2C_MAX_WRITE_LEN     65532

//#define USE_EVENT
//#define USE_WAKEUPINT

static bool ftdi4222_open = FALSE;
static bool ftdi4222_revb = TRUE; // automatically set to FALSE if we get FT4222_FUN_NOT_SUPPORT in response to ReadEx or WriteEx
/* handle to one FT4222 device; the rest of the code is written to allow for
future expansion to having more than one at runtime */
FT_DEVICE_LIST_INFO_NODE *devInfo = NULL;
int num_busses = 0;
int num_used_busses = 0;
static bool i2c_initialized = FALSE;
static bool irq_initialized = FALSE;
static bool out_initialized = FALSE;
static int bitrate_khz = DEFAULT_BITRATE_KHZ;
static struct IRQ_HANDLE irq_handle = {0, 0};
static struct OUT_HANDLE out_handle = {0, 0};
#if defined(USE_EVENT)
static HANDLE ft_event = NULL;
#endif
extern PLATFORM_DRIVER_T ft_driver;

void DeviceFlagToString(uint32_t flags, char *str)
{
   sprintf(str, "%s, %s", (flags & 0x1)? "DEVICE_OPEN" : "DEVICE_CLOSED", (flags & 0x2)? "High-speed USB" : "Full-speed USB");
}

/**
 * \brief set up the FTDI4222 USB->I2C adapter
 * \return bool
 */
FT_HANDLE ftdi4222_init(bool verbose, char *unique_id)
{
   FT_HANDLE ftHandle = NULL;
   int bus_num = 0;                                                  // just use the first found
   char flag_string[100];
   FT_STATUS ftStatus = 0;
   uint32_t numOfDevices = 0;
   uint32_t iDev;
   FT_DEVICE_LIST_INFO_NODE *dev;

   if (!num_busses)
   {
      num_used_busses = 0;
      ftStatus = FT_CreateDeviceInfoList(&numOfDevices);
      if (numOfDevices)
         devInfo = (FT_DEVICE_LIST_INFO_NODE *)calloc(numOfDevices, sizeof(FT_DEVICE_LIST_INFO_NODE));

      for(iDev=0; iDev<numOfDevices; ++iDev)
      {
          dev = &devInfo[num_busses];
          memset(dev, 0, sizeof(devInfo[0]));

          ftStatus = FT_GetDeviceInfoDetail(iDev, &dev->Flags, &dev->Type,
                                          &dev->ID, &dev->LocId,
                                          dev->SerialNumber,
                                          dev->Description,
                                          &dev->ftHandle);
          if (FT_OK == ftStatus)
          {
             if ((strcmp(dev->Description, "FT4222") == 0) || (strcmp(dev->Description, "FT4222 A") == 0) || (strcmp(dev->Description, "FT4222 B") == 0))
             {
                // we have one
                info_log("FT4222 %d: ID %u, LocId %u, unique id = %s, desc %s\n", num_busses, dev->ID, dev->LocId, dev->SerialNumber, dev->Description);
                num_busses++;
             }
          }
      }

      if (!num_busses)
      {
         error_log("No FT4222 found\n");
         return NULL;
      }
      info_log("FT4222: found %d devices\n", num_busses);
   }

   if (num_used_busses < num_busses)
   {
      if (unique_id)
      {
         for (bus_num = 0; bus_num < num_busses; bus_num++)
         {
            if (strcmp(devInfo[bus_num].SerialNumber, unique_id) == 0)
               break;
         }
         if (bus_num >= num_busses)
         {
            error_log("FT4222: unique_id %s not found\n", unique_id);
            return NULL;
         }
      }
      else
      {
         // pick next one
         bus_num = num_used_busses;
      }

      dev = &devInfo[bus_num];

      ftStatus = FT_OpenEx((PVOID)dev->LocId, FT_OPEN_BY_LOCATION, &ftHandle);
      if (FT_OK != ftStatus)
      {
          info_log("Open a FT4222 device failed!\n");
          return NULL;
      }
      dev->ftHandle = ftHandle;

      num_used_busses++;

      if (verbose)
      {
         info_log("FT4222: device %u: ", bus_num);
         DeviceFlagToString(dev->Flags, flag_string);
         info_log("flags: 0x%x, (%s), ", dev->Flags, flag_string);
         info_log("type: 0x%x, ",        dev->Type);
         info_log("ID: 0x%x, ",          dev->ID);
         info_log("loc id: 0x%x, ",      dev->LocId);
         info_log("serial number: %s, ", dev->SerialNumber);
         info_log("description: %s, ",   dev->Description);
         info_log("ftHandle: 0x%x\n",    dev->ftHandle);
      }

      ftdi4222_open = TRUE;
   }

   return ftHandle;
}


bool ft_i2c_init(I2C_HANDLE_T handle, char *unique_id)
{
   FT_HANDLE ft_handle = NULL;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   int bitrate_khz = DEFAULT_BITRATE_KHZ;
   bool verbose = TRUE;
   uint16_t max_size = 0;
   FT4222_STATUS status;

   if (!i2c_initialized)
   {
      ft_handle = ftdi4222_init(verbose, unique_id);
      if (!ft_handle)
         return FALSE;

      info_log("Init FT4222 as I2C master\n");
      status = FT4222_I2CMaster_Init(ft_handle, bitrate_khz);
      if (FT_OK != status)
      {
          info_log("Init FT4222 as I2C master device failed!\n");
          return NULL;
      }

      if ((status = FT4222_GetMaxTransferSize(ft_handle, &max_size)) == FT4222_OK)
      {
         info_log("FT4222: max transfer size %u\n", max_size);
         if (max_size > 50)
            max_size = (max_size / 50) * 50;
         ft_driver.max_read_len = ft_driver.max_write_len = max_size;
      }
      else
      {
         error_log("FT4222: error %u getting max transfer size\n", status);
         ft_driver.max_read_len = ft_driver.max_write_len = 0;
      }

      if (!fhandle->driver)
         fhandle->driver = &ft_driver;
      fhandle->driver->platform_data = (void *)ft_handle;
      irq_handle.driver = fhandle->driver;  // kludge... help out the irq subsystem
      out_handle.driver = fhandle->driver;  // ditto for output subsystem
      i2c_initialized = TRUE;
   }
   else
   {
      if (!fhandle->driver)
         fhandle->driver = &ft_driver;
   }
   return TRUE;
}


bool ft_i2c_deinit(I2C_HANDLE_T handle)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   FT_HANDLE ft_handle = (FT_HANDLE)fhandle->driver->platform_data;
   if (i2c_initialized)
   {
      FT4222_UnInitialize(ft_handle);
      i2c_initialized = FALSE;
      fhandle->driver->platform_data = NULL;
   }
   // there is no irq_deinit entry point, so deinit it here also
   if (irq_initialized)
   {
      FT4222_UnInitialize((FT_HANDLE)irq_handle.driver->platform_data);
      irq_initialized = FALSE;
      irq_handle.driver->platform_data = NULL;
   }
#if defined(USE_EVENT)
   if (ft_event != NULL)
   {
      CloseHandle(ft_event);
      ft_event = NULL;
   }
#endif
   if (devInfo)
      free (devInfo);
   devInfo = NULL;
   out_initialized = FALSE;
   return TRUE;
}


bool ft_i2c_set_rate(I2C_HANDLE_T handle, u16 rate_khz)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   FT_HANDLE ft_handle = (FT_HANDLE)fhandle->driver->platform_data;

   if (!i2c_initialized)
      return FALSE;

   warn_log("FT4222: cannot currently change the rate\n");

   return TRUE;
}

bool ft_i2c_get_rate(I2C_HANDLE_T handle, u16 *rate_khz)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   FT_HANDLE ft_handle = (FT_HANDLE)fhandle->driver->platform_data;
   if (!i2c_initialized || !rate_khz)
      return FALSE;

   fhandle->i2c_rate_khz = *rate_khz = bitrate_khz;
   return TRUE;
}

/**
 * NOTE: the FT4222 only supports blocking, so we block
 */
bool ft_i2c_read_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   bool ret;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   FT_HANDLE ft_handle = (FT_HANDLE)fhandle->driver->platform_data;
   FT4222_STATUS stat;
   uint16_t num_read = 0;
   uint16_t num_written = 0;

   fhandle->status = TS_I2C_IN_PROGRESS;
   fhandle->len_transferred = 0;

   if (ftdi4222_revb)
   {
      stat = FT4222_I2CMaster_WriteEx(ft_handle, fhandle->slave_7bit_slave_addr, START, &reg_addr, 1, &num_written);
      if (stat == FT4222_OK)
      {
         stat = FT4222_I2CMaster_ReadEx(ft_handle, fhandle->slave_7bit_slave_addr, Repeated_START | STOP, buffer, len, &num_read);
      }
      if (stat == FT4222_FUN_NOT_SUPPORT)
      {
         info_log("FT4222: not revb chip; switching to no-RESTART mode\n");
         ftdi4222_revb = FALSE;
      }
   }
   if (!ftdi4222_revb)
   {
      stat = FT4222_I2CMaster_Write(ft_handle, fhandle->slave_7bit_slave_addr, &reg_addr, 1, &num_written);
      if (stat == FT4222_OK)
      {
         stat = FT4222_I2CMaster_Read(ft_handle, fhandle->slave_7bit_slave_addr, buffer, len, &num_read);
      }
   }
   fhandle->len_transferred = num_read;
   if ((stat == FT4222_OK) && (num_written == 1) && (num_read == len))
   {
      fhandle->status = TS_I2C_COMPLETE;
      ret = TRUE;
   }
   else
   {
      fhandle->status = TS_I2C_ERROR;
      error_log("FTDI4222: I2C error %u, slave 0x%02X; write attempted %u, written %u; read %u attempted, read %u\n",
         stat, fhandle->slave_7bit_slave_addr, 1, num_written, len, num_read);
      ret = FALSE;
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool ft_i2c_write_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   bool ret;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   FT_HANDLE ft_handle = (FT_HANDLE)fhandle->driver->platform_data;
   uint16_t num_written = 0;
   FT4222_STATUS stat;
   u8 local_buffer[256];

   if (len > 255)
   {
      error_log("buffer overflow; write aborted\n");
      return FALSE;
   }
   local_buffer[0] = reg_addr;
   memcpy(&local_buffer[1], buffer, len);                            // need to add register address to start

   fhandle->status = TS_I2C_IN_PROGRESS;
   fhandle->len_transferred = 0;

   stat = FT4222_I2CMaster_Write(ft_handle, fhandle->slave_7bit_slave_addr, local_buffer, len + 1, &num_written);
   if (num_written)
      num_written--;                                                 // remove register address
   fhandle->len_transferred = num_written;
   if ((stat == FT4222_OK) && (num_written == len))
   {
      fhandle->status = TS_I2C_COMPLETE;
      ret = TRUE;
   }
//   else if ((stat == AA_I2C_STATUS_DATA_NACK) && (num_written == len))
//   {
//      fhandle->status = TS_I2C_COMPLETE;
//      ret = TRUE;
//   }
   else
   {
      fhandle->status = TS_I2C_ERROR;
      error_log("FTDI4222: I2C error %d writing %d bytes to slave 0x%02X; wrote %d\n", stat, len, fhandle->slave_7bit_slave_addr, num_written);
      ret = FALSE;
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool ft_i2c_write_read_start(I2C_HANDLE_T handle, u8 *wbuffer, u16 wlen, u8 *rbuffer, u16 rlen)
{
   bool ret;
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   FT_HANDLE ft_handle = (FT_HANDLE)fhandle->driver->platform_data;
   uint16_t num_written = 0;
   uint16_t num_read = 0;
   FT4222_STATUS stat;

   fhandle->status = TS_I2C_IN_PROGRESS;
   fhandle->len_transferred = 0;

   if (ftdi4222_revb)
   {
      stat = FT4222_I2CMaster_WriteEx(ft_handle, fhandle->slave_7bit_slave_addr, START, wbuffer, wlen, &num_written);
      if (stat == FT4222_OK)
      {
         stat = FT4222_I2CMaster_ReadEx(ft_handle, fhandle->slave_7bit_slave_addr, Repeated_START | STOP, rbuffer, rlen, &num_read);
      }
      if (stat == FT4222_FUN_NOT_SUPPORT)
      {
         info_log("FT4222: not revb chip; switching to no-RESTART mode\n");
         ftdi4222_revb = FALSE;
      }
   }
   if (!ftdi4222_revb)
   {
      stat = FT4222_I2CMaster_Write(ft_handle, fhandle->slave_7bit_slave_addr, wbuffer, wlen, &num_written);
      if (stat == FT4222_OK)
      {
         stat = FT4222_I2CMaster_Read(ft_handle, fhandle->slave_7bit_slave_addr, rbuffer, rlen, &num_read);
      }
   }

   fhandle->len_transferred = num_read;
   if ((stat == FT4222_OK) && (num_written == wlen) && (num_read == rlen))
   {
      fhandle->status = TS_I2C_COMPLETE;
      ret = TRUE;
   }
//   else if ((stat == AA_I2C_STATUS_DATA_NACK) && (num_written == wlen) && (num_read == rlen))
//   {
//      fhandle->status = TS_I2C_COMPLETE;
//      ret = TRUE;
//   }
   else
   {
      fhandle->status = TS_I2C_ERROR;
      error_log("FTDI4222: I2C error %u, slave 0x%02X; write attempted %u, written %u; read %u attempted, read %u\n",
         stat, fhandle->slave_7bit_slave_addr, wlen, num_written, rlen, num_read);
      ret = FALSE;
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool ft_i2c_check_status(I2C_HANDLE_T handle, TransferStatus *complete, u16 *len_transferred)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   if (complete)
      *complete = fhandle->status;
   if (len_transferred)
      *len_transferred = fhandle->len_transferred;
   return TRUE;
}


IRQ_HANDLE_T ft_irq_setup(u8 bit, char *unique_id)
{
   FT_HANDLE ft_handle;
   FT4222_STATUS stat;
   GPIO_Dir gpio_dir[4] = {GPIO_INPUT, GPIO_INPUT, GPIO_INPUT, GPIO_INPUT};

   if (bit > 3)
      bit = 3; // default to this bit
   irq_handle.bit = bit;
   irq_handle.mask = 1 << bit;
   if (!irq_initialized)
   {
      ft_handle = ftdi4222_init(TRUE, unique_id);
      if (!ft_handle)
         return NULL;
      if (!irq_handle.driver)
         irq_handle.driver = &ft_driver;
      irq_handle.driver->platform_data = (void *)(intptr_t)ft_handle;
   }
   else
      ft_handle = (FT_HANDLE)irq_handle.driver->platform_data;

#if defined(USE_WAKEUPINT)
   stat = FT4222_SetWakeUpInterrupt(ft_handle, TRUE);
   if (stat != FT4222_OK)
   {
      error_log("FT4222: error %u initializing GPIO\n", stat);
      return NULL;
   }
   stat = FT4222_SetInterruptTrigger(ft_handle, GPIO_TRIGGER_RISING);
   if (stat != FT4222_OK)
   {
      error_log("FT4222: error %u initializing GPIO\n", stat);
      return NULL;
   }
#if defined(USE_EVENT)
   ft_event = CreateEvent(NULL, TRUE, FALSE, "FT4222_EVENT");
   if (ft_event == NULL)
   {
      error_log("FT4222: error creating event\n");
      return NULL;
   }
   stat = FT4222_SetEventNotification(ft_handle, 0xffffffff, ft_event);
   if (stat != FT4222_OK)
   {
      error_log("FT4222: error %u initializing event notification\n", stat);
      return NULL;
   }
#endif
#else
   stat = FT4222_GPIO_Init(ft_handle, gpio_dir);
   if (stat != FT4222_OK)
   {
      error_log("FT4222: error %u initializing GPIO\n", stat);
      return NULL;
   }
   stat =  FT4222_GPIO_SetInputTrigger(ft_handle, (GPIO_Port)bit, GPIO_TRIGGER_RISING);
   if (stat != FT4222_OK)
   {
      error_log("FT4222: error %u setting GPIO input trigger for pin %u\n", stat, bit);
      return NULL;
   }
#endif
   irq_initialized = TRUE;
   return (IRQ_HANDLE_T)&irq_handle;
}


void ft_irq_acknowledge(IRQ_HANDLE_T handle)
{
   // nothing to do
}
/**< some hosts might need to be told to clear the interrupt condition before returning from the IRQ callback */


bool ft_irq_check(IRQ_HANDLE_T handle)
{
   IRQ_FULL_HANDLE_T fhandle = (IRQ_FULL_HANDLE_T)handle;
   FT_HANDLE ft_handle = (FT_HANDLE)fhandle->driver->platform_data;
   uint16_t queue_size = 0;
   uint16_t queue_read = 0;
   FT4222_STATUS stat;
   GPIO_Trigger event;
   GPIO_Trigger *events = &event;
   bool asserted = FALSE;

#if defined(USE_EVENT)
   if (WaitForSingleObject(ft_event, 0) == WAIT_OBJECT_0)
   {
      asserted = TRUE;
      debug_log("FT4222: interrupt event asserted\n");
      ResetEvent(ft_event);
   }
#endif

   stat = FT4222_GPIO_GetTriggerStatus(ft_handle, (GPIO_Port)fhandle->bit, &queue_size);
   if (stat != FT4222_OK)
   {
      error_log("FT4222: error %u getting trigger status\n", stat);
      return FALSE;
   }

   if (queue_size)
   {
      if (queue_size > 1) // allow for a single event (which should be most of the time); if there are more, dynamically allocate and free them
         events = (GPIO_Trigger *)calloc(queue_size, sizeof(GPIO_Trigger));
      stat = FT4222_GPIO_ReadTriggerQueue(ft_handle, (GPIO_Port)fhandle->bit, events, queue_size, &queue_read);
      if (queue_size > 1)
      {
         event = events[queue_size - 1];
         free(events);
      }
      if (stat != FT4222_OK)
      {
         error_log("FT4222: error %u reading trigger queue\n", stat);
         return FALSE;
      }
      asserted = (event == GPIO_TRIGGER_RISING);
   }
   else
   {
      return FALSE;
   }

   if (asserted)                                                     // host int is high
   {
      if (fhandle->callback)
      {
         fhandle->callback(handle, asserted, fhandle->user_param);
      }
   }
   return asserted;
}


bool ft_irq_is_reliable(IRQ_HANDLE_T handle)
{
   return TRUE;
}

OUT_HANDLE_T ft_output_init(u8 bit, char *unique_id)
{
   FT4222_STATUS stat;
   FT_HANDLE ft_handle;
   GPIO_Dir gpio_dir[4] = {GPIO_INPUT, GPIO_INPUT, GPIO_INPUT, GPIO_INPUT};

   if (bit > 3)
      return NULL;
   out_handle.bit = bit;
   out_handle.mask = 1 << bit;
   gpio_dir[bit] = GPIO_OUTPUT;
   if (!out_initialized)
   {
      ft_handle = ftdi4222_init(FALSE, unique_id);
      if (!ft_handle)
         return NULL;
      if (!out_handle.driver)
         out_handle.driver = &ft_driver;
      out_handle.driver->platform_data = (void *)(intptr_t)ft_handle;
   }
   else
      ft_handle = (FT_HANDLE)out_handle.driver->platform_data;

   stat = FT4222_GPIO_Init(ft_handle, gpio_dir);
   if (stat != FT4222_OK)
   {
      error_log("FT4222: error %u setting GPIO bit %u direction\n", stat, bit);
      return NULL;
   }
   out_initialized = TRUE;
   return (OUT_HANDLE_T)&out_handle;
}

void ft_output_set(OUT_HANDLE_T handle, bool value)
{
   FT_HANDLE ft_handle = (FT_HANDLE)handle->driver->platform_data;
   FT4222_STATUS stat;
   if (out_initialized)
   {
      stat = FT4222_GPIO_Write(ft_handle, (GPIO_Port)out_handle.bit, value);
      if (stat != FT4222_OK)
      {
         error_log("FT4222: error %u writing %u to bit %u\n", stat, value, out_handle.bit);
      }
   }
   else
   {
      error_log("FT4222: error attempting to set output when output not initialized\n");
   }
}

PLATFORM_DRIVER_T ft_driver =
{
   NULL,
   PLATFORM_I2C_MAX_READ_LEN,
   PLATFORM_I2C_MAX_WRITE_LEN,
   ft_i2c_init,
   ft_i2c_deinit,
   ft_i2c_set_rate,
   ft_i2c_get_rate,
   ft_i2c_read_start,
   ft_i2c_write_start,
   ft_i2c_write_read_start,
   ft_i2c_check_status,
   ft_irq_setup,
   ft_irq_acknowledge,
   ft_irq_check,
   ft_irq_is_reliable,
   ft_output_init,
   ft_output_set
};
