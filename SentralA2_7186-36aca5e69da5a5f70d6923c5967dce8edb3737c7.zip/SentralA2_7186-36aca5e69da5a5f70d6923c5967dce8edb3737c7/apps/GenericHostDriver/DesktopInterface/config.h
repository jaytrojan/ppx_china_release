#ifndef _CONFIG_H_
#define _CONFIG_H_

#include "types.h"
#include "host_services.h"
#include "driver_ext.h"

//typedef uint32_t bool;
#define TRUE 1
#define FALSE 0

#endif

