#ifndef _SERIAL_INTERFACE_H_

#include "config.h"
#include "serial.h"

#ifdef __cplusplus
extern "C" {
#endif

extern int serial_i2c_read(uint32_t slaveaddr, uint32_t reg, uint8_t* words, uint32_t num_bytes, Serial* port);
extern int serial_i2c_write(uint32_t slaveaddr, uint32_t reg, uint8_t* words, uint32_t num_bytes, Serial* port);
extern uint32_t serial_set_i2c_frequency(uint32_t frequency, Serial* port);
extern int serial_poll_irq(Serial *port);

#ifdef __cplusplus
}
#endif

#endif

