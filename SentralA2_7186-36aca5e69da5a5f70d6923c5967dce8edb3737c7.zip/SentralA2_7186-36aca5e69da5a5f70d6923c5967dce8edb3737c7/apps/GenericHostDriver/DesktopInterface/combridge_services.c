/**
 * \file combridge_services.c
 *
 *
 * \brief COM Bridge host interface
 *
 * \copyright  (C) 2014 EM Microelectronic
 *
 */

#ifdef _MSC_VER
#include <windows.h>
#include <direct.h>
#define STAT_STRUCT _stat
#else
#include <sys/time.h>
#include <unistd.h>
#include <errno.h>
#define BOOL bool
#define STAT_STRUCT stat
#define _getcwd getcwd
#define GetLastError() errno
#endif
#include <sys/stat.h>
#include <stdint.h>
#include <stdarg.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include "types.h"
#include "host_services.h"
#include "host_definitions.h"

//#include "test_config.h"
#include "serial.h"
#include "serial_interface.h"
#ifdef _MSC_VER
#define DEFAULT_BAUD CBR_115200
#else
#define DEFAULT_BAUD B115200
#endif

#define PLATFORM_I2C_MAX_READ_LEN      8
#define PLATFORM_I2C_MAX_WRITE_LEN     8

static bool i2c_initialized = FALSE;
static struct IRQ_HANDLE irq_handle = {0, 0};
extern PLATFORM_DRIVER_T cb_driver;


/**
 * \brief unique_id needs to be in the format "\\\\.\\COM<n>"
 *        for Windows, where <n> is an unsigned integer, or
 *        "/dev/ttyUSB<n>" for Linux
 * \param unique_id -
 * \return Serial* -
 */
Serial *open_serial(char *unique_id)
{
   static Serial *serial = NULL;

   if (!serial)
   {
      serial = serial_open(unique_id, DEFAULT_BAUD, 8, ONESTOPBIT, FLOW_CONTROL_NONE);
      if (!serial || !serial->m_isOpened)
      {
         serial = NULL;
         info_log("COM bridge not found\n");
      }
   }
   return serial;
}


bool cb_i2c_init(I2C_HANDLE_T handle, char *unique_id)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Serial *serial;

   if (!i2c_initialized)
   {
      serial = open_serial(unique_id);
      if (!serial)
         return FALSE;
      fhandle->i2c_rate_khz = serial_set_i2c_frequency(DEFAULT_BITRATE_KHZ * 1000, serial) / 1000;

      if (!fhandle->driver)
         fhandle->driver = &cb_driver;
      fhandle->driver->platform_data = (void *)serial;
      irq_handle.driver = fhandle->driver; // kludge... help out the irq subsystem
      i2c_initialized = TRUE;
   }
   else
   {
      serial = open_serial(unique_id);
      if (!fhandle->driver)
         fhandle->driver = &cb_driver;
      fhandle->driver->platform_data = (void *)serial;
   }
   return TRUE;
}


bool cb_i2c_deinit(I2C_HANDLE_T handle)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   if (fhandle->driver && fhandle->driver->platform_data && i2c_initialized)
   {
      serial_close((Serial *)fhandle->driver->platform_data);
      fhandle->driver->platform_data = NULL;
      i2c_initialized = FALSE;
   }
   return TRUE;
}

bool cb_i2c_set_rate(I2C_HANDLE_T handle, u16 rate_khz)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Serial *serial = (Serial *)fhandle->driver->platform_data;
   if (!i2c_initialized)
      return FALSE;
   fhandle->i2c_rate_khz = serial_set_i2c_frequency(rate_khz * 1000, serial) / 1000;
   return TRUE;
}

bool cb_i2c_get_rate(I2C_HANDLE_T handle, u16 *rate_khz)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   if (!i2c_initialized || !rate_khz)
      return FALSE;
   *rate_khz = fhandle->i2c_rate_khz;
   return TRUE;
}

bool cb_i2c_read_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Serial *port = (Serial *)fhandle->driver->platform_data;
   bool ret = TRUE;
   u16 chunk_len;
   u16 len_left = len;

   fhandle->status = TS_I2C_IN_PROGRESS;
   fhandle->len_transferred = 0;

   while (len_left)
   {
      if (len_left > 16)
         chunk_len = 16;
      else
         chunk_len = len_left;
      if (serial_i2c_read(fhandle->slave_7bit_slave_addr << 1, reg_addr, buffer, chunk_len, port) == -1)
      {
         fhandle->status = TS_I2C_ERROR;
         ret = FALSE;
         break;
      }
      buffer += chunk_len;
      len_left -= chunk_len;
      reg_addr += chunk_len;
   }

   if (ret)
   {
      fhandle->status = TS_I2C_COMPLETE;
      fhandle->len_transferred = len;
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool cb_i2c_write_start(I2C_HANDLE_T handle, u8 reg_addr, u8 *buffer, u16 len)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Serial *port = (Serial *)fhandle->driver->platform_data;
   bool ret;

   fhandle->status = TS_I2C_IN_PROGRESS;
   fhandle->len_transferred = 0;

   if (serial_i2c_write(fhandle->slave_7bit_slave_addr << 1, reg_addr, buffer, len, port) == -1)
   {
      fhandle->status = TS_I2C_ERROR;
      ret = FALSE;
      //info_log("serial_i2c_write(0x%02X, 0x%02X, buffer, %u, 0x%08X) returned -1\r\n",
      //   fhandle->slave_7bit_slave_addr << 1, reg_addr, len, (int)fhandle->port);
   }
	   else
   {
      fhandle->status = TS_I2C_COMPLETE;
      fhandle->len_transferred = len;
      ret = TRUE;
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool cb_i2c_write_read_start(I2C_HANDLE_T handle, u8 *wbuffer, u16 wlen, u8 *rbuffer, u16 rlen)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   Serial *port = (Serial *)fhandle->driver->platform_data;
   bool ret;
   u8 reg_addr = wbuffer[0];

   fhandle->status = TS_I2C_IN_PROGRESS;
   fhandle->len_transferred = 0;

   if (serial_i2c_write(fhandle->slave_7bit_slave_addr << 1, reg_addr, &wbuffer[1], wlen - 1, port) != -1)
   {
      if (serial_i2c_read(fhandle->slave_7bit_slave_addr << 1, reg_addr, rbuffer, rlen, port) != -1)
      {
         fhandle->len_transferred = rlen;
         fhandle->status = TS_I2C_COMPLETE;
         ret = TRUE;
      }
      else
      {
         fhandle->status = TS_I2C_ERROR;
         ret = FALSE;
      }
   }
   else
   {
      fhandle->status = TS_I2C_ERROR;
      ret = FALSE;
   }

   if (fhandle->callback)
      fhandle->callback(handle, fhandle->status, fhandle->len_transferred, fhandle->user_param);
   return ret;
}


bool cb_i2c_check_status(I2C_HANDLE_T handle, TransferStatus *complete, u16 *len_transferred)
{
   I2C_FULL_HANDLE_T fhandle = (I2C_FULL_HANDLE_T)handle;
   if (complete)
      *complete = fhandle->status;
   if (len_transferred)
      *len_transferred = fhandle->len_transferred;
   return TRUE;
}


IRQ_HANDLE_T cb_irq_setup(u8 bit, char *unique_id)
{
   IRQ_FULL_HANDLE_T fhandle = &irq_handle;
   Serial *serial;

   fhandle->prev_gpios = 0;
   fhandle->mask = 0x01;

   if (!i2c_initialized)
   {
      serial = open_serial(unique_id);
      if (!serial)
         return NULL;
      if (!fhandle->driver)
         fhandle->driver = &cb_driver;
      fhandle->driver->platform_data = (void *)serial;
   }
   return (IRQ_HANDLE_T)&irq_handle;
}


void cb_irq_acknowledge(IRQ_HANDLE_T handle)
{
   // nothing to do
}
/**< some hosts might need to be told to clear the interrupt condition before returning from the IRQ callback */


bool cb_irq_check(IRQ_HANDLE_T handle)
{
   IRQ_FULL_HANDLE_T fhandle = &irq_handle;
   Serial *port = (Serial *)fhandle->driver->platform_data;
   int gpios = serial_poll_irq(port);
#if defined(SIMULATE_EDGE_TRIGGERED_INTERRUPT)
   int prev_gpios = fhandle->prev_gpios;
#endif
   bool asserted = ((gpios & fhandle->mask) != 0);

   fhandle->prev_gpios = gpios;
#if defined(SIMULATE_EDGE_TRIGGERED_INTERRUPT)
   if (asserted && ((prev_gpios & fhandle->mask) == 0))              // host int went high
#else
   if (asserted)                                                     // host int is high
#endif
      {
         if (fhandle->callback)
         {
            fhandle->callback(handle, asserted, fhandle->user_param);
         }
      }
   return asserted;
}

bool cb_irq_is_reliable(IRQ_HANDLE_T handle)
{
   return FALSE;
}


PLATFORM_DRIVER_T cb_driver =
{
   NULL,
   PLATFORM_I2C_MAX_READ_LEN,
   PLATFORM_I2C_MAX_WRITE_LEN,
   cb_i2c_init,
   cb_i2c_deinit,
   cb_i2c_set_rate,
   cb_i2c_get_rate,
   cb_i2c_read_start,
   cb_i2c_write_start,
   cb_i2c_write_read_start,
   cb_i2c_check_status,
   cb_irq_setup,
   cb_irq_acknowledge,
   cb_irq_check,
   cb_irq_is_reliable,
   NULL,
   NULL
};
