////////////////////////////////////////////////////////////////////////////////
//
// Author(s)     : EWL
//
// Project       : Test Framework
//
// Description   : Bassic serial port class -> impliments printf / scanf.
//
////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////
//                          Copyright
////////////////////////////////////////////////////////////////////////////////
//
//         Copyright (C) EM Microelectronic US Inc.
//
// Disclosure to third parties or reproduction in any form what-
// soever, without prior written consent, is strictly forbidden
//
////////////////////////////////////////////////////////////////////////////////
#ifndef SERIAL_H
#define SERIAL_H

#include "config.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include <string.h>
#include <stdio.h>
#include <stdint.h>

#ifdef _MSC_VER
/** Windows, Visual Studio **/
#include <windows.h>
#else
/** Unix **/
#include <fcntl.h>
#include <errno.h>
#include <termios.h>
#include <unistd.h>
#include <stdarg.h>
#define ONESTOPBIT	0
#define CBR_9600	B9600
#define CBR_115200	B115200
#endif

   enum flowctrl
   {
      FLOW_CONTROL_NONE = 0,
   };

   typedef struct _serial_
   {
      bool m_debug;
      const char *m_port;
      uint32_t m_baud;
      uint8_t m_dataBits;
      uint8_t m_stopBits;
      int m_flowControl;
      bool m_isOpened;
#ifdef _MSC_VER
      HANDLE m_Serial;
#else
      int m_Serial;
      FILE* m_File;
      struct termios* m_tio;
#endif
   } Serial;

   extern Serial *serial_open(const char *port, uint32_t baud, uint8_t dataBits, uint8_t stopBits, int flowControl);
   extern void serial_close(Serial *port);
   extern void serial_printf(Serial *port, const char *str, ...);
   extern void serial_vsprintf(Serial *port, const char *str, va_list list);
   extern char *serial_getString(Serial *port, uint32_t *length);
   extern void serial_flush(Serial *port);

#ifdef __cplusplus
}
#endif

#endif // SERIAL_H
