////////////////////////////////////////////////////////////////////////////////
//
// Author(s)     : serial_interface.c
//
// Project       : 718x
//
// Description   : Basic command line program using the Point Reyes bridge board.
//
////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////
//                          Copyright
////////////////////////////////////////////////////////////////////////////////
//
//         Copyright (C) EM Microelectronic US Inc.
//
// Disclosure to third parties or reproduction in any form what-
// soever, without prior written consent, is strictly forbidden
//
////////////////////////////////////////////////////////////////////////////////

#include "config.h"


#ifndef _MSC_VER /* Unix / Linux */
#include <unistd.h>
#include <stdlib.h>
int Sleep(int msec)
{
   usleep(msec * 1000);
   return 0;
}
#define sscanf_s sscanf
#endif /* Unix / LInux */

#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <string.h>
#include <math.h>
#include <stdint.h>
#include "serial.h"

#define  VERSION_STRING "0.5.6"
#define BAUD_RATE CBR_115200

bool quiet = TRUE;

int serial_i2c_read(uint32_t slaveaddr, uint32_t reg, uint8_t *data, uint32_t num_bytes, Serial *port)
{
   int retValue = -1;
   char *result;
   char *freeaddr;
   unsigned int i;
   uint32_t num_read;
   uint32_t orig_num_read;
   char str[128];

   if (!port)
      return retValue;
   if (num_bytes == 0)
      return retValue;
   if (!port->m_isOpened)
      return retValue;

   sprintf(str, "!{%02x %02x %02x}\n\r", slaveaddr, reg, num_bytes);
   serial_printf(port, str);
   if (!quiet)
      printf("%s", str);

   result = serial_getString(port, &orig_num_read);
   freeaddr = result;
   if (!quiet)
      printf("%s", result);

   if (orig_num_read == 4)
      num_read = 1;                                                  // two hex nibbles plus \r\n
   else if (orig_num_read > 4)
      num_read = (orig_num_read - 1) / 3;                            // remove the \n then divide by 3 for the two hex nibbles plus space or \r on the last byte
   else
      num_read = 0;

   if (num_read > num_bytes)
      num_read = num_bytes;

   //printf("Returned string is %s\n", result);
   for (i = 0; i < num_read; i++)
   {
      uint32_t value = 0;

      if ((strlen(result) > 2) && sscanf(result, "%X", &value))
      {
         value &= 0xff;
         if (!quiet)
            printf("[0x%02X] Register 0x%02X is 0x%02X (%d)\n", slaveaddr, reg + i, value, value);
      }
      else
      {
         if (!quiet)
            printf("[0x%02X] Unable to read register 0x%02X (was %d)\n", slaveaddr, reg + i, value);
         value = -1;                                                 // PETE: indicate an error
         break;
      }

      if (data)
         data[i] = (uint8_t)value;

      if (i == 0)
         retValue = value;
      // Read in register value
      result += 3;                                                   //"XX " -> 3 chars
   }

   if (freeaddr)
      free(freeaddr);

   if (num_read != num_bytes)
      return -1;
   return retValue;
}

int serial_i2c_write(uint32_t slaveaddr, uint32_t reg, uint8_t *data, uint32_t num_bytes, Serial *port)
{
   int retValue = -1;
   unsigned int i;
   char str[128];

   if (!port)
      return retValue;
   if (!num_bytes)
      return retValue;
   if (!port->m_isOpened)
      return retValue;

   sprintf(str, "![%02x %02x", slaveaddr, reg);
   serial_printf(port, str);
   if (!quiet)
      printf("%s", str);

   if (num_bytes && data)
   {
      retValue = ((unsigned int)data[0]) & 0x0ff;
      for (i = 0; i < num_bytes; i++)
      {
         sprintf(str, " %02x", data[i]);
         serial_printf(port, str);
         if (!quiet)
            printf("%s", str);
      }
      serial_printf(port, "]\n\r");
      if (!quiet)
         printf("]\n\r");
   }
   else
   {
      serial_printf(port, "]\n\r");
      if (!quiet)
         printf("]\n\r");
   }
   Sleep(15);                                                        // Ensure the write takes...

   return retValue;
}

uint32_t serial_set_i2c_frequency(uint32_t frequency, Serial *port)
{
   int rate = 3;                                                     // the default on the DIL Test Board
   int i;

   uint32_t rates[] = {0, 140804, 113953, 107456, 104255, 102510, 101239, 100409, 100000, 99593, 99190, 98000, 97609, 96837, 96837, 96837};

   for (i = 1; i < sizeof(rates) / sizeof(rates[0]); i++)
   {
      if (frequency >= rates[i])
      {
         rate = i;
         break;
      }
   }

   if (port && port->m_isOpened)
   {
      serial_printf(port, "&%x\n", rate);
   }

   return rates[rate];
}

int serial_poll_irq(Serial *port)
{
   char *ret;
   uint8_t val;

   if (port && port->m_isOpened)
   {
      serial_printf(port, "?\n\r");
      ret = serial_getString(port, NULL);
      val = atoi(ret);
      free(ret);
      return val & 0x01;                                             // LSB is the DRDY line
   }
   return 0;
}



