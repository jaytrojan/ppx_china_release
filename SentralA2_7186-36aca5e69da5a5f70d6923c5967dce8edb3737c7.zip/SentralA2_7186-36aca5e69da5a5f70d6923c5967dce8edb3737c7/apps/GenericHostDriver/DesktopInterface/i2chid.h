#ifndef _I2CHID_H_
#define _I2CHID_H_

#include "types.h"

#define I2CHID_REPORT_REV 0x21 // the input report contains the i2chid sensor data
typedef uint8_t HID_UCHAR;
typedef int16_t HID_SHORT;
typedef uint16_t HID_USHORT;
typedef int32_t HID_LONG;
typedef uint32_t HID_ULONG;
typedef float HID_FLOAT;
//#define INCLUDE_REPORT_ID_IN_BUFFER // not defined unless we use multiple different reports

PREPACK typedef struct MIDPACK _GPIO_TRIGGER
{
   uint8_t gpio_pin : 4;
   uint8_t enable_int : 1;
   uint8_t rising_edge : 1;
   uint8_t falling_edge : 1;
   uint8_t unused : 1;
} GPIO_TRIGGER;
POSTPACK

PREPACK typedef struct MIDPACK _I2CHID_FEATURE_REPORT
{
   //common properties
   HID_UCHAR   ucReportId;
   HID_UCHAR   i2chid_report_rev;        // 0 change this number so host-side decoders know what the following bytes are, if you change it

   HID_SHORT   i2c_rate_khz;             // transfer rate in kHz
   HID_SHORT   timeout_ms;               // time to wait before aborting a transfer
   HID_UCHAR   pullup_enable;            // turn on our GPIO pullups on SDA/SCL
   HID_UCHAR   gpio_trigger;             // define how we want to generate "interrupts" on a GPIO pin
   HID_UCHAR   gpio_state;               // when doing a GET FEATURE REPORT, returns current state
   HID_UCHAR   irq_poll;                 // if set to 1, read GPIO line and issue a new IRQ report

   HID_UCHAR   unused[55];

} I2CHID_FEATURE_REPORT, *PI2CHID_FEATURE_REPORT;
POSTPACK

PREPACK typedef struct MIDPACK _I2CHID_INPUT_REPORT
{
   //common values
#if defined(INCLUDE_REPORT_ID_IN_BUFFER)
   HID_UCHAR   ucReportId;
#endif

   HID_UCHAR   i2chid_report_rev;         // MSB set on GPIO_TRIGGER
   HID_UCHAR   packet_count;              // host-defined number to keep track of transactions
   HID_UCHAR   slave_7bit_addr;           // which slave this was from
   HID_UCHAR   i2c_status;                // outcome of the transfer
   HID_UCHAR   actual_write_count;        // number of bytes actually written in write phase
   HID_USHORT  actual_read_count;         // actual number before transfer stopped
   HID_USHORT  read_offset;               // in multi-packet read, this is where we are
   HID_UCHAR   cur_read_byte_count;       // number of valid bytes that follow
   HID_UCHAR   read_data[54];

} I2CHID_INPUT_REPORT, *PI2CHID_INPUT_REPORT;
POSTPACK

PREPACK typedef struct MIDPACK _I2CHID_OUTPUT_REPORT
{
   //common values
   // always included when using hidapi
   HID_UCHAR   ucReportId;

   HID_UCHAR   i2c_report_rev;     // 0
   HID_UCHAR   packet_count;       // 1 -- host increments this each time
   HID_UCHAR   slave_7bit_addr;    // 2 -- slave to transfer with
   HID_UCHAR   bytes_to_write;     // 3 -- number of bytes in write phase
   HID_USHORT  bytes_to_read;      // 4 -- number of bytes in read phase
   HID_UCHAR   write_data[58];     // 6 -- remainder for writing

} I2CHID_OUTPUT_REPORT, *PI2CHID_OUTPUT_REPORT;
POSTPACK

#endif

