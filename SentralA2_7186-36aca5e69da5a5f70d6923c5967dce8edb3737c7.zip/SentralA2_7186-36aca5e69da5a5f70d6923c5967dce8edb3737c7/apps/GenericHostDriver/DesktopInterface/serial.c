////////////////////////////////////////////////////////////////////////////////
//
//
// Project       : Test Framework
//
// Description   : Bassic serial port class -> impliments printf / scanf.
//
////////////////////////////////////////////////////////////////////////////////
//
////////////////////////////////////////////////////////////////////////////////
//                          Copyright
////////////////////////////////////////////////////////////////////////////////
//
//         Copyright (C) EM Microelectronic US Inc.
//
// Disclosure to third parties or reproduction in any form what-
// soever, without prior written consent, is strictly forbidden
//
////////////////////////////////////////////////////////////////////////////////
#include "serial.h"
#include <stdio.h>


#define SERIAL_READ_TIMEOUT_MS 5000
static Serial the_port = {FALSE, "COM1", CBR_9600};

#ifdef _MSC_VER
/** Windows **/
#if _MSC_VER < 1900
// Code from here: http://stackoverflow.com/questions/2915672/snprintf-and-visual-studio-2010
#define snprintf c99_snprintf
#define vsnprintf c99_vsnprintf

int c99_vsnprintf(char *outBuf, size_t size, const char *format, va_list ap)
{
    int count = -1;

    if (size != 0)
        count = _vsnprintf_s(outBuf, size, _TRUNCATE, format, ap);
    if (count == -1)
        count = _vscprintf(format, ap);

    return count;
}

int c99_snprintf(char *outBuf, size_t size, const char *format, ...)
{
    int count;
    va_list ap;

    va_start(ap, format);
    count = c99_vsnprintf(outBuf, size, format, ap);
    va_end(ap);

    return count;
}
#endif

Serial *serial_open(const char *port_name, uint32_t baud, uint8_t dataBits, uint8_t stopBits, int flowControl)
{
   char mangledName[256];
   size_t len = 0;
   Serial *port = &the_port;

   if (!port->m_isOpened)
   {
      port->m_baud = baud;
      port->m_dataBits = dataBits;
      port->m_stopBits = stopBits;
      port->m_flowControl = flowControl;
      port->m_port = port_name;
      port->m_debug = FALSE;

      snprintf(mangledName, sizeof(mangledName), "\\\\.\\%s", port_name);

      port->m_Serial = CreateFileA(mangledName,
                                  GENERIC_READ | GENERIC_WRITE,
                                  0,
                                  0,
                                  OPEN_EXISTING,
                                  FILE_ATTRIBUTE_NORMAL,
                                  0);

      if (port->m_Serial == INVALID_HANDLE_VALUE)
      {
         char lastError[1024];
         FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                       NULL,
                       GetLastError(),
                       MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                       lastError,
                       1024, NULL);
         printf("ERR: Unable to open serial port %s. Received error %s\r\n", port_name, lastError);
         port->m_isOpened = FALSE;
         return NULL;
      }
      else
      {
         DCB dcbSerialParams = {0};
         COMMTIMEOUTS timeouts = {0};

         dcbSerialParams.DCBlength = sizeof(dcbSerialParams);

         if (!GetCommState(port->m_Serial, &dcbSerialParams))
         {
            printf("ERR: Unable to determine serial port state.\r\n");
            port->m_isOpened = FALSE;
            return NULL;
         }

         dcbSerialParams.BaudRate = port->m_baud;
         dcbSerialParams.ByteSize = port->m_dataBits;
         dcbSerialParams.StopBits = port->m_stopBits;
         dcbSerialParams.Parity = NOPARITY;

         if (!SetCommState(port->m_Serial, &dcbSerialParams))
         {
            char lastError[1024];
            FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
                          NULL,
                          GetLastError(),
                          MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
                          lastError,
                          1024, NULL);
            printf("ERR: Unable to set serial port state: %s.\r\n", lastError);
            //error setting serial port state
         }

         timeouts.ReadIntervalTimeout = 1;
         timeouts.ReadTotalTimeoutConstant = 50;
         timeouts.ReadTotalTimeoutMultiplier = 1;

         timeouts.WriteTotalTimeoutConstant = 50;
         timeouts.WriteTotalTimeoutMultiplier = 10;
         if (!SetCommTimeouts(port->m_Serial, &timeouts))
         {
            //error occureed. Inform user
            printf("WARN: Unable to set serial timeouts.\r\n");
         }

         port->m_isOpened = TRUE;
      }
   }
   return port;
}


void serial_close(Serial *port)
{
   if (port->m_isOpened)
   {
      //printf("Closing the %s serial port\r\n", port->m_port);
      CloseHandle(port->m_Serial);
   }
   port->m_isOpened = FALSE;
}


void serial_printf(Serial *port, const char *str, ...)
{
   char buffer[10240];                                               // FIXME
   va_list list;

   va_start(list, str);

   if (port && port->m_isOpened)
   {
      DWORD numWritten;
      LPOVERLAPPED val = 0;

      vsprintf_s(buffer, 10240, str, list);

      if (port->m_debug)
         printf(" Writing '%s' to the serial port\r\n", buffer);
      if (!WriteFile(port->m_Serial, buffer, (DWORD)strlen(buffer), &numWritten, val))
      {
         printf("ERR: Unable to output to the serial port.\r\n");
      }
   }

   va_end(list);
}


void serial_vsprintf(Serial *port, const char *str, va_list list)
{
   char buffer[10240];                                               // FIXME

   if (port && port->m_isOpened)
   {
      DWORD numWritten;
      LPOVERLAPPED val = 0;

      vsprintf_s(buffer, 10240, str, list);

      if (port->m_debug)
         printf(" Writing '%s' to the serial port\r\n", buffer);
      if (!WriteFile(port->m_Serial, buffer, (DWORD)strlen(buffer), &numWritten, val))
      {
         printf("ERR: Unable to output to the serial port.\r\n");
      }
   }
}

char *serial_getString(Serial *port, uint32_t *length)
{
   DWORD dwBytesRead = 0;
   char buffer[1000];
   char *buf = buffer;
   uint32_t local_length;
   uint32_t start = time_ms();

   buffer[0] = 0;
   if (!length)
      length = &local_length;
   *length = 0;

   if (port && port->m_isOpened)
   {
      for (;;)
      {
         if (!ReadFile(port->m_Serial, buf, 1, &dwBytesRead, NULL))
         {
            //error occurred. Report to user.
            if (time_ms() > (start + SERIAL_READ_TIMEOUT_MS))
            {
               printf(" Timeout waiting for serial port!\r\n");
               break;
            }
            continue;
         }
         *length += dwBytesRead;
         if (dwBytesRead && (*buf == '\r'))
            break;
         buf++;
         if (*length >= sizeof(buffer))
         {
            (*length)--;
            break;
         }
      }
      buffer[*length] = '\0';
      if (port->m_debug)
         printf(" Read '%s' from the serial port\r\n", buffer);
   }

   return _strdup(buffer);
}

void serial_flush(Serial *port)
{
   FlushFileBuffers(port->m_Serial);
}

#else

/** Unix **/
#include <stdlib.h> /* malloc / free */
#include <termios.h>
#include <unistd.h>
#include <string.h>

Serial *serial_open(const char *port_name, uint32_t baud, uint8_t dataBits, uint8_t stopBits, int flowControl)
{
   Serial *port = &the_port;

   port->m_debug = FALSE;

   if (port->m_isOpened)
      return port;

   port->m_Serial = open(port_name, O_RDWR | O_NOCTTY | O_NDELAY);
   if (port->m_Serial == -1)
   {
      printf("ERR: Unable to open serial port %s.  Received error %d: %s\n", port_name, errno, strerror(errno));
      port->m_isOpened = FALSE;
      port->m_File = NULL;
      return NULL;
   }
   else
   {
      port->m_tio = (struct termios *)malloc(sizeof(struct termios));
      memset(port->m_tio, 0, sizeof(struct termios));
      port->m_tio->c_cflag = CS8 | CREAD | CLOCAL;
      port->m_tio->c_cc[VMIN] = 0;
      port->m_tio->c_cc[VTIME] = 5;

      fcntl(port->m_Serial, F_SETFL, 0);
      cfsetospeed(port->m_tio, baud);
      cfsetispeed(port->m_tio, baud);

      tcsetattr(port->m_Serial, TCSANOW, port->m_tio);
      port->m_File = fdopen(port->m_Serial, "w+");
      port->m_isOpened = TRUE;
      return port;
   }
}

void serial_close(Serial *port)
{
   if (port->m_isOpened)
   {
      fclose(port->m_File);
      close(port->m_Serial);
      free(port->m_tio);
      port->m_tio = NULL;
   }
   port->m_isOpened = FALSE;
}

void serial_printf(Serial *port, const char *str, ...)
{
   char buffer[10240];                                               // FIXME
   va_list list;

   va_start(list, str);

   if (port && port->m_isOpened)
   {
      int num_written;
      vsprintf(buffer, str, list);

      if (port->m_debug)
         printf(" Writing '%s' to the serial port\r\n", buffer);
      num_written = fprintf(port->m_File, "%s", buffer);
      if (num_written != strlen(buffer))
      {
         printf("ERR: Unable to output to the serial port.\r\n");
      }
   }

   va_end(list);
}

void serial_vsprintf(Serial *port, const char *str, va_list list)
{
   char buffer[10240];                                               // FIXME

   if (port && port->m_isOpened)
   {
      int num_written;

      vsprintf(buffer, str, list);

      if (port->m_debug)
         printf(" Writing '%s' to the serial port\r\n", buffer);

      num_written = fprintf(port->m_File, "%s", buffer);
      if (num_written != strlen(buffer))
      {
         printf("ERR: Unable to output to the serial port.\r\n");
      }
   }
}

char *serial_getString(Serial *port, uint32_t *length)
{
   char buffer[1000];
   char *buf = buffer;
   uint32_t local_length;
   int val;
   uint32_t start = time_ms();

   buffer[0] = 0;
   if (!length)
      length = &local_length;
   *length = 0;

   if (port && port->m_isOpened)
   {
      for (;;)
      {
         val = fgetc(port->m_File);
         if (val == EOF)
         {
            if (time_ms() > (start + SERIAL_READ_TIMEOUT_MS))
            {
               printf(" Timeout waiting for serial port!\r\n");
               break;
            }
            continue;
         }
         //printf("%c", val);
         (*length)++;
         *buf = val;
         if ((*buf == '\r') || (*length >= (sizeof(buffer) - 1)))
            break;
         buf++;
      }
      buffer[*length] = '\0';
      if (port->m_debug)
         printf(" Read '%s' from the serial port\r\n", buffer);
   }

   return strdup(buffer);
}

void serial_flush(Serial *port)
{
   // not found in GLIBC_2.2.5: fflush(port->m_File);
}



#endif

