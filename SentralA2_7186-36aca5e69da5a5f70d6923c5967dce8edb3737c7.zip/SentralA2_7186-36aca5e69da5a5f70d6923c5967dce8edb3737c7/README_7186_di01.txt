EM7184 SDK README
-------------------------------------------------------------------
You will need to have Synopsys Metaware Lite (or the full version) J-2014-12 
installed and in the PATH in order to build firmware with this SDK.

To make firmware (RAM patch file):

[./boards]  make DevKit_7186_svn_BMX055.cfg

Note: choose a *.cfg file according to the sensors you need; feel free to edit them
to use the correct slave I2C address, GPIO pin, and sensor drivers.

It will generate *.fw file in ./board/sym eg.: DevKit_7184_di01_BMX055-7184_di01.2.1.8741.fw

Ensure your *.cfg file has lines:

  irq,6              - the host IRQ line
  pull,default,default,default,default,default,default,default,none - the pull up / down settings for the GPIO lines
  noexec,0           - affects whether firmware is automatically executed after load
  upload-speed,400   - specifies EEPROM upload speed
  rom,7184_di01      - this selects the correct ROM release
  rom_name,boot_rom  - this identifies the normal ROM
  hw,7180            - this identifies the correct hardware

as well as any physical and virtual drivers your application requires.
