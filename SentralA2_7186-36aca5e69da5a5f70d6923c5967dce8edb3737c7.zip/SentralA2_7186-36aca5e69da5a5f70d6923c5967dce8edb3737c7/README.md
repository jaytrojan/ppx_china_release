# SentralA2_7186_SDK_GENERATOR
Compilable full RAM source code and the ability to generate customer SDKs.

To generate the release folder with the linux and windows customer SDKs, run 
"make dstgz" in the root directory.

To generate firmware images for cfg files in the boards directory, run "make" in the boards directorry.
