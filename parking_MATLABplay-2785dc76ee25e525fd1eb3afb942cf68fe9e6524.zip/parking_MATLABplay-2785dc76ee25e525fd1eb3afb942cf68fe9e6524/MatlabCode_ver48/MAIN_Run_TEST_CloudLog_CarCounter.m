%% Algorithm using SSA and SSR with real-time functionality 
% No motion data


close all;
clear; clc;
dbstop if error


% choose and open data file
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\original')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\app_data')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors3')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\continuous_mode_logs')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\issue_cases')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\power_line_simulation')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs_RSSI')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\electric_car')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\cars_countinuously_pull_OutIn')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\Drive_Thru_logs')

% 
% % addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\weekend_issue_cases\week_0415')
% % addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\weekend_issue_cases\week_0422')
% % addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\weekend_issue_cases\week_0429')
% % addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\weekend_issue_cases\week_0506')
% % addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\weekend_issue_cases\week_0513')
% % addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\weekend_issue_cases\week_0520')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\weekend_issue_cases\week_0603')



% 
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\06b5')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\06b6')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\065f')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\067c')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\0670')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\0671')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\0674')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\0679')








addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_Semtech\S1_066d')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_Semtech\S2_069a')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_Semtech\S3_0659')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_Semtech\S4_06b3')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_Semtech\S6_0680')




addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S1_0677_3inch')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S2_066f_3inch')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S3_1388_3inch')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S4_137e_3inch')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S9_067b_3inch')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S14_137a_3inch')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S18_06ac_3inch')


addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S5_0670')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S6_0671')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S7_0674')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S8_0679')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S15_067c')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S16_06b5')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\S17_06b6')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\Side1_065f')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\Rear1_068e')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs\Sensor_PNI\Rear2_138e')




addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\Argentina Units')
% addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\Argentina Units\old_firmware')











% [FileName,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File -mag data');
[alldatfiles,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File', 'MultiSelect', 'on');

[mraw,timeRaw,SentralOutput,CarCounterData,DataRaw,sentralTimestamp,FileName] = Read_Data_CloudLog_CarCounter(alldatfiles);





% plot: mag data 
figure;   
subplot(2,1,1);
plot(mraw); grid on;
xlabel('Sample Index');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');

%%%% plot car counter from SENtral
subplot(2,1,2); plot(DataRaw(:,5)); grid on;






%% Setup data structures
ParkingStruct = Parking_struct_init;


%%%%% update knobs setting for drive thru algo
if ParkingStruct.DriveThruFLAG
    ParkingStruct = Parking_struct_init_DriveThru(ParkingStruct);
end







% if raw_rate <= ParkingStruct.HS_rate
%     
%     warning('upsampling is not supported');
%     
% else
%    
%     factor = floor(raw_rate/ ParkingStruct.HS_rate);
%     sprintf('Down Sampling Factor: %f',factor);    
%     
%     magData       = downsample(mraw,factor);
%     time          = downsample(timeRaw,factor);
%     SentralOutput = downsample(SentralOutput,factor);
% end
    


if strcmp(PathName, 'C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\continuous_mode_logs\')
   
    if (FileName(2) == '7' && FileName(3) == '_') || (FileName(2) == '1' && FileName(3) == '2') ...
            || (FileName(2) == '1' && FileName(3) == '9')
        start_ind = 130;

    elseif (FileName(2) == '8' && FileName(3) == '_') || (FileName(2) == '1' && FileName(3) == '0')...
            || (FileName(2) == '1' && FileName(3) == '1') || (FileName(2) == '1' && FileName(3) == '4')|| (FileName(2) == '1' && FileName(3) == '7')...
            || (FileName(2) == '2' && FileName(3) == '2') || (FileName(2) == '2' && FileName(3) == '3')|| (FileName(2) == '2' && FileName(3) == '4')...
            || (FileName(2) == '2' && FileName(3) == '7')
        start_ind = 50;

    else
        start_ind = 1;
    end

    
elseif strcmp(PathName, 'C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\issue_cases\')  
    
    if (FileName(2) == '2' && FileName(3) == '0') 
        
        start_ind = 323;    
        
    elseif (FileName(2) == '2' && FileName(3) == '5') 
        
        start_ind = 20; 
        
    elseif (FileName(2) == '2' && FileName(3) == '_') 
        
        start_ind = 1;
        
        ParkingStruct.State_count_thresh         = uint16(4);    % reqiures 1 seconds to confirm the correct state (no car OR car parked)
        ParkingStruct.State_count_thresh_timeout = uint16(4);    % TIMEOUT: no state change in 5 secods - BACK TO LOW SPEED MODE 
    
    else
        start_ind = 1;
    end
    

elseif strcmp(PathName, 'C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\Drive_Thru_logs\')  
    
    if (FileName(2) == '1' && FileName(3) == '_') 
        
        start_ind = 860;  
        
        
    else
        start_ind = 1;
    
    end
    
    
else
    start_ind = 1;
end    




% start_ind = 860;   % 323;  %% 130;  %%%%670;   %%%1400;


end_ind = size(mraw,1);    %%%% 1690;   %%%%size(mraw,1);  %%%625;


magData       = mraw(start_ind:end_ind,:);
time          = timeRaw(start_ind:end_ind,:);
SentralOutput = SentralOutput(start_ind:end_ind,2);
sentralTimestamp = sentralTimestamp(start_ind:end_ind,:);




magNdata = sqrt(sum(magData.^2,2));

magNdata2 = sqrt(sum(magData(:,2:3).^2,2));

figure;   
subplot(3,1,1);
plot(magData),title('mag data of X/Y/Z'); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');

% subplot(4,1,2); plot(magNdata2),title('magnitude of X+Y'); grid on;

subplot(3,1,2); plot(magNdata),title('magnitude of X+Y+Z');  grid on;

subplot(3,1,3); plot(SentralOutput),title('Sentral Output'); grid on;




% diffTime = [0; diff(time)];
% diffTime(1) = diffTime(2);
% 
% HS_label = diffTime<0.5;




figure;   
subplot1 = subplot(3,1,1);
plot(magData(:,1)),title('mag data of X','FontSize',20,'FontWeight','bold'); grid on;
% xlabel('Sample Index','FontSize',20,'FontWeight','bold');
ylabel('raw mag data','FontSize',20,'FontWeight','bold');

hold on; 
y1=get(gca,'ylim');
set(subplot1,'FontSize',20,'FontWeight','bold');


subplot2 = subplot(3,1,2);
plot(magData(:,2)),title('mag data of Y','FontSize',20,'FontWeight','bold'); grid on;
% xlabel('Sample Index','FontSize',20,'FontWeight','bold');
ylabel('raw mag data','FontSize',20,'FontWeight','bold');

hold on; 
y1=get(gca,'ylim');
set(subplot2,'FontSize',20,'FontWeight','bold');


subplot3 = subplot(3,1,3);
plot(magData(:,3)),title('mag data of Z','FontSize',20,'FontWeight','bold'); grid on;
xlabel('Sample Index','FontSize',20,'FontWeight','bold');
ylabel('raw mag data','FontSize',20,'FontWeight','bold');

hold on; 
y1=get(gca,'ylim');
set(subplot3,'FontSize',20,'FontWeight','bold');




% ParkingStruct.Calibration_FLAG    = uint8(1);
% ParkingStruct.LS_StartValue       = mean(magData(end-4:end,:));
% ParkingStruct.AVGInit2            = ParkingStruct.LS_StartValue;












N3 = length(magData);


magNdata = zeros(N3,1);
mag_diff = zeros(N3,1);
phase_level = zeros(N3,1);
detection_output = zeros(N3,1);

car_state = zeros(N3,4);

MEAN_value = zeros(N3,2);
STD_value = zeros(N3,1);

MEAN_value2 = zeros(N3,3);

moving_avg = zeros(N3,1);

MEAN_Baseline_value = zeros(N3,1);
STD_Baseline_value = zeros(N3,1);
MEAN_Occupied_value = zeros(N3,1);
STD_Occupied_value = zeros(N3,1);



ALG2Level = zeros(N3,1);
car_state_alg2 = zeros(N3,1);

car_state_buffer =zeros(N3,1);

Alarm_level = zeros(N3,1);

for i = 1:length(magData)
    
    

    if i == 270
        1;
    end
    
    
    
    
    ParkingStruct.NUM               = single(i);
    
    
%     ParkingStruct.PreDataBuffer      = shifting_array(ParkingStruct.PreDataBuffer);
%     ParkingStruct.PreDataBuffer(ParkingStruct.PreDataBufferSize,:)  = magData(i,:);    
    
    
    
    
    if ((abs(magData(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
        || (abs(magData(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
        || (abs(magData(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
        || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
%         || ParkingStruct.NUM              == 756
    
        


        if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
            ParkingStruct.StartNUM          = ParkingStruct.NUM;
        end
        
        
        

        
        
        
        % hardware alarm 
%         ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
        ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),sentralTimestamp(i),1);        
        
        
%          %%%%% downsample to 4 Hz
%          if ParkingStruct.downsampleFLAG == 1
%             ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),sentralTimestamp(i),1);               
%             ParkingStruct.downsampleFLAG = 0;        
%          else             
%              ParkingStruct.downsampleFLAG = 1;            
%          end
         
    end



%     % software alarm 
%     ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),sentralTimestamp(i),0);    
    
    

   magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
%    MEAN_value(i,1) = ParkingStruct.AVG;
   STD_value(i,1)  = ParkingStruct.STD;
   
%    STD_value(i,2)  = ParkingStruct.STDz;
   
   MEAN_value2(i,:) = ParkingStruct.AVG2;
   
   MEAN_value(i,1) = ParkingStruct.moving_avg;
   
   moving_avg(i,1)=ParkingStruct.moving_avg;
   
   
   car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2 ParkingStruct.car_present ParkingStruct.car_present2]; 
   Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG; 
   
%    RMS(i,1) = ParkingStruct.RMS;
   
   SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;
    
end



% static_state1 = [ParkingStruct.AVGInit2 single(1)];
% static_state = [static_state1; ParkingStruct.LS_StartValue_stateALL];
% 
% for i = 1:size(static_state,1)
%     static_state(i,5) = sum(abs(static_state(i,1:3) - static_state(1,1:3)));
%     static_state(i,6) = sqrt(sum(static_state(i,1:3).^2)) - sqrt(sum(static_state(1,1:3).^2));
% end







% figure;
% subplot(4,1,1); plot(time,magNdata),title('absolute mag'); grid on;
% subplot(4,1,2); plot(time,MEAN_value(:,2)),title('Feature: Magnetic Counts Change'); grid on;
% subplot(4,1,3); plot(time,STD_value),title('Feature: STD'); grid on;
% subplot(4,1,4); plot(time,Alarm_level),title('Alarm Trigger Level'); grid on;
% 
% 
% 
% figure;
% subplot(2,1,1); plot(time,moving_avg),title('Feature: Magnetic Counts Change');  grid on;
% subplot(2,1,2); plot(time,car_state(:,1)),title('Car States from MATLAB'); grid on; 
% set(gca,'YTick',1:4);
% labels = {
%         'Empty';
%         'Car Entering';
%         'Occupied';
%         'Car Leaving';
%         };
% set(gca,'YTickLabel',labels)
% % xlabel('Time (Seconds)');


% % subplot(3,1,3); plot(time,SentralOutput(1:length(time))),title('Car States from SENtral'); grid on;
% % set(gca,'YTick',1:4);
% % labels = {
% %         'Empty';
% %         'Car Entering';
% %         'Occupied';
% %         'Car Leaving';
% %         };
% % set(gca,'YTickLabel',labels)
% % xlabel('Time (Seconds)');





% figure;
% subplot(4,1,1); plot(magNdata),title('absolute mag'); grid on;
% subplot(4,1,2); plot(MEAN_value(:,2)),title('Feature: Magnetic Counts Change'); grid on;
% subplot(4,1,3); plot(STD_value),title('Feature: STD'); grid on;
% subplot(4,1,4); plot(Alarm_level),title('Alarm Trigger Level'); grid on;



figure;
% subplot(3,1,1); plot(moving_avg),title('Feature: Magnetic Counts Change');  grid on;

subplot(3,1,1);  plot(magData),title('mag data of X/Y/Z'); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');


subplot(3,1,2); plot(car_state(:,1)),title('Car States from MATLAB'); grid on; 
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)



subplot(3,1,3); plot(SentralOutput(1:length(time))),title('Car States from SENtral'); grid on;
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)










figure;

subplot(2,1,1);  plot(magData),title('mag data of X/Y/Z'); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');


subplot(2,1,2); plot(car_state(:,1),'r'),title('Car States'); grid on; hold on;
plot(SentralOutput(1:length(time)))
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
legend('MATLAB','SENtral');

