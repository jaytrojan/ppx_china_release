function [ParkingStruct, filtStruct] = histFilt(ParkingStruct, filtStruct)

if filtStruct.histFiltEnable && ParkingStruct.LS_Trigger_FLAG

%     hist13FldThresh = [3 600]; % [uT sec]
%     hist31FldThresh = [2 600]; % [uT sec]

    hist13FldThresh = filtStruct.hist13FldThresh;
    hist31FldThresh = filtStruct.hist31FldThresh;


%     stateFieldMeas = ParkingStruct.LS_StartValue;
    stateFieldMeas = filtStruct.mmnCln;

    if ParkingStruct.car_present == uint8(1)
        if ParkingStruct.car_presentPersist==3 && ParkingStruct.car_presentPersist ~= ParkingStruct.car_present
            if filtStruct.ihist1
                deltaFields = zeros(filtStruct.ihist1,1,'single');
                deltaTime = zeros(filtStruct.ihist1,1,'single');
                for ii=1:filtStruct.ihist1
                    deltaFields(ii,:) = sqrt(sum((filtStruct.mhiststate1(ii,:) - stateFieldMeas).^2));
                    deltaTime(ii,:) = (ParkingStruct.time - filtStruct.mhisttime1(ii,:))/32000;
                end
                %             deltaCalInit = sqrt(sum((ParkingStruct.AVGInit2 - stateFieldMeas).^2));
                histCheck = deltaFields>hist13FldThresh(1);
                histCheck = histCheck(deltaTime<hist13FldThresh(2));
                
                % logical all check
                if isempty(histCheck)
                    histCheck2 = false; 
                else
                    histCheck2 = true;                     
                end
                for jj=1:numel(histCheck)
                    if ~histCheck(jj)
                        histCheck2 = false;
                    end
                end
                if histCheck2
                    ParkingStruct.car_present            = uint8(3);
                    ParkingStruct.car_present2           = uint8(3);
                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                end
            end
        end

    elseif ParkingStruct.car_present == uint8(3)
        if ParkingStruct.car_presentPersist==1 && ParkingStruct.car_presentPersist ~= ParkingStruct.car_present
            if filtStruct.ihist1
                deltaFields = zeros(filtStruct.ihist1,1,'single');
                deltaTime = zeros(filtStruct.ihist1,1,'single');
                for ii=1:filtStruct.ihist1
                    deltaFields(ii,:) = sqrt(sum((filtStruct.mhiststate1(ii,:) - stateFieldMeas).^2));
                    deltaTime(ii,:) = (ParkingStruct.time - filtStruct.mhisttime1(ii,:))/32000;
                end
                deltaCalInit = sqrt(sum((ParkingStruct.AVGInit2 - stateFieldMeas).^2));
                histCheck = deltaFields<hist31FldThresh(1);
                histCheck = histCheck(deltaTime<hist31FldThresh(2));
                %             histCheck = any(histCheck) || deltaCalInit<hist31FldThresh(1);
                
                % logical any check
                histCheck2 = false;
                for jj=1:numel(histCheck)
                    if histCheck2 || histCheck(jj)
                        histCheck2 = true;
                    end
                end
                histCheck2 = histCheck2 || deltaCalInit<hist31FldThresh(1); % || deltaCalInit>hist13FieldThresh(1);
                if histCheck2
                    %                     if any(deltaFields<hist31FieldThresh(1)) || deltaCalInit<hist31FieldThresh(1)
                    ParkingStruct.car_present            = uint8(1);
                    ParkingStruct.car_present2           = uint8(1);
                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                end
            end
        end
    end

    %%% Update persistent state tracking buffer
    if ParkingStruct.car_present == uint8(1)
        if ParkingStruct.car_presentPersist ~= ParkingStruct.car_present
            if filtStruct.ihist1<filtStruct.Nhist
                filtStruct.ihist1 = filtStruct.ihist1+1;
                filtStruct.mhiststate1(filtStruct.ihist1,:) = stateFieldMeas;
                filtStruct.mhisttime1(filtStruct.ihist1,:) = ParkingStruct.time;
            else
                filtStruct.mhiststate1 = [filtStruct.mhiststate1(2:end,:); stateFieldMeas]; % drop oldest, add new at end
                filtStruct.mhisttime1 = [filtStruct.mhisttime1(2:end,:); ParkingStruct.time]; % drop oldest, add new at end
            end
            ParkingStruct.car_presentPersist = ParkingStruct.car_present;
        end

    elseif ParkingStruct.car_present == uint8(3)
        if ParkingStruct.car_presentPersist ~= ParkingStruct.car_present
            %                     if filtStruct.ihist3<filtStruct.Nhist
            %                         filtStruct.ihist3 = filtStruct.ihist3+1;
            %                         filtStruct.mhiststate3(filtStruct.ihist3,:) = stateFieldMeas;
            %                         filtStruct.mhisttime3(filtStruct.ihist3,:) = ParkingStruct.time;
            %                     else
            %                         filtStruct.mhiststate3 = [filtStruct.mhiststate3(2:end,:); stateFieldMeas]; % drop oldest, add new at end
            %                         filtStruct.mhisttime3 = [filtStruct.mhisttime3(2:end,:); ParkingStruct.time]; % drop oldest, add new at end
            %                     end

            % update state 1 time to time at state 3 transition since original time could be long ago
            if filtStruct.ihist1
                filtStruct.mhisttime1(filtStruct.ihist1,:) = ParkingStruct.time;
            end
            ParkingStruct.car_presentPersist = ParkingStruct.car_present;
        end
    end


end
