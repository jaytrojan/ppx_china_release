code with both algorithms:   -- new scale factor on mag data  (0.026)



9/12/2017

1. Merge updates in RC5 (codegen v37) and RC6 (codegen V39) into parking algorithm 







8/16/2017

1. Add car counter reset in the calibration process






8/1/2017

1. Parking Algorithm for aggressive parking events (Jira: PMG-102)
Aggressive Parking (one car pulls out and the second car pulls in immediately)


1. data rate in High speed mode = 8Hz

2. measure the mag data within 0.8seconds (ParkingStruct.ZdataWindowSize) to capture the vacant status during aggressive parking
3. notify SENtral the case of aggressive parking by set ParkingStruct.multipleCarsFLAG = 1

4. display the total number of cars have been parked @ ParkingStruct.NumCars



2.Parking Algorithm for drive through case (Jira: PMG-113) 
Reports the total number of cars over the sensor

Algorithm Outputs:
ParkingStruct.NumCars_DriveThru                           = uint16(0); 
ParkingStruct.NumCars_DriveThruPre                        = uint16(0);                                                                
                                                                
ParkingStruct.multipleCarsFLAG_DriveThru                  = uint8(0);     %%% aggressive drive thru detection FLAG
ParkingStruct.DriveThruFLAG                               = uint8(1);     %%% 1 -- run algorithm for Drive Thru cases   0 -- run algorithm for normal car parking (default case)









7/21/2017
Algorithm Update: knob changes (Jira: PPX-94)

tuning threshold setting on mag-Z_diff (z-axis mag change) 


ParkingStruct.HS_DatadiffZ_ThreshLevel1   = single(3.0);   % threshold on mag changes of Z-axis during HS mode   --- previous value: 4.0
ParkingStruct.HS_DatadiffZ_ThreshLevel2   = single(4.0);   % threshold on mag changes of Z-axis during HS mode   --- previous value: 5.0
ParkingStruct.HS_DatadiffXY_ThreshLevel2  = single(8.0);    % threshold on mag changes of X or Y-axis during HS mode   --- previous value: 10

ParkingStruct.HS_DataNdiff_Thresh         = single(4.0);   % threshold on mag changes of Z-axis during HS mode    --- previous value: 5.0







7/20/2017
Algorithm Update: (Jira: PMG-109)

Add time related condition check during parking event detection

%%% time related condition check
ParkingStruct.HS_totalTimeLS_thresh    = single(1); %%% threshold on the minimal time interval (in second) between time interval between the starting time of current HS mode and ending time of previous HS mode to allow car status change
ParkingStruct.MAG_threshUp3            = single(6); %%%% (loose threshold)
ParkingStruct.MAG_thresh_ZaxisLevel2   = single(2.5);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state









7/11/2017
Algorithm Update: (Jira: PMG-104)

Add demo used parking algorithm for simulated parking events with demo cars


%%% for demo case:

ParkingStruct.DemoFLAG               = uint8(0);     %%%%% 1 -- run algorithm for demo cases   0 -- run algorithm for normal car parking (default case)

ParkingStruct.MAG_threshDEMO         = single(2.5);   % minus/plus range from initilized AVGInit to check the correctness of the state
ParkingStruct.MAG_threshUpDEMO       = single(7);     % minus/plus range from last state3 to check the correctness of the state


ParkingStruct.count_threshDEMO               = uint16(2);    % reqiures 2 seconds to avoid spike peak in STD (false trigger the state changing)

ParkingStruct.State_count_threshDEMO         = uint16(2);    % reqiures 2 seconds to confirm the correct state (no car OR car parked)
ParkingStruct.State_count_thresh_timeoutDEMO = uint16(2);    % TIMEOUT: no state change in 2 secods - BACK TO LOW SPEED MODE
















07/05/2017
Algorithm Update: Aggressive Parking (one car pulls out and the second car pulls in immediately)

1. data rate in High speed mode = 8Hz
2. measure the mag data within 0.8seconds (ParkingStruct.ZdataWindowSize) to capture the vacant status during aggressive parking
3. notify SENtral the case of aggressive parking by set ParkingStruct.multipleCarsFLAG = 1
4. display the total number of cars have been parked @ ParkingStruct.NumCars






6/29/2017

using absolute mag value instead of relative diff mag to trigger strong magnet detection


condition:  current_mag >  ParkingStruct.StandbyMode_Trigger_thresh_SHIP






6/26/2017

change the knob name  (ParkingStruct.StandbyMode_Cnt    has been used in SENtral codes already )



ParkingStruct.StandbyMode_CntAlgo               = uint16(0);    %%% cnt used in algorithm, counts number of samples with mag value above 500uT

ParkingStruct.StandbyMode_Timeout               = uint16(4);    %%% strong magnet requires to be placed on the top of the sensor for 4 seconds







6/23/2017

Algorithm update: detection of strong magnet to get out of shipping mode without service tool

Goal: separate cases of using strong magnet or service tool

corner case: fail to using service tool, but still generate high enough mag data (>500)


using the counts to delay the FLAG update:  
counts the number of samples are higher than 500  (ParkingStruct.StandbyMode_Cnt)

update the FLAG (ParkingStruct.StandbyMode_FLAG) with 16 counts (timeout set at 4seconds  (ParkingStruct.StandbyMode_Timeout))












6/21/2017

Algorithm update: detection of strong magnet to get out of shipping mode without service tool

ParkingStruct.HS_Trigger_thresh_SHIP            = single(200);  % HS mode trigger threshold in shipping mode
ParkingStruct.StandbyMode_Trigger_thresh_SHIP   = single(500);  % strong magnet detection threshold in shipping mode 

ParkingStruct.StandbyMode_FLAG                  = uint8(0);     % 1 - detect strong magnet


delta-mag data > ParkingStruct.HS_Trigger_thresh_SHIP  ==>  ParkingStruct.StandbyMode_FLAG = 1 (notify SENtral of detecting strong magnet)











6/05/2017

Algorithm update
issue-1: false negative error caused by car event in nearby space (Jira Issue: PPX-52)   
ISSUE-2: tuning threshold setting on mag-Z_diff (z-axis mag change) (Jira Issue: PPX-94)


Knobs update:

issue-1:
add condition check with different level of MAG_threshold (difference between current mag with previous local baseline or initial baseline)

ParkingStruct.MAG_threshLevel1            = single(2.0);   % minus/plus range from initilized AVGInit or local baseline to check the correctness of the state
ParkingStruct.MAG_threshLevel3            = single(3.0);   % minus/plus range from initilized AVGInit or local baseline to check the correctness of the state


issue-2: 
add condition check with different level of  Z-axis mag changes 
level 1: 0- 4.0, 
level 2: 4.0-5.5, 
on level 2 condition, check X/Y - axis mag changes as well

ParkingStruct.HS_DatadiffZ_ThreshLevel1   = single(4.0);   % threshold on mag changes of Z-axis during HS mode 
ParkingStruct.HS_DatadiffZ_ThreshLevel2   = single(5.5);   % threshold on mag changes of Z-axis during HS mode
ParkingStruct.HS_DatadiffXY_ThreshLevel2  = single(10);    % threshold on mag changes of X or Y-axis during HS mode











5/10/2017

Algorithm update
issue: false car event detection in the case of door open/close, engine on/off of hybrid car 


add back condition check:

if ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    
   && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh2

               


      ParkingStruct.car_present            = uint8(3);



 





5/09/2017

Algorithm update
issue: false car event detection in the case of door open/close, engine on/off of hybrid car 


add condition check for HS_dataDiff_X, HS_dataDiff_Y for a loose condition check

ParkingStruct.MAG_threshUp2         = single(9);     %%%% (loose threshold)
ParkingStruct.MAG_thresh3           = single(4.0);   % minus/plus range from last state3 to check the correctness of the state (loose threshold)


ParkingStruct.HS_DataNdiff_Thresh   = single(5.5);   % threshold on mag changes of Z-axis during HS mode
ParkingStruct.HS_DataNdiff_Thresh2  = single(2);     % threshold on mag changes of X/Y -axis during HS mode


if ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh3...  
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh)                        
                
                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(6); 









4/19/2017

Algorithm update
issue: no car event detection when hybrid car back into the space

using HS_DataNdiff_Z  instead of HS_DataNdiff, threshold setting = 5

knob changes:



ParkingStruct.HS_DataNdiff_Thresh   = single(5);

ParkingStruct.MAG_thresh            = single(3);  
 
ParkingStruct.MAG_threshUp          = single(13);    



ParkingStruct.STD_threshUp          = single(1.5);   % 3

ParkingStruct.STD_threshDown        = single(0.5);



ParkingStruct.detection_threshUp    = single(1.5);

ParkingStruct.detection_threshDown  = single(0.5);











4/13/2017

Algorithm Update  
issue: no car event detection when hybrid car back into the space




threshold adjustment:


1. ParkingStruct.MAG_threshUp          = single(12);      %%% previously 15



2. ParkingStruct.STD_thresh2           = single(1.8);     %%%  previously 2.5
    
   ParkingStruct.detection_thresh2     = single(1.8);     %%%  previously 2




condition check in case of from state 1 to state 3:


1. sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp

2. ParkingStruct.HS_DataNdiff > ParkingStruct.HS_DataNdiff_Thresh

3. ParkingStruct.HS_STDmax > ParkingStruct.STD_thresh2 || ParkingStruct.HS_MAmax > ParkingStruct.detection_thresh2






In case of confidence level = 1 (ParkingStruct.SecondSensor_Req_FLAG   = uint8(1))
:
ParkingStruct.car_present2 = ParkingStruct.car_present;








4/11/2017

Algorithm Update: solving the failure caused by extra magnetic signal from hybrid car 


adding the following conditions check when trying to convert from state 3 (previous car state) into state 1 (current estimated car state)

1. checking the number of mag data that passing STD threshold or MA threshold         
   (number of samples needs to > 2)

2. checking the difference between current mag data and previous mag data in state 3  
   (difference needs to > 2.5uT)











4/10/2017

1. Adding pattern E 
ParkingStruct.BLE_Trigger_PatternE      = uint8([1 0 0 0 1 0 1 1 0 0 1 0]);

ParkingStruct.BLE_Trigger_FLAG          = uint8(6);






4/05/2017

Threshold adjustments for environmental changes when hourly RTC temperature data received

1. SENtral will write "5" as context input when temperature data received and current in LS mode (no car event)
2. threshold for triggering next HS mode will be updated based on current mag data
3. local baseline will be update if 
     ParkingStruct.LocalBaseline_Update_Enable        = uint8(1);
   AND current in no car state












4/04/2017

1. add pre-pattern [1 1 0 0] 
2. actual wake up pattern matching process will be handled only after pre-pattern has been recognized
3. when pre-pattern is recognized, reset "ParkingStruct.BLE_Trigger_Buffer" 






4/04/2017

1. pattern update:  12-bit, adding "0" to previous 11-bit pattern

2. ParkingStruct.BLE_Trigger_FLAG          = uint8(7);   %  when no pattern matched after 5 high-bit shows up in first 11-bit








4/03/2017

1. algorithm update with 4 patterns

2. 4th pattern used for enable shipping mode












3/29/2017

1. algorithm update for 11-bit wake up pattern (3 patterns)


2. disable pattern matching process once detected 5 high-bit (1 in BLE_Trigger_Buffer) and not matching any pattern


3. re-enable pattern matching process after one event detection cycle and back to low speed mode, and re-entering to high speed mode












3/23/2017

1) removal of BLE_trigger_mode = 0 (trigger by 1-bit)
2) try to fix false positive error caused by car parked next to it

adding checking condition of difference between max and min mag magnitude values during transition stage (when previous state @ 1 and estimated current state @ 3)
--
try to reduce the potential false positive error


when current state comes to 1, no addtional check. (try to get accurate state on empty space at all time)







2/15/2017

1) start @ normal operation mode
   
shippingMode_FLAG = 0
ShippingMode_InitFLAG = 0

LS_Trigger_FLAG = 0  (start @ HS mode for calibration)

Calibration_FLAG = 0  (enable calibration, start @ operation mode with calibration)
Calibration_InitFLAG = 0



2) manually enforce into SHIPPING MODE by reset "shippingMode_FLAG = 1"

3) two wake-up patterns:
	pattern A: one time use only, unless reset FLAG from ParamIO
	pattern B: normal wake-up pattern

4) parking algorithm only handles pattern recognition and car detection, all state machine (in/out shipping mode, in/out operation mode) are handled inside of SENtral







2/9/2017

1> add shipping mode and standby mode (5seconds after wake-up, in order to smooth transition between shipping mode and normal operation mode)

2> wake-up pattern:
1. 1-bit wake up by strength
2. multi-bit wake up by pattern


3> FLAG (ParkingStruct.ShippingMode_FLAG) for manually re-enter into shipping mode






2/6/2017

Jira: PEK-2
Change the mag wake-up bit pattern from "1001010" to "100010110".






2/2/2017

testing on new threshold setting 


car state machine update for algo1, phase based algorithm

threshold change:  ParkingStruct.detection_thresh        = single(2);









car state machine:

case of STD > STD_threshold: transition from state 1 or 3 into state 2 or 4


decision made based on the current detected car state and last car state in previous LS mode:

1. if current car state == last car state in previous LS mode, then  state 1 --> 2, or state 3 -->4

2. if current car state ~= last car state in previous LS mode, then  state 1 --> 4, or state 3 -->2    (assuming the current car state is false)









HS-trigger_threshold ==3


%%%% updated on 2/1/2017
ParkingStruct.STD_thresh          = single(2.5);   % 3
ParkingStruct.MAG_thresh          = single(2.5);   % 3  % minus/plus range from initilized AVGInit to check the correctness of the state
ParkingStruct.MAG_threshUp        = single(10);
ParkingStruct.MAG_thresh2         = single(7);

ParkingStruct.SecondSensor_Req_FLAG_count = uint8(0);
ParkingStruct.SecondSensor_Req_FLAG_countMAX = uint8(2);



also updating on two algorithm not generting same state, wait for next 2 seconds for 2nd round










