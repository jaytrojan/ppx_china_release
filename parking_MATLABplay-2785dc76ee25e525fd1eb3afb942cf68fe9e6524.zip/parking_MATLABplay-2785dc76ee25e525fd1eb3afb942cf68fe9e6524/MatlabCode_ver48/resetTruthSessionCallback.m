function resetTruthSessionCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global dataInfo plotInfo cntrlInfo

% reset truth to truth_state_load state

truth_state_load = dataInfo.truth_state_load;
dataInfo.truth_state = truth_state_load;

plotInfo.hTruthStateLine.YData = truth_state_load(:,1);

% update slider
if isfield(cntrlInfo,'BrushData') && ~isempty(cntrlInfo.BrushData)
    currentTruth = truth_state_load(logical(cntrlInfo.BrushData),1);
    if ~isempty(currentTruth)
        setVal = currentTruth(1);
        setVal = round(setVal);
        cntrlInfo.sld.Value = setVal;
        cntrlInfo.sldText.String = num2str(setVal);
    end
end



% % adjust all current brush data to slider value
% currentTruth = dataInfo.truth_state(logical(cntrlInfo.BrushData),1);
% 
% if ~isempty(currentTruth)
%     
%     % set slider to first value
%     setVal = cntrlInfo.sld.Value;
%     
%     setVal = round(setVal);
%     cntrlInfo.sld.Value = setVal;
%     cntrlInfo.sldText.String = num2str(setVal);
%     
%     % make all selected truth match slider
%     hTruthStateLine.YData(logical(cntrlInfo.BrushData)) = setVal;
%     dataInfo.truth_state(logical(cntrlInfo.BrushData),1) = setVal;
% 
% end

