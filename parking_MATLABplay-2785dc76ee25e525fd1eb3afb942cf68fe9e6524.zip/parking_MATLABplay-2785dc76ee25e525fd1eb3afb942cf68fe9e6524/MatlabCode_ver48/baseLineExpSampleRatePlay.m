% baseline exp moving average sample rate adjustment

N = 100;
testSig0 = [zeros(N,3);  ones(N,3);  10*ones(N,3);  zeros(N,3);  -ones(N,3)];
N = size(testSig0,1);

dt=1/8;
t0 = (0:dt:(N-1)*dt)';


filtStruct = stableFilt_struct_init;
baseFilt = filtStruct.baseFilt;

% %% init
% if baseFilt.initFilt
%     baseFilt.dfiltS.dataFilt = data;
%     baseFilt.dfiltwS.dataFilt = data;
%     baseFilt.baseLineMeas = data;
%     baseFilt.initFilt = uint8(0);
% end
% dfiltwS_dataFilt_prev = baseFilt.dfiltwS.dataFilt;


%% exp moving stats calc
% average
alpha0 = baseFilt.alpha;

t1 = t0;
testSig1 = testSig0;
N = size(testSig1,1);

alpha = alpha0;
dataFiltAy = zeros(N,3);
dataVarAy = zeros(N,3);
dataVarFiltAy = zeros(N,3);
for ii=1:N
    data = testSig1(ii,:);
    beta = 1-alpha;
    baseFilt.dfiltS.data = data;
    baseFilt.dfiltS = expStatCalcS(baseFilt.dfiltS,alpha,beta);
    dataFiltAy(ii,:) = baseFilt.dfiltS.dataFilt;
    dataVarAy(ii,:) = baseFilt.dfiltS.dataVar;
    dataVarFiltAy(ii,:) = baseFilt.dfiltS.dataVarFilt;
end
dataFiltAy1 = dataFiltAy;

figure(7); clf
plot(t1,testSig1,'--'); hold all
plot(t1,dataFiltAy1,'-','LineWidth',2)
% plot(t2,testSig2,':'); hold all
% plot(t2,dataFiltAy2,'--','LineWidth',2)
grid on
xlabel('sec')

% downsample to 4 hz with different alphas
alpha = alpha0;

for alpha = 0.72:0.0025:0.74
    disp(alpha)
    t2 = t0(1:2:end,:);
    testSig2 = testSig0(1:2:end,:);
    N = size(testSig2,1);
    dataFiltAy = zeros(N,3);
    dataVarAy = zeros(N,3);
    dataVarFiltAy = zeros(N,3);
    for ii=1:N
        data = testSig2(ii,:);
        beta = 1-alpha;
        baseFilt.dfiltS.data = data;
        baseFilt.dfiltS = expStatCalcS(baseFilt.dfiltS,alpha,beta);
        dataFiltAy(ii,:) = baseFilt.dfiltS.dataFilt;
        dataVarAy(ii,:) = baseFilt.dfiltS.dataVar;
        dataVarFiltAy(ii,:) = baseFilt.dfiltS.dataVarFilt;
    end
    dataFiltAy2 = dataFiltAy;
    
    figure(7);
%     plot(t1,testSig1,':'); hold all
%     plot(t1,dataFiltAy1,'-','LineWidth',2)
    plot(t2,testSig2,':'); hold all
    plot(t2,dataFiltAy2,'--','LineWidth',2)
    grid on
    xlabel('sec')
    pause
end

% beta = dt/T % where T = timeconstant to 63%
T = dt/0.15;


% dynamic alpha
Tconstant = 0.83333;
sRate = 2; %ParkingStruct.LS_rate;
dt = 1/single(sRate);
beta = dt/Tconstant;




