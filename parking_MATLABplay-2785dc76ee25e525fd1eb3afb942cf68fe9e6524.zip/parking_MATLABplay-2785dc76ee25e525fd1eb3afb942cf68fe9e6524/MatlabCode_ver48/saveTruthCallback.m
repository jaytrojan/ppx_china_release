function saveTruthCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global dataInfo

% save current dataInfo states for current file


fName = dataInfo.fileName;
[pathstr,fileName,ext] = fileparts(fName);

pName = dataInfo.pathName;
% % % % [FileName,PathName] = uiputfile([pName fileName '_states.mat']);
% % % [FileName,PathName] = uiputfile([pName fileName '.mat']);
% % % 
% % % % .mat should already exists. dataInfo field is replaced if already present
% % % save([PathName FileName],'dataInfo','-append')

try
    save([pName fileName '.mat'],'dataInfo','-append')
    disp('Meta Data Updated')
catch
    disp('>>> Meta Data Save Error <<<')
end

% % adjust all current brush data to slider value
% currentTruth = dataInfo.truth_state(logical(cntrlInfo.BrushData),1);
% 
% if ~isempty(currentTruth)
%     
%     % set slider to first value
%     setVal = cntrlInfo.sld.Value;
%     
%     setVal = round(setVal);
%     cntrlInfo.sld.Value = setVal;
%     cntrlInfo.sldText.String = num2str(setVal);
%     
%     % make all selected truth match slider
%     hTruthStateLine.YData(logical(cntrlInfo.BrushData)) = setVal;
%     dataInfo.truth_state(logical(cntrlInfo.BrushData),1) = setVal;
% 
% end

