function [ParkingStruct, filtStruct] = Calibration_process(ParkingStruct, filtStruct, data)

ParkingStruct.Calibration_Counter  = ParkingStruct.Calibration_Counter + uint16(1);


data1                              = single(data);
ParkingStruct.AVGSUM2              = ParkingStruct.AVGSUM2  + data1 ;


% % % data1                              = single(sqrt(data1(1)*data1(1)+data1(2)*data1(2)+data1(3)*data1(3)));
% % % ParkingStruct.AVGSUM               = ParkingStruct.AVGSUM   + data1 ;



%%% update 2/10/2017
%%% values for cloud algorithm

% % max-min mag data
% if data1 > ParkingStruct.HS_DataNMax
%     ParkingStruct.HS_DataNMax            = data1;
% end
%
% if data1 < ParkingStruct.HS_DataNMin
%     ParkingStruct.HS_DataNMin            = data1;
% end



% % % % max-min mag data on X/Y/Z
% % % for i = 1:3
% % %     if single(data(i)) > ParkingStruct.HS_DataMax(i)
% % %         ParkingStruct.HS_DataMax(i)            = single(data(i));
% % %     end
% % %
% % %     if single(data(i)) < ParkingStruct.HS_DataMin(i)
% % %         ParkingStruct.HS_DataMin(i)            = single(data(i));
% % %     end
% % % end
% % %
% % %
% % %
% % % % STD
% % % if ParkingStruct.K2 < ParkingStruct.dataBufferSize - uint8(1)
% % %
% % %     ParkingStruct.K2 = ParkingStruct.K2 + uint8(1);
% % %
% % %     ParkingStruct.SUM         = ParkingStruct.SUM   + data1 ;             % sum
% % %     ParkingStruct.SUMSq       = ParkingStruct.SUMSq + data1 * data1;      % sum square
% % %
% % %
% % %     if ParkingStruct.K2 == uint8(1)
% % %         ParkingStruct.STD = single(0);
% % %     else
% % %         ParkingStruct.STD = sqrt(abs(ParkingStruct.SUMSq -ParkingStruct.SUM*ParkingStruct.SUM/single(ParkingStruct.K2))...
% % %             /(single(ParkingStruct.K2 - uint8(1))));
% % %     end
% % %
% % % else
% % %     ParkingStruct.STD = Parking_std(ParkingStruct.dataBuffer,ParkingStruct.dataBufferSize);
% % % end
% % %
% % %
% % %
% % % if ParkingStruct.STD > ParkingStruct.HS_STDmax
% % %     ParkingStruct.HS_STDmax  = ParkingStruct.STD;
% % % end





if ParkingStruct.Calibration_Counter == ParkingStruct.Calibration_Timeout * ParkingStruct.HS_rate

%     if ParkingStruct.Context_Input == uint8(1)
%
%         ParkingStruct.AVGInit_User          = ParkingStruct.AVGSUM  / single(ParkingStruct.Calibration_Counter);
%         ParkingStruct.AVGInit2_User         = ParkingStruct.AVGSUM2 / single(ParkingStruct.Calibration_Counter);
%
%     elseif ParkingStruct.Context_Input == uint8(99)
%
%         ParkingStruct.AVGInit_Factory       = ParkingStruct.AVGSUM  / single(ParkingStruct.Calibration_Counter);
%         ParkingStruct.AVGInit2_Factory      = ParkingStruct.AVGSUM2 / single(ParkingStruct.Calibration_Counter);
%
%     end



% % %     ParkingStruct.AVGInit          = ParkingStruct.AVGSUM  / single(ParkingStruct.Calibration_Counter);
    ParkingStruct.AVGInit2         = ParkingStruct.AVGSUM2 / single(ParkingStruct.Calibration_Counter);

    % init local average to cal baseline as reference for next HS

    % init stable filt buffer with cal value






    ParkingStruct.Calibration_FLAG            = uint8(1);   % calibration process finished

    ParkingStruct.Calibration_InitFLAG        = uint8(0);

    ParkingStruct.LS_Trigger_FLAG             = uint8(1);    % trigger the Alarm: back to low speed mode

    ParkingStruct.SecondSensor_Req_FLAG       = uint8(0);    %%% reset confidence level

    ParkingStruct.Context_Input               = uint8(0);

    ParkingStruct.Reset_FLAG                  = uint8(0);


    ParkingStruct.LS_StartValue               = ParkingStruct.AVGInit2;
    ParkingStruct.LS_StartValue_state1        = ParkingStruct.LS_StartValue;
    ParkingStruct.LS_StartValue_state3        = zeros(1,3,'single');


    % reset
    ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct) ;


    %%% Reset Mag State History Filters to Cal field
    % assumes already in car empty state
    filtStruct.ihist1 = uint8(0);
    Nhist = size(filtStruct.mhiststate1,1);
    filtStruct.mhisttime1 = zeros(Nhist,1,'single'); % should be uint32
    filtStruct.mhiststate1 = zeros(Nhist,3,'single');
    filtStruct.ihist1 = filtStruct.ihist1+1;
    filtStruct.mhiststate1(filtStruct.ihist1,:) = ParkingStruct.AVGInit2;
    filtStruct.mhisttime1(filtStruct.ihist1,:) = ParkingStruct.time;
    ParkingStruct.car_presentPersist = ParkingStruct.car_present;



    %%% Car Counting
    ParkingStruct.NumCars                           = uint16(0);
    ParkingStruct.NumCarsPre                        = uint16(0);
    ParkingStruct.multipleCarsFLAG                  = uint8(0);
    
    ParkingStruct.NumCars_DriveThru                 = uint16(0);
    ParkingStruct.NumCars_DriveThruPre              = uint16(0);
    ParkingStruct.multipleCarsFLAG_DriveThru        = uint8(0);


end


