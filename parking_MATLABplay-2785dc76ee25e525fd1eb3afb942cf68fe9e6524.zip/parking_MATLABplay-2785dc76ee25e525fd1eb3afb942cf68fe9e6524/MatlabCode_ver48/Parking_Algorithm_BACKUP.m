function ParkingStruct = Parking_Algorithm_BACKUP(ParkingStruct, data)
% 

ParkingStruct.car_presentPre   = ParkingStruct.car_presentCur; 
ParkingStruct.car_presentPre2  = ParkingStruct.car_presentCur2; 


data1                          = single(data);
ParkingStruct.dataBuffer2      = shifting_array(ParkingStruct.dataBuffer2);
ParkingStruct.dataBuffer2(ParkingStruct.dataBufferSize,:)= data1;



data1                         = single(sqrt(data1(1)*data1(1)+data1(2)*data1(2)+data1(3)*data1(3)));
ParkingStruct.dataBuffer      = shifting_array(ParkingStruct.dataBuffer);
ParkingStruct.dataBuffer(end) = data1;



% max-min mag data on X/Y/Z
for i = 1:3
    if single(data(i)) > ParkingStruct.HS_DataMax(i)
        ParkingStruct.HS_DataMax(i)            = single(data(i));
    end

    if single(data(i)) < ParkingStruct.HS_DataMin(i)
        ParkingStruct.HS_DataMin(i)            = single(data(i));
    end
end




% % max-min mag data on magnitude of X+Y+Z
% if data1 > ParkingStruct.HS_DataNMax
%     ParkingStruct.HS_DataNMax            = data1;
% end
% 
% if data1 < ParkingStruct.HS_DataNMin
%     ParkingStruct.HS_DataNMin            = data1;
% end












if abs(data1 - single(sqrt(ParkingStruct.LS_StartValue(1)*ParkingStruct.LS_StartValue(1)...
        +ParkingStruct.LS_StartValue(2)*ParkingStruct.LS_StartValue(2) ...
        +ParkingStruct.LS_StartValue(3)*ParkingStruct.LS_StartValue(3)))) >= ParkingStruct.BLE_Trigger_thresh

        ParkingStruct.BLE_Trigger_FLAG       = uint8(1);
else

        ParkingStruct.BLE_Trigger_FLAG       = uint8(0);  
end





%%%%%% update on 6/21/17 (Jira: PMG-97)
%%%%%%%%%%%%%%%%%%%%% using strong magnet and BLE to get out of shipping mode
%%%% detect strong magnet in shipping mode


%%%% the strong magnet requires to be placed on the top of sensor for at least 4seconds (ParkingStruct.StandbyMode_Timeout), 
%%%% total number of samples that mag value above threshold (500uT) needs to be 16 (4seconds data) 

% if (abs(data1 - single(sqrt(ParkingStruct.LS_StartValue(1)*ParkingStruct.LS_StartValue(1)...
%         +ParkingStruct.LS_StartValue(2)*ParkingStruct.LS_StartValue(2) ...
%         +ParkingStruct.LS_StartValue(3)*ParkingStruct.LS_StartValue(3)))) >= ParkingStruct.StandbyMode_Trigger_thresh_SHIP) ...
%     && ParkingStruct.ShippingMode_FLAG        == uint8(1)

%%%%% using absolute mag value instead of relative diff mag to trigger strong magnet detection
if data1 >= ParkingStruct.StandbyMode_Trigger_thresh_SHIP ...
    && ParkingStruct.ShippingMode_FLAG        == uint8(1)

        
        ParkingStruct.StandbyMode_CntAlgo          = ParkingStruct.StandbyMode_CntAlgo + uint16(1);
        
        
        if ParkingStruct.StandbyMode_CntAlgo >= ParkingStruct.StandbyMode_Timeout * ParkingStruct.HS_rate
            
            ParkingStruct.StandbyMode_FLAG             = uint8(1);
        
            % reset
            
            ParkingStruct.StandbyMode_CntAlgo              = uint16(0);            
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);   
            
            ParkingStruct.LS_Trigger_FLAG              = uint8(1);    % trigger the Alarm: back to low speed mode     
            
            ParkingStruct.BLE_Trigger_Buffer           = zeros(12,1,'uint8');             
            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);                                 
            ParkingStruct.BLE_Trigger_FLAG             = uint8(0);  
            
        end
end
%%%%%%%%%%%%%%%%%%%%%

    
    

%%%%%%%%%%%%  pattern matching process
if ParkingStruct.BLE_Trigger_Enable
    
    

    ParkingStruct.BLE_Trigger_Buffer      = shifting_array(ParkingStruct.BLE_Trigger_Buffer);
    ParkingStruct.BLE_Trigger_Buffer(end) = ParkingStruct.BLE_Trigger_FLAG;
        
    
    match_flagPre = pattern_comparison(ParkingStruct.BLE_Trigger_PatternPre,ParkingStruct.BLE_Trigger_Buffer(end-3:end));
    
    %%%%% reset BLE_Trigger_Buffer when pre-pattern has been detected 
    if match_flagPre == uint8(1) && ParkingStruct.BLE_Trigger_PatternPre_FLAG  == uint8(0)
        
        ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(1);
        
        ParkingStruct.BLE_Trigger_FLAG     = uint8(0);  
        ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8'); 
    end
    
    
    
    %%%%% wake up pattern matching only when pre-pattern (1 1 0 0) has
    %%%%% been recognized (ParkingStruct.BLE_Trigger_PatternPre_FLAG = 1)
    if ParkingStruct.BLE_Trigger_PatternPre_FLAG
        
        match_flagA=pattern_comparison(ParkingStruct.BLE_Trigger_PatternA,ParkingStruct.BLE_Trigger_Buffer);

        if match_flagA == uint8(1)         

            ParkingStruct.BLE_Trigger_FLAG     = uint8(2);  
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8'); 
            
            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;  
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;    

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);   

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode
            
            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet   
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT   

            
%             %%% values for cloud algorithm    
%             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;    

            ParkingStruct.LastTransitionState2 = uint8(6); 

        end    


        %%% update 2/13
        % 2nd pattern   % patternA should only be matched one time at beginning, unless reset FLAG
        match_flagB=pattern_comparison(ParkingStruct.BLE_Trigger_PatternB,ParkingStruct.BLE_Trigger_Buffer);
        if match_flagB == uint8(1)
            ParkingStruct.BLE_Trigger_FLAG     = uint8(3);  
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');
            
            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;  
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;    

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct); 

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode 
            
            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet   
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT   
            
            

%             %%% values for cloud algorithm    
%             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;    

            ParkingStruct.LastTransitionState2 = uint8(6);      

        end 




        %%% update 3/27
        % 3rd pattern   
        match_flagC=pattern_comparison(ParkingStruct.BLE_Trigger_PatternC,ParkingStruct.BLE_Trigger_Buffer);
        if match_flagC == uint8(1)
            ParkingStruct.BLE_Trigger_FLAG     = uint8(4);  
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');  
            
            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;  
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;    

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct); 

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode  
            
            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet   
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT    
            
            

%             %%% values for cloud algorithm    
%             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;    

            ParkingStruct.LastTransitionState2 = uint8(6);  

        end    



        %%% update 4/3
        % 4th pattern   
        match_flagD=pattern_comparison(ParkingStruct.BLE_Trigger_PatternD,ParkingStruct.BLE_Trigger_Buffer);
        if match_flagD == uint8(1)
            ParkingStruct.BLE_Trigger_FLAG     = uint8(5);  
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');  
            
            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;  
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;    

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct); 

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode  
            
            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet   
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT  
            
            

%             %%% values for cloud algorithm    
%             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;    

            ParkingStruct.LastTransitionState2 = uint8(6);  

        end  



        %%% update 4/10
        % 5th pattern   
        match_flagE=pattern_comparison(ParkingStruct.BLE_Trigger_PatternE,ParkingStruct.BLE_Trigger_Buffer);
        if match_flagE == uint8(1)
            ParkingStruct.BLE_Trigger_FLAG     = uint8(6);  
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');  
            
            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;  
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;    

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct); 

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode  
            
            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet   
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT   
            
            

%             %%% values for cloud algorithm    
%             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;    

            ParkingStruct.LastTransitionState2 = uint8(6);  

        end 
        
        
        
        

        %%% update 3/27
        % lock up the matching process until next time entering from LS mode    
        if match_flagA == uint8(0) && match_flagB == uint8(0) && match_flagC == uint8(0) && match_flagD == uint8(0) && match_flagE == uint8(0) && sum(ParkingStruct.BLE_Trigger_Buffer(1:11)) == uint8(5) %%% && ParkingStruct.BLE_Trigger_Buffer(end) == uint8(0)  


            ParkingStruct.BLE_Trigger_FLAG          = uint8(7);  
            ParkingStruct.BLE_Trigger_Buffer        = zeros(12,1,'uint8'); 
            
            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);

            ParkingStruct.BLE_Trigger_Enable        = uint8(0);  


        end        
        
    end   
            
end  %%%% end of pattern matching process









if ParkingStruct.LS_Trigger_FLAG      == uint8(0) 


%% **************  Phase based Algorithm  (feature: moving average)**************************



%setup bias or calc avg.
if(ParkingStruct.local_avg == single(0))
    
   ParkingStruct.local_avg      = data1;   
   
else
    %take local average
    ParkingStruct.local_avg    = ParkingStruct.filter_alpha*ParkingStruct.local_avg    + ParkingStruct.filter_beta*data1;
end

% ****** FEATURE: DIFFERENCE between current mag and previous mag *********
ParkingStruct.dx_history      = shifting_array(ParkingStruct.dx_history);
ParkingStruct.dx_history(end) = single(abs(data1 - ParkingStruct.local_avg));


%get new moving average, compare to last, set new
if ParkingStruct.dx_history(1) > single(0)

    ParkingStruct.moving_avg    = mean(ParkingStruct.dx_history);
    
else
    
    ParkingStruct.moving_avg    = ParkingStruct.dx_history(end);
    
end


%%% update 2/6/2017
%%% values for cloud algorithm
% max-min MA data (magnitude(X+Y+Z))
if ParkingStruct.moving_avg > ParkingStruct.HS_MAmax
    ParkingStruct.HS_MAmax  = ParkingStruct.moving_avg;   
end




if ParkingStruct.moving_avg < ParkingStruct.detection_threshUp    %%%%ParkingStruct.detection_thresh
    
    
    % Previous STATE:  State 1- no car 
    if ParkingStruct.car_present2   == uint8(1)  %% NO CAR STATE  -- CALCULATE the baseline mean & STD value
        
        ParkingStruct.state1_count2  = ParkingStruct.state1_count2 + uint16(1);
                     
        
               
     % Previous STATE:  State 2 - Car In   
     elseif ParkingStruct.car_present2   == uint8(2)   
         
         
        if ParkingStruct.state2_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate 
            
            ParkingStruct.car_present2   = uint8(3);              
            ParkingStruct.state3_count2  = uint16(1);
            
            
            ParkingStruct.state1_count2  = uint16(0);
            ParkingStruct.state2_count2  = uint16(0);
            ParkingStruct.state4_count2  = uint16(0);                
                            
        else
             
            ParkingStruct.state2_count2 = ParkingStruct.state2_count2 + uint16(1);
        end
        
        
    % Previous STATE:  State 3 - Car Parked    
    elseif ParkingStruct.car_present2   == uint8(3)
       
        
        ParkingStruct.state3_count2 = ParkingStruct.state3_count2 + uint16(1);
        
        
        
    % Previous STATE:  State 4 - Car Out     
    elseif ParkingStruct.car_present2   == uint8(4)    
        
        if ParkingStruct.state4_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate
        
            ParkingStruct.car_present2   = uint8(1);               
            ParkingStruct.state1_count2  = uint16(1);
            
            
            ParkingStruct.state2_count2  = uint16(0);
            ParkingStruct.state3_count2  = uint16(0);
            ParkingStruct.state4_count2  = uint16(0);                              
            
        else
            
            ParkingStruct.state4_count2  = ParkingStruct.state4_count2 + uint16(1);
            
        end
                     
    end
    
    
    
    
% elseif ParkingStruct.moving_avg > ParkingStruct.detection_threshUp
else    
    
    ParkingStruct.TransitionState_count2        = ParkingStruct.TransitionState_count2 + uint16(1);
    
    % Previous STATE:  State 1 - No Car 
    if ParkingStruct.car_present2   == uint8(1)
        
        if ParkingStruct.LS_TO_HS_FLAG2

            ParkingStruct.car_present2   = uint8(2); 
            ParkingStruct.state2_count2  = uint16(1);

            ParkingStruct.state1_count2  = uint16(0);
            ParkingStruct.state3_count2  = uint16(0);
            ParkingStruct.state4_count2  = uint16(0);             
            
            ParkingStruct.LS_TO_HS_FLAG2 = uint8(0);
            

        else

%            if ParkingStruct.state1_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate
           if ParkingStruct.car_present2 == ParkingStruct.Car_State_last_HS               
               
               
               
                ParkingStruct.car_present2   = uint8(2); 
                ParkingStruct.state2_count2  = uint16(1);

                ParkingStruct.state1_count2  = uint16(0);
                ParkingStruct.state3_count2  = uint16(0);
                ParkingStruct.state4_count2  = uint16(0);             

           else

                ParkingStruct.car_present2    = uint8(4);
                ParkingStruct.state4_count2   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                ParkingStruct.state1_count2   = uint16(0);
                ParkingStruct.state2_count2   = uint16(0);
                ParkingStruct.state3_count2   = uint16(0);             

           end

        end
        
    elseif ParkingStruct.car_present2    == uint8(2)
        
        ParkingStruct.car_present2   = uint8(2);        
        ParkingStruct.state2_count2  = ParkingStruct.state2_count2 + uint16(1);
        
        
        ParkingStruct.state1_count2  = uint16(0);
        ParkingStruct.state3_count2  = uint16(0);
        ParkingStruct.state4_count2  = uint16(0);                  
        
        
        
                
    elseif ParkingStruct.car_present2    == uint8(3)
        
        
        if ParkingStruct.LS_TO_HS_FLAG2   
            
            ParkingStruct.car_present2    = uint8(4);
            ParkingStruct.state4_count2   = uint16(1);
            
            ParkingStruct.state1_count2   = uint16(0);
            ParkingStruct.state2_count2   = uint16(0);
            ParkingStruct.state3_count2   = uint16(0);  
            
            ParkingStruct.LS_TO_HS_FLAG2  = uint8(0);
            
            
        else
            
        
%             if ParkingStruct.state3_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate
            if ParkingStruct.car_present2 == ParkingStruct.Car_State_last_HS    

                ParkingStruct.car_present2    = uint8(4);
                ParkingStruct.state4_count2   = uint16(1);

                ParkingStruct.state1_count2   = uint16(0);
                ParkingStruct.state2_count2   = uint16(0);
                ParkingStruct.state3_count2   = uint16(0);              


            else

                ParkingStruct.car_present2    = uint8(2);
                ParkingStruct.state2_count2   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                ParkingStruct.state1_count2   = uint16(0);
                ParkingStruct.state3_count2   = uint16(0);
                ParkingStruct.state4_count2   = uint16(0);                            

            end
            
        end
        
    elseif ParkingStruct.car_present2    == uint8(4)
        
        ParkingStruct.car_present2   = uint8(4);        
        ParkingStruct.state4_count2  = ParkingStruct.state4_count2 + uint16(1);  
        
        
        ParkingStruct.state1_count2  = uint16(0);
        ParkingStruct.state3_count2  = uint16(0);
        ParkingStruct.state2_count2  = uint16(0);         
        

    end
    
    
    
% else
%     
%     % Previous STATE:  State 1 - No Car 
%     if ParkingStruct.car_present2   == uint8(1)
%         
%         ParkingStruct.state1_count2  = uint16(0);
%         ParkingStruct.state3_count2  = uint16(0);
%         
%     elseif ParkingStruct.car_present2   == uint8(3)
%         
%         ParkingStruct.state1_count2  = uint16(0);
%         ParkingStruct.state3_count2  = uint16(0);
%         
%     end    
    
    
        
end




    

    
    
FLAG = uint8(1);
ParkingStruct.car_presentBufferCount = zeros(4,1,'uint8');

ParkingStruct.car_presentBuffer2      = shifting_array(ParkingStruct.car_presentBuffer2);
ParkingStruct.car_presentBuffer2(end) = ParkingStruct.car_present2;



for i = 1:4

    ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) =  ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) + uint8(1);

    if ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) == uint8(3)

        ParkingStruct.car_presentCur2  = ParkingStruct.car_presentBuffer2(i);
        FLAG = uint8(0);
        break;        
    end
end


if FLAG    
    ParkingStruct.car_presentCur2  = ParkingStruct.car_presentPre2;
end









%% **************  Absolute MAG based Algorithm  (feature: STD)**************************



if ParkingStruct.K2 < ParkingStruct.dataBufferSize - uint8(1)
    
    ParkingStruct.K2 = ParkingStruct.K2 + uint8(1);
    
    ParkingStruct.SUM         = ParkingStruct.SUM   + data1 ;             % sum
    ParkingStruct.SUMSq       = ParkingStruct.SUMSq + data1 * data1;      % sum square  
    
%     ParkingStruct.AVG         = ParkingStruct.SUM / single(ParkingStruct.K2);
%     ParkingStruct.RMS         = sqrt(ParkingStruct.SUMSq / single(ParkingStruct.K2));
    
        
    if ParkingStruct.K2 == uint8(1)
        
        ParkingStruct.STD      = single(0);  
        
        ParkingStruct.STDz     = single(0);
        
    else
        
        ParkingStruct.STD = sqrt(abs(ParkingStruct.SUMSq -ParkingStruct.SUM*ParkingStruct.SUM/single(ParkingStruct.K2))...
            /(single(ParkingStruct.K2 - uint8(1)))); 
        
        
        ParkingStruct.STDz = Parking_std(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize - ParkingStruct.K2 + uint8(1)):ParkingStruct.dataBufferSize,3),ParkingStruct.K2);
               
    end
    
else
    
    ParkingStruct.STD = Parking_std(ParkingStruct.dataBuffer,ParkingStruct.dataBufferSize);
    
    ParkingStruct.STDz= Parking_std(ParkingStruct.dataBuffer2(:,3),ParkingStruct.dataBufferSize);
    
%     ParkingStruct.AVG = mean(ParkingStruct.dataBuffer);        
%     ParkingStruct.RMS = sqrt(mean(ParkingStruct.dataBuffer.* ParkingStruct.dataBuffer));
    
end



% 
% % ^^^^^ save the RMS value for no car state 
% if ParkingStruct.RMSFLAG == uint8(0) && ParkingStruct.car_present2 == uint8(1) ...
%         && ParkingStruct.car_presentCur2 == uint8(1) && ParkingStruct.Car_State_last_HS == uint8(3)
%     
%     ParkingStruct.RMSBuffer      = shifting_array(ParkingStruct.RMSBuffer); 
%     ParkingStruct.RMSBuffer(end) = ParkingStruct.RMS;
%     
%     
%     ParkingStruct.AVGBuffer      = shifting_array(ParkingStruct.AVGBuffer); 
%     ParkingStruct.AVGBuffer(end) = ParkingStruct.AVG;   
%     
%     ParkingStruct.RMSFLAG        = uint8(1);
%     
% end





%%% values for cloud algorithm

% max-min STD data (magnitude of X+Y+Z)
if ParkingStruct.STD > ParkingStruct.HS_STDmax
    ParkingStruct.HS_STDmax  = ParkingStruct.STD;  
end






if ParkingStruct.STD < ParkingStruct.STD_threshDown     %%%%ParkingStruct.STD_thresh   %% no car or car occupied
    
    
    % Previous STATE:  State 1- no car 
    if ParkingStruct.car_present   == uint8(1)  %% NO CAR STATE  -- CALCULATE the baseline mean & STD value
        
        ParkingStruct.state1_count  = ParkingStruct.state1_count + uint16(1);
         
        
        % checking in the proposed no car state, the absolute mag is in the initilized mag range
        % if current MEAN of mag is not in the init range, jump to state 3 (car occupied)
        if ParkingStruct.state1_count == ParkingStruct.State_count_thresh * ParkingStruct.HS_rate 
            
            
            ParkingStruct.HS_Datadiff            = ParkingStruct.HS_DataMax - ParkingStruct.HS_DataMin;                       
            ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);  %%% reset confidence level
            
            
            ParkingStruct.HS_Datadiff_baseline1  = abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1);
            

            
            

            %%%% case of previous car state is 3(with car), current estimated state will go to state 1 (no car), 
            %%%% therefore should include at least one transition in the middle
            %%%% so adding condition check for transition (check the diff on max and min mag data)
            if ParkingStruct.Car_State_last_HS      == uint8(1) ...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp ...
                    && ParkingStruct.HS_Datadiff(3) > ParkingStruct.HS_DataNdiff_Thresh ...   
                    && (ParkingStruct.HS_STDmax > ParkingStruct.STD_threshUp || ParkingStruct.HS_MAmax > ParkingStruct.detection_threshUp)
                
               ParkingStruct.car_present            = uint8(3); 
               
               
            elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp  
                
               ParkingStruct.car_present            = uint8(3); 
               

               
            elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh2
                
               ParkingStruct.car_present            = uint8(3);   
               
               
               
            elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp2 ...
                        || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh3)... 
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh)
                
               ParkingStruct.car_present            = uint8(3);     
               
               
               
            elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && ParkingStruct.HS_totalTimeLS < ParkingStruct.HS_totalTimeLS_thresh...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp3
                
                ParkingStruct.car_present            = uint8(3);
                
                
               
                              
                
            end
            
            
                
             
            ParkingStruct.LS_Trigger_FLAG        = uint8(1);
            ParkingStruct.LS_StartValue          = mean(ParkingStruct.dataBuffer2);   
            
            
           % case of the outputs from 2 algorithms are not the same     
           if ParkingStruct.car_present ~= ParkingStruct.car_present2  %%% && (ParkingStruct.car_present2 == uint8(1) || ParkingStruct.car_present2 == uint8(3))

               
%                if (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_thresh ...
%                        || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_thresh) 
% %                    && (ParkingStruct.Car_State_last_HS      == uint8(1) ...
% %                        || (ParkingStruct.Car_State_last_HS      == uint8(3) ...
% %                             && (ParkingStruct.HS_DataNdiff > ParkingStruct.HS_DataNdiff_Thresh) ...
% %                             && (ParkingStruct.HS_STDmax > ParkingStruct.STD_thresh || ParkingStruct.HS_MAmax > ParkingStruct.detection_thresh)))                       
%                    
% 
%                    ParkingStruct.car_present            = uint8(1);       
%                    ParkingStruct.car_present2           = uint8(1);   
%                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                   
                   
                   
                   
                   
               if sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel1 ...
                            || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel1

                        
                   ParkingStruct.car_present            = uint8(1);       
                   ParkingStruct.car_present2           = uint8(1);    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                   


% %                elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel2 ...
% %                             || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel2) ...
% %                      && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel2
%                  
%                  
%                elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel2 ...
%                             || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel2) ...
%                         && (ParkingStruct.Car_State_last_HS      == uint8(1) ...    
%                             || (ParkingStruct.Car_State_last_HS      == uint8(3) ...
%                                 && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel2)) 
%                             
%                             
% 
%                    ParkingStruct.car_present            = uint8(1);       
%                    ParkingStruct.car_present2           = uint8(1);    
%                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(21);



               elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel3 ...
                            || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel3) ...
                     && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel3 ...
                     && any(ParkingStruct.HS_Datadiff> ParkingStruct.HS_Datadiff_thresh_Level3)


                   ParkingStruct.car_present            = uint8(1);       
                   ParkingStruct.car_present2           = uint8(1);    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);



%                elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel4 ...
%                             || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel4) ...
%                      && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel4 ...
%                      && ParkingStruct.HS_DataNdiff > ParkingStruct.HS_Datadiff_thresh_Level3 ...
%                      && ParkingStruct.HS_DataNdiff_ratio_preLS > ParkingStruct.HS_DataNdiff_ratio_thresh 
% 
% 
%                    ParkingStruct.car_present            = uint8(1);       
%                    ParkingStruct.car_present2           = uint8(1);    
%                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(23);                      
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
               elseif sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp ...%&& sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) >= ParkingStruct.MAG_threshUp) ...
                   && (ParkingStruct.Car_State_last_HS      == uint8(3) ...
                       || (ParkingStruct.Car_State_last_HS      == uint8(1) ...
                            && ParkingStruct.HS_Datadiff(3) > ParkingStruct.HS_DataNdiff_Thresh ...   %%%%%(ParkingStruct.HS_DataNdiff > ParkingStruct.HS_DataNdiff_Thresh || any(ParkingStruct.HS_Datadiff > ParkingStruct.HS_DataNdiff_Thresh)) ...
                            && (ParkingStruct.HS_STDmax > ParkingStruct.STD_threshUp || ParkingStruct.HS_MAmax > ParkingStruct.detection_threshUp)))
                        
                
                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(3);
                   
                   
%%%%%%%
%%% update on 4/6                    
               elseif sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh2 ...
                   && ParkingStruct.Car_State_last_HS      == uint8(3)                         
                
                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(4);
                   
                   
                   
%                elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
%                     && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh 
% 
%                    ParkingStruct.car_present            = uint8(1);       
%                    ParkingStruct.car_present2           = uint8(1);    
%                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);
                   
                   
                   
                   
               elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
                    && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel1  

                   ParkingStruct.car_present            = uint8(1);       
                   ParkingStruct.car_present2           = uint8(1);    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);   
                   
                   
                   
                   
              elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
                    && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel2 ...
                    && ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                    && ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DatadiffXY_ThreshLevel2
            
                   ParkingStruct.car_present            = uint8(1);       
                   ParkingStruct.car_present2           = uint8(1);    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);  
                   
                   
                   
                   
                   
               elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp2 ...
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh)                        
                
                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(5);   
                   
                   
                   
               elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh3...  
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh)                        
                
                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(6);
                   
                   
                   
                   
                   
                elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                        && ParkingStruct.HS_totalTimeLS < ParkingStruct.HS_totalTimeLS_thresh...
                        && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp3 
                            
                    
                    ParkingStruct.car_present            = uint8(3);                   
                    ParkingStruct.car_present2           = uint8(3);       
                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(2); 
                    
                    
                    
%                elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
%                         && (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel4 ...
%                             || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel4) ...
%                      && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel1
% 
%                     ParkingStruct.car_present            = uint8(1);                                         
%                     ParkingStruct.car_present2           = uint8(1);       
%                     ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);                      
                    
                   
                   
                   

               else
                   if ParkingStruct.SecondSensor_Req_FLAG_count  < ParkingStruct.SecondSensor_Req_FLAG_countMAX
                       
                       ParkingStruct.state1_count                = ParkingStruct.SecondSensor_Req_FLAG_countReset;
                       ParkingStruct.LS_Trigger_FLAG             = uint8(0); 
                       ParkingStruct.SecondSensor_Req_FLAG_count = ParkingStruct.SecondSensor_Req_FLAG_count + uint8(1);

                   else
                   
                        ParkingStruct.SecondSensor_Req_FLAG       = uint8(1);
                        ParkingStruct.SecondSensor_Req_FLAG_count = uint8(0);
                        ParkingStruct.car_present2                = ParkingStruct.car_present;  
                   end                     
               end                

           end
           

           
        % TIMEOUT CASE:
        elseif ParkingStruct.state1_count == ParkingStruct.State_count_thresh_timeout * ParkingStruct.HS_rate ...
                && ParkingStruct.car_present == ParkingStruct.Car_State_last_HS
            
            
            ParkingStruct.LS_Trigger_FLAG        = uint8(1);               
            ParkingStruct.LS_StartValue          = mean(ParkingStruct.dataBuffer2);
            
            ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);  %%% reset confidence level
            
            
        end     
        
        
        
        
               
     % Previous STATE:  State 2 - Car In   
     elseif ParkingStruct.car_present   == uint8(2)   
         
         
        if ParkingStruct.state2_count > ParkingStruct.count_thresh * ParkingStruct.HS_rate 
            
            ParkingStruct.car_present   = uint8(3);              
            ParkingStruct.state3_count  = uint16(1);
         
            
            ParkingStruct.state1_count  = uint16(0);
            ParkingStruct.state2_count  = uint16(0);
            ParkingStruct.state4_count  = uint16(0);   
                            
        else
             
             ParkingStruct.state2_count = ParkingStruct.state2_count + uint16(1);
        end
        
        
    % Previous STATE:  State 3 - Car Parked    
    elseif ParkingStruct.car_present   == uint8(3)

        
        ParkingStruct.state3_count = ParkingStruct.state3_count + uint16(1);
        
        
        % checking in the proposed no car state, the absolute mag is in the initilized mag range
        % if current MEAN of mag is in the init range, jump to state 1 (NO car)
        if ParkingStruct.state3_count == ParkingStruct.State_count_thresh * ParkingStruct.HS_rate
                        
            
            ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);  %%% reset confidence level            
            ParkingStruct.HS_Datadiff            = ParkingStruct.HS_DataMax - ParkingStruct.HS_DataMin;
            
            
            ParkingStruct.HS_Datadiff_baseline1  = abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1);
            
            

%             %%%% case of previous car state is 3(with car), current estimated state will go to state 1 (no car), 
%             %%%% therefore should include at least one transition in the middle
%             %%%% so adding condition check for transition (check the diff on max and min mag data)

%             if ParkingStruct.Car_State_last_HS      == uint8(3) ...
%                     && (ParkingStruct.HS_DataNdiff > ParkingStruct.HS_DataNdiff_Thresh) ...
%                     && (ParkingStruct.HS_STDmax > ParkingStruct.STD_thresh || ParkingStruct.HS_MAmax > ParkingStruct.detection_thresh)...
%                     && (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_thresh ...
%                         || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_thresh)
%                 
%                ParkingStruct.car_present            = uint8(1); 
%                               
%                
%             elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
%                     && (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_thresh ...
%                         || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_thresh)
%                 
%                ParkingStruct.car_present            = uint8(1);                
%                
%             end            
            
            




%            if sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_thresh ...
%                         || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_thresh
%                 
%                ParkingStruct.car_present            = uint8(1);   
               
               
           if sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel1 ...
                        || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel1
                
               ParkingStruct.car_present            = uint8(1);   
               
               
% %            elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel2 ...
% %                         || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel2) ...
% %                  && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel2
% %              
% %                ParkingStruct.car_present            = uint8(1);
%                
% 
%              
%            elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel2 ...
%                         || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel2) ...
%                     && (ParkingStruct.Car_State_last_HS      == uint8(1) ...    
%                         || (ParkingStruct.Car_State_last_HS      == uint8(3) ...
%                             && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel2))             
%              
% 
%                         
%                ParkingStruct.car_present            = uint8(1);                        
                        
                        
               
               
           elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel3 ...
                        || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel3) ...
                 && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel3 ...
                 && any(ParkingStruct.HS_Datadiff> ParkingStruct.HS_Datadiff_thresh_Level3)
                 
             
               ParkingStruct.car_present            = uint8(1);
               
               
               
%            elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel4 ...
%                         || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel4) ...
%                  && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel4 ...
%                  && ParkingStruct.HS_DataNdiff > ParkingStruct.HS_Datadiff_thresh_Level3 ...
%                  && ParkingStruct.HS_DataNdiff_ratio_preLS > ParkingStruct.HS_DataNdiff_ratio_thresh 
%                  
%              
%                ParkingStruct.car_present            = uint8(1);            
         
          




               
           
%           elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
%                 && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh 
% 
%                 ParkingStruct.car_present            = uint8(1); 
                
                
                
                
          elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
                && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel1 

                ParkingStruct.car_present            = uint8(1);  
                
                
                
%            elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
%                     && (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel4 ...
%                         || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel4) ...
%                  && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel1 ...
% 
%                 ParkingStruct.car_present            = uint8(1);      
                
                
                
                
                
          elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
                && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel2 ...
                && ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                && ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DatadiffXY_ThreshLevel2

                ParkingStruct.car_present            = uint8(1); 
                                                
           end
            
            
           
           
            
            ParkingStruct.LS_Trigger_FLAG        = uint8(1);             
            ParkingStruct.LS_StartValue          = mean(ParkingStruct.dataBuffer2);
            
            
            
            
            
            
           % case of the outputs from 2 algorithms are not the same                
           if ParkingStruct.car_present ~= ParkingStruct.car_present2 %%%% && (ParkingStruct.car_present2 == uint8(1) || ParkingStruct.car_present2 == uint8(3))  
               

%                if (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_thresh ...
%                        || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_thresh) 
% %                    && (ParkingStruct.Car_State_last_HS      == uint8(1) ...
% %                        || (ParkingStruct.Car_State_last_HS      == uint8(3) ...
% %                             && (ParkingStruct.HS_DataNdiff > ParkingStruct.HS_DataNdiff_Thresh) ...
% %                             && (ParkingStruct.HS_STDmax > ParkingStruct.STD_thresh || ParkingStruct.HS_MAmax > ParkingStruct.detection_thresh)))
% 
%                    ParkingStruct.car_present            = uint8(1);       
%                    ParkingStruct.car_present2           = uint8(1);    
%                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                   
                   
                   
                   
                   
               if sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel1 ...
                            || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel1

                        
                   ParkingStruct.car_present            = uint8(1);       
                   ParkingStruct.car_present2           = uint8(1);    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                   


% %                elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel2 ...
% %                             || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel2) ...
% %                      && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel2
%                  
%                  
%                elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel2 ...
%                             || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel2) ...
%                         && (ParkingStruct.Car_State_last_HS      == uint8(1) ...    
%                             || (ParkingStruct.Car_State_last_HS      == uint8(3) ...
%                                 && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel2))                 
%                  
%                  
% 
%                    ParkingStruct.car_present            = uint8(1);       
%                    ParkingStruct.car_present2           = uint8(1);    
%                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(21);



               elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel3 ...
                            || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel3) ...
                     && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel3 ...
                     && any(ParkingStruct.HS_Datadiff> ParkingStruct.HS_Datadiff_thresh_Level3)


                   ParkingStruct.car_present            = uint8(1);       
                   ParkingStruct.car_present2           = uint8(1);    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);



%                elseif (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel4 ...
%                             || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel4) ...
%                      && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel4 ...
%                      && ParkingStruct.HS_DataNdiff > ParkingStruct.HS_Datadiff_thresh_Level3 ...
%                      && ParkingStruct.HS_DataNdiff_ratio_preLS > ParkingStruct.HS_DataNdiff_ratio_thresh 
% 
% 
%                    ParkingStruct.car_present            = uint8(1);       
%                    ParkingStruct.car_present2           = uint8(1);    
%                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(23);                      
                   
                   
                   
                   
                   
                   
                   
                   
                   
                   
               elseif sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp ...%%%&& sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) >= ParkingStruct.MAG_threshUp) ...
                        && (ParkingStruct.Car_State_last_HS      == uint8(3) ...
                            || (ParkingStruct.Car_State_last_HS      == uint8(1) ...
                                && ParkingStruct.HS_Datadiff(3) > ParkingStruct.HS_DataNdiff_Thresh ...   %%%%%(ParkingStruct.HS_DataNdiff > ParkingStruct.HS_DataNdiff_Thresh || any(ParkingStruct.HS_Datadiff > ParkingStruct.HS_DataNdiff_Thresh)) ...
                                && (ParkingStruct.HS_STDmax > ParkingStruct.STD_threshUp || ParkingStruct.HS_MAmax > ParkingStruct.detection_threshUp)))
                        

                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(3);  
                   
                  
               elseif sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh2 ...
                   && ParkingStruct.Car_State_last_HS      == uint8(3)                         
                
                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(4);                   
                   
                   
                   
%                elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
%                     && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh 
% 
%                    ParkingStruct.car_present            = uint8(1);       
%                    ParkingStruct.car_present2           = uint8(1);    
%                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);
                   
                   
                   
                   
               elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
                    && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel1  

                   ParkingStruct.car_present            = uint8(1);       
                   ParkingStruct.car_present2           = uint8(1);    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);   
                   
                   
                   
                   
              elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
                    && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel2 ...
                    && ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                    && ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DatadiffXY_ThreshLevel2
            
                   ParkingStruct.car_present            = uint8(1);       
                   ParkingStruct.car_present2           = uint8(1);    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);   
                   
               
            
                   
                   
               elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp2 ...
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh)                        
                
                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(5);   
                   
                   
                   
               elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh3...  
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                        || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh)                        
                
                   ParkingStruct.car_present             = uint8(3);       
                   ParkingStruct.car_present2            = uint8(3);       
                   ParkingStruct.SecondSensor_Req_FLAG   = uint8(6);   
                   
                   
                   
                   
                elseif ParkingStruct.Car_State_last_HS      == uint8(3) ...
                        && ParkingStruct.HS_totalTimeLS < ParkingStruct.HS_totalTimeLS_thresh...
                        && sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) >= ParkingStruct.MAG_threshUp3

                    ParkingStruct.car_present            = uint8(3);                   
                    ParkingStruct.car_present2           = uint8(3);       
                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);    
                    
                    
                    
                    
%                elseif ParkingStruct.Car_State_last_HS      == uint8(1) ...
%                         && (sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) < ParkingStruct.MAG_threshLevel4 ...
%                             || sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) < ParkingStruct.MAG_threshLevel4) ...
%                      && ParkingStruct.HS_Datadiff_baseline1(3) < ParkingStruct.MAG_thresh_ZaxisLevel1 ...
% 
%                     ParkingStruct.car_present            = uint8(1);                                         
%                     ParkingStruct.car_present2           = uint8(1);       
%                     ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);                      
                   
                   

               else
                   if ParkingStruct.SecondSensor_Req_FLAG_count  < ParkingStruct.SecondSensor_Req_FLAG_countMAX
                       
                       ParkingStruct.state3_count                = ParkingStruct.SecondSensor_Req_FLAG_countReset;
                       ParkingStruct.LS_Trigger_FLAG             = uint8(0); 
                       ParkingStruct.SecondSensor_Req_FLAG_count = ParkingStruct.SecondSensor_Req_FLAG_count + uint8(1);

                   else
                   
                       ParkingStruct.SecondSensor_Req_FLAG       = uint8(1);
                       ParkingStruct.SecondSensor_Req_FLAG_count = uint8(0);
                       ParkingStruct.car_present2                = ParkingStruct.car_present; 
                   end
                   
               end               
               
               
               
               
               
           end           
                                
            
        
        % TIMEOUT CASE:
        elseif ParkingStruct.state3_count == ParkingStruct.State_count_thresh_timeout * ParkingStruct.HS_rate ...
                && ParkingStruct.car_present == ParkingStruct.Car_State_last_HS
            
            
            ParkingStruct.LS_Trigger_FLAG        = uint8(1);    
            ParkingStruct.LS_StartValue          = mean(ParkingStruct.dataBuffer2);
            
            ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);  %%% reset confidence level
            
            
        end         
        
        
    
        
        
    % Previous STATE:  State 4 - Car Out     
    elseif ParkingStruct.car_present   == uint8(4)    
        
        if ParkingStruct.state4_count > ParkingStruct.count_thresh * ParkingStruct.HS_rate
        
            ParkingStruct.car_present   = uint8(1);               
            ParkingStruct.state1_count  = uint16(1);
            
            
            ParkingStruct.state2_count  = uint16(0);
            ParkingStruct.state3_count  = uint16(0);
            ParkingStruct.state4_count  = uint16(0);     

        else
            
            ParkingStruct.state4_count  = ParkingStruct.state4_count + uint16(1);
            
        end
                     
    end
    
    

    
elseif ParkingStruct.STD > ParkingStruct.STD_threshUp    

    
    ParkingStruct.TransitionState_count        = ParkingStruct.TransitionState_count + uint16(1);
    
    % Previous STATE:  State 1 - No Car 
    if ParkingStruct.car_present   == uint8(1)
        
        if ParkingStruct.LS_TO_HS_FLAG

            ParkingStruct.car_present   = uint8(2); 
            ParkingStruct.state2_count  = uint16(1);

            ParkingStruct.state1_count  = uint16(0);
            ParkingStruct.state3_count  = uint16(0);
            ParkingStruct.state4_count  = uint16(0);             
            
            ParkingStruct.LS_TO_HS_FLAG = uint8(0);
            

        else

           if ParkingStruct.car_present == ParkingStruct.Car_State_last_HS
               
               
                ParkingStruct.car_present   = uint8(2); 
                ParkingStruct.state2_count  = uint16(1);

                ParkingStruct.state1_count  = uint16(0);
                ParkingStruct.state3_count  = uint16(0);
                ParkingStruct.state4_count  = uint16(0);             
                
           else

                ParkingStruct.car_present   = uint8(4);
                ParkingStruct.state4_count  = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                ParkingStruct.state1_count  = uint16(0);
                ParkingStruct.state2_count  = uint16(0);
                ParkingStruct.state3_count  = uint16(0);    

           end

        end
        
    elseif ParkingStruct.car_present    == uint8(2)
        
        ParkingStruct.car_present   = uint8(2);        
        ParkingStruct.state2_count  = ParkingStruct.state2_count + uint16(1);
        
        ParkingStruct.state1_count  = uint16(0);
        ParkingStruct.state3_count  = uint16(0);
        ParkingStruct.state4_count  = uint16(0);          
        
        
        
        % TIMEOUT CASE:  
        if ParkingStruct.state2_count == ParkingStruct.timeout_transition * ParkingStruct.HS_rate ...
                        
            ParkingStruct.LS_Trigger_FLAG        = uint8(1);           

            ParkingStruct.car_present            = ParkingStruct.Car_State_last_HS; 
            ParkingStruct.SecondSensor_Req_FLAG  = uint8(7);
            
        end         
        
        
                
    elseif ParkingStruct.car_present    == uint8(3)
        
        
        if ParkingStruct.LS_TO_HS_FLAG   
            
            ParkingStruct.car_present    = uint8(4);
            ParkingStruct.state4_count   = uint16(1);
            
            ParkingStruct.state1_count   = uint16(0);
            ParkingStruct.state2_count   = uint16(0);
            ParkingStruct.state3_count   = uint16(0);  

            ParkingStruct.LS_TO_HS_FLAG  = uint8(0);
            
            
        else
            
      
            if ParkingStruct.car_present == ParkingStruct.Car_State_last_HS

                ParkingStruct.car_present    = uint8(4);
                ParkingStruct.state4_count   = uint16(1);

                ParkingStruct.state1_count   = uint16(0);
                ParkingStruct.state2_count   = uint16(0);
                ParkingStruct.state3_count   = uint16(0);  

            else 

                ParkingStruct.car_present    = uint8(2);
                ParkingStruct.state2_count   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                ParkingStruct.state1_count   = uint16(0);
                ParkingStruct.state3_count   = uint16(0);
                ParkingStruct.state4_count   = uint16(0);               

            end
            
        end
        
    elseif ParkingStruct.car_present    == uint8(4)
        
        ParkingStruct.car_present   = uint8(4);        
        ParkingStruct.state4_count  = ParkingStruct.state4_count + uint16(1);
        
        ParkingStruct.state1_count  = uint16(0);
        ParkingStruct.state3_count  = uint16(0);
        ParkingStruct.state2_count  = uint16(0);                  
        

        
        % TIMEOUT CASE:  
        if ParkingStruct.state4_count == ParkingStruct.timeout_transition * ParkingStruct.HS_rate ...
                        
            ParkingStruct.LS_Trigger_FLAG        = uint8(1);           
            ParkingStruct.car_present            = ParkingStruct.Car_State_last_HS; 
            
            ParkingStruct.SecondSensor_Req_FLAG  = uint8(7);
            
        end         
        
        
        

    end
    
    
 
    
    
else
    
    ParkingStruct.middleState_count = ParkingStruct.middleState_count + uint16(1);
    
    if ParkingStruct.middleState_count < ParkingStruct.timeout_transition * ParkingStruct.HS_rate
    
        % Previous STATE:  State 1 - No Car 
        if ParkingStruct.car_present   == uint8(1)

            ParkingStruct.state1_count  = uint16(0);
            ParkingStruct.state3_count  = uint16(0);

        elseif ParkingStruct.car_present   == uint8(3)

            ParkingStruct.state1_count  = uint16(0);
            ParkingStruct.state3_count  = uint16(0);

        end
        
    else
        
        ParkingStruct.LS_Trigger_FLAG        = uint8(1);                       
        ParkingStruct.SecondSensor_Req_FLAG  = uint8(7);

        if  ParkingStruct.car_present  == uint8(2) || ParkingStruct.car_present  == uint8(4) 

           ParkingStruct.car_present            = ParkingStruct.Car_State_last_HS; 

        end
        
    end   
   
    
    
        
end




    
    
if ~ParkingStruct.LS_Trigger_FLAG       % ParkingStruct.LS_Trigger_FLAG = 0  -- still in HS MODE
    
    if ParkingStruct.car_present == uint8(2) || ParkingStruct.car_present == uint8(4)
    
    
        FLAG = uint8(1);
        ParkingStruct.car_presentBufferCount = zeros(4,1,'uint8');

        ParkingStruct.car_presentBuffer      = shifting_array(ParkingStruct.car_presentBuffer);
        ParkingStruct.car_presentBuffer(end) = ParkingStruct.car_present;



        for i = 1:4

            ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) =  ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) + uint8(1);

            if ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) == uint8(3)

                ParkingStruct.car_presentCur  = ParkingStruct.car_presentBuffer(i);
                FLAG = uint8(0);
                ParkingStruct.LastTransitionState     = ParkingStruct.car_presentCur;  
                break;        
            end
        end


        if FLAG    
            ParkingStruct.car_presentCur  = ParkingStruct.car_presentPre;
        end
        
        
    else
        
        ParkingStruct.car_presentBuffer      = shifting_array(ParkingStruct.car_presentBuffer);
        ParkingStruct.car_presentBuffer(end) = ParkingStruct.car_presentPre;        
        
    end
    
    
    
else    % ParkingStruct.LS_Trigger_FLAG = 1  -- WILL MOVE TO LS mode
    
%     ParkingStruct.HS_totalTimeLS         = (ParkingStruct.HS_startTime - ParkingStruct.HS_endTime)/32000;

%     %%% values for cloud algorithm    
%     ParkingStruct.HS_endValue            = single(data);
    ParkingStruct.HS_endTime             = ParkingStruct.time;  

    
    ParkingStruct.HS_Datadiff            = ParkingStruct.HS_DataMax - ParkingStruct.HS_DataMin;
    

    ParkingStruct.LastTransitionState2   = ParkingStruct.LastTransitionState;
    
    ParkingStruct.Diff_mag_baseline      = [sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state1)) ...
                        sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.AVGInit2)) ...
                        sum(abs(mean(ParkingStruct.dataBuffer2) - ParkingStruct.LS_StartValue_state3))];
                    
    
%     if ParkingStruct.HS_endTime >=  ParkingStruct.HS_startTime                
%         ParkingStruct.HS_totalTime       = (ParkingStruct.HS_endTime - ParkingStruct.HS_startTime)/single(32000);     %%% total time in HS mode 
%     else
%         ParkingStruct.HS_totalTime       = (ParkingStruct.HS_endTime + single(4294967296) - ParkingStruct.HS_startTime)/single(32000);     %%% total time in HS mode
%     end
    
    
if isempty(coder.target)
    
    
    
%     temp = [single(ParkingStruct.Car_State_last_HS) single(ParkingStruct.car_present) ...
%         single(ParkingStruct.SecondSensor_Req_FLAG) single(ParkingStruct.LastTransitionState2) ...
%         single(ParkingStruct.HS_startTime) single(ParkingStruct.HS_endTime) single(ParkingStruct.HS_totalTime) ...
%         single(ParkingStruct.TransitionState_count) single(ParkingStruct.TransitionState_count2) single(ParkingStruct.middleState_count)... %%%ParkingStruct.HS_startValue ParkingStruct.LS_StartValue ParkingStruct.HS_startTime ParkingStruct.HS_endTime ...
%         single(0) single(0) ...  %%%ParkingStruct.HS_DatadiffXY ...   %%% ParkingStruct.HS_DataNMax ParkingStruct.HS_DataNMin 
%         ParkingStruct.HS_STDmax ParkingStruct.HS_MAmax ...
%         ParkingStruct.Diff_mag_baseline ...
%         ParkingStruct.HS_Datadiff ...
%         ParkingStruct.HS_Datadiff_baseline1 ParkingStruct.HS_Datadiff_baseline3...
%         ParkingStruct.HS_totalTimeLS ParkingStruct.StartNUM ParkingStruct.NUM];


    
    
    temp = [single(ParkingStruct.Car_State_last_HS) single(ParkingStruct.car_present) ...
        single(ParkingStruct.SecondSensor_Req_FLAG) single(ParkingStruct.LastTransitionState2) ...
        ParkingStruct.HS_STDmax ...
        ParkingStruct.HS_MAmax ...
        ParkingStruct.Diff_mag_baseline ...
        ParkingStruct.HS_Datadiff ...
        ParkingStruct.HS_Datadiff_baseline1...
        ParkingStruct.HS_totalTimeLS...
        ParkingStruct.StartNUM...
        ParkingStruct.NUM];  
    
%         ParkingStruct.HS_Datadiff_baseline3...
%         ParkingStruct.HS_Datadiff_ratio_preLS ...
%         ParkingStruct.HS_Datadiff_ratio_curLS ...
%         ParkingStruct.HS_DataNdiff...
%         ParkingStruct.HS_DataNdiff_ratio_preLS...
%         ParkingStruct.HS_DataNdiff_ratio_curLS...
%         ParkingStruct.HS_DataNMin ParkingStruct.HS_DataNMax ...      
%         ParkingStruct.HS_DataNMax_ratio_preLS...
%         ParkingStruct.HS_DataNMax_ratio_curLS... 
    
    
    
    
    
    
    
    
    
    ParkingStruct.CloudDataALL                      = [ParkingStruct.CloudDataALL;temp];
    
end




    
    if ParkingStruct.car_present == uint8(1)
    
        ParkingStruct.LS_StartValue_state1            = ParkingStruct.LS_StartValue;
        
    elseif ParkingStruct.car_present == uint8(3)
        
        ParkingStruct.LS_StartValue_state3            = ParkingStruct.LS_StartValue;        
    end
 
      
    
    ParkingStruct.car_present2          = ParkingStruct.car_present;
    
    % reset
    ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct); 
    
    
    
    ParkingStruct.StandbyMode_FLAG              = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet   
    ParkingStruct.StandbyMode_CntAlgo           = uint16(0);    % counts number of samples above 500uT  
    
end
    
end