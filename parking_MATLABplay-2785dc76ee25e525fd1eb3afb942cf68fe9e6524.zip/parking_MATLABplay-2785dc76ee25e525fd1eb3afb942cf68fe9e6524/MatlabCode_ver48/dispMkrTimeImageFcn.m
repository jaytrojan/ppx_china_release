function output_txt = dispMkrTimeImageFcn(obj,event_obj)
% Display the position of the data cursor
% obj          Currently not used (empty)
% event_obj    Handle to event object
% output_txt   Data cursor text string (string or cell array of strings).


global  dataInfoExtra parkImageShow

% servTime = dataInfoExtra.servTime;


pos = get(event_obj,'Position');
index = get(event_obj,'DataIndex');

tserv = dataInfoExtra.servTime(index);
% tcam = parkImageShow.imageTimeTrack(index);

tpad = 120; % seconds of padding for time matching
inds = find(parkImageShow.dateTimeAyAy >= tserv-seconds(tpad) & parkImageShow.dateTimeAyAy <= tserv+seconds(tpad));
if ~isempty(inds)
    indsInd = ceil(mean(1:length(inds)));
    if indsInd < 1, indsInd=1; end
    if indsInd > length(inds), indsInd=length(inds); end
    minInd = inds(indsInd); % pick mid-later match since image load time can be delayed
    %                     minInd = round(mean(inds));
else
    minInd = [];
%     [minVal, minInd] = min(abs(parkImageShow.dateTimeAyAy - tserv)); % closest...
end

if ~isempty(minInd)
    ipage = parkImageShow.pageTrackAyAy(minInd);
    iind = parkImageShow.indTrackAyAy(minInd);
    %                 [minVal, iInd] = min(abs(imageStructAy(ipage).dateTimeAy - tserv));
    % inds = parkImageShow.imageStructAy
    
    % (ipage).dateTimeAy >= tserv-seconds(tpad) & imageStructAy(ipage).dateTimeAy <= tserv+seconds(tpad));
    tcam = parkImageShow.imageStructAy(ipage).dateTimeAy(iind);
else
    tcam = [];
end

output_txt = {...
    ['X: ',num2str(pos(1))],...
    ['Y: ',num2str(pos(2))]...
    ['tserv: ',char(tserv)]...
    ['tcam: ',char(tcam)]...
    };

% show parking image
try
    if parkImageShow.on && isfield(parkImageShow,'imageStructAy') && ~isempty(parkImageShow.imageStructAy)
%         inds = parkImageShow.imageIndsTrack(index,:); % [page ind]
        if isempty(inds)
            % no images close enough
            imSize = size(parkImageShow.imageStructAy(1).imageAy);
            parkImage = 0.7*255*ones(imSize(1:3),'uint8');
            image(parkImageShow.hax,parkImage);
        else
%             ipage = inds(1); iind = inds(2);
            parkImage = parkImageShow.imageStructAy(ipage).imageAy(:,:,:,iind);
            image(parkImageShow.hax,parkImage);
        end
    end
catch
    disp('image display problem!!!')
end

