function tcheck2 = time2FromTime(time,tcheck)
% correlate time times with time2
% time = dataStruct.time;
% tcheck = statS.statSmeas3.truthTimes;

dt = [0; time(2:end) - time(1:end-1)];

% time2: replace large time gaps
tgapmax = 60;
dtBigInds = find(dt>=tgapmax);
tgapreplace = 10;
% [time(dtBigInds-1) time(dtBigInds) time(dtBigInds+1)]

dt2 = dt;
% tgapmeas = dt(dtBigInds);
dt2(dtBigInds) = tgapreplace;
time2 = time(1) + cumsum(dt2);

tcheck2 = [];
for irow=1:size(tcheck,1)
    for icol=1:size(tcheck,2)
%         ind = find(tcheck(irow,icol)>time,1);
            ind = find(time>=tcheck(irow,icol),1);
%         if isempty(ind)
%         end
        if ~isempty(ind)
            tcheck2(irow,icol) = time2(ind);
        else
            tcheck2(irow,icol) = nan;
        end
    end
end



