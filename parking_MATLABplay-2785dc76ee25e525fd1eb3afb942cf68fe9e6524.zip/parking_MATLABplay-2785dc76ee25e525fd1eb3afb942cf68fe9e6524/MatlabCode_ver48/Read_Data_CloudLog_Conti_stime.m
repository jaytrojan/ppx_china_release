function [mraw,time,SentralOutput,raw_rate,RSSIdata,mDataRaw, sentralTimestamp, servTime] = Read_Data_CloudLog_Conti_stime(FileName)

[rawData,~] = xlsread(FileName);

% load all data into str columns
% magR  SENtralTime  SensorId  ServerTime_PST  CarPresence  Temperature  LoraWan_rssi  Confidence  magx magy magz
dataStrArray = loadcsvTextCols('',FileName,2);
serverTimeStr = dataStrArray{4};

% sstr = serverTimeStr{1}

iSentralTime = 2;
iSensorID = 3;
iServeTime = 4;
iCarStat = 5;
iTemp = 6;
iRSSI = 7;
iConf = 8;
iData = 9:11;


reverseIdx = size(rawData,1):-1:1;
rawData = rawData(reverseIdx,:);
serverTimeStr = serverTimeStr(reverseIdx,:);

inds = rawData(:,iSentralTime)~=0;
rawData = rawData(inds,:);
serverTimeStr = serverTimeStr(inds,:);


diffT = diff(rawData(:,iSentralTime));
tind = find(diffT< -10^9);

if ~isempty(tind)
    if length(tind)>1
        1;
    end
    
    for i = 1:length(tind)
        rawData(tind(i)+1:end,iSentralTime)=rawData(tind(i)+1:end,iSentralTime)+rawData(tind(i),iSentralTime);
    end
end

%sort data by timestamp
[~, sortedIndexes] = sort(rawData(:,iSentralTime));
rawData = rawData(sortedIndexes,:);

serverTimeStr = serverTimeStr(sortedIndexes);





% ****** load raw mag data
midx=find(~isnan(rawData(:,1)));

mDataRaw=rawData(midx,[iSentralTime  iData  iRSSI]); 
serverTimeStr = serverTimeStr(midx);



%sort data by timestamp
[~, sortedIndexes] = sort(mDataRaw(:,1));
mDataRaw = mDataRaw(sortedIndexes,:); 
serverTimeStr = serverTimeStr(sortedIndexes);


%%%% removal of repeated data
[~,ia,~] = unique(mDataRaw(:,1));
mDataRaw = mDataRaw(ia,:); 
serverTimeStr = serverTimeStr(ia,:); 


mDataRaw=[mDataRaw zeros(size(mDataRaw,1),3)];
mDataRaw(:,8) = 10;

% %%%%%% SENtral output
sidx1=find(~isnan(rawData(:,iCarStat)));
SentralOutputRaw1=rawData(sidx1,[iCarStat iSentralTime]);    
[~,ia,~] = unique(SentralOutputRaw1(:,2));

sidx = sidx1(ia);
SentralOutputRaw=rawData(sidx,[iSentralTime iCarStat iConf]);

empty_record = [];
for i = 1:length(sidx)
    
    iind = find(mDataRaw(:,1)==SentralOutputRaw(i,1));
    
    if ~isempty(iind)
        mDataRaw(iind,6)=SentralOutputRaw(i,2);
        mDataRaw(iind,7)=SentralOutputRaw(i,3);
        

        %%% car state
        if mDataRaw(iind,6) == 0        
           mDataRaw(iind,6) = 1;
        elseif mDataRaw(iind,6) == 100        
            mDataRaw(iind,6) = 3;        
        elseif mDataRaw(iind,6) == 50        
            mDataRaw(iind,6) = 2;  
        elseif mDataRaw(iind,6) == -50        
            mDataRaw(iind,6) = 4;  
        end         
        
        
        
        
    else
        empty_record = [empty_record;i];
    end
end



for i = 2: size(mDataRaw,1)
    
    if mDataRaw(i,6) == 0 && mDataRaw(i,7) == 0 && mDataRaw(i-1,6) ~= 0 && mDataRaw(i-1,7) ~= 0
        
        mDataRaw(i,6) = mDataRaw(i-1,6);
        mDataRaw(i,7) = mDataRaw(i-1,7); 
        mDataRaw(i,8) = 20;
    end
end







% timestamp in seconds
tRaw = mDataRaw(:,1);
time = (tRaw - tRaw(1,:))/32000;  % time in seconds 

sentralTimestamp = mDataRaw(:,1);

% mag data
mraw = mDataRaw(:,2:4);     
    
RSSIdata = mDataRaw(:,5);


SentralOutput = mDataRaw(:,6:7);


% server time convert from str
clear dateTimeAy
for ii=1:length(serverTimeStr)
    sStr = serverTimeStr{ii};
    iplus = strfind(sStr,'+');
    iminus = strfind(sStr,'-');
    iT = strfind(sStr,'T');
    iColon = strfind(sStr,':');
    timeCheck = length(iminus)==2 & ~isempty(iT);
    
    if timeCheck
        if ~isempty(iplus)
            sStr = sStr(1:iplus-1);
        end
        y = str2num(sStr(1:iminus(1)-1));
        m = str2num(sStr(iminus(1)+1:iminus(2)-1));
        d = str2num(sStr(iminus(2)+1:iT(1)-1));
        thr = str2num(sStr(iT(1)+1:iColon(1)-1));
        tmin = str2num(sStr(iColon(1)+1:iColon(2)-1));
        tsec0 = str2num(sStr(iColon(2)+1:end));
        %     DateNumber = datenum(y,m,d,thr,tmin,tsec0) ; % matlab date/time format
        tsec = floor(tsec0);
        tmsec = 1000*(tsec0-tsec);
        dateTime = datetime(y,m,d,thr,tmin,tsec,tmsec);
    else
        dateTime = [];
    end
    dateTimeAy(ii,:) = dateTime;
end

servTime = dateTimeAy;



% % ****** load output on from SENtral
% % sidx=find(~isnan(rawData(:,5)));
% % SentralOutputRaw=rawData(~isnan(rawData(:,5)),[5]);
% 
% 
% sidx1=find(~isnan(rawData(:,5)));
% SentralOutputRaw1=rawData(sidx1,[5 2]);    
% [~,ia,~] = unique(SentralOutputRaw1(:,2));
% 
% sidx = sidx1(ia);
% SentralOutputRaw=rawData(sidx,[5 8]);
% 
% 
% SentralOutput = zeros(size(time,1),2);
% 
% endpoint = 1;
% index = 1;
% 
% for i = 1:length(sidx)
%     
%     sentral_index = sidx(i);
%     
%     
%     %%% car state
%     if SentralOutputRaw(i,1) == 0        
%        SentralOutputRaw(i,1) = 1;
%     elseif SentralOutputRaw(i,1) == 100        
%         SentralOutputRaw(i,1) = 3;        
%     elseif SentralOutputRaw(i,1) == 50        
%         SentralOutputRaw(i,1) = 2;  
%     elseif SentralOutputRaw(i,1) == -50        
%         SentralOutputRaw(i,1) = 4;  
%     end    
%     
%     
%     
%     
%     for j = endpoint:length(time)
%         
%         mag_index = midx(j);                  
%         
%         if sentral_index > mag_index
%             
%             SentralOutput(index,:) = SentralOutputRaw(i,:);    
%             index = index + 1;
%             
%         else
%             
%            endpoint = j;
%            break;
%            
%         end
%         
%     end
%     
%     
% end
% 
% if (length(time) > (endpoint-1)) && (~isempty(SentralOutputRaw)) 
%     
%     for i = endpoint:length(time)
%        SentralOutput(i,:) = SentralOutputRaw(end,:); 
%     end
% end
% 



%compute the average rate of a single time axis. axis should be
%a column vector.

%compute delta-t vector
tDels = time(2:end)-time(1:end-1);
%compute frequency vector
tFqs = tDels.^(-1);
%compute mean rate in hz
% raw_rate = mean(tFqs);
% raw_rate = mean(tFqs(1:10));
raw_rate = tFqs(1);






