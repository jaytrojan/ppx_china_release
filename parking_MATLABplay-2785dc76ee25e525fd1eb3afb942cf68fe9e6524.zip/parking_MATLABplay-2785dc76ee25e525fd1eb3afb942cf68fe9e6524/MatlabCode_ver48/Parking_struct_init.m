function ParkingStruct = Parking_struct_init
%%% init of parking structure
%
%#codegen




%%% update 3/27
% patterns for magnetic gesture wakeup

ParkingStruct.BLE_Trigger_thresh        = single(100);   %%% changed to 100 at 5/23/2017, previous @ 200   % threshod to generate high-bit ("1") in wake up pattern

ParkingStruct.BLE_Trigger_Buffer        = zeros(12,1,'uint8');
ParkingStruct.BLE_Trigger_PatternA      = uint8([1 0 1 0 0 0 0 1 0 1 1 0]);  %%% BLE wake up
ParkingStruct.BLE_Trigger_PatternB      = uint8([1 0 1 1 1 0 0 0 0 0 1 0]);  %%% Exit shipping mode
ParkingStruct.BLE_Trigger_PatternC      = uint8([1 0 0 1 0 0 0 0 1 1 1 0]);  %%% Hard reset
ParkingStruct.BLE_Trigger_PatternD      = uint8([1 1 1 0 0 1 0 0 0 0 1 0]);  %%% shipping mode enable
ParkingStruct.BLE_Trigger_PatternE      = uint8([1 0 0 0 1 0 1 1 0 0 1 0]);  %%% gateway
ParkingStruct.BLE_Trigger_PatternF      = uint8([1 1 0 1 0 0 0 0 0 1 1 0]);  %%% NOT USED


ParkingStruct.BLE_Trigger_FLAG          = uint8(0);  %  1 - mag value pass the trigger threshold    2- match pattern A   3- match pattern B    4- match pattern C   5- match pattern D   6- match pattern E  7 - NO PATTERN MATCHED
ParkingStruct.BLE_Trigger_Enable        = uint8(1);  %% 1 - enable pattern matching  0 - disable pattern matching




%%%%%%%%%%
% update 4/4  (adding pre-pattern to triggering actual wake up pattern matching)

ParkingStruct.BLE_Trigger_PatternPre       = uint8([1 1 0 0]);  %%% pre pattern to clean BLE_trigger_Buffer for pattern matching
ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);         %%% pre pattern should only be matched one time at the beginning to clean the BLE_Trigger_Buffer






%%%% shipping mode

ParkingStruct.BLE_Trigger_Mode         = uint8(1);     % 0 - wake up by strength    1- wake up by pattern

ParkingStruct.ShippingMode_FLAG        = uint8(0);     % 1 - in shipping mode    0- NORMAL operation mode   %%%%% update on 2/14/2017    initialized  @ normal operation mode



%%%%%% update on 6/21/17 (Jira: PMG-97)
%%%%%%%%%%%%%%%%%%%%% using strong magnet and BLE to get out of shipping mode
%%%% detect strong mag in shipping mode

%%%% the strong magnet requires to be placed on the top of sensor for at least 4seconds (ParkingStruct.StandbyMode_Timeout),
%%%% total number of samples that mag value above threshold (500uT) needs to be 16 (4seconds data)

ParkingStruct.HS_Trigger_thresh_SHIP            = single(200);  % HS mode trigger threshold in shipping mode
ParkingStruct.StandbyMode_Trigger_thresh_SHIP   = single(500);  % strong magnet detection threshold in shipping mode
ParkingStruct.StandbyMode_FLAG                  = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet
% ParkingStruct.StandbyMode_FLAG_Internal         = uint8(0);     % internal FLAG, 1 - detect strong magnet

ParkingStruct.StandbyMode_Cnt                   = uint16(0);    %%% cnt used in SENtral
ParkingStruct.StandbyMode_CntAlgo               = uint16(0);    %%% cnt used in algorithm, counts number of samples with mag value above 500uT
ParkingStruct.StandbyMode_Timeout               = uint16(4);    %%% strong magnet requires to be placed on the top of the sensor for 4 seconds


%%%%%%%%%%%%%%%%%%%%%



ParkingStruct.ShippingMode_InitFLAG    = uint8(0);     % intial stage to get start value in shipping mode
% ParkingStruct.StandbyMode_Cnt          = uint16(0);
% ParkingStruct.StandbyMode_Timeout      = uint16(4);    % 4 seconds for standby mode





% ParkingStruct.HS_Trigger_thresh        = single(3);





%%%%% temperature compensation by updating LS_StartValue every hour(when obtains temperature data from external temperature sensor)
% ParkingStruct.dataBufferTC             = zeros(4,3,'single');  %% buffer to store 1s (4 samples) mag data for LS_StartValue update (using the average value as updated LS_StartValue)
ParkingStruct.dataBufferTCSize         = uint8(4);  %% buffer to store 1s (4 samples) mag data for LS_StartValue update (using the average value as updated LS_StartValue)

ParkingStruct.LocalBaseline_Update_Enable        = uint8(1);   %% 1 - enable updating local baseline(LS_StartValue_state1) during LS_StartValue update process




%%%%% temperature compensation by common coefficients

ParkingStruct.temperature              = int8(25);

% ParkingStruct.temperatureCF            = single([1 1 1 0 0 0 0 0 0]);
% % ParkingStruct.temperatureCF            = single([1.191638382	1.26483618	1.196024099  -0.002175682	0.003270512	-0.000600306  -0.000357533	-0.000477555	-0.000379372]);
%
% ParkingStruct.temperatureSF            = single(1);
% ParkingStruct.temperatureOFFSET        = single(0);




%% knobs for "absolute mag" based Algorithm

% ParkingStruct.HS_rate             = uint16(4);  % In High Speed Mode, Sampling Rate = 4Hz
% ParkingStruct.LS_rate             = uint16(1);  % In Low Speed Mode, Sampling Rate = 1Hz

ParkingStruct.STD                 = single(0);


% % % % ParkingStruct.dataBufferSize      = uint8(8);
% % % %
% % % % ParkingStruct.dataBuffer          = zeros(8,1,'single');
% % % % ParkingStruct.dataBuffer2         = zeros(8,3,'single');



ParkingStruct.Context_Input       = uint8(0);   % 0 - no context input    1 /3 - context inout from user
ParkingStruct.Reset_FLAG          = uint8(0);   % 1 - reset finished


%%%%% update on 2/14/2017
ParkingStruct.LS_Trigger_FLAG     = uint8(0);   % 1 - low speed mode    0 - high speed mode     %%%%% update on 2/14/2017    initialized  @ high speed mode for operation mode start with calibration

ParkingStruct.Calibration_FLAG    = uint8(0);   % 1 - calibration process finished      %%%%% update on 2/14/2017    initialized  @ high speed mode for operation mode start with calibration
ParkingStruct.Calibration_InitFLAG    = uint8(0);     % intial stage to get start value in calibration



ParkingStruct.LS_TO_HS_FLAG       = uint8(0);   % 1 - just move to HS mode  %% reset to ZERO when state change or come back to LS mode


ParkingStruct.Calibration_Counter = uint16(0);
ParkingStruct.Calibration_Timeout = uint16(5);  % 5 seconds for calibration stage






%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% updated on 2/1/2017
ParkingStruct.STD_thresh          = single(2.5);   % 3



% ParkingStruct.MAG_thresh          = single(2.5);   % 3  % minus/plus range from initilized AVGInit to check the correctness of the state
% ParkingStruct.MAG_threshUp        = single(12);
% ParkingStruct.MAG_thresh2         = single(7);

ParkingStruct.SecondSensor_Req_FLAG_count      = uint8(0);

% % old alg <= r03
% ParkingStruct.SecondSensor_Req_FLAG_countMAX   = uint8(2);
% new stable filt >= r04
ParkingStruct.SecondSensor_Req_FLAG_countMAX   = uint8(6);

ParkingStruct.SecondSensor_Req_FLAG_countReset = uint16(12);
%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




ParkingStruct.state1_count        = uint16(0);
ParkingStruct.state2_count        = uint16(0);
ParkingStruct.state3_count        = uint16(0);
ParkingStruct.state4_count        = uint16(0);

% ParkingStruct.count_thresh        = uint16(2);  % reqiures 1 seconds to avoid spike peak in STD (false trigger the state changing)
%
%
% ParkingStruct.State_count_thresh         = uint16(5);    % reqiures 1 seconds to confirm the correct state (no car OR car parked)
% ParkingStruct.State_count_thresh_timeout = uint16(5);    % TIMEOUT: no state change in 5 secods - BACK TO LOW SPEED MODE



ParkingStruct.car_present            = uint8(1);            % 1 - Empty   2 - Car Entering   3 - Occupied   4 - Car Leaving
ParkingStruct.car_presentBuffer      = ones(4,1,'uint8');   % 1 - Empty   2 - Car Entering   3 - Occupied   4 - Car Leaving
ParkingStruct.car_presentBufferCount = zeros(4,1,'uint8');


ParkingStruct.car_presentCur         = uint8(1);
ParkingStruct.car_presentPre         = uint8(1);

ParkingStruct.Car_State_last_HS      = uint8(1);



ParkingStruct.K2                     = uint8(0);
ParkingStruct.SUM                    = single(0) ;    % sum
ParkingStruct.SUMSq                  = single(0);     % sum square


ParkingStruct.AVG2                   = zeros(1,3,'single');
ParkingStruct.AVGSUM2                = zeros(1,3,'single');
ParkingStruct.AVGInit2               = zeros(1,3,'single');




ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);      % in NO CAR / CAR PARKED state, compare the outputs from 2 algorithms
% 0 - outputs are the same, no need for 2nd sensor,  1 - require for 2nd sensor



%% knobs for "phase" based Algorithm

ParkingStruct.detection_thresh        = single(2);     %%%%%% single(10);
% % % % ParkingStruct.dx_history              = zeros(8,1,'single');


%%%%% moving average on magnitude (X+Y+Z)
ParkingStruct.local_avg               = single(0);
ParkingStruct.moving_avg              = single(0);
ParkingStruct.filter_alpha            = single(0.8);
ParkingStruct.filter_beta             = single(0.2);


ParkingStruct.state1_count2           = uint16(0);
ParkingStruct.state2_count2           = uint16(0);
ParkingStruct.state3_count2           = uint16(0);
ParkingStruct.state4_count2           = uint16(0);


ParkingStruct.car_present2            = uint8(1);            % 1 - Empty   2 - Car Entering   3 - Occupied   4 - Car Leaving
ParkingStruct.car_presentBuffer2      = ones(4,1,'uint8');   % 1 - Empty   2 - Car Entering   3 - Occupied   4 - Car Leaving



ParkingStruct.car_presentCur2         = uint8(1);
ParkingStruct.car_presentPre2         = uint8(1);

ParkingStruct.LS_TO_HS_FLAG2          = uint8(0);   % 1 - just move to HS mode  %% reset to ZERO when state change or come back to LS mode





ParkingStruct.timeout_transition      = uint16(120);    % TIMEOUT: stuck in the transition mode - BACK TO LOW SPEED MODE


ParkingStruct.Calibration_Delay_FLAG  = uint8(0);   % 1 - calibration request during car present state, delay the calibration request
                                                    %%0 - calibration request during no car state






%%% USED for light version of paramIO to cloud (with less info on paramIO and sending only when request from cloud, may once every transition)



ParkingStruct.LS_StartValue            = zeros(1,3,'single');

ParkingStruct.LS_StartValue_state1     = zeros(1,3,'single');
ParkingStruct.LS_StartValue_state3     = zeros(1,3,'single');




ParkingStruct.time                  = single(0);







%%% update 2/13/2017
% data sending to cloud: 51 byte

%%% values for cloud algorithm
ParkingStruct.HS_startTime          = single(0);              %%% HS mode start timestamp
ParkingStruct.HS_endTime            = single(0);              %%% HS mode ending timestamp

ParkingStruct.HS_totalTimeLS        = single(0);              %%% time interval between the starting time of current HS mode and ending time of previous HS mode



% max-min mag data on X/Y/Z
ParkingStruct.HS_DataMax            = zeros(1,3,'single');
ParkingStruct.HS_DataMin            = zeros(1,3,'single');
ParkingStruct.HS_Datadiff           = zeros(1,3,'single');



% STD + Moving Avg (magnitude of X+Y+Z)
ParkingStruct.HS_STDmax             = single(0);              %%% max STD value, magnitude of X+Y+Z
ParkingStruct.HS_MAmax              = single(0);              %%% max MA value, magnitude of X+Y+Z





ParkingStruct.HS_Datadiff_baselineZ     = single(0);  %%%% difference between current mag with last baseline in state 1 (ParkingStruct.LS_StartValue_state1) in Z axis
% ParkingStruct.HS_Datadiff_baselineInitZ = single(0); %%%% difference between current mag with initial baseline  (ParkingStruct.AVGInit2) in Z axis









% %%%%% ratio of the mag changes in X/Y/Z
% ParkingStruct.HS_Datadiff_ratio_preLS       = zeros(1,3,'single'); %%%% ParkingStruct.HS_Datadiff/previous_LS_StartValue in X/Y/Z
% ParkingStruct.HS_Datadiff_ratio_curLS       = zeros(1,3,'single'); %%%% ParkingStruct.HS_Datadiff/current_LS_StartValue  in X/Y/Z
%
%
%
% %%%%% ratio of the mag changes in Magnitude of X+Y+Z
% % max-min mag data (magnitude of X+Y+Z)
% ParkingStruct.HS_DataNMax           = single(0);
% ParkingStruct.HS_DataNMin           = single(0);
% ParkingStruct.HS_DataNdiff          = single(0);
%
% ParkingStruct.HS_DataNdiff_ratio_preLS       = single(0); %%%% ParkingStruct.HS_DataNdiff/previous_LS_StartValue in Magnitude of X+Y+Z
% ParkingStruct.HS_DataNdiff_ratio_curLS       = single(0); %%%% ParkingStruct.HS_DataNdiff/current_LS_StartValue  in Magnitude of X+Y+Z
%
%
% ParkingStruct.HS_DataNMax_ratio_preLS        = single(0); %%%% ParkingStruct.HS_DataNMax/previous_LS_StartValue in Magnitude of X+Y+Z
% ParkingStruct.HS_DataNMax_ratio_curLS        = single(0); %%%% ParkingStruct.HS_DataNMax/previous_LS_StartValue in Magnitude of X+Y+Z






ParkingStruct.LastTransitionState   = uint8(0);
ParkingStruct.LastTransitionState2  = uint8(0);      %%%% 2: car entering   4: car leaving   5: calibration stage   6: mag wake-up






ParkingStruct.TransitionState_count = uint16(0);
ParkingStruct.TransitionState_count2= uint16(0);

ParkingStruct.middleState_count     = uint16(0);  %%% number of sample in [thresholdUp >  STD >thresholdDown  ]




%%%%%%
%%%% update 04/12/2017
%%%% false positive error by large car parked at nearby space
%%%% false negative error by hybrid car back in with small magnetic changes
% ParkingStruct.STD_thresh2           = single(1.5);   %%%  previously 2.5
% ParkingStruct.detection_thresh2     = single(1.5);   %%%  previously 2

ParkingStruct.MAG_threshUp                = single(9.6);    %%%% = single(10);    %%% Jay is cool
ParkingStruct.MAG_threshUp2               = single(9);     %%%% (loose threshold)


ParkingStruct.STD_threshUp                = single(1.5);   % high threshold on STD
ParkingStruct.STD_threshDown              = single(0.5);   % low threshold on STD

ParkingStruct.detection_threshUp          = single(1.5);   % high threshold on MA
ParkingStruct.detection_threshDown        = single(0.5);   % low threshold on MA



ParkingStruct.HS_DatadiffZ_ThreshLevel1   = single(3.0);   % threshold on mag changes of Z-axis during HS mode
ParkingStruct.HS_DatadiffZ_ThreshLevel2   = single(4.0);   % threshold on mag changes of Z-axis during HS mode   --- previous value: 5.5
ParkingStruct.HS_DatadiffXY_ThreshLevel2  = single(8.0);    % threshold on mag changes of X or Y-axis during HS mode



ParkingStruct.HS_DataNdiff_Thresh         = single(4.0);   % threshold on mag changes of Z-axis during HS mode    --- previous value: 5.5
ParkingStruct.HS_DataNdiff_Thresh2        = single(2);     % threshold on mag changes of X/Y -axis during HS mode






ParkingStruct.MAG_thresh                  = single(2.5);   % minus/plus range from initilized AVGInit to check the correctness of the state
ParkingStruct.MAG_thresh2                 = single(2.8);   % minus/plus range from last state3 to check the correctness of the state
ParkingStruct.MAG_thresh3                 = single(4.0);   % minus/plus range from last state3 to check the correctness of the state (loose threshold)




ParkingStruct.MAG_threshLevel1            = single(2.0);   % minus/plus range from initilized AVGInit or local baseline to check the correctness of the state
% ParkingStruct.MAG_threshLevel2            = single(2.5);   % minus/plus range from initilized AVGInit or local baseline to check the correctness of the state
ParkingStruct.MAG_threshLevel3            = single(3.0);   % minus/plus range from initilized AVGInit or local baseline to check the correctness of the state
% ParkingStruct.MAG_threshLevel4            = single(3.1);   % minus/plus range from initilized AVGInit or local baseline to check the correctness of the state


% ParkingStruct.MAG_thresh_ZaxisLevel1      = single(0.35);  % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state
ParkingStruct.MAG_thresh_ZaxisLevel2      = single(2.5);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state
ParkingStruct.MAG_thresh_ZaxisLevel3      = single(1.5);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state
ParkingStruct.MAG_thresh_ZaxisLevel4      = single(5.0);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state
ParkingStruct.MAG_thresh_ZaxisLevel5      = single(7.5);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state

ParkingStruct.MAG_thresh_ZaxisLevel6      = single(10);    % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state




ParkingStruct.HS_Datadiff_thresh_Level3   = single(40);    % deal with the issue that large magnetic field change (>80 uT) --- previous value: 100




% ParkingStruct.RSSI_num  = uint8([0 5 3 3 3 3 3 5]);  %%% MAPPING confidence level to number of RSSI







%%%%% update on 07/05/2017 (Jira: PMG-104)
%%% for demo case:

ParkingStruct.DemoFLAG                       = uint8(2);      %%%%% 1 -- run algorithm for demo cases   0 -- run algorithm for normal car parking (default case)

ParkingStruct.MAG_threshDEMO                 = single(2.5);   % minus/plus range from initilized AVGInit to check the correctness of the state
ParkingStruct.MAG_threshUpDEMO               = single(7);     % minus/plus range from last state3 to check the correctness of the state


ParkingStruct.count_threshDEMO               = uint16(2);    % reqiures 1 seconds to avoid spike peak in STD (false trigger the state changing)

ParkingStruct.State_count_threshDEMO         = uint16(2);    % reqiures 2 seconds to confirm the correct state (no car OR car parked)
ParkingStruct.State_count_thresh_timeoutDEMO = uint16(2);    % TIMEOUT: no state change in 2 secods - BACK TO LOW SPEED MODE








%%%% update on 7/7/2017 (Jira: PMG-109)
%%% time related condition check
ParkingStruct.HS_totalTimeLS_thresh        = single(20);         %%% threshold on the minimal time interval (in second) between time interval between the starting time of current HS mode and ending time of previous HS mode to allow car status change
ParkingStruct.MAG_threshUp3                = single(5);         %%%% (loose threshold)






% %%%% update on 7/18/2017 (Jira: PMG-112)
% %%% knob setting for 3-inch sensor
% ParkingStruct.Sensor3Inch               = uint8(0);     %%%%% 1 -- run algorithm for 3-inch sensor   0 -- run algorithm for 1-inch sensor (default case)









ParkingStruct.STDz               = single(0);
ParkingStruct.HS_STDmaxZ         = single(0);




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% buffer size related knobs (current buffer size = 8)

ParkingStruct.dataBufferSize      = uint8(8);

ParkingStruct.dataBuffer          = zeros(8,1,'single');
ParkingStruct.dataBuffer2         = zeros(8,3,'single');

ParkingStruct.dx_history          = zeros(8,1,'single');




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% sample rate related knobs

ParkingStruct.HS_rate             = uint16(8);  % In High Speed Mode, Sampling Rate = 4Hz
ParkingStruct.LS_rate             = uint16(4);  % In Low Speed Mode, Sampling Rate = 1Hz




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% car detection latency related knobs

% % old alg <= r03
% ParkingStruct.count_thresh               = uint16(2);    % reqiures 2 seconds to avoid spike peak in STD (false trigger the state changing)
% ParkingStruct.State_count_thresh         = uint16(5);    % reqiures 5 seconds to confirm the correct state (no car OR car parked)
% ParkingStruct.State_count_thresh_timeout = uint16(5);    % TIMEOUT: no state change in 5 secods - BACK TO LOW SPEED MODE

% new stable filt >= r04
ParkingStruct.count_thresh               = uint16(4);    % reqiures 2 seconds to avoid spike peak in STD (false trigger the state changing)
ParkingStruct.State_count_thresh         = uint16(2);    % reqiures 5 seconds to confirm the correct state (no car OR car parked)
ParkingStruct.State_count_thresh_timeout = uint16(2);    % TIMEOUT: no state change in 5 secods - BACK TO LOW SPEED MODE



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% High speed mode trigger threshold related knobs
ParkingStruct.HS_Trigger_thresh        = single(3);










%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% update on 06/28/2017  (Jira: PMG-102)  Aggressive parking

%%%%%%%%%% add function of detecting multiple cars during continuous pulling out/in

%%% Aggressvie Parking CASE: one car pulls out from the space while the next car pulls into the space immediately



ParkingStruct.NumCars                           = uint16(0);    %%% the number of cars have been parked in the space since last calibration, will be reset to 0 after calibration
                                                                %%% the number will be increased:
                                                                %%%  1. state from 1 to 3 (from vacant to occupied)
                                                                %%%  2. state from 3 to 3 (aggressive parking: one car pulls out and the second car pulls in immediately)



ParkingStruct.NumCarsPre                        = uint16(0);


ParkingStruct.ZdataWindowSize                   = uint8(6);   %% window size is 1 second data







ParkingStruct.STDz_max                          = single(0);

ParkingStruct.STDz_max_threshold                = single(3);

ParkingStruct.rangeZ_threshold                  = single(5);     %%% threshold on the range of all data within window (max - min)
ParkingStruct.diff_baseline_Z_threshold         = single(2.5);   %%% threshold on the average of the difference between data within window and baseline (latest no car state)



ParkingStruct.NumCarsTemp                       = uint8(0);
ParkingStruct.multipleCarsFLAG                  = uint8(0);     %%% aggressive parking detection FLAG, SENtral will check FLAG to send VACANT status before sending actual OCCUPIED status






% %%% window size is based on the high speed data rate
% if ParkingStruct.HS_rate             == uint16(4)
%     ParkingStruct.ZdataWindowSize                   = uint8(4);   %% window size is 1 second data
% elseif ParkingStruct.HS_rate         == uint16(8)
%     ParkingStruct.ZdataWindowSize                   = uint8(6);   %% window size is 0.8 second data
% end





%%%%%%% Update 7/24/2017 (Jira: PMG-113)
%%%%%   Drive Thru Case: count the number of cars past by the sensor

ParkingStruct.NumCars_DriveThru                           = uint16(0);    %%% drive thru case ---  the number of cars have been past over the sensor since last calibration, will be reset to 0 after calibration
                                                                %%% the number will be increased:
                                                                %%%  1. state from 1 to 3 (from vacant to occupied)
                                                                %%%  2. state from 3 to 3 (aggressive parking: one car pulls out and the second car pulls in immediately)
                                                                %%%  3. state from 1 to 1 (from vacant to vacant) with state 2 (car entering) in the middle -- only ONE car drive over the sensor
                                                                %%%  4. state from 1 to 1  aggressive driving thru case - multiple cars drive over the sensor continuously



ParkingStruct.NumCars_DriveThruPre                        = uint16(0);

ParkingStruct.multipleCarsFLAG_DriveThru                  = uint8(0);     %%% aggressive drive thru detection FLAG


ParkingStruct.DriveThruFLAG                               = uint8(0);     %%% 1 -- run algorithm for Drive Thru cases   0 -- run algorithm for normal car parking (default case)


% %% removed for codegen
%
% ParkingStruct.HS_Datadiff_baseline1    = zeros(1,3,'single'); %%%% difference between current mag with last baseline in state 1 (ParkingStruct.LS_StartValue_state1) in X/Y/Z
% ParkingStruct.HS_Datadiff_baselineInit = zeros(1,3,'single'); %%%% difference between current mag with initial baseline  (ParkingStruct.AVGInit2) in X/Y/Z
%
% ParkingStruct.Diff_mag_baseline       = zeros(1,3,'single');  %%%% difference between current mag with initial baseline(ParkingStruct.AVG2), last baseline in state 1 (ParkingStruct.LS_StartValue_state1),last baseline in state 3 (ParkingStruct.LS_StartValue_state3)
%
%
% ParkingStruct.NUM               = single(0);
% ParkingStruct.StartNUM          = single(0);
% % ParkingStruct.HS_FLAG           = uint8(0);
% % ParkingStruct.ALG2level         = uint8(0);
% % ParkingStruct.time              = single(0);
% % ParkingStruct.level             = uint8(0);
% % ParkingStruct.LS_StartValue_stateALL            = [];
% ParkingStruct.CloudDataALL            = [];



%%%%%% values to support LS checking
ParkingStruct.cPastLsMode       = uint16(0); % number of samples past ls mode
ParkingStruct.lsRecheckEnable   = int8(1); % control how many times to rerun loop
ParkingStruct.exit_lsRecheck_FLAG = uint8(0); % move to normal use case if mag field is detected (only relevant for embedded)

ParkingStruct.lsRecheckTime     = uint16(10); % time interval after ls to recheck data
ParkingStruct.lsRecheckNumber   = uint8(3); % number of time to recheck after ls event. -1 turns system off
ParkingStruct.lsMagThr          = single([3 5 2]); % mag threshold under which mag mean difference should be to learn unoccupied [rel, abs, closeabs]


%%% special cases
ParkingStruct.caseTrackNumb = uint8(0); % track which special case occured
ParkingStruct.caseFlags = ones(1,16,'uint8'); % turn on/off special cases -> caseFlags(1) is the first special case and so on
% ParkingStruct.caseFlags(10) = uint8(0);

% persistent car present track until actual state change recorded
ParkingStruct.car_presentPersist = uint8(0);

% %%% Stable Filter Struct & Settings
% ParkingStruct.filtStruct = stableFilt_struct_init;
% % if stable filter on, change some park struct settings
% if ParkingStruct.filtStruct.stableMethod == 2
%     ParkingStruct.State_count_thresh         = uint16(2);    % reqiures 5 seconds to confirm the correct state (no car OR car parked)
%     ParkingStruct.State_count_thresh_timeout = uint16(2);    % TIMEOUT: no state change in 5 secods - BACK TO LOW SPEED MODE
% end


% %%% Set Special Cases Cases
% ParkingStruct.caseFlags(4) = uint8(0);


%%% settings to make decisions based on initial conditions at start of state
ParkingStruct.LS_StartValue_state1_initial = zeros(1,3,'single');
ParkingStruct.LS_StartValue_state3_initial = zeros(1,3,'single');
ParkingStruct.MAG_threshLevel7            = single(1.5);   % minus/plus range from most recent parked state to check the correctness of the state

% constrained on space, just use 7 for both:
% ParkingStruct.MAG_threshLevel8            = single(2);   % minus/plus range from most recent parked state to check the correctness of the state after 1m increments

ParkingStruct.stateCorrection_FLAG   = uint8(0); % flag to denote when the system is correcting an error, not observing a state change
ParkingStruct.stateCorrection_type   = uint8(0); % indicator to denote whether most recent update was due to state change or algorithm update
% ParkingStruct.HS_Trigger_thresh_FLAG = uint8(0); % indicator if the HS trigger flag has been flipped

ParkingStruct.state3dif_thr     = single(2); % threshold for allowing recheck method to make changes to current state. changes must be greater than this value to allow change out of phase




