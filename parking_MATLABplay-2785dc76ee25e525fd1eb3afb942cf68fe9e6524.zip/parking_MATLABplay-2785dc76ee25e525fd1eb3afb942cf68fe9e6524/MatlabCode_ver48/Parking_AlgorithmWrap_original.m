function ParkingStruct = Parking_AlgorithmWrap_original(ParkingStruct, data, AlarmSourceFLAG)


%%  &&&&&&&&&&&&& Hardware Alarm Mode  -- trigger HS mode in hardware    &&&&&&&&&&&& 
if AlarmSourceFLAG
    
    
    if ParkingStruct.Context_Input == uint8(1)  % context input in NO CAR state  -- Re-calibration

        if ~ParkingStruct.Reset_FLAG
            ParkingStruct = Parking_structure_reset(ParkingStruct);
        end           

        if ParkingStruct.LS_Trigger_FLAG  == uint8(0)
            ParkingStruct = Calibration_process(ParkingStruct, data);
        end



    elseif ParkingStruct.Context_Input == uint8(3)  % context input in CAR parked state 

        ParkingStruct.car_present      = uint8(3);  
        ParkingStruct.car_present2     = uint8(3);    

        ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct); 

        ParkingStruct.Context_Input    = uint8(0);    % RESET context input 
        ParkingStruct.LS_Trigger_FLAG  = uint8(1);    % trigger the Alarm: back to low speed mode    



    else


       if ~ParkingStruct.Calibration_FLAG  

           ParkingStruct = Calibration_process(ParkingStruct, data);

       else

            if ParkingStruct.LS_Trigger_FLAG  == uint8(1)


                ParkingStruct.LS_Trigger_FLAG     = uint8(0);

                ParkingStruct.LS_TO_HS_FLAG       = uint8(1);                 
                ParkingStruct.LS_TO_HS_FLAG2      = uint8(1); 


                ParkingStruct.Car_State_last_HS   = ParkingStruct.car_presentCur;

                ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);


    %             ParkingStruct = Parking_Algorithm(ParkingStruct, data);

            elseif ParkingStruct.LS_Trigger_FLAG  == uint8(0)

                ParkingStruct = Parking_Algorithm(ParkingStruct, data);

            end

       end


    end

    
    

    
    
    
%%  &&&&&&&&&  Software Alarm Mode  -- trigger HS mode in software   &&&&&&&&&&&&&&&
else


    if ParkingStruct.Context_Input == uint8(1)  % context input in NO CAR state  -- Re-calibration

        if ~ParkingStruct.Reset_FLAG

            ParkingStruct = Parking_structure_reset(ParkingStruct);

        end           

        if ParkingStruct.LS_Trigger_FLAG  == uint8(0)
            ParkingStruct = Calibration_process(ParkingStruct, data);
        end



    elseif ParkingStruct.Context_Input == uint8(3)  % context input in CAR parked state  


        ParkingStruct.car_present      = uint8(3);  
        ParkingStruct.car_present2     = uint8(3);    


        ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct); 



        ParkingStruct.Context_Input    = uint8(0);    % RESET context input 
        ParkingStruct.LS_Trigger_FLAG  = uint8(1);    % trigger the Alarm: back to low speed mode    



    else


       if ~ParkingStruct.Calibration_FLAG  

           ParkingStruct = Calibration_process(ParkingStruct, data);

       else


            if ParkingStruct.LS_Trigger_FLAG  == uint8(1) ...
                    && ((abs(data(1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
                    || (abs(data(2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
                    || (abs(data(3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )


                ParkingStruct.LS_Trigger_FLAG     = uint8(0);

                ParkingStruct.LS_TO_HS_FLAG       = uint8(1);                 
                ParkingStruct.LS_TO_HS_FLAG2      = uint8(1); 


                ParkingStruct.Car_State_last_HS   = ParkingStruct.car_presentCur;

                ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);


    %             ParkingStruct = Parking_Algorithm(ParkingStruct, data);



            elseif ParkingStruct.LS_Trigger_FLAG  == uint8(0)


                ParkingStruct = Parking_Algorithm(ParkingStruct, data);



            end

       end


    end


end

