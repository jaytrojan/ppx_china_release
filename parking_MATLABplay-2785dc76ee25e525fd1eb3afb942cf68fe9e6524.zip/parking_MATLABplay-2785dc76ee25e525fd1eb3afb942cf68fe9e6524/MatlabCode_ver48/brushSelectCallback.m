function brushSelectCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global plotInfo dataInfo cntrlInfo

% plotInfo.hBr.Enable = 'off'


hTruthStateLine = plotInfo.hTruthStateLine;
hCarStateLine = plotInfo.hCarStateLine;
hSenStateLine = plotInfo.hSenStateLine;

truth_state = dataInfo.truth_state;

cntrlInfo.BrushData = hTruthStateLine.BrushData;

currentTruth = truth_state(logical(cntrlInfo.BrushData),1);

if ~isempty(currentTruth)
    
    % set slider to first value
    setVal = currentTruth(1);
%     cntrlInfo.sld.Value = setVal;
    setVal = round(setVal);
    
    % text for val
    carStateListAy = {
        'Empty';
        'Entering';
        'Occupied';
        'Leaving';
        };
    if setVal
        carStateStr = carStateListAy{setVal};
    else
        carStateStr = 'Unknown';
    end
    
    cntrlInfo.sld.Value = setVal;
    cntrlInfo.sldText.String = carStateStr;
    
    % make all selected truth match slider
    hTruthStateLine.YData(logical(cntrlInfo.BrushData)) = setVal;
    dataInfo.truth_state(logical(cntrlInfo.BrushData),1) = setVal;
    
    % deselect other lines
    hstateAy = plotInfo.hstateAy;
    hsenstateAy = plotInfo.hsenstateAy;
    
    if ~isempty(hCarStateLine.BrushData)
        hCarStateLine.BrushData = zeros(1,length(hSenStateLine.BrushData),'uint8');
    end
    if ~isempty(hSenStateLine.BrushData)
        hSenStateLine.BrushData = zeros(1,length(hSenStateLine.BrushData),'uint8');
    end
    
    for ii=1:length(hstateAy)
        if ~isempty(hstateAy(ii).BrushData)
            hstateAy(ii).BrushData =  zeros(1,length(hSenStateLine.BrushData),'uint8');
        end
    end
    for ii=1:length(hsenstateAy)
        if ~isempty(hsenstateAy(ii).BrushData)
            hsenstateAy(ii).BrushData =  zeros(1,length(hSenStateLine.BrushData),'uint8');
        end
    end
    

end



aaa=999;

% xd = get(Handle, 'XData');
% yd = get(Handle, 'YData');
% brush = get(Handle, 'BrushData');
% brushed_x = xd(brush);
% brushed_y = yd(brush);

end

