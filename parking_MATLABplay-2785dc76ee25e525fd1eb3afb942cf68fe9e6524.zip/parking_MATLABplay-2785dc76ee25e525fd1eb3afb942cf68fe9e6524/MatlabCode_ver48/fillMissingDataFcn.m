function dataStruct = fillMissingDataFcn(dataStruct,resultRecAy,filtStruct,dtLim,tintMax,interpMethod)

% Add interp mag data
% dtLim = 0.36; % gap ~ 3x HS mode
% tintMax = 3; % max number of seconds to add with interp

% mraw = dataStruct.magDataAy(:,2:4);
% timeRaw = dataStruct.time;
% SentralOutput = dataStruct.magDataAy(:,6:7);
% raw_rate = dataStruct.magRaw_rate;
% magSenTimestamp = dataStruct.magSenTimestamp;
% servTime = dataStruct.magDateTimeAy; % server time

% start_ind = 1;
% end_ind = size(mraw,1);    %%%% 1690;   %%%%size(mraw,1);  %%%625;
% magData       = mraw(start_ind:end_ind,:);
% time          = timeRaw(start_ind:end_ind,:);
% SentralOutput = SentralOutput(start_ind:end_ind,:);
% magSenTimestamp = magSenTimestamp(start_ind:end_ind,:);


magDataAy = dataStruct.magDataAy;
time = dataStruct.time;

% find magdata length fields to interp
N = size(magDataAy,1);
flds = fieldnames(dataStruct);
dataFlds = {};
for ii=1:length(flds)
    n = size(dataStruct.(flds{ii}),1);
    if n==N
        dataFlds = [dataFlds; flds(ii)];
        dS.(flds{ii}) = dataStruct.(flds{ii});
    end
end
dSinterp = dS;

dt = [0; time(2:end) - time(1:end-1)];
LS_Trigger_FLAG_ay = resultRecAy.LS_Trigger_FLAG_ay;
filtStructAy = resultRecAy.filtStructAy;

stableThreshDown = filtStruct.stableThreshDown;
stableThreshUp = filtStruct.stableThreshUp;

mstdCln = reshape([filtStructAy.mstdCln],3,N)';
mstdClnR = sqrt(sum(mstdCln.^2,2));
mslopeMoveClnMn = reshape([filtStructAy.mslopeMoveClnMn],3,N)';
mslopeMoveClnMnR = sqrt(sum(mslopeMoveClnMn.^2,2));
stableFlags = mstdClnR<stableThreshDown(1) & abs(mslopeMoveClnMnR)<stableThreshDown(2);
% unStableFlags = mstdClnR>stableThreshUp(1) | abs(mslopeMoveClnMnR)>stableThreshUp(2);

            
% find large dt's still in HS

dtMissFlags = dt>=dtLim;
% dtMissFlags = dtMissFlags & ~LS_Trigger_FLAG_ay;
dtMissFlags(end) = 1;

dtMissInds = find(dtMissFlags);
% missed time is before each dtMissInds
% 
% figure
% plot(dtMissFlags)
% hold all
% plot(dtMissFlags,'.--')



% find typical HS time to interp to
dtHSmed = median(dt(~LS_Trigger_FLAG_ay));
ioff = 0; i1prev = 1;
for iit = 1:length(dtMissInds)
    i1 = dtMissInds(iit)-1;
    i2 = dtMissInds(iit);
    t1 = time(i1);
    t2c = time(i2); % cutoff time
    t2interp = t2c; % interp to here
    dtcov = (t2c-t1);
    if dtcov>tintMax
        t2c = t1+tintMax;
    end
    if dtcov<(0.7*tintMax)
        % interp for short sections
        covMethod = 'interp';
    else
        covMethod = 'fill';
    end
%     dtc = t2c-t1;

    tint = (t1:dtHSmed:t2interp)';
    if length(tint)<3
        tint = (t1:(0.6*dtHSmed):t2interp)';
    end
    tint(1) = t1; tint(end) = t2interp;
    it2c = find(tint>=t2c,1);
    tintc = tint(1:it2c,:); % tint up to cutoff time
    
    stableBack = stableFlags(i1:-1:i1prev,:);
%     tstableBack = time(i1:-1:i1prev,:);
    istable = find(~stableBack,1,'last');
    if isempty(istable)
        istable=length(stableBack);
    end
    
    % use first half of reversed stable section to avoid instability tail.
    if istable>16
        istable = 16;
    end
    
    % special handling fields (repeated data instead of interpolated)
    specialFields = {'magDataAy'};
    excludeFields = {'dataCellAy', 'magLogicInds', 'otherLogicInds'};
    
    for ifld=1:length(dataFlds)
        
        if ~any(~cellfun('isempty',strfind(excludeFields, dataFlds{ifld})))
            d1 = dS.(dataFlds{ifld})(i1,:);
            d2 = dS.(dataFlds{ifld})(i2,:);
            
            dInterp = interp1([t1; t2interp], [d1; d2], tint, 'linear', 'extrap');
            dInterp = dInterp(1:it2c,:);
            if strcmp(interpMethod,'fill') && strcmp(covMethod,'fill') && any(~cellfun('isempty',strfind(specialFields, dataFlds{ifld})))
                % repeat stable data to fill in to tintc time
                dstableBack = dS.(dataFlds{ifld})(i1:-1:i1prev,:);
                dstableBack = dstableBack(1:istable,:);
                %             dInterp = [repmat(dstableBack,floor(dtratio),1); dstableBack(1:ifrac,:)];
                dRep = repmat(dstableBack,ceil(length(tintc)/size(dstableBack,1)),1);
                dRep = dRep(1:length(tintc),:);
                
                % replace some columns with repeated data
                switch dataFlds{ifld}
                    case 'magDataAy'
                        dInterp(:,2:4) = dRep(:,2:4);
                end
            end
            dSinterp.(dataFlds{ifld}) = [dSinterp.(dataFlds{ifld})(1:(i1+ioff),:); dInterp(2:end-1,:); dSinterp.(dataFlds{ifld})(i2+ioff:end,:)];
        end
    end
    
    i1prev = i1;
    ioff = ioff + length(tintc)-2;
end


% copy interpolated fields
for ifld=1:length(dataFlds)
    if ~any(~cellfun('isempty',strfind(excludeFields, dataFlds{ifld})))
        dataStruct.(dataFlds{ifld}) = dSinterp.(dataFlds{ifld});
    end
end

