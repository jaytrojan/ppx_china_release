function hax1 = plotTempDataTime(time2,servTime,tgapmeas,tempData,dtBigInds,figN,titleStr)

%%% >>> mag data vs time

% titleStr = 'Mag Data Full vs Time';

N = size(tempData,1);

% figN = figPlotS.magDataFull(1);
figure(figN); clf
hax1 = axes;
markInds = [dtBigInds; N];
istart=1; istopprev = 0;
for ii=1:length(markInds)
    istop = markInds(ii)-1;
    if istopprev
        plot(hax1,time2(istopprev:istart,:),tempData(istopprev:istart,1),':r'); hold all
%         plot(hax1,time2(istopprev:istart,:),rssiData(istopprev:istart,2),':g'); hold all
%         plot(hax1,time2(istopprev:istart,:),rssiData(istopprev:istart,3),':r'); hold all
%         plot(hax1,time2(istopprev:istart,:),magDataR(istopprev:istart,:),':k','LineWidth',1)
    end
    plot(hax1,time2(istart:istop,:),tempData(istart:istop,1),'p-r','LineWidth',1.5,'MarkerSize',18); hold all
%     plot(hax1,time2(istart:istop,:),rssiData(istart:istop,2),'.-g','LineWidth',1.5,'MarkerSize',18); hold all
%     plot(hax1,time2(istart:istop,:),rssiData(istart:istop,3),'.-r','LineWidth',1.5,'MarkerSize',18); hold all
%     plot(hax1,time2(istart:istop,:),magDataR(istart:istop,:),'.-k','LineWidth',3,'MarkerSize',20)
    
    istart = markInds(ii);
    istopprev = istop;
end

% add missing time notes
yLim = ylim;
ymk1 = 0.85*yLim(1);
ymk2 = 0.85*yLim(2);
for ii=1:length(dtBigInds)
    istart = dtBigInds(ii)-1;
    istop = dtBigInds(ii);
    tcent = mean(time2(istart:istop));
    tstr = num2str(round(tgapmeas(ii)/60));
    text(hax1,tcent,ymk1,['~' tstr ' min~'],'HorizontalAlignment','center')
    
%     % server time
%     tserv = mean([tcent time2(istop)]);
%     sTime = datestr(servTime(istart),'yy-mm-dd HH:MM');
%     text(hax1,tserv,ymk2,['[' sTime ']'],'HorizontalAlignment','center')
    
    % plot vertical line at start of each section
    tline = time2(istop);
    plot(hax1,[tline tline],[yLim(1) yLim(2)],':k','LineWidth',1);
end
title(hax1,titleStr,'FontSize',16,'FontWeight','bold'); grid on;
xlabel(hax1,'t(sec)','FontSize',14,'FontWeight','bold');
ylabel(hax1,'T (degC)','FontSize',14,'FontWeight','bold');
% legend(hax1,'X','Y','Z','vectR')
%%% >>> mag data vs time

