function imageAy = loadImageArray(filename,fmt)

% load images
% tic
infoImage=imfinfo([filename '.' fmt]);
Nimages=length(infoImage);
mwidth=infoImage(1).Width;
nheight=infoImage(1).Height;

% toc
imageAy = zeros(nheight,mwidth,3,Nimages,'uint8');
for im = 1:Nimages
    imageAy(:,:,:,im) = imread([filename '.' fmt],im);
end
% toc

