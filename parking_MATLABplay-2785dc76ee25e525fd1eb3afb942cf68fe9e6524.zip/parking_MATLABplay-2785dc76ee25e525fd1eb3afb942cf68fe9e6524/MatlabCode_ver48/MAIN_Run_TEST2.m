%% Algorithm using SSA and SSR with real-time functionality 
% No motion data


close all;
clear; clc;
dbstop if error


% choose and open data file


addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\original')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\app_data')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors3')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\wake-up_test')


global car_state MEAN_value STD_value Alarm_level static_state



% [alldatfiles,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File', 'MultiSelect', 'on');
% numfiles=length(alldatfiles);
% 
% 
% for file_index=1:numfiles
% 
%     FileName=char(alldatfiles(file_index));



% % Load PPG and Accel data (need to select multiple data files)
[FileName,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File');


[mraw,timeRaw,SentralOutput,raw_rate,markerTimes,markNames] = Read_Data(FileName);


magN = sqrt(sum(mraw.^2,2));



% plot: mag data with markers
figure;   
subplot(2,1,1);plot(timeRaw,mraw); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');

for i=1:length(markerTimes)
    plot([markerTimes(i),markerTimes(i)],y1);hold on;
end



subplot(2,1,2); plot(timeRaw,magN); grid on;










tic;



%% Setup data structures
ParkingStruct = Parking_struct_init;



if raw_rate <= ParkingStruct.HS_rate
    
    warning('upsampling is not supported');   
    
    magData       = mraw;
    time          = timeRaw;
    SentralOutput = SentralOutput;  
    magN = magN;
    
else
   
    factor = floor(raw_rate/ ParkingStruct.HS_rate);
    sprintf('Down Sampling Factor: %f',factor);    
    
    magData       = downsample(mraw,factor);
    time          = downsample(timeRaw,factor);
    SentralOutput = downsample(SentralOutput,factor);
    magN = downsample(magN,factor);
end
    


% magData       = downsample(mraw,1);
% time          = downsample(timeRaw,1);
% SentralOutput = downsample(SentralOutput,1);   
    
    

N3 = length(magData);


magNdata = zeros(N3,1);
mag_diff = zeros(N3,1);
phase_level = zeros(N3,1);
detection_output = zeros(N3,1);

car_state = zeros(N3,2);

MEAN_value = zeros(N3,2);
STD_value = zeros(N3,1);

MEAN_value2 = zeros(N3,3);

moving_avg = zeros(N3,1);

MEAN_Baseline_value = zeros(N3,1);
STD_Baseline_value = zeros(N3,1);
MEAN_Occupied_value = zeros(N3,1);
STD_Occupied_value = zeros(N3,1);



ALG2Level = zeros(N3,1);
car_state_alg2 = zeros(N3,1);

car_state_buffer =zeros(N3,1);

Alarm_level = zeros(N3,1);

BLE_Trigger_FLAG=zeros(N3,1);


%% Setup data structures
ParkingStruct = Parking_struct_init;

% ParkingStruct.ShippingMode_FLAG = 1;


% magData(142:143,:) = 400*ones(2,3);
% magData([150 152 157 158 160],:) = 400*ones(5,3);
% 
% 
% magData(242:243,:) = 400*ones(2,3);
% magData([250 252 253 254 260],:) = 400*ones(5,3);




figure;   
subplot(2,1,1);plot(magData); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');


subplot(2,1,2); plot(magN); grid on;






% for i = 1: 700
for i = 1: N3
    
%     ParkingStruct.Context_Input = uint8(0);

%     if i == 100
%         
%         ParkingStruct.Context_Input = uint8(5);
%         
%         1;
%     end 
%     
%     if i == 174        
%         ParkingStruct.Context_Input = uint8(5);        
%     end     
    
%     
%     
%     if i == 260
%         
%         ParkingStruct.ShippingMode_FLAG        = uint8(1);
% 
%     end      
    



%     if i == 142
%         
% %         ParkingStruct.ShippingMode_FLAG        = uint8(1);
%         
%         1;
%     end   
%     
%     
    if i == 1084        
        
        1;
    end 





ParkingStruct.NUM               = i;
ParkingStruct.time              = time(i);    
    
    
    
%     ParkingStruct.PreDataBuffer      = shifting_array(ParkingStruct.PreDataBuffer);
%     ParkingStruct.PreDataBuffer(ParkingStruct.PreDataBufferSize,:)  = magData(i,:);







%%% hardware alarm
    
    if ParkingStruct.ShippingMode_FLAG
        
        % initial stage: using first data as startValue
        if ~ParkingStruct.ShippingMode_InitFLAG            
            
            ParkingStruct.LS_StartValue            = single(magData(i,:));
            ParkingStruct.ShippingMode_InitFLAG    = uint8(1);    % intial stage to get start value in shipping mode
            ParkingStruct.LS_Trigger_FLAG          = uint8(1);    % back to LS mode

            ParkingStruct.Calibration_FLAG         = uint8(1);    % disable calibration % 1 - calibration process finishe      
            ParkingStruct.Calibration_InitFLAG     = uint8(0);     % intial stage to get start value in calibration

            
        else        
        
        

            if ((abs(magData(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh_SHIP) ...
                || (abs(magData(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh_SHIP) ...
                || (abs(magData(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh_SHIP) ) ...
                || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
                || ParkingStruct.StandbyMode_Cnt  > uint16(0)


                if ParkingStruct.StandbyMode_Cnt  == uint16(0)   %%%% && ParkingStruct.BLE_Trigger_FLAG == uint8(0)
                    % hardware alarm 
                    ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
                    
                end
                    
                                  
                if (ParkingStruct.BLE_Trigger_FLAG     == uint8(1) && ParkingStruct.BLE_Trigger_Mode == uint8(0)) ...
                        || (ParkingStruct.BLE_Trigger_FLAG  == uint8(3) && ParkingStruct.BLE_Trigger_Mode == uint8(1) && ParkingStruct.BLE_Trigger_PatternAFLAG  == uint8(0))...
                        || (ParkingStruct.BLE_Trigger_FLAG  == uint8(2) && ParkingStruct.BLE_Trigger_Mode == uint8(1))

                    ParkingStruct.StandbyMode_Cnt          = ParkingStruct.StandbyMode_Cnt + uint16(1);


                    if ParkingStruct.StandbyMode_Cnt == ParkingStruct.StandbyMode_Timeout * ParkingStruct.LS_rate

                        ParkingStruct.ShippingMode_FLAG        = uint8(0);   %% leaving shipping mode
                        ParkingStruct.StandbyMode_Cnt          = uint16(0);

                        ParkingStruct.ShippingMode_InitFLAG    = uint8(0);    % intial stage to get start value in shipping mode          
                        ParkingStruct.LS_StartValue            = zeros(1,3,'single');

                        ParkingStruct.LS_Trigger_FLAG          = uint8(0);   % 1 - low speed mode    0 - high speed mode     %%%%% update on 2/13/2017    initialized  @ low speed mode for shipping  

                        ParkingStruct.Calibration_FLAG         = uint8(0);   % 1 - calibration process finishe    %%%%% update on 2/13/2017    initialized as no calibration @ beginning                     
                        ParkingStruct.Calibration_InitFLAG     = uint8(0);
                        
                        
                        if ParkingStruct.BLE_Trigger_FLAG  == uint8(3)
                            
                           ParkingStruct.BLE_Trigger_PatternAFLAG  = uint8(1);
                           
                        end
                        
                        
                    end                   

                end

                

            end
            
        end
    
        
        
        
        
    %%%%% Normal operation mode
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    else
    
        if ((abs(magData(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
            || (abs(magData(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
            || (abs(magData(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
            || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
            || ParkingStruct.Context_Input > uint8(0)
        
        
        
            if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
                ParkingStruct.StartNUM          = ParkingStruct.NUM;
            end        
        



            % hardware alarm 
%             ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
            ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
        end
        
        
        
%         % software alarm 
%         ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),0);        
        
        
        
    end





% % %     % software alarm 
% % %     ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),0);
    





    

   magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
%    MEAN_value(i,1) = ParkingStruct.AVG;
   STD_value(i,1)  = ParkingStruct.STD;
   
   MEAN_value2(i,:) = ParkingStruct.AVG2;
   
   MEAN_value(i,2) = ParkingStruct.moving_avg;
   
   moving_avg(i,1)=ParkingStruct.moving_avg;
   
   car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2];
%    car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2 ParkingStruct.car_present ParkingStruct.car_present2]; 
   Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG; 
   
%    RMS(i,1) = ParkingStruct.RMS;
   
   SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;
   
   BLE_Trigger_FLAG(i,:)=ParkingStruct.BLE_Trigger_FLAG;

   
end


% static_state1 = [ParkingStruct.AVGInit2 single(1)];
% static_state = [static_state1; ParkingStruct.LS_StartValue_stateALL];
% 
% for i = 1:size(static_state,1)
%     static_state(i,5) = sum(abs(static_state(i,1:3) - static_state(1,1:3)));
%     static_state(i,6) = sqrt(sum(static_state(i,1:3).^2)) - sqrt(sum(static_state(1,1:3).^2));
% end




figure;
subplot(4,1,1); plot(time,magNdata),title('absolute mag'); grid on;
subplot(4,1,2); plot(time,MEAN_value(:,2)),title('Feature: Magnetic Counts Change'); grid on;
subplot(4,1,3); plot(time,STD_value),title('Feature: STD'); grid on;
subplot(4,1,4); plot(time,Alarm_level),title('Alarm Trigger Level'); grid on;



figure;
subplot(3,1,1); plot(time,moving_avg),title('Feature: Magnetic Counts Change');  grid on;
subplot(3,1,2); plot(time,car_state(:,1:2)),title('Car States from MATLAB'); grid on; 
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
% xlabel('Time (Seconds)');



% subplot(3,1,3); plot(time,SentralOutput),title('Car States from SENtral'); grid on;
subplot(3,1,3); plot(time,car_state(:,1)),title('Car States from SENtral'); grid on;
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
xlabel('Time (Seconds)');






% subplot(4,1,4); plot(time,detection_output),title('Theshold Detection'); grid on;
% set(gca,'YTick',0:3);
% labels = [
%         'Under Thresh   ';
%         'Over Thresh (t)';
%         'Over Thresh (s)';
%         'Anomaly        ';
%         ];
% set(gca,'YTickLabel',labels)