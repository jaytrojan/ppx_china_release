function y = Parking_std(x,sizeofX)

%STD Standard deviation.


xbar  = mean(x);

y     = single(0);

for i =1:sizeofX
    y = y + (x(i)-xbar)* (x(i)-xbar);
end

y = y /(single(sizeofX)-single(1));

y = sqrt(y);






% 
% function y = Parking_std(x)
% 
% %STD Standard deviation.
% 
% 
% xbar  = mean(x);
% 
% y     = single(0);
% 
% for i =1:8
%     y = y + (x(i)-xbar)* (x(i)-xbar);
% end
% 
% y = y /single(7);
% 
% y = sqrt(y);