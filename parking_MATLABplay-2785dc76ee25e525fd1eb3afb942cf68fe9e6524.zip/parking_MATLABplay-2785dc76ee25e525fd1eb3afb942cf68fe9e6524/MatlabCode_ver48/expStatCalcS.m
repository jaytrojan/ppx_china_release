function dfiltS = expStatCalcS(dfiltS,alpha,beta)

% exp average
dfiltS.dataFilt = alpha*dfiltS.dataFilt + beta*dfiltS.data;

% exp variance
dataDev = dfiltS.data-dfiltS.dataFilt;
dfiltS.dataVar = dataDev .* dataDev;
dfiltS.dataVarFilt = alpha*dfiltS.dataVarFilt + beta*dfiltS.dataVar;