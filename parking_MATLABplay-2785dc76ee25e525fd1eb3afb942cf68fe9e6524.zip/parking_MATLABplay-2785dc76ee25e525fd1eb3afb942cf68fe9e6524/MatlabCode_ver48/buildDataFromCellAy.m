function dataAy = buildDataFromCellAy(dataCellAy,iay)

% build data arrays
N = size(dataCellAy,1);
% iay = [iSentralTime iData iRSSI];
dataAy = [];
for ii=1:N
    dline = [];
    for jj=1:length(iay)
        dline=[dline  str2double(cell2mat(dataCellAy(ii,iay(jj))))];
    end
   dataAy=[dataAy;   dline];
end
