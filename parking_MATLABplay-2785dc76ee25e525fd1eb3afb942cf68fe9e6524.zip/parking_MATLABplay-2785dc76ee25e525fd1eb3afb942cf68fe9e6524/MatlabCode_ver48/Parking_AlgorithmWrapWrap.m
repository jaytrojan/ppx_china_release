function [ParkingStruct, filtStruct, numcarprev, car_state, parkStatusAy] = Parking_AlgorithmWrapWrap(ParkingStruct, filtStruct, magData, magSenTimestamp, time, time2, HS_mode_triggerIND, numcarprev, i, car_state, parkStatusAy, triggertwoevent)
% Compartmentalization of all the virtual sensor operations that occur when
% calling the main wrapper for the parking algorithm

            ParkingStruct.stateCorrection_FLAG   = uint8(0); % default not correcting an error in state


            %%% LS/HS baseline measurement
            if  ParkingStruct.LS_Trigger_FLAG == 1
                % LS
                sRate = ParkingStruct.LS_rate;
            else
                % HS
                sRate = ParkingStruct.HS_rate;
            end
%             filtStruct.baseFilt = baseLineFilt(filtStruct.baseFilt,magData,sRate);


            % conditional simulates RM3100 hardware mode
            MAG_trigger = ((abs(magData(1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
                    || (abs(magData(2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
                    || (abs(magData(3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) );

%             if MAG_trigger %observation on whether the system is triggering due to HS mode or not
%                 ParkingStruct.HS_Trigger_thresh_FLAG = uint8(1);
%             end

            if  MAG_trigger...
                    || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
                    || (~isempty(HS_mode_triggerIND) && any(HS_mode_triggerIND == ParkingStruct.NUM))

                if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
                    ParkingStruct.StartNUM          = ParkingStruct.NUM;
                end

%                 disp(time2(i))
                if time2>= 4290
                    testState=1;
                end
                
                LS_StartValue_state3prev = ParkingStruct.LS_StartValue_state3;
                
                % hardware alarm
                %         ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
                [ParkingStruct, filtStruct] = Parking_AlgorithmWrap(ParkingStruct, filtStruct, magData,magSenTimestamp,1);

                % code to cause a quick empty-occupied jump whenever
                % additional cars are detected, this is to ensure in a two
                % car scenario that the first car does not pay for two cars

                %%%% now controlled by demoFLAG on virtual driver system%%%
                if ParkingStruct.LS_Trigger_FLAG == 1
                    state3dif = abs(sum(LS_StartValue_state3prev - ParkingStruct.LS_StartValue_state3));
                    disp([time time2 state3dif])
                end

                %%%% now controlled by demoFLAG on virtual driver system%%%
                if triggertwoevent>0 && ParkingStruct.LS_Trigger_FLAG == 1 && ParkingStruct.car_present == 3 && ParkingStruct.car_present2 == 3 ...
                        && (ParkingStruct.car_presentPre == 3 && ParkingStruct.car_presentPre2 == 3 && (ParkingStruct.NumCars_DriveThru - numcarprev) > 0)...
                        && ParkingStruct.Car_State_last_HS == uint8(3) && bitand(ParkingStruct.DemoFLAG,2) == uint8(2) && state3dif > ParkingStruct.state3dif_thr
%                         || (ParkingStruct.NumCars_DriveThru - numcarprev) > 1)

                        % go back a step and modify the car status arrays
                        parkStatusAy(i-1).car_present       = uint8(1);
                        parkStatusAy(i-1).car_present2      = uint8(1);
                        parkStatusAy(i-1).car_presentCur	= uint8(1);
                        parkStatusAy(i-1).car_presentCur2   = uint8(1);
                        car_state(i-1,:) = [uint8(1) uint8(1) uint8(1) uint8(1)];

                end

                numcarprev =ParkingStruct.NumCars_DriveThru;

                %          %%%%% downsample to 4 Hz
                %          if ParkingStruct.downsampleFLAG == 1
                %             ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),magSenTimestamp(i),1);
                %             ParkingStruct.downsampleFLAG = 0;
                %          else
                %              ParkingStruct.downsampleFLAG = 1;
                %          end
                if ParkingStruct.lsRecheckEnable >= 0 %&& ParkingStruct.HS_Trigger_thresh_FLAG
                    ParkingStruct.cPastLsMode = uint16(0);
                    ParkingStruct.lsRecheckEnable = int8(1);
                end
            else
                %                 disp('Hardware LS Mode Sim Pt!!!')
%                 ParkingStruct.HS_Trigger_thresh_FLAG = uint8(0);
                ParkingStruct.cPastLsMode = ParkingStruct.cPastLsMode + uint16(1); % keep track of time since last parking event

                if ParkingStruct.cPastLsMode > ParkingStruct.LS_rate * ParkingStruct.lsRecheckTime % only perform check if the system is confirmed in parked mode
                    ParkingStruct = Parking_isEmptyCheck(ParkingStruct,magData);
                end
            end

end

