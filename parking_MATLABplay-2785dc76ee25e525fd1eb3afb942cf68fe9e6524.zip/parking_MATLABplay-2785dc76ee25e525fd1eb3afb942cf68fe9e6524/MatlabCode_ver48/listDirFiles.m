function fileList = listDirFiles(MainDirName,matchExt,excludeFileStr)

% matchExt = '.mat';
dirList = dir(MainDirName);
fileList = [];
for idir=1:length(dirList)
    testFileDir = dirList(idir).folder;
    testDirFname = dirList(idir).name;
    dirFlag = dirList(idir).isdir;
    
    fileNameCheck = [testFileDir '\' testDirFname];
    [pathstr,name,ext] = fileparts(fileNameCheck);
    
    if ~dirFlag && ~isempty(testDirFname) && ~(strcmp(testDirFname,'.')) && ~(strcmp(testDirFname,'..'))
        % file case
        excludeFileCheck = isempty(strfind(name,excludeFileStr));
%         disp(excludeFileCheck)
        if excludeFileCheck && strcmp(ext,lower(matchExt))
            fileList = [fileList; {fileNameCheck}];
        end
    elseif dirFlag && ~isempty(testDirFname) && ~(strcmp(testDirFname,'.')) && ~(strcmp(testDirFname,'..'))
        % dir case (recursive)
        fileListSubDir = listDirFiles(fileNameCheck,matchExt,excludeFileStr);
        fileList = [fileList; fileListSubDir];
    end
    
end