close all;
clear; clc;
dbstop if error



addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\Argentina Units\phone_logs')

[FileName,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File -mag data');


[rawData,~] = xlsread(FileName);

mraw = rawData(:,4:6);

timeRaw = rawData(:,9)+rawData(:,8)*65536;
timeRaw = (timeRaw-timeRaw(1))/32000;


figure; plot(timeRaw,mraw); grid on;
title(FileName);
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');



% magData       = mraw(start_ind:end_ind,:);
% time          = timeRaw(start_ind:end_ind,:);


figure; plot(mraw); grid on;
legend('mag-x', 'mag-y', 'mag-z');


NFFT = 4096;
sampling_rate = 250;


[pxx,f] = periodogram( mraw,hamming(length(timeRaw)),NFFT,sampling_rate);

figure;
plot(f,10*log10(pxx)); title('Spectrum-drive through'); xlabel('Frequency (Hz)'); grid on;     
legend('mag-x', 'mag-y', 'mag-z');



figure;
[pxx,f] = periodogram( mraw(:,1),hamming(length(timeRaw)),NFFT,sampling_rate);
subplot(3,1,1);plot(f,10*log10(pxx));  grid on;  hold on; 
title('X axis'); xlabel('Frequency (Hz)'); 

[pxx,f] = periodogram( mraw(:,2),hamming(length(timeRaw)),NFFT,sampling_rate);
subplot(3,1,2);plot(f,10*log10(pxx));  grid on;  hold on; 
title('Y axis'); xlabel('Frequency (Hz)'); 

[pxx,f] = periodogram( mraw(:,3),hamming(length(timeRaw)),NFFT,sampling_rate);
subplot(3,1,3);plot(f,10*log10(pxx));   grid on;  hold on; 
title('Z axis'); xlabel('Frequency (Hz)'); 


  

