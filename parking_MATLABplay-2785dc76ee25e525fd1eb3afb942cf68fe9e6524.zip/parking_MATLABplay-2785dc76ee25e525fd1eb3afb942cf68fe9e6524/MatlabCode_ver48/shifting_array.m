function aa=shifting_array(aa)

L=length(aa);

for i=1:L-1
    aa(i,:)=aa(i+1,:);
end
    
