function [plotInfo,figPlotS,cntrlInfo,haxS] = parkingDataPlot(plotData,dataStruct,dataInfo,cntrlInfo,parkImageShow,plotInfo,figPlotS,haxS)

fNameTitle = plotData.fNameTitle;

timeRaw = plotData.timeRaw;
time2 = plotData.time2;
dt = plotData.dt;
servTime = plotData.servTime;
tgapmeas = plotData.tgapmeas;
dtBigInds = plotData.dtBigInds;
LS_Trigger_FLAG_ay = plotData.LS_Trigger_FLAG_ay;
parkStatusAy = plotData.parkStatusAy;
parkMeasAy = plotData.parkMeasAy;
startInd = plotData.startInd;
time2Temp = plotData.time2Temp;

car_state = plotData.car_state;
truth_state = plotData.truth_state;
SentralOutput = plotData.SentralOutput;
tcalRangeInds = plotData.tcalRangeInds;
        
magData = plotData.magData;
magDataRef = plotData.magDataRef;
magDataDelta = plotData.magDataDelta;
magDataDeltaR = plotData.magDataDeltaR;
magDataDeltaDiff = plotData.magDataDeltaDiff;
magDataDeltaDiffR = plotData.magDataDeltaDiffR;
magDataR = plotData.magDataR;

truthDataNeighbor = [] ;
truthDataStoppedTraffic = [] ;
truthDataTraffic = [] ;
if isfield(dataStruct,'simS')
%     truthDataParked = dataStruct.simS.truthDataParked ;
    truthDataNeighbor = dataStruct.simS.truthDataNeighbor ;
    truthDataStoppedTraffic = dataStruct.simS.truthDataStoppedTraffic ;
    truthDataTraffic = dataStruct.simS.truthDataTraffic ;
end

% differential bin clr inds
dbinclrs = [...
    0     0   51  102
    0.25  0   102 204
    0.5   51  153 255
    1     153 204 255
    2     0   204 0
    4     0   255 0
    6     102 255 102
    8     255 128 0
    10    255 178 102
    30    255 0   0
    100   255 102 255 ...
    ];

dbinInds = zeros(length(magDataDeltaDiffR),1);
for ii=1:length(dbinclrs)-1
    inds = magDataDeltaDiffR >= dbinclrs(ii) &  magDataDeltaDiffR < dbinclrs(ii+1);
    dbinInds(inds) = ii;
end
inds = magDataDeltaDiffR >= dbinclrs(ii+1);
dbinInds(inds) = ii+1;



figFld = 'magDeltaVectorSample';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    % plot(time,magDataDelta,'.-')
    % plot(magDataDelta,'.-'); hold all
    % plot(magDataDeltaR,'-k','LineWidth',2)
    plot(hax, magDataDelta(:,1),'.-b','LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax, magDataDelta(:,2),'.-g','LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax, magDataDelta(:,3),'.-r','LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax, magDataDeltaR(:,:),'.-k','LineWidth',2,'MarkerSize',18)
    title(hax, ['Mag Data Vector Delta vs Sample:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
    xlabel(hax, 'Sample Index','FontSize',14,'FontWeight','bold');
    ylabel(hax, 'uT','FontSize',14,'FontWeight','bold');
    legend(hax, 'X','Y','Z','R')
    haxS.(figFld) = hax;
end


% plot time
figFld = 'Time';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    plot(hax,timeRaw,'.-b','LineWidth',1.0,'MarkerSize',14)
    plot(hax,time,'.-g','LineWidth',1.0,'MarkerSize',14)
    title(hax,['Time:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
    xlabel(hax,'samples','FontSize',14,'FontWeight','bold');
    ylabel(hax,'t (sec)','FontSize',14,'FontWeight','bold');
    %             ylim([-0.5 2])
    grid on
    haxS.(figFld) = hax;
end

% plot deltatime
figFld = 'deltaTime';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    plot(hax,time2,dt,'.-b','LineWidth',1.0,'MarkerSize',14)
    title(hax,['DeltaTime:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
    xlabel(hax,'t(sec)','FontSize',14,'FontWeight','bold');
    ylabel(hax,'dt (sec)','FontSize',14,'FontWeight','bold');
    ylim([-0.1 2.1])
    grid on
    haxS.(figFld) = hax;
end


%%% >>> mag data full vs time
titleStr = ['Mag Data Full vs Time:  ' fNameTitle];
figFld = 'magDataFull';
figN = figPlotS.(figFld)(1);
if figN
    hax = plotMagDataTime(time2,servTime,tgapmeas,magData,magDataR,dtBigInds,figN,titleStr);
    haxS.(figFld) = hax;
end
%%% >>> mag data vs time


%         set(0,'DefaultFigureWindowStyle','docked') %docked figures

%%% >>> mag delta data vs time
titleStr = ['Mag Data Vector Delta vs Time:  ' fNameTitle];
figFld = 'magDeltaVectorTime';
figN = figPlotS.(figFld)(1);
if figN
    hax = plotMagDataTime(time2,servTime,tgapmeas,magDataDelta,magDataDeltaR,dtBigInds,figN,titleStr,startInd);
    haxS.(figFld) = hax;
end
%%% >>> mag delta data vs time


%%% >>> mag delta data vs serv time
titleStr = ['Mag Data Vector Delta vs Server Time:  ' fNameTitle];
figFld = 'magDeltaVectorServTime';
figN = figPlotS.(figFld)(1);
if figN
    hax = plotMagDataServerTime(servTime,tgapmeas,magDataDelta,magDataDeltaR,dtBigInds,figN,titleStr);
    haxS.(figFld) = hax;
end
%%% >>> mag delta data vs serv time


%%% >>> rssi vs time
titleStr = ['RSSI vs Time:  ' fNameTitle];
figFld = 'rssiTime';
figN = figPlotS.(figFld)(1);
try
    if figN
        hax = plotRSSIDataTime(time2,servTime,tgapmeas,dataStruct.RSSIdata,dtBigInds,figN,titleStr);
        haxS.(figFld) = hax;
    end
catch
end
%%% >>> rssi vs time


%%% >>> temp vs time
titleStr = ['Temperature vs Time:  ' fNameTitle];
figFld = 'temperatureTime';
figN = figPlotS.(figFld)(1);
try
    if figN
        hax = plotTempDataTime(time2Temp,servTime,tgapmeas,dataStruct.dataTempAy(:,2),dtBigInds,figN,titleStr);
        haxS.(figFld) = hax;
    end
catch
end
%%% >>> rssi vs time


%%% >>> mag sample2sample delta data vs time
titleStr = ['Mag sample2sample Vector Delta vs Time:  ' fNameTitle];
figFld = 'magS2SDeltaVectorTime';
figN = figPlotS.(figFld)(1);
try
    if figN
        hax = plotMagDataTime(time2,servTime,tgapmeas,magDataDeltaDiff,magDataDeltaDiffR,dtBigInds,figN,titleStr);
        haxS.(figFld) = hax;
    end
catch
end

%%% >>> mag sample2sample delta data vs time



% static_state1 = [ParkingStruct.AVGInit2 single(1)];
% static_state = [static_state1; ParkingStruct.LS_StartValue_stateALL];
%
% for i = 1:size(static_state,1)
%     static_state(i,5) = sum(abs(static_state(i,1:3) - static_state(1,1:3)));
%     static_state(i,6) = sqrt(sum(static_state(i,1:3).^2)) - sqrt(sum(static_state(1,1:3).^2));
% end

figFld = 'HSmode';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    plot(time2,LS_Trigger_FLAG_ay,'.-');
    grid on
    title('HS Mode')
    xlabel('t(sec)')
    haxS.(figFld) = hax;
end

%%% >>> Car States
figFld = 'carStates';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    
    %         truth_state = car_state;
    %         global plotInfo dataInfo
    %         dataInfo.truth_state = truth_state;
    %         plotInfo.hTruthStateLine = plot(hax4,time2,truth_state(:,1),'-c','LineWidth',2,'MarkerSize',20); hold all
    %         plotInfo.hCarStateLine = plot(hax4,time2,car_state(:,1),':b','LineWidth',1,'MarkerSize',20); hold all
    %         plotInfo.hSenStateLine = plot(hax4,time2,SentralOutput(:,1),':g','LineWidth',1,'MarkerSize',20); hold all
    
    markInds = [dtBigInds; N];
    istart=1; istopprev = 0;
    hstateLineAy = []; hstateAy = []; hsenstateAy = [];
    for ii=1:length(markInds)
        istop = markInds(ii)-1;
        %             hstateLineAy(ii,1) =
        plot(hax,time2(istart:istop,:),car_state(istart:istop,1),'.-b','LineWidth',2,'MarkerSize',22); hold all
        plot(hax,time2(istart:istop,:),SentralOutput(istart:istop,1),'.--r','LineWidth',1.5,'MarkerSize',8); hold all
        if istopprev
            plot(hax,time2(istopprev:istart,:),car_state(istopprev:istart,1),':b'); hold all
            plot(hax,time2(istopprev:istart,:),SentralOutput(istopprev:istart,1),':r'); hold all
        end
        
        istart = markInds(ii);
        istopprev = istop;
    end
    hstateAy = [hstateAy plot(hax,time2(istop:N,:),car_state(istop:N,1),'.-b','LineWidth',1,'MarkerSize',22)]; hold all
    hsenstateAy = [hsenstateAy plot(hax,time2(istop:N,:),SentralOutput(istop:N,1),'.--r','LineWidth',1,'MarkerSize',8)]; hold all
    hstateAy = [hstateAy plot(hax,time2(N,:),car_state(N,1),'.b','LineWidth',1,'MarkerSize',30)]; hold all
    hsenstateAy = [hsenstateAy plot(hax,time2(N,:),SentralOutput(N,1),'.r','LineWidth',1,'MarkerSize',20)]; hold all
    
    %             % add discreet sentral parking events
    %             timeSentral = SentralOutputRaw(:,1)/32000;
    %             plot(hax4,time2(istart:istop,:),SentralOutput(istart:istop,1),'.-','LineWidth',2,'MarkerSize',20,'Color',[0 1 0]); hold all
    
    % add missing time notes
    ylim([0 4])
    yLim = ylim;
    ymk1 = 0.7;
    ymk2 = 3.5;
    for ii=1:length(dtBigInds)
        istart = dtBigInds(ii)-1;
        istop = dtBigInds(ii);
        tcent = mean(time2(istart:istop));
        tstr = num2str(round(tgapmeas(ii)/60));
        text(hax,tcent,ymk1,['~' tstr ' min~'],'HorizontalAlignment','center')
        
        % server time
        tserv = mean([tcent time2(istop)]);
        sTime = datestr(servTime(istart),'yy-mm-dd HH:MM');
        text(hax,tserv,ymk2,['[' sTime ']'],'HorizontalAlignment','center')
        
        % plot vertical line at start of each section
        tline = time2(istop);
        plot(hax,[tline tline],[yLim(1) yLim(2)],':k','LineWidth',1);
        
    end
    title(hax,['Matlab Car States vs Time:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
    xlabel(hax,'t(sec)','FontSize',14,'FontWeight','bold');
    % ylabel('uT','FontSize',14,'FontWeight','bold');
    % legend('X','Y','Z','vectR')
    set(hax,'YTick',1:4);
    labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
    set(hax,'YTickLabel',labels)
    legend(hax,'mat','sen')
    haxS.(figFld) = hax;
end
%%% >>> Car States


%%% >>> Car States with Truth
figFld = 'carStatesTruth';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    
    N = size(car_state,1);
    plotInfo.hTruthStateLine = plot(hax,time2(:,1),truth_state(:,1),'-c','LineWidth',14,'MarkerSize',20); hold all
    if startInd>1
        plotInfo.hTruthStateLineStart = plot(hax,time2(1:startInd-1,1),truth_state(1:startInd-1,1),'-','Color',[0 0.5 0.5],'LineWidth',14,'MarkerSize',20); hold all
    else
        plotInfo.hTruthStateLineStart = [];
    end
    plotInfo.hCarStateLine = plot(hax,time2,car_state(:,1),':b','LineWidth',1,'MarkerSize',20); hold all
    plotInfo.hSenStateLine = plot(hax,time2,SentralOutput(:,1),':r','LineWidth',1,'MarkerSize',20); hold all
    
    markInds = [dtBigInds; N];
    istart=1; istopprev = 0;
    hstateLineAy = [];
    hstateAy = [];
    hsenstateAy = [];
    for ii=1:length(markInds)
        istop = markInds(ii)-1;
        %             hstateLineAy(ii,1) =
        
        if istop > startInd
            cclr = 'b'; sclr = 'r';
        else
            cclr = [0 0 0.5]; sclr = [0.5 0 0];
        end
        
        hstateAy = [hstateAy plot(hax,time2(istart:istop,:),car_state(istart:istop,1),'.-','Color',cclr,'LineWidth',2,'MarkerSize',22)]; hold all
        hsenstateAy = [hsenstateAy plot(hax,time2(istart:istop,:),SentralOutput(istart:istop,1),'.--','Color',sclr,'LineWidth',1.5,'MarkerSize',8)]; hold all
        if istopprev
            plot(hax,time2(istopprev:istart,:),car_state(istopprev:istart,1),':','Color',cclr); hold all
            plot(hax,time2(istopprev:istart,:),SentralOutput(istopprev:istart,1),':','Color',sclr); hold all
        end
        
        istart = markInds(ii);
        istopprev = istop;
    end
    hstateAy = [hstateAy plot(hax,time2(istop:N,:),car_state(istop:N,1),'.-b','LineWidth',1,'MarkerSize',22)]; hold all
    hsenstateAy = [hsenstateAy plot(hax,time2(istop:N,:),SentralOutput(istop:N,1),'.--r','LineWidth',1,'MarkerSize',8)]; hold all
    hstateAy = [hstateAy plot(hax,time2(N,:),car_state(N,1),'.b','LineWidth',1,'MarkerSize',30)]; hold all
    hsenstateAy = [hsenstateAy plot(hax,time2(N,:),SentralOutput(N,1),'.r','LineWidth',1,'MarkerSize',20)]; hold all
    plotInfo.hstateAy = hstateAy;
    plotInfo.hsenstateAy = hsenstateAy;
    
    % add missing time notes
    ylim([-0.5 4])
    yLim = ylim;
    ymk1 = 0.7;
    ymk2 = 3.5;
    for ii=1:length(dtBigInds)
        istart = dtBigInds(ii)-1;
        istop = dtBigInds(ii);
        tcent = mean(time2(istart:istop));
        tstr = num2str(round(tgapmeas(ii)/60));
        text(hax,tcent,ymk1,['~' tstr ' min~'],'HorizontalAlignment','center')
        
        % server time
        tserv = mean([tcent time2(istop)]);
        sTime = datestr(servTime(istart),'yy-mm-dd HH:MM');
        text(hax,tserv,ymk2,['[' sTime ']'],'HorizontalAlignment','center')
        
        % plot vertical line at start of each section
        tline = time2(istop);
        plot(hax,[tline tline],[yLim(1) yLim(2)],':k','LineWidth',1);
        
    end
    
    %             %%% add line for id time and image tracking
    %             Nimages = length(parkImageShow.dateTimeAyAy);
    %             time2_images = time2(1):((time2(end)-time2(1))/(Nimages-1)):time2(end);
    %             plotInfo.hTimeTrackLine = plot(haxS.carStatesTruth,time2_images,-0.25*ones(length(time2_images),1),'-','LineWidth',3,'MarkerSize',20,'Color',0.7*[1 1 1]); hold all
    
    title(hax,['Car States vs Time with Truth:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
    xlabel(hax,'t(sec)','FontSize',14,'FontWeight','bold');
    % ylabel('uT','FontSize',14,'FontWeight','bold');
    % legend('X','Y','Z','vectR')
    set(hax,'YTick',0:4);
    labels = {
        'Unknown';
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
    set(hax,'YTickLabel',labels)
    legend(hax,[plotInfo.hTruthStateLine hstateAy(1) hsenstateAy(1)], {'truth','mat','sen'})
    
    % extra plots
    if ~isempty(truthDataNeighbor)
        plot(hax,time2(:,1),truthDataNeighbor(:,1)*0.5+3.25,'-','LineWidth',5,'MarkerSize',20,'Color',[0 1 1]*0.7); hold all
    end
    if ~isempty(truthDataStoppedTraffic)
        plot(hax,time2(:,1),truthDataStoppedTraffic(:,1)*0.5+3.25,'-','LineWidth',3,'MarkerSize',20,'Color',[0 1 1]*0.5); hold all
    end
    if ~isempty(truthDataTraffic)
        plot(hax,time2(:,1),truthDataTraffic(:,1)*0.5+3.25,'-','LineWidth',2,'MarkerSize',20,'Color',[0 1 1]*0.3); hold all
    end
    
    %         figN = 106;
    
    plotInfo.hBr = brush(figN);
    plotInfo.hBr.ActionPostCallback = {@brushSelectCallback};
    %             plotInfo.hBr.Enable = 'on';
    
    
    figCntrl = 10155;
    figure(figCntrl); clf
    
    cntrlInfo.figCntrl = figCntrl;
    set(figCntrl,'Units','normalized','Position',[0.75 0.4 0.22 0.5])
    cntrlInfo.sld = uicontrol(figCntrl,'Style', 'slider',...
        'Min',0,'Max',4,'Value',0,...
        'SliderStep',[0.25 0.25],...
        'Units','normalized',...
        'Position', [0.20 0.10 0.2 0.7], ...
        'Callback', @carStateCallback);
    
    cntrlInfo.sldTitle = uicontrol(figCntrl,'Style', 'text',...
        'FontSize',14,'FontWeight','bold',...
        'String','Car State Update',...
        'Units','normalized',...
        'Position', [0.20 0.82 0.6 0.14] ...
        );
    
    cntrlInfo.sldText = uicontrol(figCntrl,'Style', 'text',...
        'FontSize',24,'FontWeight','bold',...
        'String','000',...
        'Units','normalized',...
        'Position', [0.45 0.6 0.37 0.25] ...
        );
    
    
    cntrlInfo.startTimeText = uicontrol(figCntrl,'Style', 'text',...
        'FontSize',10,'FontWeight','bold',...
        'String','Start Time',...
        'Units','normalized',...
        'Position', [0.52 0.68 0.38 0.04] ...
        );
    cntrlInfo.startTimeEdit = uicontrol(figCntrl,'Style', 'edit',...
        'FontSize',10,'FontWeight','bold',...
        'String','',...
        'Units','normalized',...
        'Position', [0.52 0.63 0.38 0.05], ...
        'Callback', @updateMetaCallback);
    
    cntrlInfo.preCalCheck = uicontrol(figCntrl,'Style', 'checkbox',...
        'FontSize',10,'FontWeight','bold',...
        'String','Perform Pre-Cal',...
        'Units','normalized',...
        'Position', [0.52 0.54 0.38 0.07], ...
        'Callback', @updateMetaCallback);
    
    cntrlInfo.calTimesText = uicontrol(figCntrl,'Style', 'text',...
        'FontSize',10,'FontWeight','bold',...
        'String','Cal Times',...
        'Units','normalized',...
        'Position', [0.52 0.48 0.38 0.04] ...
        );
    cntrlInfo.calTimesEdit = uicontrol(figCntrl,'Style', 'edit',...
        'FontSize',10,'FontWeight','bold',...
        'String','',...
        'Units','normalized',...
        'Position', [0.52 0.43 0.38 0.05], ...
        'Callback', @updateMetaCallback);
    
    
    %             cntrlInfo.calContextCheck = uicontrol(figCntrl,'Style', 'checkbox',...
    %                     'FontSize',10,'FontWeight','bold',...
    %                     'String','Cal Context',...
    %                     'Units','normalized',...
    %                     'Position', [0.52 0.38 0.38 0.07], ...
    %                     'Callback', @updateMetaCallback);
    
    cntrlInfo.loadImagesCheck = uicontrol(figCntrl,'Style', 'checkbox',...
        'FontSize',10,'FontWeight','bold',...
        'String','Load Images',...
        'Units','normalized',...
        'Position', [0.52 0.34 0.38 0.07], ...
        'Callback', @loadImagesCallback);
    
    
    cntrlInfo.resetTruthSessionBtn = uicontrol(figCntrl,'Style', 'pushbutton',...
        'FontSize',8,'FontWeight','bold',...
        'String','Reset Truth Session',...
        'Units','normalized',...
        'Position', [0.52 0.26 0.38 0.06], ...
        'Callback', @resetTruthSessionCallback);
    
    cntrlInfo.resetTruthBtn = uicontrol(figCntrl,'Style', 'pushbutton',...
        'FontSize',8,'FontWeight','bold',...
        'String','Reset Truth to Car State',...
        'Units','normalized',...
        'Position', [0.52 0.18 0.38 0.06], ...
        'Callback', @resetTruthCallback);
    
    cntrlInfo.saveBtn = uicontrol(figCntrl,'Style', 'pushbutton',...
        'FontSize',10,'FontWeight','bold',...
        'String','Save Meta Data',...
        'Units','normalized',...
        'Position', [0.52 0.05 0.38 0.08], ...
        'Callback', @saveTruthCallback);
    
    
    if ~isempty(dataInfo.startTime)
        cntrlInfo.startTimeEdit.String = num2str(dataInfo.startTime);
    end
    if length(dataInfo.calTime)>1
        cntrlInfo.calTimesEdit.String = [num2str(dataInfo.calTime(1)) ', ' num2str(dataInfo.calTime(2))];
    end
    cntrlInfo.preCalCheck.Value = dataInfo.preCalLoop;
    cntrlInfo.loadImagesCheck.Value = parkImageShow.on;
    
    haxS.(figFld) = hax;
    
end
%%% >>> Car States with Truth



%%% >>> 3d quiver over time
set(0,'DefaultFigureWindowStyle','normal') %docked figures

figFld = 'magDeltaVector3D';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    N = size(magDataDelta,1);
    x = time2; y=zeros(N,1); z=zeros(N,1);
    qh0 = quiver3(hax,x,y,z,magDataDelta(:,1),magDataDelta(:,2),magDataDelta(:,3),0);
    qh0.LineStyle = '--';
    qh0.LineWidth = 0.5;
    qh0.Color = [1 1 1]*0.7;
    grid on
    title(hax,['Mag Vector 3D vs Time:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
    xlabel(hax,'t(sec) & uT','FontSize',12,'FontWeight','bold');
    ylabel(hax,'uT','FontSize',12,'FontWeight','bold');
    zlabel(hax,'uT','FontSize',12,'FontWeight','bold');
    
    hold all
    tplotLims2 = [];
    if ~isempty(tplotLims2)
        tinds0 = time2 >= tplotLims(1) & time2 <= tplotLims(2);
    else
        tinds0 = true(length(time2),1);
    end
    tinds0 = tinds0 & magDataDeltaDiffR > 1;
    
    for ii=1:size(dbinclrs,1)
        inds = find(dbinInds == ii & tinds0);
        if ~isempty(inds)
            for jj=1:length(inds)
                inds2 = inds(jj);
                N = length(inds2);
                x = time2(inds2,:); y=zeros(N,1); z=zeros(N,1);
                qh = quiver3(hax,x,y,z,magDataDelta(inds2,1),magDataDelta(inds2,2),magDataDelta(inds2,3),0);
                qh.LineStyle = '-';
                qh.LineWidth = 3;
                qh.Color = dbinclrs(ii,2:end)/255;
            end
        end
    end
    
    %     xlim(hax3q,[470 490])
    %     xlim('auto')
    haxS.(figFld) = hax;
end
%%% >>> 3d quiver over time


%%% >>> plot parking status fields
parkStatusFlds = fieldnames(parkStatusAy);
% Context_InputAy = [parkStatusAy.Context_Input]'
plotInfo.parkStatusFlds = parkStatusFlds;

figFld = 'parkStatus';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    lineStyles = {':','-.','--','-','.:','.-.','.--','.-'};
    istyle = 0;
    hlines = [];
    for ifld = 1:length(parkStatusFlds)
        data = single([parkStatusAy.(parkStatusFlds{ifld})]');
        
        % style only if nonzero data
        if sum(data)
            istyle=istyle+1;
            if istyle>length(lineStyles), istyle = 1; end
            lstyle = lineStyles{istyle};
            lwidth = 2;
        else
            lstyle = ':k';
            lwidth = 1;
        end
        
        hlines = [hlines; plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)];
        hold all
    end
    hStatusAy = hlines;
    haxS.(figFld) = hax;
    title(hax,['Park Status Fields:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
    xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
    ylabel(hax,'status','FontSize',12,'FontWeight','bold');
    grid on
    legend(parkStatusFlds);
    ylim([0 12]);
    
    % custom data cursor with line name info
    dcm_obj1 = datacursormode(figN);
    set(dcm_obj1,'UpdateFcn',@dispMkrTimeLineNameFcn);
    
    
    %%% create drop down list of status fields
    figStatus = 10166;
    figure(figStatus); clf
    
    statusInfo = [];
    statusInfo.figStatus = figStatus;
    set(figStatus,'MenuBar','none');
    set(figStatus,'Units','normalized','Position',[0.05 0.25 0.22 0.7])
    
    popUpAy = ['~none~'; plotInfo.parkStatusFlds];
    statusInfo.popup = uicontrol('Style', 'listbox',...
        'String', popUpAy,...
        'Min', 1, 'Max', length(popUpAy),...
        'Units','normalized',...
        'Position', [0.10 0.06 0.8 0.84], ...
        'FontSize',10,'FontWeight','bold',...
        'Callback', @carStatusCallback);
    
    statusInfo.Title = uicontrol(figStatus,'Style', 'text',...
        'FontSize',14,'FontWeight','bold',...
        'String','HighLight Status Fields',...
        'Units','normalized',...
        'Position', [0.20 0.92 0.6 0.05] ...
        );
    
    % Save original status styles for reference
    statusRefStyleAy = [];
    for ifld=1:length(hStatusAy)
        statusRefStyleAy(ifld).Color = hStatusAy(ifld).Color;
        statusRefStyleAy(ifld).LineStyle = hStatusAy(ifld).LineStyle;
        statusRefStyleAy(ifld).LineWidth = hStatusAy(ifld).LineWidth;
        statusRefStyleAy(ifld).Marker = hStatusAy(ifld).Marker;
        statusRefStyleAy(ifld).MarkerSize = hStatusAy(ifld).MarkerSize;
        statusRefStyleAy(ifld).MarkerFaceColor = hStatusAy(ifld).MarkerFaceColor;
    end
    statusRefStyleAy = statusRefStyleAy;
    statusIndex = 0; % 0 is none
    
    % control struct
    plotInfo.statusPlotS.hAy = hStatusAy;
    plotInfo.statusPlotS.refStyleAy = statusRefStyleAy;
    plotInfo.statusPlotS.index = statusIndex;
end
%%% >>> plot parking status fields


%%% >>> plot parking meas fields
parkMeasFlds = fieldnames(parkMeasAy);
plotInfo.parkMeasFlds0 = parkMeasFlds;

figFld = 'parkMeas';
figN = figPlotS.(figFld)(1);
if figN
    figure(figN); clf
    hax = axes;
    lineStyles = {':','-.','--','-','.:','.-.','.--','.-'};
    istyle = 0;
    hlines = [];
    Nvals = length(parkMeasAy);
    legAy = [];
    for ifld = 1:length(parkMeasFlds)
        %                 fldSize = size(parkMeasAy(1).(parkMeasFlds{ifld}));
        data = single([parkMeasAy.(parkMeasFlds{ifld})]');
        data = reshape(data,[],Nvals)';
        fldSize = size(data);
        % style only if nonzero data
        if any(sum(data))
            istyle=istyle+1;
            if istyle>length(lineStyles), istyle = 1; end
            lstyle = lineStyles{istyle};
            lwidth = 2;
        else
            lstyle = ':k';
            lwidth = 1;
        end
        
        hlines = [hlines; plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)];
        %                 hlines = [hlines; {plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)}];
        
        legLine = [];
        if fldSize(2)<2
            legLine = [legLine parkMeasFlds(ifld)];
        else
            for iax=1:fldSize(2)
                legLine = [legLine {[parkMeasFlds{ifld} '-' num2str(iax)]}];
            end
        end
        legAy = [legAy legLine];
        hold all
    end
    hMeasAy = hlines;
    haxS.(figFld) = hax;
    title(hax,['Park Meas Fields:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
    xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
    ylabel(hax,'meas','FontSize',12,'FontWeight','bold');
    grid on
    legend(legAy);
    ylim([-60 60]);
    plotInfo.parkMeasFlds = legAy';
    
    % custom data cursor with line name info
    dcm_obj2 = datacursormode(figN);
    set(dcm_obj2,'UpdateFcn',@dispMkrTimeLineNameFcn2);
    
    
    %%% create drop down list of meas fields
    figMeas = 10177;
    figure(figMeas); clf
    
    measInfo = [];
    measInfo.figMeas = figMeas;
    set(figMeas,'MenuBar','none');
    set(figMeas,'Units','normalized','Position',[0.30 0.25 0.22 0.7])
    
    
    popUpAy = ['~none~'; plotInfo.parkMeasFlds];
    measInfo.popup = uicontrol('Style', 'listbox',...
        'String', popUpAy,...
        'Min', 1, 'Max', length(popUpAy),...
        'Units','normalized',...
        'Position', [0.10 0.06 0.8 0.84], ...
        'FontSize',10,'FontWeight','bold',...
        'Callback', @carMeasCallback);
    
    measInfo.Title = uicontrol(figMeas,'Style', 'text',...
        'FontSize',14,'FontWeight','bold',...
        'String','HighLight Meas Fields',...
        'Units','normalized',...
        'Position', [0.20 0.92 0.6 0.05] ...
        );
    
    % Save original meas styles for reference
    measRefStyleAy = [];
    for ifld=1:length(hMeasAy)
        measRefStyleAy(ifld).Color = hMeasAy(ifld).Color;
        measRefStyleAy(ifld).LineStyle = hMeasAy(ifld).LineStyle;
        measRefStyleAy(ifld).LineWidth = hMeasAy(ifld).LineWidth;
        measRefStyleAy(ifld).Marker = hMeasAy(ifld).Marker;
        measRefStyleAy(ifld).MarkerSize = hMeasAy(ifld).MarkerSize;
        measRefStyleAy(ifld).MarkerFaceColor = hMeasAy(ifld).MarkerFaceColor;
    end
    measRefStyleAy = measRefStyleAy;
    measIndex = 0; % 0 is none
    
    % control struct
    plotInfo.measPlotS.hAy = hMeasAy;
    plotInfo.measPlotS.refStyleAy = measRefStyleAy;
    plotInfo.measPlotS.index = measIndex;
end
%%% >>> plot parking meas fields



if isfield( plotData,'magStableMeas') && isfield(figPlotS,'magStableMeas')
    magStableMeas = plotData.magStableMeas;
    figFld = 'magStableMeas';
    figN = figPlotS.(figFld)(1);
    if figN
        figure(figN); clf
        hax = axes;
        haxS.(figFld) = hax;
        
        hmagStableMeas = [];
        hmagStableMeas(1) = plot(haxS.(figFld),time2,magStableMeas(:,1),'.--','LineWidth',1.0,'MarkerSize',10); hold all
        hmagStableMeas(2) = plot(haxS.(figFld),time2,magStableMeas(:,2),'.-','LineWidth',1.5,'MarkerSize',11);
        
        title(hax,['magStableMeas:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
        xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
        ylabel(hax,'uT','FontSize',12,'FontWeight','bold');
        grid on
        legend('stdCln','slopeClnMove')
    end
%         magStableMeas = [sqrt(sum(mstdCln.^2,2))  sqrt(sum(mslopeMoveClnMn.^2,2))];
    
    mstdCln = plotData.mstdCln;
    mslopeCln = plotData.mslopeCln;
    mslopeMoveClnStd = plotData.mslopeMoveClnStd;
    mslopeMoveClnMn = plotData.mslopeMoveClnMn;

    if figN
        figFldExtra = [figFld '_1'];
        figure(figN+1); clf
        hax = axes;
        haxS.(figFldExtra) = hax;
        hmagStableMeas1 = [];
        hmagStableMeas1(1,1) = plot(haxS.(figFldExtra),time2,mstdCln(:,1),'--b','LineWidth',1.0,'MarkerSize',10); hold all
        hmagStableMeas1(1,2) = plot(haxS.(figFldExtra),time2,mstdCln(:,2),'--g','LineWidth',1.0,'MarkerSize',10); hold all
        hmagStableMeas1(1,3) = plot(haxS.(figFldExtra),time2,mstdCln(:,3),'--r','LineWidth',1.0,'MarkerSize',10); hold all
        hmagStableMeas1(2,1) = plot(haxS.(figFldExtra),time2,mslopeCln(:,1),'.-b','LineWidth',1.5,'MarkerSize',11);
        hmagStableMeas1(2,2) = plot(haxS.(figFldExtra),time2,mslopeCln(:,2),'.-g','LineWidth',1.5,'MarkerSize',11);
        hmagStableMeas1(2,3) = plot(haxS.(figFldExtra),time2,mslopeCln(:,3),'.-r','LineWidth',1.5,'MarkerSize',11);
        title(hax,['magStableMeas1:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
        xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
        ylabel(hax,'uT','FontSize',12,'FontWeight','bold');
        grid on
        legend('mstdClnX','mstdClnY','mstdClnZ','mslopeClnX','mslopeClnY','mslopeClnZ')
    end
    
    if figN
        figFldExtra = [figFld '_2'];
        figure(figN+2); clf
        hax = axes;
        haxS.(figFldExtra) = hax;
        hmagStableMeas2 = [];
        hmagStableMeas2(1,1) = plot(haxS.(figFldExtra),time2,mslopeMoveClnStd(:,1),'--b','LineWidth',1.0,'MarkerSize',10); hold all
        hmagStableMeas2(1,2) = plot(haxS.(figFldExtra),time2,mslopeMoveClnStd(:,2),'--g','LineWidth',1.0,'MarkerSize',10); hold all
        hmagStableMeas2(1,3) = plot(haxS.(figFldExtra),time2,mslopeMoveClnStd(:,3),'--r','LineWidth',1.0,'MarkerSize',10); hold all
        hmagStableMeas2(2,1) = plot(haxS.(figFldExtra),time2,mslopeMoveClnMn(:,1),'.-b','LineWidth',1.5,'MarkerSize',11);
        hmagStableMeas2(2,2) = plot(haxS.(figFldExtra),time2,mslopeMoveClnMn(:,2),'.-g','LineWidth',1.5,'MarkerSize',11);
        hmagStableMeas2(2,3) = plot(haxS.(figFldExtra),time2,mslopeMoveClnMn(:,3),'.-r','LineWidth',1.5,'MarkerSize',11);
        title(hax,['magStableMeas2:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
        xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
        ylabel(hax,'uT','FontSize',12,'FontWeight','bold');
        grid on
        legend('mslopeMoveClnStdX','mslopeMoveClnStdY','mslopeMoveClnStdZ','mslopeMoveClnMnX','mslopeMoveClnMnY','mslopeMoveClnMnZ')
    end
    
end


%%% >>> show mag calibration data
% % %         if ~preCalLoop
% % %             % cal section defined by 'Calibration_FLAG'
% % %             dataCalFlags = single([parkStatusAy.('Calibration_FLAG')]');
% % %             tcalRangeInds = find(~dataCalFlags);
% % %             calTime = [time2(tcalRangeInds(1)) time2(tcalRangeInds(end))];
% % %         else
% % %             tcalRangeInds = find(time2>=calTime(1) & time2<=calTime(2));
% % %         end

figFld = 'magDataFull';
figN = figPlotS.(figFld)(1);
if figN
    hMagDataCal = plot(haxS.(figFld),time2(tcalRangeInds,:),magData(tcalRangeInds,:),'-c','LineWidth',10,'MarkerSize',10);
    uistack(hMagDataCal,'bottom')
end
figFld = 'magDeltaVectorTime';
figN = figPlotS.(figFld)(1);
if figN
    hMagDataDeltaCal = plot(haxS.(figFld),time2(tcalRangeInds,:),magDataDelta(tcalRangeInds,:),'-c','LineWidth',10,'MarkerSize',10);
    uistack(hMagDataDeltaCal,'bottom')
end


