function  [dataArray, hdrArray] = loadcsvTextCols(PathName,FileName,startRow,ncols)

% Initialize variables.
fName = [PathName FileName];

% startRow = 1;
endRow = inf;

if nargin<4
    ncols = 24;
end

delimiter = ',';

% if nargin<2
%     startRow = 1;
% end
% if nargin<3
%     endRow = inf;
% end
% if nargin<4
%     ncols = 16;
% end


%% Format for each line of text:
%   column3: double (%f)
%	column4: double (%f)
% For more information, see the TEXTSCAN documentation.
% formatSpec = '%u32%u32%u32%u32%[^\n\r]';
% formatSpec = '%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%f%[^\n\r]';
% formatSpec = '%f%f%f%f%f%f%f%f%f%f%[^\n\r]';
formatSpecHdr = [repmat('%s',1,ncols) '%[^\n\r]'];
formatSpec = [repmat('%s',1,ncols) '%[^\n\r]'];



%% Open the text file.
fileID = fopen(fName,'r');

%% Read columns of data according to the format.
% This call is based on the structure of the file used to generate this
% code. If an error occurs for a different file, try regenerating the code
% from the Import Tool.
% dataArray = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false, 'EndOfLine', '\r\n');

block = 1;
frewind(fileID);

% read hdr lines
if startRow>1
    hdrArray = textscan(fileID, formatSpecHdr, startRow-1, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines', 0, 'ReturnOnError', false, 'EndOfLine', '\r\n');
else
    hdrArray = {};
end

% read data
dataArray = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines', 0, 'ReturnOnError', false, 'EndOfLine', '\r\n');

    
%% Close the text file.
fclose(fileID);

%% Post processing for unimportable data.
% No unimportable data rules were applied during the import, so no post
% processing code is included. To generate code which works for
% unimportable data, select unimportable cells in a file and regenerate the
% script.

% %% Create output variable
% % time_array = [dataArray{tCols}];
% % topic_array = [dataArray{IDcol}];
% % % type_array = [dataArray{4}];
% % data_array = [dataArray{IDcol:end-1}];
% data_full_array = [dataArray{1:ncols}];
% 
% % limit to cols with data
% data_full_array = data_full_array(:,~all(isnan(data_full_array),1));
