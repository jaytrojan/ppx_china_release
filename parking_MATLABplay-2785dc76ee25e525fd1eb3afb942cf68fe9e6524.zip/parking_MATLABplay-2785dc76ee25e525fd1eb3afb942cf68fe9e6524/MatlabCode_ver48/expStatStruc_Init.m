function dfiltS = expStatStruc_Init()

dfiltS.data = single([0 0 0]);
dfiltS.dataFilt = single([0 0 0]);
dfiltS.dataVar = single([0 0 0]);
dfiltS.dataVarFilt = single([0 0 0]);
