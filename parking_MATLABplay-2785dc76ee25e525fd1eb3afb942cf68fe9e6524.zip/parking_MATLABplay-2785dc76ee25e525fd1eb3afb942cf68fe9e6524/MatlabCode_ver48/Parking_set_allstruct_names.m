function [ParkingStruct, filtStruct] = Parking_set_allstruct_names(ParkingStruct, filtStruct)
%#codegen
%
% MatLab script defining SP Algorithm arguments, structures, and default values
%
%
% ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
%
% Copyright (c) 2012 PNI Sensor Corporation.  All rights reserved.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% code generation structure name directives

coder.cstructname(ParkingStruct, 'Parking_struct_t'); % force eml structure name
coder.cstructname(filtStruct, 'filt_struct_t'); % force eml structure name