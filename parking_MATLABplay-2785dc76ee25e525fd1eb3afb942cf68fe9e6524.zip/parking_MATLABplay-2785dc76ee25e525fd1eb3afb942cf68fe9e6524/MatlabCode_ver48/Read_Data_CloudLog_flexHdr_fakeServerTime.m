function dataStruct = Read_Data_CloudLog_flexHdr_fakeServerTime(FileName, indS)

% [rawData,~] = xlsread(FileName);

% load all data into str columns
% magR  SENtralTime  SensorId  ServerTime_PST  CarPresence  Temperature  LoraWan_rssi  Confidence  magx magy magz
[dataStrArray, hdrArray0] = loadcsvTextCols('',FileName,2);


% read hdr from file
if isfield(indS,'hdr') && ~isempty(indS.hdr)
    hdrArray = [];
    for ii=1:length(hdrArray0)
        hdrArray = [hdrArray hdrArray0{ii}(1)];
    end
    excludeFlds = {'hdr'};
    flds = fieldnames(indS.hdr);
    for ii=1:length(flds)
        fldName = flds{ii};
        if ~any(strcmpi(excludeFlds,fldName))
            colNames = indS.hdr.(fldName);
            icols = [];
            for jj=1:length(colNames)
                icol = find(strcmpi(hdrArray,colNames{jj}),1,'first');
                if ~isempty(icol)
                    icols = [icols find(strcmpi(hdrArray,colNames{jj}),1,'first')];
                end
            end
            if ~isempty(icols)
                indS.(fldName) = icols; % reassign column
            end
        end
    end
end

iSentralTime = indS.iSentralTime;
iSensorID = indS.iSensorID;
% iServeTime = indS.iServeTime;
if isfield(indS,'iCarStat')
    iCarStat = indS.iCarStat;
else
    iCarStat = [];
end

iTemp = indS.iTemp;
iRSSI = indS.iRSSI;
% iConf = indS.iConf;
iData = indS.iData;


% build cell data array
dataCellAy = [];
for ii=1:length(dataStrArray)
    dataCellAy = [dataCellAy dataStrArray{ii}];
end
N = size(dataCellAy,1);

%%% reverse all data
reverseIdx = N:-1:1;
dataCellAy = dataCellAy(reverseIdx,:);
dataCellAy0 = dataCellAy;


%%% >>> remove mag data dups
% only look at inds with real mag data
dataMagAy = buildDataFromCellAy(dataCellAy,[iSentralTime iData iRSSI]);
magLogicInds = ~any(isnan(dataMagAy(:,1:4)),2); % global ref inds
dataMagAy = dataMagAy(magLogicInds,:);
magInds = find(magLogicInds); % global reference inds

% remove lines of duplicate data for relevant columns
[dataMagAyUnique,ia,ic] = unique(dataMagAy(:,1:4),'rows','stable');
magLogicIndsDupLocal = ones(size(dataMagAy,1),1,'logical');
magLogicIndsDupLocal(ia) = false;  % local reference inds
magIndsDup = magInds(magLogicIndsDupLocal); % global reference inds
% magIndsUnique = magInds(ia); % global reference inds

% duplicate mag inds
magLogicIndsDup = zeros(N,1,'logical');  % global reference inds
magLogicIndsDup(magIndsDup) = true;  % global reference inds

% remove dup inds
dataCellAy = dataCellAy(~magLogicIndsDup,:);
%%% >>> remove mag data dups

% generate time for each entry in csv
% time in seconds from start
% use sentral time unless '0', then interp or extrap from sentral time;
% unless time gap too big, then interp from server time or use server time.

% now there should not be any repeated mag data
% data should be still be in order logged by server
% can now deal with time wrap/reset issue
% for negative sentral deltatimes, look at servertime behavior to resolve.
% measure time scale adjust in clean sections???

% create similar dataset for non-magdata.

%%% sort first by server time, than by sentral time. Handle sentral wrap


%%% sort by sentral time
% redo Mag
dataMagAy = buildDataFromCellAy(dataCellAy,[iSentralTime iData iRSSI]);
tSen = dataMagAy(:,1);
tSen = tSen/32000;
[tSenSort, isenSort] = sort(tSen(:,1));
% dt = tSen(2:end,:) -  tSen(1:end-1,:);
% figure
% plot(dt)
dataCellAy = dataCellAy(isenSort,:);

%%% generate server time from sentral time
tSenSort_rel = tSenSort - tSenSort(1,:);
dateTimeAy = datetime(datevec(0)) + seconds(tSenSort_rel);
sentTime_temp = buildDataFromCellAy(dataCellAy,iSentralTime);


% % % % server time convert from str
% % % serverTimeStr = dataCellAy(:,iServeTime);
% % % sentTime_temp = buildDataFromCellAy(dataCellAy,iSentralTime);
% % % 
% % % dateTimeAy = dateTimeFromTimeStr(serverTimeStr);


%%% >>> sort by server time
[~, iservSort] = sort(dateTimeAy(:,1));
dateTimeAy = dateTimeAy(iservSort,:);
sentTime_temp = sentTime_temp(iservSort,:);
dataCellAy = dataCellAy(iservSort,:);
%%% >>> sort by server time


%%% >>> sort groups of sentral time within  server time group
N = size(dateTimeAy,1);
twrapFullCnts = (2^32); % wrap time in cnts
dtwrap = 0; % total wrap cnts that need to be added to all subsequent times
ii=1;
while ii<N
    % find inds for matching server time
    t0 = dateTimeAy(ii);
    inext = find(dateTimeAy(ii:end) ~= t0,1,'first'); % local
    if ~isempty(inext)
        inext = ii+inext-1; % global
        iiay0 = ii:inext-1; % global
    else
        iiay0 = ii:N; % global
    end
    
    % add any previous cumulative wraps to times
    sentTime_temp(iiay0) = sentTime_temp(iiay0) + dtwrap; 
    
    if length(iiay0)>1
        % sort sentral time where sentral time ~=0
        % apply sort to array for use on all data
        
        % sentral time to sort
        sent = sentTime_temp(iiay0);
        iiay1 = iiay0;

        % detect and handle wrap within group of same server time
        % assumption is later server times will have later sentral times
        % and wrap within group is constrained in time and not distributed
        % widely over a wrap period
        % only one wrap in group allowed
        % note this only handles a wrap within a group
        % other wraps handled later
        inot0 = sent~=0;
        if any(inot0)
%             tgrp = [95 80 10 90 5]';
%             twrapFullCnts = 100;
            %         tgrp = sentnot0;
            tgrp = sent(inot0);
            minVal = min(tgrp);
            maxVal = max(tgrp);
            dtsen = maxVal - minVal;
            if dtsen>0.5*twrapFullCnts
                % indicates min val is wraparound from maxval
                dtime = maxVal - tgrp;
                wrapFlags = abs(dtime)>0.5*twrapFullCnts; % samples that need to have wrap applied
                tgrp(wrapFlags) = tgrp(wrapFlags) + twrapFullCnts; % deltatime taking wrap into account
                dtwrap = dtwrap + twrapFullCnts; % total wrap cnts that need to be added to all subsequent times
            end
            
            [~, isentSort] = sort(tgrp);
            iiaynot = iiay1(inot0);
            iiay1(inot0) = iiaynot(isentSort);
        end
        
        % apply sorted inds
        sentTime_temp(iiay0) = sentTime_temp(iiay1);
        dateTimeAy(iiay0) = dateTimeAy(iiay1); % this one shouldn't matter...
        dataCellAy(iiay0,:) = dataCellAy(iiay1,:);
    end
    ii = iiay0(end)+1;
end
%%% >>> sort groups of sentral time within  server time group



%%% >> process sentral time for wrapping / gaps
% time in seconds from start (server based)
dateTimeRef = dateTimeAy(1); % first serv time as ref
dateTimeAySecs = seconds(dateTimeAy-dateTimeRef);

% ok to rewrap sentral time because now sorted in proper order
sentTimeAy = buildDataFromCellAy(dataCellAy,iSentralTime);
% sentTimeAy0 = sentTimeAy;
% sentTimeAy = sentTime;

indsNOT0 = sentTimeAy(:,1)~=0;
sentTimeAyNOT0sec = sentTimeAy(indsNOT0,:)/32000;
% dataCellAyNOT0 = dataCellAy(indsNOT0,:);
dateTimeAySecsNOT0 = dateTimeAySecs(indsNOT0,:);
dtSentralSec = [0; diff(sentTimeAyNOT0sec(:,1))];
dtDateTime = [0; diff(dateTimeAySecsNOT0(:,1))];

twrapMatchLim = 300; % > thresh then use server time on wrap type event
tcompareLim = [600 300]; % [ sec server delta  sec delta between server and sentral time] to force use of server time

% 1) a sen time delta of 0 will use server time reference if server has non-zero time delta.
% 2) a negative sen time delta will look for wrap and use if within range of server time lim; >otherwise use server time
% 3) tcompareLim sen time >(1) and delta sen-serv > (2) >> use server

%%% >> wrap correction - also fixes large gaps that are not necesarily wraps (like system reset)
indsNegTime = find(dtSentralSec < 0);
twrapFull = (2^32)/32000; % wrap time in sec
for ii=1:length(indsNegTime)
    tSenprev = sentTimeAyNOT0sec(indsNegTime(ii)-1);
    tSencurr = sentTimeAyNOT0sec(indsNegTime(ii));
    dtsen = dtSentralSec(indsNegTime(ii));
    dtwrap = twrapFull + dtsen; % deltatime taking wrap into account
    
    dtDT = dtDateTime(indsNegTime(ii));
    if abs(dtwrap - dtDT) > twrapMatchLim
        % use server time delta
        tnew = tSenprev + dtDT;
        tdeltaUpdate = tnew - tSencurr; % update dtime to apply to all subsequent times
        % update sentime and dtsen
        sentTimeAyNOT0sec(indsNegTime(ii):end) = sentTimeAyNOT0sec(indsNegTime(ii):end) + tdeltaUpdate;
        dtSentralSec = [0; diff(sentTimeAyNOT0sec(:,1))];
    end
end

% dtimes check agains server
for ii=2:length(dtSentralSec)
    dtsen = dtSentralSec(ii);
    dtDT = dtDateTime(ii);
    tSenprev = sentTimeAyNOT0sec(ii-1);
    tSencurr = sentTimeAyNOT0sec(ii);
    tupdateFlag = false;
    if dtsen==0 && dtDT~=0
        % dtsen=0 && dtDT non-zero delta
        disp('dtsen=0: Server Time Sub')
        disp([dtDT dtsen dtDT-dtsen])
        dtUpdate = dtDT;
        tupdateFlag = true;
    elseif dtDT > tcompareLim(1) && abs(dtDT-dtsen) > tcompareLim(2)
        % use server time delta
        disp('Server Time Sub')
        disp([dtDT dtsen dtDT-dtsen])
        dtUpdate = dtDT;
        tupdateFlag = true;
    end
    if tupdateFlag
        tnew = tSenprev + dtUpdate;
        tdeltaUpdate = tnew - tSencurr; % update dtime to apply to all subsequent times
        sentTimeAyNOT0sec(ii:end) = sentTimeAyNOT0sec(ii:end) + tdeltaUpdate;
        dtSentralSec = [0; diff(sentTimeAyNOT0sec(:,1))];
    end
end


% overall time comparison
dataMagCellAy = [];
if ~isempty(dateTimeAySecsNOT0)
    dateTimeRuntime = dateTimeAySecsNOT0(end) - dateTimeAySecsNOT0(1);
    sentTimeRuntime = sentTimeAyNOT0sec(end) - sentTimeAyNOT0sec(1);
    dDateTimeCompareTotal = sentTimeRuntime - dateTimeRuntime;
    dDateTimeCompareTotalPcnt = 100*dDateTimeCompareTotal/dateTimeRuntime;
    
    dDateTimeCompareTotalPcnt
    
    
    %%% >> update with sentral time corrections
    sentTimeAy(indsNOT0,:) = sentTimeAyNOT0sec*32000;
    % replace sentime==0 with server time
    % meas now in sync except cell sentral time would still be original
    % at this point senTimeAy should be clean with no wraps; except for 0 values
    sentTimeAySecs = sentTimeAy/32000;
    
    % create initial reference sentral time if not present
    if sentTimeAySecs(1) == 0
        ifirst = find(sentTimeAySecs,1,'first');
        ddateTime = dateTimeAySecs(ifirst) - dateTimeAySecs(1);
        sentTimeAySecs(1) = sentTimeAySecs(ifirst) - ddateTime;
    end
    for ii=2:length(sentTimeAy)
        tDateprev = dateTimeAySecs(ii-1);
        tDatecurr = dateTimeAySecs(ii);
        tSenprev = sentTimeAySecs(ii-1);
        tSencurr = sentTimeAySecs(ii);
        
        if tSencurr == 0
            % replace tSencurr with sentral time estimate
            % use dtserve from prev tserve added tsen ref.
            dtserve = tDatecurr - tDateprev;
            tSennew = tSenprev + dtserve;
            
            sentTimeAySecs(ii) = tSennew;
        end
    end
    
    % convert to sen t cnts
    sentTimeAy = sentTimeAySecs*32000;
    
    % dups removed
    % sen time unwrapped / cleaned
    % sent == 0 fixed
    %%% >> update full matrix with time sentral time corrections
    
    
    %%% server time estimate interp to Sentral time
    N = size(dateTimeAy,1);
    % twrapFullCnts = (2^32); % wrap time in cnts
    % dtwrap = 0; % total wrap cnts that need to be added to all subsequent times
    ii=1;
    dateTimeInterpAy = dateTimeAy;
    while ii<N
        % find inds for matching server time
        t0 = dateTimeAy(ii);
        inext = find(dateTimeAy(ii:end) ~= t0,1,'first'); % local
        if ~isempty(inext)
            inext = ii+inext-1; % global
            iiay0 = ii:inext-1; % global
        else
            iiay0 = ii:N; % global
        end
        
        if length(iiay0)>1
            % interp sever to sentral for grps with same time
            dtServSec = sentTimeAySecs(iiay0) - sentTimeAySecs(iiay0(1));
            dateTimeInterpAy(iiay0) = dateTimeInterpAy(iiay0) + seconds(dtServSec);
        end
        ii = iiay0(end)+1;
    end
    
    
    
    %%% >> Now separate mag and other data
    
    %%% >>> Separate Mag and Other Data
    % treat mag data lines separate from other data
    % dataMagCellAy = dataCellAy;
    % only inds with real mag data
    dataMagAy = buildDataFromCellAy(dataCellAy,[iData iRSSI]);
    dataMagAy = [sentTimeAy  dataMagAy];
    magLogicInds = ~any(isnan(dataMagAy(:,1:4)),2); % global ref inds
    
    
    % other data inds (not mag and not mag dup)
    % otherLogicInds = ~magLogicIndsUnique & ~magLogicIndsDup; % global reference inds
    otherLogicInds = ~magLogicInds; % global reference inds
    
    % separated data, dup mag data removed
    dataMagCellAy = dataCellAy(magLogicInds,:);
    magSenTimeAy = sentTimeAy(magLogicInds,:);
    
    
    %%% temperature data
    dataTempAy = buildDataFromCellAy(dataCellAy,iTemp);
    if ~isempty(dataTempAy)
        dataTempAy = [sentTimeAy  dataTempAy];
    end
end

% dataOtherCellAy = dataCellAy(otherLogicInds,:);
% otherSenTimeAy = sentTimeAy(otherLogicInds,:);

% % save original indexes for reference
% dataMagInds = find(magLogicInds);
% dataOtherInds = find(otherLogicInds);
%%% >>> Separate Mag and Other Data
    

if ~isempty(dataMagAy)
    dataMagAy = buildDataFromCellAy(dataMagCellAy,[iData iRSSI]);
    dataMagAy = [magSenTimeAy  dataMagAy];
end

if ~isempty(dataMagAy) && isfield(indS,'iDiag')
    dataDiagAy = buildDataFromCellAy(dataMagCellAy,indS.iDiag);
else
    dataDiagAy = [];
end

SentralOutputRaw = [];
if ~isempty(dataMagAy)
    
%     serverTimeStr = dataMagCellAy(:,iServeTime);
%     magDateTimeAy = dateTimeFromTimeStr(serverTimeStr);
    magDateTimeAy = dateTimeInterpAy(magLogicInds);

    dataMagAy=[dataMagAy zeros(size(dataMagAy,1),3)];
    dataMagAy(:,8) = 10;
    
    %%% >>> SENtral output
    senCellAy = dataCellAy;
    
    if isfield(indS,'iConf') && ~isempty(iCarStat)
        senCarStat = buildDataFromCellAy(senCellAy,[iCarStat indS.iConf]);
    elseif ~isempty(iCarStat)
        senCarStat = buildDataFromCellAy(senCellAy,iCarStat);
        senCarStat(:,2) = nan;
    else
        senCarStat = zeros(length(sentTimeAy),2)*nan;
    end
    senCarStat = [sentTimeAy senCarStat];
    
    % reject nans
    sidx=find(~isnan(senCarStat(:,2)));
    SentralOutputRaw=senCarStat(sidx,:);
    
    
    empty_record = [];
    for iii = 1:length(sidx)
        
%         % find == time
%         iind = find(dataMagAy(:,1) == SentralOutputRaw(iii,1));
        
        % find closest previous time to data raw
        dt = (dataMagAy(:,1) - SentralOutputRaw(iii,1));
        logInds = dt<=0; % means sentral output is at =or later time
        [minVal iind] = min(abs(dt(logInds)));
        
        if ~isempty(iind)
            dataMagAy(iind,6)=SentralOutputRaw(iii,2);
            dataMagAy(iind,7)=SentralOutputRaw(iii,3);
            
            %%% car state
            if dataMagAy(iind,6) == 0
                dataMagAy(iind,6) = 1;
            elseif dataMagAy(iind,6) == 100
                dataMagAy(iind,6) = 3;
            elseif dataMagAy(iind,6) == 50
                dataMagAy(iind,6) = 2;
            elseif dataMagAy(iind,6) == -50
                dataMagAy(iind,6) = 4;
            end
            
        else
            empty_record = [empty_record;iii];
        end
    end
    
    
    
    for iii = 2: size(dataMagAy,1)
        
        if dataMagAy(iii,6) == 0 && dataMagAy(iii,7) == 0 && dataMagAy(iii-1,6) ~= 0 && dataMagAy(iii-1,7) ~= 0
            
            dataMagAy(iii,6) = dataMagAy(iii-1,6);
            dataMagAy(iii,7) = dataMagAy(iii-1,7);
            dataMagAy(iii,8) = 20;
        end
    end
    
end

if ~isempty(dataMagAy)
    % timestamp in seconds
    
    % reference time sentral earliest in file
    magSenTimestamp = dataMagAy(:,1);
    senTimeRef = min([sentTimeAy(1) magSenTimestamp(1)]);
    
    senTime = (dataTempAy(:,1) - senTimeRef)/32000;  % time in seconds
    dataTempAy(:,1) = senTime;
    
    magTime = (magSenTimestamp - senTimeRef)/32000;  % time in seconds
    dataMagAy(:,1) = magTime;
    
    tDels = magTime(2:end)-magTime(1:end-1);
    tFqs = 1/(mean(tDels));
    %compute mean rate in hz
    raw_rate = mean(tFqs);

    dataStruct.FileName = FileName;
    dataStruct.indS = indS;
    dataStruct.dataCellAy = dataCellAy;
    dataStruct.sentTimeAy = sentTimeAy;
    dataStruct.dateTimeInterpAy = dateTimeInterpAy;
    dataStruct.magLogicInds = magLogicInds;
    dataStruct.otherLogicInds = otherLogicInds;
    dataStruct.dataTempAy = dataTempAy;
    dataStruct.time = magTime;  % time in seconds
    dataStruct.magDataAy = dataMagAy;
    dataStruct.magSenTimestamp = magSenTimestamp;
    dataStruct.magDateTimeAy = magDateTimeAy; % server time
    dataStruct.RSSIdata = dataMagAy(:,5);
    dataStruct.magRaw_rate = raw_rate;
    dataStruct.SentralOutputRaw = SentralOutputRaw;
    dataStruct.dataDiagAy = dataDiagAy;
    
else
%     time = [];  % time in seconds
%     magTimestamp = [];
%     mraw = [];
%     RSSIdata = [];
%     SentralOutput = [];
%     raw_rate = [];
    dataStruct = [];
end





