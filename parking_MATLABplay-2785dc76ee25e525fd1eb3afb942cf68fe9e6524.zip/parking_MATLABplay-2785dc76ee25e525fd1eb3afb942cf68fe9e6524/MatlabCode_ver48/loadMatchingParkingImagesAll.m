function parkImageShow = loadMatchingParkingImagesAll(parkImageShow,camDir,servTime)

imageStructAy = loadImageTimeData(camDir,servTime);

%%% id images matching server times
imStart = 1; ipage = 0;
dateTimeAyAy = []; % covers all times in imageStructAy in one long array list
for im=1:length(imageStructAy)
    dateTimeAy = imageStructAy(im).dateTimeAy;
    nLength = length(dateTimeAy);
    
    ipage = ipage+1;
    indTrack = (1:nLength)';
    pageTrack = repmat(ipage,nLength,1);
    if isempty(dateTimeAyAy)
        dateTimeAyAy = dateTimeAy;
        pageTrackAyAy = pageTrack;
        indTrackAyAy = indTrack;
    else
        dateTimeAyAy = [dateTimeAyAy; dateTimeAy];
        pageTrackAyAy = [pageTrackAyAy; pageTrack];
        indTrackAyAy = [indTrackAyAy; indTrack];
    end
end


% for each servtime, find closest in image times
if ~isempty(dateTimeAyAy)
    
    % sort to ensure image dates are in date-time order
    [dateTimeAyAy, isort] = sort(dateTimeAyAy);
    pageTrackAyAy = pageTrackAyAy(isort,:);
    indTrackAyAy = indTrackAyAy(isort,:);

    parkImageShow.servTimeRef = servTime;
    parkImageShow.imageStructAy = imageStructAy;
    parkImageShow.dateTimeAyAy = dateTimeAyAy;
    parkImageShow.pageTrackAyAy = pageTrackAyAy;
    parkImageShow.indTrackAyAy = indTrackAyAy;
    
    
%     parkImageShow.imageTimeTrack = imageTimeTrack;
%     parkImageShow.imageIndsTrack = imageIndsTrack;
end

% init figure
% if parkImageShow.on
%     figure(parkImageShow.figN); clf
%     hax = axes;
%     parkImageShow.hax = hax;
%     
%     for ifig = 1:length(parkImageShow.cursFigs)
%         dcm_obj4 = datacursormode(parkImageShow.cursFigs(ifig));
%         set(dcm_obj4,'UpdateFcn',@dispMkrTimeImage2Fcn);
%     end
% end

%%% >>> load parking camera images
