function [ParkingStruct, filtStruct] = Parking_Algorithm(ParkingStruct, filtStruct, data)
%

% global testState

%% Initial Measurements
ParkingStruct.car_presentPre   = ParkingStruct.car_presentCur;
ParkingStruct.car_presentPre2  = ParkingStruct.car_presentCur2;


data1                          = single(data);
ParkingStruct.dataBuffer2      = shifting_array(ParkingStruct.dataBuffer2);
ParkingStruct.dataBuffer2(ParkingStruct.dataBufferSize,:)= data1;

data1                         = single(sqrt(data1(1)*data1(1)+data1(2)*data1(2)+data1(3)*data1(3)));
ParkingStruct.dataBuffer      = shifting_array(ParkingStruct.dataBuffer);
ParkingStruct.dataBuffer(end) = data1;


% max-min mag data on X/Y/Z
for i = 1:3
    if single(data(i)) > ParkingStruct.HS_DataMax(i)
        ParkingStruct.HS_DataMax(i)            = single(data(i));
    end

    if single(data(i)) < ParkingStruct.HS_DataMin(i)
        ParkingStruct.HS_DataMin(i)            = single(data(i));
    end
end


% % max-min mag data on magnitude of X+Y+Z
% if data1 > ParkingStruct.HS_DataNMax
%     ParkingStruct.HS_DataNMax            = data1;
% end
%
% if data1 < ParkingStruct.HS_DataNMin
%     ParkingStruct.HS_DataNMin            = data1;
% end


%%% Stability Filter Settings
% if filtStruct.stableMethod>=2
%     % new std dev and slope stable filter
%     State_count_thresh = filtStruct.State_count_thresh;
%     State_count_thresh_timeout = filtStruct.State_count_thresh_timeout;
% else
%     % old STD based stable filter
%     State_count_thresh = ParkingStruct.State_count_thresh;
%     State_count_thresh_timeout = ParkingStruct.State_count_thresh_timeout;
% end
State_count_thresh = ParkingStruct.State_count_thresh;
State_count_thresh_timeout = ParkingStruct.State_count_thresh_timeout;


%%% stability filter buffer and measurement
filtStruct = stableFilt(filtStruct,data);




if abs(data1 - single(sqrt(ParkingStruct.LS_StartValue(1)*ParkingStruct.LS_StartValue(1)...
        +ParkingStruct.LS_StartValue(2)*ParkingStruct.LS_StartValue(2) ...
        +ParkingStruct.LS_StartValue(3)*ParkingStruct.LS_StartValue(3)))) >= ParkingStruct.BLE_Trigger_thresh

    ParkingStruct.BLE_Trigger_FLAG       = uint8(1);
	ParkingStruct.car_present            = uint8(2);  
else

    ParkingStruct.BLE_Trigger_FLAG       = uint8(0);
end


%%%%%% update on 6/21/17 (Jira: PMG-97)
%%%%%%%%%%%%%%%%%%%%% using strong magnet and BLE to get out of shipping mode
%%%% detect strong magnet in shipping mode


%%%% the strong magnet requires to be placed on the top of sensor for at least 4seconds (ParkingStruct.StandbyMode_Timeout),
%%%% total number of samples that mag value above threshold (500uT) needs to be 16 (4seconds data)

% if (abs(data1 - single(sqrt(ParkingStruct.LS_StartValue(1)*ParkingStruct.LS_StartValue(1)...
%         +ParkingStruct.LS_StartValue(2)*ParkingStruct.LS_StartValue(2) ...
%         +ParkingStruct.LS_StartValue(3)*ParkingStruct.LS_StartValue(3)))) >= ParkingStruct.StandbyMode_Trigger_thresh_SHIP) ...
%     && ParkingStruct.ShippingMode_FLAG        == uint8(1)

%%%%% using absolute mag value instead of relative diff mag to trigger strong magnet detection
if data1 >= ParkingStruct.StandbyMode_Trigger_thresh_SHIP ...
        && ParkingStruct.ShippingMode_FLAG        == uint8(1)


    ParkingStruct.StandbyMode_CntAlgo          = ParkingStruct.StandbyMode_CntAlgo + uint16(1);


    if ParkingStruct.StandbyMode_CntAlgo >= ParkingStruct.StandbyMode_Timeout * ParkingStruct.HS_rate

        ParkingStruct.StandbyMode_FLAG             = uint8(1);

        % reset

        ParkingStruct.StandbyMode_CntAlgo              = uint16(0);
        ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);

        ParkingStruct.LS_Trigger_FLAG              = uint8(1);    % trigger the Alarm: back to low speed mode

        ParkingStruct.BLE_Trigger_Buffer           = zeros(12,1,'uint8');
        ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);
        ParkingStruct.BLE_Trigger_FLAG             = uint8(0);

    end
end
%%%%%%%%%%%%%%%%%%%%%


%% Pattern Matching
if ParkingStruct.BLE_Trigger_Enable



    ParkingStruct.BLE_Trigger_Buffer      = shifting_array(ParkingStruct.BLE_Trigger_Buffer);
    ParkingStruct.BLE_Trigger_Buffer(end) = ParkingStruct.BLE_Trigger_FLAG;


    match_flagPre = pattern_comparison(ParkingStruct.BLE_Trigger_PatternPre,ParkingStruct.BLE_Trigger_Buffer(end-3:end));

    %%%%% reset BLE_Trigger_Buffer when pre-pattern has been detected
    if match_flagPre == uint8(1) && ParkingStruct.BLE_Trigger_PatternPre_FLAG  == uint8(0)

        ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(1);

        ParkingStruct.BLE_Trigger_FLAG     = uint8(0);
        ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');
    end



    %%%%% wake up pattern matching only when pre-pattern (1 1 0 0) has
    %%%%% been recognized (ParkingStruct.BLE_Trigger_PatternPre_FLAG = 1)
    if ParkingStruct.BLE_Trigger_PatternPre_FLAG

        %         disp('Pattern Matching Check!!!')

        match_flagA=pattern_comparison(ParkingStruct.BLE_Trigger_PatternA,ParkingStruct.BLE_Trigger_Buffer);

        if match_flagA == uint8(1)

            ParkingStruct.BLE_Trigger_FLAG     = uint8(2);
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');

            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode

            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT


            %             %%% values for cloud algorithm
            %             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;

            ParkingStruct.LastTransitionState2 = uint8(6);

        end


        %%% update 2/13
        % 2nd pattern   % patternA should only be matched one time at beginning, unless reset FLAG
        match_flagB=pattern_comparison(ParkingStruct.BLE_Trigger_PatternB,ParkingStruct.BLE_Trigger_Buffer);
        if match_flagB == uint8(1)
            ParkingStruct.BLE_Trigger_FLAG     = uint8(3);
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');

            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode

            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT



            %             %%% values for cloud algorithm
            %             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;

            ParkingStruct.LastTransitionState2 = uint8(6);

        end




        %%% update 3/27
        % 3rd pattern
        match_flagC=pattern_comparison(ParkingStruct.BLE_Trigger_PatternC,ParkingStruct.BLE_Trigger_Buffer);
        if match_flagC == uint8(1)
            ParkingStruct.BLE_Trigger_FLAG     = uint8(4);
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');

            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode

            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT



            %             %%% values for cloud algorithm
            %             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;

            ParkingStruct.LastTransitionState2 = uint8(6);

        end



        %%% update 4/3
        % 4th pattern
        match_flagD=pattern_comparison(ParkingStruct.BLE_Trigger_PatternD,ParkingStruct.BLE_Trigger_Buffer);
        if match_flagD == uint8(1)
            ParkingStruct.BLE_Trigger_FLAG     = uint8(5);
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');

            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode

            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT



            %             %%% values for cloud algorithm
            %             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;

            ParkingStruct.LastTransitionState2 = uint8(6);

        end



        %%% update 4/10
        % 5th pattern
        match_flagE=pattern_comparison(ParkingStruct.BLE_Trigger_PatternE,ParkingStruct.BLE_Trigger_Buffer);
        if match_flagE == uint8(1)
            ParkingStruct.BLE_Trigger_FLAG     = uint8(6);
            ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');

            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);


            ParkingStruct.car_present          = ParkingStruct.Car_State_last_HS;
            ParkingStruct.car_present2         = ParkingStruct.Car_State_last_HS;

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);

            ParkingStruct.LS_Trigger_FLAG      = uint8(1);    % trigger the Alarm: back to low speed mode

            ParkingStruct.StandbyMode_FLAG     = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet
            ParkingStruct.StandbyMode_CntAlgo  = uint16(0);    % counts number of samples with mag value above 500uT



            %             %%% values for cloud algorithm
            %             ParkingStruct.HS_endValue          = single(data);
            ParkingStruct.HS_endTime           = ParkingStruct.time;

            ParkingStruct.LastTransitionState2 = uint8(6);

        end





        %%% update 3/27
        % lock up the matching process until next time entering from LS mode
        blsum = uint8(0);for i = 1:11;blsum=ParkingStruct.BLE_Trigger_Buffer(i)+blsum;end
        if match_flagA == uint8(0) && match_flagB == uint8(0) && match_flagC == uint8(0) && match_flagD == uint8(0) && match_flagE == uint8(0) && blsum == uint8(5) %%% && ParkingStruct.BLE_Trigger_Buffer(end) == uint8(0)


            ParkingStruct.BLE_Trigger_FLAG          = uint8(7);
            ParkingStruct.BLE_Trigger_Buffer        = zeros(12,1,'uint8');

            ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);

            ParkingStruct.BLE_Trigger_Enable        = uint8(0);


        end

    end

end  %%%% end of pattern matching process


%% Parking & Counting Algorithm
if ParkingStruct.LS_Trigger_FLAG      == uint8(0)
    % >>> HS Mode

    %% > RELATIVE ALGORITHM

    %**************  Phase based Algorithm  (feature: moving average)**************************

    %setup bias or calc avg.
    if(ParkingStruct.local_avg == single(0))

        ParkingStruct.local_avg      = data1;

    else
        %take local average
        ParkingStruct.local_avg    = ParkingStruct.filter_alpha*ParkingStruct.local_avg    + ParkingStruct.filter_beta*data1;
    end

    % ****** FEATURE: DIFFERENCE between current mag and previous mag *********
    ParkingStruct.dx_history      = shifting_array(ParkingStruct.dx_history);
    ParkingStruct.dx_history(end) = single(abs(data1 - ParkingStruct.local_avg));


    %get new moving average, compare to last, set new
    if ParkingStruct.dx_history(1) > single(0)

        ParkingStruct.moving_avg    = mean(ParkingStruct.dx_history);

    else

        ParkingStruct.moving_avg    = ParkingStruct.dx_history(end);

    end


    %%% update 2/6/2017
    %%% values for cloud algorithm
    % max-min MA data (magnitude(X+Y+Z))
    if ParkingStruct.moving_avg > ParkingStruct.HS_MAmax
        ParkingStruct.HS_MAmax  = ParkingStruct.moving_avg;
    end


    if ParkingStruct.moving_avg < ParkingStruct.detection_threshUp    %%%%ParkingStruct.detection_thresh


        % Previous STATE:  State 1- no car
        if ParkingStruct.car_present2   == uint8(1)  %% NO CAR STATE  -- CALCULATE the baseline mean & STD value

            ParkingStruct.state1_count2  = ParkingStruct.state1_count2 + uint16(1);



            % Previous STATE:  State 2 - Car In
        elseif ParkingStruct.car_present2   == uint8(2)


            if ParkingStruct.state2_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate

                ParkingStruct.car_present2   = uint8(3);
                ParkingStruct.state3_count2  = uint16(1);


                ParkingStruct.state1_count2  = uint16(0);
                ParkingStruct.state2_count2  = uint16(0);
                ParkingStruct.state4_count2  = uint16(0);

            else

                ParkingStruct.state2_count2 = ParkingStruct.state2_count2 + uint16(1);
            end


            % Previous STATE:  State 3 - Car Parked
        elseif ParkingStruct.car_present2   == uint8(3)


            ParkingStruct.state3_count2 = ParkingStruct.state3_count2 + uint16(1);



            % Previous STATE:  State 4 - Car Out
        elseif ParkingStruct.car_present2   == uint8(4)

            if ParkingStruct.state4_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate

                ParkingStruct.car_present2   = uint8(1);
                ParkingStruct.state1_count2  = uint16(1);


                ParkingStruct.state2_count2  = uint16(0);
                ParkingStruct.state3_count2  = uint16(0);
                ParkingStruct.state4_count2  = uint16(0);

            else

                ParkingStruct.state4_count2  = ParkingStruct.state4_count2 + uint16(1);

            end

        end




        % elseif ParkingStruct.moving_avg > ParkingStruct.detection_threshUp
    else

        ParkingStruct.TransitionState_count2        = ParkingStruct.TransitionState_count2 + uint16(1);

        % Previous STATE:  State 1 - No Car
        if ParkingStruct.car_present2   == uint8(1)

            if ParkingStruct.LS_TO_HS_FLAG2

                ParkingStruct.car_present2   = uint8(2);
                ParkingStruct.state2_count2  = uint16(1);

                ParkingStruct.state1_count2  = uint16(0);
                ParkingStruct.state3_count2  = uint16(0);
                ParkingStruct.state4_count2  = uint16(0);

                ParkingStruct.LS_TO_HS_FLAG2 = uint8(0);


            else

                %            if ParkingStruct.state1_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate
                if ParkingStruct.car_present2 == ParkingStruct.Car_State_last_HS



                    ParkingStruct.car_present2   = uint8(2);
                    ParkingStruct.state2_count2  = uint16(1);

                    ParkingStruct.state1_count2  = uint16(0);
                    ParkingStruct.state3_count2  = uint16(0);
                    ParkingStruct.state4_count2  = uint16(0);

                else

                    ParkingStruct.car_present2    = uint8(4);
                    ParkingStruct.state4_count2   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                    ParkingStruct.state1_count2   = uint16(0);
                    ParkingStruct.state2_count2   = uint16(0);
                    ParkingStruct.state3_count2   = uint16(0);

                end

            end

        elseif ParkingStruct.car_present2    == uint8(2)

            ParkingStruct.car_present2   = uint8(2);
            ParkingStruct.state2_count2  = ParkingStruct.state2_count2 + uint16(1);


            ParkingStruct.state1_count2  = uint16(0);
            ParkingStruct.state3_count2  = uint16(0);
            ParkingStruct.state4_count2  = uint16(0);




        elseif ParkingStruct.car_present2    == uint8(3)


            if ParkingStruct.LS_TO_HS_FLAG2

                ParkingStruct.car_present2    = uint8(4);
                ParkingStruct.state4_count2   = uint16(1);

                ParkingStruct.state1_count2   = uint16(0);
                ParkingStruct.state2_count2   = uint16(0);
                ParkingStruct.state3_count2   = uint16(0);

                ParkingStruct.LS_TO_HS_FLAG2  = uint8(0);


            else


                %             if ParkingStruct.state3_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate
                if ParkingStruct.car_present2 == ParkingStruct.Car_State_last_HS

                    ParkingStruct.car_present2    = uint8(4);
                    ParkingStruct.state4_count2   = uint16(1);

                    ParkingStruct.state1_count2   = uint16(0);
                    ParkingStruct.state2_count2   = uint16(0);
                    ParkingStruct.state3_count2   = uint16(0);


                else

                    ParkingStruct.car_present2    = uint8(2);
                    ParkingStruct.state2_count2   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                    ParkingStruct.state1_count2   = uint16(0);
                    ParkingStruct.state3_count2   = uint16(0);
                    ParkingStruct.state4_count2   = uint16(0);

                end

            end

        elseif ParkingStruct.car_present2    == uint8(4)

            ParkingStruct.car_present2   = uint8(4);
            ParkingStruct.state4_count2  = ParkingStruct.state4_count2 + uint16(1);


            ParkingStruct.state1_count2  = uint16(0);
            ParkingStruct.state3_count2  = uint16(0);
            ParkingStruct.state2_count2  = uint16(0);


        end



        % else
        %
        %     % Previous STATE:  State 1 - No Car
        %     if ParkingStruct.car_present2   == uint8(1)
        %
        %         ParkingStruct.state1_count2  = uint16(0);
        %         ParkingStruct.state3_count2  = uint16(0);
        %
        %     elseif ParkingStruct.car_present2   == uint8(3)
        %
        %         ParkingStruct.state1_count2  = uint16(0);
        %         ParkingStruct.state3_count2  = uint16(0);
        %
        %     end



    end


    FLAG = uint8(1);
    ParkingStruct.car_presentBufferCount = zeros(4,1,'uint8');

    ParkingStruct.car_presentBuffer2      = shifting_array(ParkingStruct.car_presentBuffer2);
    ParkingStruct.car_presentBuffer2(end) = ParkingStruct.car_present2;


    for i = 1:4

        ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) =  ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) + uint8(1);

        if ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) == uint8(3)

            ParkingStruct.car_presentCur2  = ParkingStruct.car_presentBuffer2(i);
            FLAG = uint8(0);
            break;
        end
    end


    if FLAG
        ParkingStruct.car_presentCur2  = ParkingStruct.car_presentPre2;
    end


    %% > ABSOLUTE ALGORITHM

    % **************  Absolute MAG based Algorithm  (feature: STD)**************************


    if ParkingStruct.K2 < ParkingStruct.dataBufferSize - uint8(1)

        ParkingStruct.K2 = ParkingStruct.K2 + uint8(1);

        ParkingStruct.SUM         = ParkingStruct.SUM   + data1 ;             % sum
        ParkingStruct.SUMSq       = ParkingStruct.SUMSq + data1 * data1;      % sum square

        %     ParkingStruct.AVG         = ParkingStruct.SUM / single(ParkingStruct.K2);
        %     ParkingStruct.RMS         = sqrt(ParkingStruct.SUMSq / single(ParkingStruct.K2));


        if ParkingStruct.K2 == uint8(1)

            ParkingStruct.STD      = single(0);

            ParkingStruct.STDz     = single(0);

        else

            ParkingStruct.STD = sqrt(abs(ParkingStruct.SUMSq -ParkingStruct.SUM*ParkingStruct.SUM/single(ParkingStruct.K2))...
                /(single(ParkingStruct.K2 - uint8(1))));


            ParkingStruct.STDz = Parking_std(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize - ParkingStruct.K2 + uint8(1)):ParkingStruct.dataBufferSize,3),ParkingStruct.K2);

        end

    else


        if filtStruct.stableMethod==0
            ParkingStruct.STD = Parking_std(ParkingStruct.dataBuffer,ParkingStruct.dataBufferSize);
            ParkingStruct.STDz= Parking_std(ParkingStruct.dataBuffer2(:,3),ParkingStruct.dataBufferSize);
        end


        %     ParkingStruct.AVG = mean(ParkingStruct.dataBuffer);
        %     ParkingStruct.RMS = sqrt(mean(ParkingStruct.dataBuffer.* ParkingStruct.dataBuffer));

    end




    %>>> TEST New Stability Filter
    if filtStruct.stableMethod>0
        %         ParkingStruct.STD = mean(filtStruct.mstdCln);
        ParkingStruct.STD = sqrt(sum(filtStruct.mstdCln.^2,2));
        ParkingStruct.STDz = filtStruct.mstdCln(3);
    end    %>>> TEST Stability Filter



    %
    % % ^^^^^ save the RMS value for no car state
    % if ParkingStruct.RMSFLAG == uint8(0) && ParkingStruct.car_present2 == uint8(1) ...
    %         && ParkingStruct.car_presentCur2 == uint8(1) && ParkingStruct.Car_State_last_HS == uint8(3)
    %
    %     ParkingStruct.RMSBuffer      = shifting_array(ParkingStruct.RMSBuffer);
    %     ParkingStruct.RMSBuffer(end) = ParkingStruct.RMS;
    %
    %
    %     ParkingStruct.AVGBuffer      = shifting_array(ParkingStruct.AVGBuffer);
    %     ParkingStruct.AVGBuffer(end) = ParkingStruct.AVG;
    %
    %     ParkingStruct.RMSFLAG        = uint8(1);
    %
    % end





    %%% values for cloud algorithm

    % max-min STD data (magnitude of X+Y+Z)
    if ParkingStruct.STD > ParkingStruct.HS_STDmax
        ParkingStruct.HS_STDmax  = ParkingStruct.STD;
    end



    % max-min STD data (Z axis)

    if ParkingStruct.STDz > ParkingStruct.HS_STDmaxZ
        ParkingStruct.HS_STDmaxZ  = ParkingStruct.STDz;
    end


    %% >
    %%%%%% *******************************************************************
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% update on 06/28/2017

    %%%%%%%%%% add function of detecting multiple cars during aggressive parking events
    %%% aggressive parking: one car pulls out from the space while the next car pulls into the space immediately


    %% > STDz_max Update
    %%%% only considering the cases of previous state = 3, new state = 3
    %%%% measuring the features within window (window size: 0.8 -- 1 second)
    if ParkingStruct.Car_State_last_HS      == uint8(3) && ParkingStruct.K2 >= ParkingStruct.ZdataWindowSize


        STD_Z = Parking_std(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize-ParkingStruct.ZdataWindowSize+uint8(1)):ParkingStruct.dataBufferSize,3),ParkingStruct.ZdataWindowSize);
        range_Z = max(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize-ParkingStruct.ZdataWindowSize+uint8(1)):ParkingStruct.dataBufferSize,3))-min(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize-ParkingStruct.ZdataWindowSize+uint8(1)):ParkingStruct.dataBufferSize,3));
        diff_baseline_Z = mean(abs(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize-ParkingStruct.ZdataWindowSize+uint8(1)):ParkingStruct.dataBufferSize,3)-ParkingStruct.LS_StartValue_state1(3)));
        % before this line in codegen will be necessary to remove 2x a scalar abs value, why code is generated this way is unknown

        if STD_Z >= ParkingStruct.STDz_max

            ParkingStruct.STDz_max         = STD_Z;

        end

        if range_Z <= ParkingStruct.rangeZ_threshold && diff_baseline_Z <= ParkingStruct.diff_baseline_Z_threshold && ParkingStruct.STDz_max > ParkingStruct.STDz_max_threshold
%             disp(single(ParkingStruct.time));disp([range_Z diff_baseline_Z ParkingStruct.STDz_max])
            ParkingStruct.STDz_max         = single(0);
            ParkingStruct.NumCarsTemp      = ParkingStruct.NumCarsTemp + uint8(1);
        end

        % if isempty(coder.target)
        %
        %     tempZ = [STD_Z range_Z diff_baseline_Z ParkingStruct.STDz_max single(ParkingStruct.NumCarsTemp)];
        %     ParkingStruct.ZdataBuffer         = [ParkingStruct.ZdataBuffer;tempZ];
        %
        % end

    end



    %%%% only considering the cases of previous state = 1, new state = 1 (multiple cars are driving over the sensor continuously)
    %%%% measuring the features within window (window size: 0.8 -- 1 second)
    if ParkingStruct.Car_State_last_HS      == uint8(1) && ParkingStruct.K2 >= ParkingStruct.ZdataWindowSize




        STD_Z = Parking_std(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize-ParkingStruct.ZdataWindowSize+uint8(1)):ParkingStruct.dataBufferSize,3),ParkingStruct.ZdataWindowSize);
        range_Z = max(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize-ParkingStruct.ZdataWindowSize+uint8(1)):ParkingStruct.dataBufferSize,3))-min(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize-ParkingStruct.ZdataWindowSize+uint8(1)):ParkingStruct.dataBufferSize,3));
        diff_baseline_Z = mean(abs(ParkingStruct.dataBuffer2((ParkingStruct.dataBufferSize-ParkingStruct.ZdataWindowSize+uint8(1)):ParkingStruct.dataBufferSize,3)-ParkingStruct.LS_StartValue_state1(3)));



        if STD_Z >= ParkingStruct.STDz_max

            ParkingStruct.STDz_max         = STD_Z;

        end


        if range_Z <= ParkingStruct.rangeZ_threshold && diff_baseline_Z <= ParkingStruct.diff_baseline_Z_threshold && ParkingStruct.STDz_max > ParkingStruct.STDz_max_threshold
%             disp(single(ParkingStruct.time));disp([range_Z diff_baseline_Z ParkingStruct.STDz_max])
            ParkingStruct.STDz_max         = single(0);
            ParkingStruct.NumCarsTemp      = ParkingStruct.NumCarsTemp + uint8(1);
        end


        % if isempty(coder.target)
        %
        %     tempZ = [STD_Z range_Z diff_baseline_Z ParkingStruct.STDz_max single(ParkingStruct.NumCarsTemp)];
        %     ParkingStruct.ZdataBuffer         = [ParkingStruct.ZdataBuffer;tempZ];
        %
        % end

    end


    % update aggressive parking events in semi-real time
    % if more than 2 cars drive by in an aggressive parking event, start
    % counting the events starting with the third vaue
    if ParkingStruct.NumCarsTemp > uint8(2)
        ParkingStruct.NumCars_DriveThru = ParkingStruct.NumCars_DriveThru + uint16(ParkingStruct.NumCarsTemp - uint8(2));
        ParkingStruct.NumCarsTemp = uint8(2);
    end


    % ParkingStruct.STD = ParkingStruct.STDz;


    %% > Status vs Stability Update
    switch filtStruct.stableMethod
        case {0,1}
            % 0 = original STD based stability
            % 1 = outlier removal STD from stableFilt measurement
            stableFlag = ParkingStruct.STD < ParkingStruct.STD_threshDown; % original stability
            unStableFlag = ParkingStruct.STD > ParkingStruct.STD_threshUp; % original stability
        otherwise
            % 2 = stableFilt stability measurement based on revised std deviation and slope measurement
            mstdClnR = sqrt(sum(filtStruct.mstdCln.^2,2));
            mslopeMoveClnMnR = sqrt(sum(filtStruct.mslopeMoveClnMn.^2,2));
            stableThreshDown = filtStruct.stableThreshDown;
            stableThreshUp = filtStruct.stableThreshUp;

            stableFlag = mstdClnR<stableThreshDown(1) & abs(mslopeMoveClnMnR)<stableThreshDown(2);
            unStableFlag = mstdClnR>stableThreshUp(1) | abs(mslopeMoveClnMnR)>stableThreshUp(2);
    end


    %     if testState
    %         aaa=999;
    %     end

    if  stableFlag    %%%%ParkingStruct.STD_thresh   %% no car or car occupied
        %%% Stable STD

        % Previous STATE:  State 1- no car
        if ParkingStruct.car_present   == uint8(1)  %% NO CAR STATE  -- CALCULATE the baseline mean & STD value

            ParkingStruct.state1_count  = ParkingStruct.state1_count + uint16(1);

            % checking in the proposed no car state, the absolute mag is in the initilized mag range
            % if current MEAN of mag is not in the init range, jump to state 3 (car occupied)
            if ParkingStruct.state1_count == State_count_thresh * ParkingStruct.HS_rate

                ParkingStruct.HS_Datadiff            = ParkingStruct.HS_DataMax - ParkingStruct.HS_DataMin;
                ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);  %%% reset confidence level

                ParkingStruct.LS_Trigger_FLAG        = uint8(1);
                ParkingStruct.LS_StartValue          = mean(ParkingStruct.dataBuffer2);


                ParkingStruct.HS_Datadiff_baselineZ      = abs(ParkingStruct.LS_StartValue(3) - ParkingStruct.LS_StartValue_state1(3));
                %             ParkingStruct.HS_Datadiff_baselineInitZ  = abs(ParkingStruct.LS_StartValue(3) - ParkingStruct.AVGInit2(3));


                % TIMEOUT CASE:
            elseif ParkingStruct.state1_count >= State_count_thresh_timeout * ParkingStruct.HS_rate ...
                    && ParkingStruct.car_present == ParkingStruct.Car_State_last_HS

                ParkingStruct.LS_Trigger_FLAG        = uint8(1);
                ParkingStruct.LS_StartValue          = mean(ParkingStruct.dataBuffer2);

                ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);  %%% reset confidence level

            end


            % Previous STATE:  State 2 - Car In
        elseif ParkingStruct.car_present   == uint8(2)

            if ParkingStruct.state2_count > ParkingStruct.count_thresh * ParkingStruct.HS_rate

                ParkingStruct.car_present   = uint8(3);
                ParkingStruct.state3_count  = uint16(1);


                ParkingStruct.state1_count  = uint16(0);
                ParkingStruct.state2_count  = uint16(0);
                ParkingStruct.state4_count  = uint16(0);

            else

                ParkingStruct.state2_count = ParkingStruct.state2_count + uint16(1);
            end

            % Previous STATE:  State 3 - Car Parked
        elseif ParkingStruct.car_present   == uint8(3)

            ParkingStruct.state3_count = ParkingStruct.state3_count + uint16(1);

            % checking in the proposed no car state, the absolute mag is in the initilized mag range
            % if current MEAN of mag is in the init range, jump to state 1 (NO car)
            if ParkingStruct.state3_count == State_count_thresh * ParkingStruct.HS_rate


                ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);  %%% reset confidence level
                ParkingStruct.HS_Datadiff            = ParkingStruct.HS_DataMax - ParkingStruct.HS_DataMin;



                ParkingStruct.LS_Trigger_FLAG        = uint8(1);
                ParkingStruct.LS_StartValue          = mean(ParkingStruct.dataBuffer2);


                ParkingStruct.HS_Datadiff_baselineZ      = abs(ParkingStruct.LS_StartValue(3) - ParkingStruct.LS_StartValue_state1(3));
                %             ParkingStruct.HS_Datadiff_baselineInitZ  = abs(ParkingStruct.LS_StartValue(3) - ParkingStruct.AVGInit2(3));



                % TIMEOUT CASE:
            elseif ParkingStruct.state3_count >= State_count_thresh_timeout * ParkingStruct.HS_rate ...
                    && ParkingStruct.car_present == ParkingStruct.Car_State_last_HS


                ParkingStruct.LS_Trigger_FLAG        = uint8(1);
                ParkingStruct.LS_StartValue          = mean(ParkingStruct.dataBuffer2);

                ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);  %%% reset confidence level


            end


            % Previous STATE:  State 4 - Car Out
        elseif ParkingStruct.car_present   == uint8(4)

            if ParkingStruct.state4_count > ParkingStruct.count_thresh * ParkingStruct.HS_rate

                ParkingStruct.car_present   = uint8(1);
                ParkingStruct.state1_count  = uint16(1);


                ParkingStruct.state2_count  = uint16(0);
                ParkingStruct.state3_count  = uint16(0);
                ParkingStruct.state4_count  = uint16(0);

            else

                ParkingStruct.state4_count  = ParkingStruct.state4_count + uint16(1);

            end
        end

    elseif unStableFlag
        %%% Unstable STD

        ParkingStruct.TransitionState_count        = ParkingStruct.TransitionState_count + uint16(1);

        % Previous STATE:  State 1 - No Car
        if ParkingStruct.car_present   == uint8(1)

            if ParkingStruct.LS_TO_HS_FLAG

                ParkingStruct.car_present   = uint8(2);
                ParkingStruct.state2_count  = uint16(1);

                ParkingStruct.state1_count  = uint16(0);
                ParkingStruct.state3_count  = uint16(0);
                ParkingStruct.state4_count  = uint16(0);

                ParkingStruct.LS_TO_HS_FLAG = uint8(0);


            else

                if ParkingStruct.car_present == ParkingStruct.Car_State_last_HS


                    ParkingStruct.car_present   = uint8(2);
                    ParkingStruct.state2_count  = uint16(1);

                    ParkingStruct.state1_count  = uint16(0);
                    ParkingStruct.state3_count  = uint16(0);
                    ParkingStruct.state4_count  = uint16(0);

                else

                    ParkingStruct.car_present   = uint8(4);
                    ParkingStruct.state4_count  = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                    ParkingStruct.state1_count  = uint16(0);
                    ParkingStruct.state2_count  = uint16(0);
                    ParkingStruct.state3_count  = uint16(0);

                end

            end

        elseif ParkingStruct.car_present    == uint8(2)

            ParkingStruct.car_present   = uint8(2);
            ParkingStruct.state2_count  = ParkingStruct.state2_count + uint16(1);

            ParkingStruct.state1_count  = uint16(0);
            ParkingStruct.state3_count  = uint16(0);
            ParkingStruct.state4_count  = uint16(0);



            % TIMEOUT CASE:
            if ParkingStruct.state2_count >= ParkingStruct.timeout_transition * ParkingStruct.HS_rate ...

            ParkingStruct.LS_Trigger_FLAG        = uint8(1);

            ParkingStruct.car_present            = ParkingStruct.Car_State_last_HS;
            ParkingStruct.SecondSensor_Req_FLAG  = uint8(7);

            end



        elseif ParkingStruct.car_present    == uint8(3)


            if ParkingStruct.LS_TO_HS_FLAG

                ParkingStruct.car_present    = uint8(4);
                ParkingStruct.state4_count   = uint16(1);

                ParkingStruct.state1_count   = uint16(0);
                ParkingStruct.state2_count   = uint16(0);
                ParkingStruct.state3_count   = uint16(0);

                ParkingStruct.LS_TO_HS_FLAG  = uint8(0);


            else


                if ParkingStruct.car_present == ParkingStruct.Car_State_last_HS

                    ParkingStruct.car_present    = uint8(4);
                    ParkingStruct.state4_count   = uint16(1);

                    ParkingStruct.state1_count   = uint16(0);
                    ParkingStruct.state2_count   = uint16(0);
                    ParkingStruct.state3_count   = uint16(0);

                else

                    ParkingStruct.car_present    = uint8(2);
                    ParkingStruct.state2_count   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                    ParkingStruct.state1_count   = uint16(0);
                    ParkingStruct.state3_count   = uint16(0);
                    ParkingStruct.state4_count   = uint16(0);

                end

            end

        elseif ParkingStruct.car_present    == uint8(4)

            ParkingStruct.car_present   = uint8(4);
            ParkingStruct.state4_count  = ParkingStruct.state4_count + uint16(1);

            ParkingStruct.state1_count  = uint16(0);
            ParkingStruct.state3_count  = uint16(0);
            ParkingStruct.state2_count  = uint16(0);



            % TIMEOUT CASE:
            if ParkingStruct.state4_count >= ParkingStruct.timeout_transition * ParkingStruct.HS_rate ...

            ParkingStruct.LS_Trigger_FLAG        = uint8(1);
            ParkingStruct.car_present            = ParkingStruct.Car_State_last_HS;

            ParkingStruct.SecondSensor_Req_FLAG  = uint8(7);

            end




        end

    else
        %%% MiddleState Stability
        ParkingStruct.middleState_count = ParkingStruct.middleState_count + uint16(1);

        if ParkingStruct.middleState_count < ParkingStruct.timeout_transition * ParkingStruct.HS_rate

            % Previous STATE:  State 1 - No Car
            if ParkingStruct.car_present   == uint8(1)

                ParkingStruct.state1_count  = uint16(0);
                ParkingStruct.state3_count  = uint16(0);

            elseif ParkingStruct.car_present   == uint8(3)

                ParkingStruct.state1_count  = uint16(0);
                ParkingStruct.state3_count  = uint16(0);

            end

        else

            ParkingStruct.LS_Trigger_FLAG        = uint8(1);
            ParkingStruct.SecondSensor_Req_FLAG  = uint8(7);

            if  ParkingStruct.car_present  == uint8(2) || ParkingStruct.car_present  == uint8(4)

                ParkingStruct.car_present            = ParkingStruct.Car_State_last_HS;

            end

        end

    end


    %% > Car Status Update
    if ~ParkingStruct.LS_Trigger_FLAG       % ParkingStruct.LS_Trigger_FLAG = 0  -- still in HS MODE
        % HS Mode

        %% >> Car Present Buffer Update
        if ParkingStruct.car_present == uint8(2) || ParkingStruct.car_present == uint8(4)

            FLAG = uint8(1);
            ParkingStruct.car_presentBufferCount = zeros(4,1,'uint8');

            ParkingStruct.car_presentBuffer      = shifting_array(ParkingStruct.car_presentBuffer);
            ParkingStruct.car_presentBuffer(end) = ParkingStruct.car_present;


            for i = 1:4

                ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) =  ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) + uint8(1);

                if ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) == uint8(3)

                    ParkingStruct.car_presentCur  = ParkingStruct.car_presentBuffer(i);
                    FLAG = uint8(0);
                    ParkingStruct.LastTransitionState     = ParkingStruct.car_presentCur;
                    break;
                end
            end

            if FLAG
                ParkingStruct.car_presentCur  = ParkingStruct.car_presentPre;
            end

        else

            ParkingStruct.car_presentBuffer      = shifting_array(ParkingStruct.car_presentBuffer);
            ParkingStruct.car_presentBuffer(end) = ParkingStruct.car_presentPre;

        end


    else    % ParkingStruct.LS_Trigger_FLAG = 1  -- WILL MOVE TO LS mode
        % LS Mode

        % CAR STATUS CORRECTION CHECK
        % ------------------------------------------------------------------

        %% >> SPECIAL CASES
        %%%%% conditions check for normal field parking cases
        
        lsStart_minus_lsState = sum(abs(ParkingStruct.LS_StartValue - ParkingStruct.LS_StartValue_state1));
        lsStart_minus_cal = sum(abs(ParkingStruct.LS_StartValue - ParkingStruct.AVGInit2));
        
        if bitand(ParkingStruct.DemoFLAG,1)  == uint8(0)
            % Non-demo cases
            caseFlags = ParkingStruct.caseFlags;
            ParkingStruct.caseTrackNumb  = uint8(0);
            
            if caseFlags(1) && (lsStart_minus_lsState < ParkingStruct.MAG_threshLevel1 ...
                    || lsStart_minus_cal < ParkingStruct.MAG_threshLevel1)...
                    && (ParkingStruct.car_present ~= uint8(1) || ParkingStruct.car_present2 ~= uint8(1))
                %% >>> CASE1: diff-mag compared to NO_CAR_BASELINE is within threshold level_1(ParkingStruct.MAG_threshLevel1)
                %% >>> CASE12
                %%%        ---  ENFORCE TO VACANT STATE

                ParkingStruct.car_present            = uint8(1);
                ParkingStruct.car_present2           = uint8(1);
                ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                ParkingStruct.caseTrackNumb          = uint8(1);

            elseif caseFlags(2) && ((lsStart_minus_lsState < ParkingStruct.MAG_threshLevel3 ...
                    || lsStart_minus_cal < ParkingStruct.MAG_threshLevel3) ...
                    && ParkingStruct.HS_Datadiff_baselineZ < ParkingStruct.MAG_thresh_ZaxisLevel3 ...
                    && any(ParkingStruct.HS_Datadiff > ParkingStruct.HS_Datadiff_thresh_Level3)) ...
                    && (ParkingStruct.car_present ~= uint8(1) || ParkingStruct.car_present2 ~= uint8(1))

                %% >>> CASE2: diff-mag compared to NO_CAR_BASELINE is within threshold level_3(ParkingStruct.MAG_threshLevel3),
                %%%        AND z-axis diff-mag within threshold (ParkingStruct.MAG_thresh_ZaxisLevel3)
                %%%        AND one of the axis's the total mag value change during entire HS mode is larger than threshold (ParkingStruct.HS_Datadiff_thresh_Level3)

                %%%        ---  ENFORCE TO VACANT STATE

                %%% deal with the issue that large magnetic field change (>80uT  ParkingStruct.HS_Datadiff_thresh_Level3),
                %%% sensor mag get magnetized that can not get back to the value that close enough to previous no_car_baseline

                ParkingStruct.car_present            = uint8(1);
                ParkingStruct.car_present2           = uint8(1);
                ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                ParkingStruct.caseTrackNumb          = uint8(2);

            elseif caseFlags(3) && (lsStart_minus_lsState >= ParkingStruct.MAG_threshUp ...
                    && (ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    || (ParkingStruct.Car_State_last_HS      == uint8(1) ...
                    && ParkingStruct.HS_Datadiff(3) > ParkingStruct.HS_DataNdiff_Thresh ...
                    && (ParkingStruct.HS_STDmax > ParkingStruct.STD_threshUp || ParkingStruct.HS_MAmax > ParkingStruct.detection_threshUp || ParkingStruct.HS_STDmaxZ > ParkingStruct.STD_threshUp))))...
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3))...
                    && (lsStart_minus_lsState > ParkingStruct.MAG_threshLevel1 ...
                    && lsStart_minus_cal > ParkingStruct.MAG_threshLevel1)

                %% >>> CASE3: diff-mag compared to NO_CAR_BASELINE is larger than upper threshold(ParkingStruct.MAG_threshUp),
                %%%        AND OPTIONAL conditions only reqired for last car status in previous LS mode is VACANT (car state = 1)
                %%%            (1) z-axis total mag changes during entire HS mode is larger than threshold (ParkingStruct.HS_DataNdiff_Thresh)
                %%%            (2) maximal STD or MA or STD_Z is larger than threshold

                %%%        ---  ENFORCE TO OCCUPIED STATE

                ParkingStruct.car_present             = uint8(3);
                ParkingStruct.car_present2            = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG   = uint8(3);
                ParkingStruct.caseTrackNumb          = uint8(3);

            elseif caseFlags(4) && (sum(abs(ParkingStruct.LS_StartValue - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh2 ...
                    && ParkingStruct.Car_State_last_HS      == uint8(3))...
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                    || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                    || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffXY_ThreshLevel2) ...
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3)) ...
                    && (lsStart_minus_lsState > ParkingStruct.MAG_threshLevel1 ...
                    && lsStart_minus_cal > ParkingStruct.MAG_threshLevel1)

                %% >>> CASE4: diff-mag compared to last OCCUPIED STATE(STATE = 3) is within threshold(ParkingStruct.MAG_thresh2),
                %%%        AND last car status in previous LS mode is OCCUPIPED (car state = 3)
                %%%        AND meet AT LEAST ONE of the following conditions
                %%%             (1) x-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffXY_ThreshLevel2)
                %%%             (2) y-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffXY_ThreshLevel2)
                %%%             (3) z-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffXY_ThreshLevel2)

                %%%        ---  ENFORCE TO OCCUPIED STATE

                ParkingStruct.car_present             = uint8(3);
                ParkingStruct.car_present2            = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG   = uint8(4);
                ParkingStruct.caseTrackNumb          = uint8(4);


                %             elseif (ParkingStruct.Car_State_last_HS      == uint8(1) ...
                %                     && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel1 ...
                %                     && (ParkingStruct.HS_Datadiff_baselineZ < ParkingStruct.MAG_thresh_ZaxisLevel6))...
                %                     && (ParkingStruct.car_present ~= uint8(1) || ParkingStruct.car_present2 ~= uint8(1))
                %
                %                 %%% CASE5: last car status in previous LS mode is VACANT (car state = 1)
                %                 %%%        AND z-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffZ_ThreshLevel1)
                %                 %%%        AND z-axis mag changes compared to NO_CAR_BASELINE is larger than threshold (ParkingStruct.MAG_thresh_ZaxisLevel6)
                %
                %                 %%%        ---  ENFORCE TO VACANT STATE
                %
                %                 ParkingStruct.car_present            = uint8(1);
                %                 ParkingStruct.car_present2           = uint8(1);
                %                 ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);
                %
                %             elseif (ParkingStruct.Car_State_last_HS      == uint8(1) ...
                %                     && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel2  ...
                %                     && ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                %                     && ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                %                     && (ParkingStruct.HS_Datadiff_baselineZ < ParkingStruct.MAG_thresh_ZaxisLevel6))...
                %                     && (ParkingStruct.car_present ~= uint8(1) || ParkingStruct.car_present2 ~= uint8(1))
                %
                %                 ParkingStruct.car_present            = uint8(1);
                %                 ParkingStruct.car_present2           = uint8(1);
                %                 ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);
                %
                %                 %%% CASE6: last car status in previous LS mode is VACANT (car state = 1)
                %                 %%%        AND z-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffZ_ThreshLevel2)
                %                 %%%        AND x-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffXY_ThreshLevel2)
                %                 %%%        AND y-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffXY_ThreshLevel2)
                %                 %%%        AND z-axis mag changes compared to NO_CAR_BASELINE is larger than threshold (ParkingStruct.MAG_thresh_ZaxisLevel6)
                %
                %                 %%%        ---  ENFORCE TO VACANT STATE


            elseif caseFlags(5) && (ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && lsStart_minus_lsState >= ParkingStruct.MAG_threshUp2 ...
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                    || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                    || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh) )...
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3))...
                    && (lsStart_minus_lsState > ParkingStruct.MAG_threshLevel1 ...
                    && lsStart_minus_cal > ParkingStruct.MAG_threshLevel1)

                %% >>> CASE7: last car status in previous LS mode is OCCUPIPED (car state = 3)
                %%%        AND diff-mag compared to NO_CAR_BASELINE (STATE = 1) is larger than threshold(ParkingStruct.MAG_threshUp2),
                %%%        AND meet AT LEAST ONE of the following conditions
                %%%             (1) x-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DataNdiff_Thresh2)
                %%%             (2) y-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DataNdiff_Thresh2)
                %%%             (3) z-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DataNdiff_Thresh)

                %%%        ---  ENFORCE TO OCCUPIED STATE

                ParkingStruct.car_present             = uint8(3);
                ParkingStruct.car_present2            = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG   = uint8(5);
                ParkingStruct.caseTrackNumb          = uint8(5);

            elseif caseFlags(6) && (ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && sum(abs(ParkingStruct.LS_StartValue - ParkingStruct.LS_StartValue_state3)) <= ParkingStruct.MAG_thresh3...
                    && (ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                    || ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DataNdiff_Thresh2 ...
                    || ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DataNdiff_Thresh) ) ...
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3)) ...
                    && (lsStart_minus_lsState > ParkingStruct.MAG_threshLevel1 ...
                    && lsStart_minus_cal > ParkingStruct.MAG_threshLevel1)

                %% >>> CASE8: last car status in previous LS mode is OCCUPIPED (car state = 3)
                %%%        AND diff-mag compared to last OCCUPIED STATE(STATE = 3) is within threshold(ParkingStruct.MAG_thresh3),
                %%%        AND meet AT LEAST ONE of the following conditions
                %%%             (1) x-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DataNdiff_Thresh2)
                %%%             (2) y-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DataNdiff_Thresh2)
                %%%             (3) z-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DataNdiff_Thresh)

                %%%        ---  ENFORCE TO OCCUPIED STATE

                ParkingStruct.car_present             = uint8(3);
                ParkingStruct.car_present2            = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG   = uint8(6);
                ParkingStruct.caseTrackNumb          = uint8(6);

            elseif caseFlags(7) && (ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && ParkingStruct.HS_totalTimeLS < ParkingStruct.HS_totalTimeLS_thresh...
                    && lsStart_minus_lsState >= ParkingStruct.MAG_threshUp3 )...
                    && ParkingStruct.HS_Datadiff_baselineZ > ParkingStruct.MAG_thresh_ZaxisLevel2 ...
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3))...
                    && (lsStart_minus_lsState > ParkingStruct.MAG_threshLevel1 ...
                    && lsStart_minus_cal > ParkingStruct.MAG_threshLevel1)

                %% >>> CASE9: time interval between the starting time of current HS mode and ending time of previous HS mode is within threshold(ParkingStruct.HS_totalTimeLS_thresh),
                %%%        AND last car status in previous LS mode is OCCUPIPED (car state = 3)
                %%%        AND diff-mag compared to NO_CAR_BASELINE is larger than threshold(ParkingStruct.MAG_threshUp3)

                %%%        ---  ENFORCE TO OCCUPIED STATE

                ParkingStruct.car_present            = uint8(3);
                ParkingStruct.car_present2           = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                ParkingStruct.caseTrackNumb          = uint8(7);
                %             ParkingStruct.SecondSensor_Req_FLAG  = uint8(200);

            elseif caseFlags(8) && (lsStart_minus_lsState >= ParkingStruct.MAG_threshUp ...
                    && (ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    || (ParkingStruct.Car_State_last_HS      == uint8(1) ...
                    && ParkingStruct.HS_Datadiff_baselineZ > ParkingStruct.MAG_thresh_ZaxisLevel4 ...
                    && (ParkingStruct.HS_STDmax > ParkingStruct.STD_threshDown || ParkingStruct.HS_MAmax > ParkingStruct.detection_threshDown))))...
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3))...
                    && (lsStart_minus_lsState > ParkingStruct.MAG_threshLevel1 ...
                    && lsStart_minus_cal > ParkingStruct.MAG_threshLevel1)

                %% >>> CASE10: diff-mag compared to NO_CAR_BASELINE is larger than upper threshold(ParkingStruct.MAG_threshUp),
                %%%        AND OPTIONAL conditions only reqired for last car status in previous LS mode is VACANT (car state = 1)
                %%%            (1) z-axis mag changes compared to NO_CAR_BASELINE is larger than threshold (ParkingStruct.MAG_thresh_ZaxisLevel4)
                %%%            (2) maximal STD or MA is larger than threshold

                %%%        ---  ENFORCE TO OCCUPIED STATE

                ParkingStruct.car_present             = uint8(3);
                ParkingStruct.car_present2            = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG   = uint8(3);
                ParkingStruct.caseTrackNumb          = uint8(8);
                %            ParkingStruct.SecondSensor_Req_FLAG   = uint8(203);

            elseif caseFlags(9) && (ParkingStruct.Car_State_last_HS      == uint8(3) ...
                    && lsStart_minus_lsState >= ParkingStruct.MAG_threshUp2 ...
                    && (ParkingStruct.HS_Datadiff_baselineZ > ParkingStruct.MAG_thresh_ZaxisLevel5))...
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3))...
                    && (lsStart_minus_lsState > ParkingStruct.MAG_threshLevel1 ...
                    && lsStart_minus_cal > ParkingStruct.MAG_threshLevel1)

                %% >>> CASE11: last car status in previous LS mode is OCCUPIPED (car state = 3)
                %%%        AND diff-mag compared to NO_CAR_BASELINE (STATE = 1) is larger than threshold(ParkingStruct.MAG_threshUp2),
                %%%        AND z-axis mag changes compared to NO_CAR_BASELINE is larger than threshold (ParkingStruct.MAG_thresh_ZaxisLevel5)

                %%%        ---  ENFORCE TO OCCUPIED STATE

                ParkingStruct.car_present             = uint8(3);
                ParkingStruct.car_present2            = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG   = uint8(5);
                ParkingStruct.caseTrackNumb          = uint8(9);
                %            ParkingStruct.SecondSensor_Req_FLAG  = uint8(205);

            elseif caseFlags(10) && (ParkingStruct.Car_State_last_HS      == uint8(1) ...
                    && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel1 ...
                    && (ParkingStruct.HS_Datadiff_baselineZ < ParkingStruct.MAG_thresh_ZaxisLevel6))...
                    && (ParkingStruct.car_present ~= uint8(1) || ParkingStruct.car_present2 ~= uint8(1))
%                     && ParkingStruct.HS_Trigger_thresh_FLAG %don't use if this is a non-normal call

                %% >>> CASE5: last car status in previous LS mode is VACANT (car state = 1)
                %%%        AND z-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffZ_ThreshLevel1)
                %%%        AND z-axis mag changes compared to NO_CAR_BASELINE is larger than threshold (ParkingStruct.MAG_thresh_ZaxisLevel6)

                %%%        ---  ENFORCE TO VACANT STATE

                ParkingStruct.car_present            = uint8(1);
                ParkingStruct.car_present2           = uint8(1);
                ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);
                ParkingStruct.caseTrackNumb          = uint8(10);


                %             elseif (ParkingStruct.Car_State_last_HS      == uint8(1) ...
                %                     && ParkingStruct.HS_Datadiff(3) < ParkingStruct.HS_DatadiffZ_ThreshLevel2  ...
                %                     && ParkingStruct.HS_Datadiff(1) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                %                     && ParkingStruct.HS_Datadiff(2) < ParkingStruct.HS_DatadiffXY_ThreshLevel2 ...
                %                     && (ParkingStruct.HS_Datadiff_baselineZ < ParkingStruct.MAG_thresh_ZaxisLevel6))...
                %                     && (ParkingStruct.car_present ~= uint8(1) || ParkingStruct.car_present2 ~= uint8(1))
                %
                %                 %%% CASE6: last car status in previous LS mode is VACANT (car state = 1)
                %                 %%%        AND z-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffZ_ThreshLevel2)
                %                 %%%        AND x-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffXY_ThreshLevel2)
                %                 %%%        AND y-axis's total mag changes during entire HS mode is less than threshold (ParkingStruct.HS_DatadiffXY_ThreshLevel2)
                %                 %%%        AND z-axis mag changes compared to NO_CAR_BASELINE is larger than threshold (ParkingStruct.MAG_thresh_ZaxisLevel6)
                %
                %                 %%%        ---  ENFORCE TO VACANT STATE
                %
                %                 ParkingStruct.car_present            = uint8(1);
                %                 ParkingStruct.car_present2           = uint8(1);
                %                 ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);
                
            elseif caseFlags(11) && sum(abs(ParkingStruct.LS_StartValue - ParkingStruct.LS_StartValue_state3_initial)) < ParkingStruct.MAG_threshLevel7 ...
                    && lsStart_minus_cal > ParkingStruct.MAG_threshLevel1 ... %&& lsStart_minus_lsState > ParkingStruct.MAG_threshLevel1  
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3))...
                    && ParkingStruct.stateCorrection_type == 0 % only correct if previous change was a true delta
                
                %% >>> CASE12: car state is very close to most recent car state and is trying to transition away (car state = 1)

                %%%        ---  ENFORCE TO OCCUPIED STATE
                ParkingStruct.car_present            = uint8(3);
                ParkingStruct.car_present2           = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                ParkingStruct.caseTrackNumb          = uint8(11);
                ParkingStruct.stateCorrection_FLAG   = uint8(1); % a note that this might be correcting a previous error
                ParkingStruct.stateCorrection_type   = uint8(1);
            end
            
            if ParkingStruct.car_presentPre ~= ParkingStruct.car_present && ~ParkingStruct.stateCorrection_FLAG
                ParkingStruct.stateCorrection_type   = uint8(0);
            end



        elseif  bitand(ParkingStruct.DemoFLAG,1)                == uint8(1)
            %% >>> DEMO Flag
            %%% conditions check for DEMO cases

            if (lsStart_minus_lsState < ParkingStruct.MAG_threshDEMO ...
                    || lsStart_minus_cal < ParkingStruct.MAG_threshDEMO) ...
                    && (ParkingStruct.car_present ~= uint8(1) || ParkingStruct.car_present2 ~= uint8(1))


                ParkingStruct.car_present            = uint8(1);
                ParkingStruct.car_present2           = uint8(1);
                ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);

            elseif lsStart_minus_lsState >= ParkingStruct.MAG_threshUpDEMO ...
                    && (ParkingStruct.car_present ~= uint8(3) || ParkingStruct.car_present2 ~= uint8(3))


                ParkingStruct.car_present             = uint8(3);
                ParkingStruct.car_present2            = uint8(3);
                ParkingStruct.SecondSensor_Req_FLAG   = uint8(3);


            end

        end


        %% >> Algorithm Mismatch
        % case of the outputs from 2 algorithms are not the same -- extend the HS time, allow 2 more seconds HS data to process
        if ParkingStruct.car_present ~= ParkingStruct.car_present2


            if ParkingStruct.SecondSensor_Req_FLAG_count  < ParkingStruct.SecondSensor_Req_FLAG_countMAX

                if ParkingStruct.car_present == uint8(1)

                    ParkingStruct.state1_count           = ParkingStruct.SecondSensor_Req_FLAG_countReset;
                    ParkingStruct.state2_count           = uint16(0);
                    ParkingStruct.state3_count           = uint16(0);
                    ParkingStruct.state4_count           = uint16(0);


                elseif ParkingStruct.car_present == uint8(3)

                    ParkingStruct.state3_count           = ParkingStruct.SecondSensor_Req_FLAG_countReset;
                    ParkingStruct.state2_count           = uint16(0);
                    ParkingStruct.state1_count           = uint16(0);
                    ParkingStruct.state4_count           = uint16(0);

                end


                ParkingStruct.LS_Trigger_FLAG             = uint8(0);
                ParkingStruct.SecondSensor_Req_FLAG_count = ParkingStruct.SecondSensor_Req_FLAG_count + uint8(1);

            else

                ParkingStruct.SecondSensor_Req_FLAG       = uint8(1);
                ParkingStruct.SecondSensor_Req_FLAG_count = uint8(0);
                ParkingStruct.car_present2                = ParkingStruct.car_present;
            end

        end


    end

    %% > Persistent history check
        % check history for validation comparison with state history

%     disp([ParkingStruct.car_present ParkingStruct.car_presentPersist]);

    if ParkingStruct.LS_Trigger_FLAG
        [ParkingStruct, filtStruct] = histFilt(ParkingStruct, filtStruct);
    end


    %% > LS Mode Reset
    if ParkingStruct.LS_Trigger_FLAG       % ParkingStruct.LS_Trigger_FLAG = 0  -- still in HS MODE
        %%% LS Mode

        %% >> Car Status Reset
        ParkingStruct.HS_endTime             = ParkingStruct.time;
        ParkingStruct.LastTransitionState2   = ParkingStruct.LastTransitionState;

        if ParkingStruct.car_present == uint8(1)
            ParkingStruct.LS_StartValue_state1            = ParkingStruct.LS_StartValue;
            if ParkingStruct.car_presentPre ~= ParkingStruct.car_present && ~ParkingStruct.stateCorrection_type
                ParkingStruct.LS_StartValue_state1_initial = ParkingStruct.LS_StartValue;
            end
        elseif ParkingStruct.car_present == uint8(3)
%             ParkingStruct.LS_StartValue_state3prev = ParkingStruct.LS_StartValue_state3;
            ParkingStruct.LS_StartValue_state3            = ParkingStruct.LS_StartValue;
            if ParkingStruct.car_presentPre ~= ParkingStruct.car_present && ~ParkingStruct.stateCorrection_type
                ParkingStruct.LS_StartValue_state3_initial = ParkingStruct.LS_StartValue;
            end
        end

        ParkingStruct.car_present2            = ParkingStruct.car_present;

        % reset
        ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);

        ParkingStruct.StandbyMode_FLAG        = uint8(0);     % SENtral checks this FLAG 1 - detect strong magnet
        ParkingStruct.StandbyMode_CntAlgo     = uint16(0);    % counts number of samples above 500uT

        % max-min mag data on X/Y/Z
        % reset here to catch last values before going to LS.
        % Helps when HS starting section has a gap at the beginning, as in from timing
        ParkingStruct.HS_DataMax           = single(data);
        ParkingStruct.HS_DataMin           = single(data);


%         % reset filtStruct
%         Nbuf = size(filtStruct.mbuf,1);
%         filtStruct.mbuf = zeros(Nbuf,3,'single');
%         filtStruct.mslopeClnbuf = zeros(Nbuf,3,'single');
%         filtStruct.mtempbuf1 = zeros(Nbuf,1,'single');
%         filtStruct.ibuf = uint8(0);
%         filtStruct.mmn = single([0 0 0]);
%         filtStruct.mstd = single([0 0 0]);
%         filtStruct.mmnCln = single([0 0 0]);
%         filtStruct.mstdCln = single([0 0 0]);
%         filtStruct.mslopeCln = single([0 0 0]);
%         filtStruct.mslopeMoveClnMn = single([0 0 0]);
%         filtStruct.mslopeMoveClnStd = single([0 0 0]);

        % reset filtStruct keeping latest value
        if filtStruct.ibuf
            Nbuf = size(filtStruct.mbuf,1);

            filtStruct.mbuf = zeros(Nbuf,3,'single');
            filtStruct.mslopeClnbuf = zeros(Nbuf,3,'single');
            filtStruct.mtempbuf1 = zeros(Nbuf,1,'single');
            filtStruct.ibuf = uint8(0);

            filtStruct.mmn = single([0 0 0]);
            filtStruct.mstd = single([0 0 0]);
            filtStruct.mmnCln = single([0 0 0]);
            filtStruct.mstdCln = single([0 0 0]);
            filtStruct.mslopeCln = single([0 0 0]);
            filtStruct.mslopeMoveClnMn = single([0 0 0]);
            filtStruct.mslopeMoveClnStd = single([0 0 0]);
        end



        %% >> Car Counter
        ParkingStruct.NumCarsPre              = ParkingStruct.NumCars;
        ParkingStruct.NumCars_DriveThruPre    = ParkingStruct.NumCars_DriveThru;

        %%%% case 1: normal parking event case, increase both counters when state changed from vacant to occupied
        %         if ParkingStruct.Car_State_last_HS ==  uint8(1)  && ParkingStruct.car_present == uint8(3)
        %
        %             ParkingStruct.NumCars             = ParkingStruct.NumCars + uint16(1);
        %             ParkingStruct.NumCars_DriveThru   = ParkingStruct.NumCars_DriveThru + uint16(1);
        %
        %             disp(ParkingStruct.NumCarsTemp)
        %             %%%% case 2: aggressive parking case, increase both counters when state changed from occupied to occupied
        %             %%%%         also set the detection FLAG (ParkingStruct.multipleCarsFLAG)
        %         elseif ParkingStruct.Car_State_last_HS ==  uint8(3)  && ParkingStruct.car_present == uint8(3)
        %
        %             if ParkingStruct.NumCarsTemp > uint8(0) && ParkingStruct.STDz_max > ParkingStruct.STDz_max_threshold
        %
        %                 ParkingStruct.NumCars               = ParkingStruct.NumCars + uint16(1);
        %                 ParkingStruct.multipleCarsFLAG      = uint8(1);   %%% detect aggressive parking
        %
        %                 ParkingStruct.NumCars_DriveThru     = ParkingStruct.NumCars_DriveThru + uint16(1);
        %
        %
        %             elseif ParkingStruct.NumCarsTemp > uint8(1)
        %
        %                 ParkingStruct.NumCars               = ParkingStruct.NumCars + uint16(1);
        %                 ParkingStruct.multipleCarsFLAG      = uint8(1);    %%% detect aggressive parking
        %
        %                 ParkingStruct.NumCars_DriveThru     = ParkingStruct.NumCars_DriveThru + uint16(ParkingStruct.NumCarsTemp);
        %
        % %             else
        % %                 disp('no cars')
        %
        %             end
        %
        %
        %             %%%% case 3: driving thru case, increase ONLY the drive thru car counter when state changed from vacant to vacant
        %         elseif ParkingStruct.Car_State_last_HS ==  uint8(1)  && ParkingStruct.car_present == uint8(1)
        %
        %
        %             %%%%% aggressive driving thru case, increase the counters when state changed from vacant to vacant with multiple cars entering continuously
        %             %%%%         also set the detection FLAG (ParkingStruct.multipleCarsFLAG_DriveThru)
        %             if ParkingStruct.NumCarsTemp > uint8(0) && ParkingStruct.STDz_max > ParkingStruct.STDz_max_threshold
        %
        %                 ParkingStruct.NumCars_DriveThru              = ParkingStruct.NumCars_DriveThru + uint16(ParkingStruct.NumCarsTemp);
        %                 ParkingStruct.multipleCarsFLAG_DriveThru     = uint8(1);   %%% detect aggressive drive thru
        %
        %
        %                 %%%%% aggressive driving thru case, increase the counters when state changed from vacant to vacant with multiple cars entering continuously
        %                 %%%%         also set the detection FLAG (ParkingStruct.multipleCarsFLAG_DriveThru)
        %             elseif ParkingStruct.NumCarsTemp > uint8(1)
        %
        %                 ParkingStruct.NumCars_DriveThru              = ParkingStruct.NumCars_DriveThru + uint16(ParkingStruct.NumCarsTemp);
        %                 ParkingStruct.multipleCarsFLAG_DriveThru     = uint8(1);   %%% detect aggressive drive thru
        %
        %
        %                 %%%% normal driving thru case, increase the counters when state changed from vacant to vacant with a car entering (state = 2) in the middle
        %             elseif ParkingStruct.LastTransitionState2 == uint8(2)
        %
        %                 ParkingStruct.NumCars_DriveThru              =  ParkingStruct.NumCars_DriveThru + uint16(1);
        %
        %             end
        %
        %         else
        %             % all other cases
        %             if ParkingStruct.NumCarsTemp > uint8(1) && ParkingStruct.DriveThruFLAG
        %                 ParkingStruct.NumCars_DriveThru              = ParkingStruct.NumCars_DriveThru + uint16(ParkingStruct.NumCarsTemp);
        %                 ParkingStruct.multipleCarsFLAG_DriveThru     = uint8(1);   %%% detect aggressive drive thru
        %             end
        %
        %         end
        if ParkingStruct.NumCarsTemp > uint8(1);ParkingStruct.multipleCarsFLAG_DriveThru = uint8(1);end
        ParkingStruct.NumCars_DriveThru     = ParkingStruct.NumCars_DriveThru + uint16(ParkingStruct.NumCarsTemp);
        ParkingStruct.NumCars               = ParkingStruct.NumCars + uint16(ParkingStruct.NumCarsTemp);

        %% >> End Fcn Reset
        ParkingStruct.STDz_max                          = single(0);
        ParkingStruct.NumCarsTemp                       = uint8(0);


        % if isempty(coder.target)
        %     ParkingStruct.ZdataBuffer                       = [];   %% window size is 1 second data
        % end








        % if isempty(coder.target)
        %
        %
        %     tempData = [tempData ...
        %         single(ParkingStruct.NumCars_DriveThru) ...
        %         single(ParkingStruct.NumCars_DriveThruPre) ...
        %         single(ParkingStruct.multipleCarsFLAG_DriveThru) ...
        %         single(ParkingStruct.NumCars) ];
        %
        %
        %
        %     ParkingStruct.CloudDataALL                      = [ParkingStruct.CloudDataALL;tempData];
        %
        % end


    end


%     %%% hist buffer init
%     if ParkingStruct.Calibration_FLAG && ~ParkingStruct.car_presentPersist
%         % reset hist filters
%         filtStruct.mhisttime1 = zeros(size(filtStruct.mhisttime1,1),1,'single');
%         filtStruct.mhiststate1 = zeros(size(filtStruct.mhiststate1,1),3,'single');
%         filtStruct.mhisttime3 = zeros(size(filtStruct.mhisttime3,1),1,'single');
%         filtStruct.mhiststate3 = zeros(size(filtStruct.mhiststate3,1),3,'single');
%         %%% Update persistent state tracker
%         if ParkingStruct.car_present == uint8(1)
%             if ParkingStruct.car_presentPersist ~= ParkingStruct.car_present
%                 if filtStruct.ihist1<filtStruct.Nhist
%                     filtStruct.ihist1 = filtStruct.ihist1+1;
%                     filtStruct.mhiststate1(filtStruct.ihist1,:) = ParkingStruct.LS_StartValue;
%                     filtStruct.mhisttime1(filtStruct.ihist1,:) = ParkingStruct.time;
%                 else
%                     filtStruct.mhiststate1 = [filtStruct.mhiststate1(2:end,:); ParkingStruct.LS_StartValue]; % drop oldest, add new at end
%                     filtStruct.mhisttime1 = [filtStruct.mhisttime1(2:end,:); ParkingStruct.time]; % drop oldest, add new at end
%                 end
%                 ParkingStruct.car_presentPersist = ParkingStruct.car_present;
%             end
%
%         elseif ParkingStruct.car_present == uint8(3)
%             if ParkingStruct.car_presentPersist ~= ParkingStruct.car_present
%                 if filtStruct.ihist3<filtStruct.Nhist
%                     filtStruct.ihist3 = filtStruct.ihist3+1;
%                     filtStruct.mhiststate3(filtStruct.ihist3,:) = ParkingStruct.LS_StartValue;
%                     filtStruct.mhisttime3(filtStruct.ihist3,:) = ParkingStruct.time;
%                 else
%                     filtStruct.mhiststate3 = [filtStruct.mhiststate3(2:end,:); ParkingStruct.LS_StartValue]; % drop oldest, add new at end
%                     filtStruct.mhisttime3 = [filtStruct.mhisttime3(2:end,:); ParkingStruct.time]; % drop oldest, add new at end
%                 end
%                 ParkingStruct.car_presentPersist = ParkingStruct.car_present;
%             end
%         end
%     end
end