function [mraw,time,SentralOutput,CarCounterData,mDataRaw, sentralTimestamp, CarCounterLog] = Read_Data_CloudLog_CarCounter(alldatfiles)



FileName1=char(alldatfiles(1));
FileName2=char(alldatfiles(2));

if strcmp(FileName1(end-7:end-4),'Logs')
    
    CarCounterLog =FileName1;
    SensorLog     =FileName2;
else
    CarCounterLog =FileName2;
    SensorLog     =FileName1;
    
end


%%%%% load car counter log
delimiter = ',';
startRow = 2;   %10
formatSpec = '%s%f%s%f%s%s%s%s%s%f%s%f%[^\n\r]';
fileID = fopen([CarCounterLog],'r');
rawData1 = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);

%     size(rawData{1,10},1)
fclose(fileID);

rawData = zeros(size(rawData1{1,13},1),4);



%%%%% SENtral Timestamp
temp = rawData1{1,12};
rawData(:,1) = temp(1:size(rawData1{1,13},1)); 



%%%%% Car Counter
for i = 1:length(rawData1{1,7})

    temp1 = rawData1{1,7}{i,1};
    Ind = find(temp1 == ':');
    rawData(i,2) = str2double(temp1(Ind+1:end));     
    
    temp1 = rawData1{1,8}{i,1};
    Ind = find(temp1 == ':');
    rawData(i,3) = str2double(temp1(Ind+1:end)); 
        
    temp1 = rawData1{1,9}{i,1};
    Ind = find(temp1 == ':');
    rawData(i,4) = str2double(temp1(Ind+2)) - 2; 
     
end



[CarCounterTimestamp,ia,~] = unique(rawData(:,1));

CarCounterData = rawData(ia,:);






%%%%%% Load mag data

[rawData,~] = xlsread(SensorLog);

reverseIdx = size(rawData,1):-1:1;
rawData = rawData(reverseIdx,:);

rawData = rawData(rawData(:,2)~=0,:);


diffT = diff(rawData(:,2));
tind = find(diffT< -10^9);

if ~isempty(tind)
    if length(tind)>1
        1;
    end
    
    for i = 1:length(tind)
        rawData(tind(i)+1:end,2)=rawData(tind(i)+1:end,2)+rawData(tind(i),2);
    end
end

%sort data by timestamp
[~, sortedIndexes] = sort(rawData(:,2));
rawData = rawData(sortedIndexes,:);


% ****** load raw mag data
midx=find(~isnan(rawData(:,1)));
mDataRaw=rawData(midx,[2 9 10 11]); 

%sort data by timestamp
[~, sortedIndexes] = sort(mDataRaw(:,1));
mDataRaw = mDataRaw(sortedIndexes,:); 


%%%% removal of repeated data
[~,ia,~] = unique(mDataRaw(:,1));
mDataRaw = mDataRaw(ia,:); 



mDataRaw=[mDataRaw zeros(size(mDataRaw,1),4)];




[C,ia,ib] = intersect(mDataRaw(:,1),CarCounterTimestamp);


for i = 1:length(C)
    mDataRaw(ia(i):length(mDataRaw(:,1)),5) = CarCounterData(ib(i),2);
    mDataRaw(ia(i):length(mDataRaw(:,1)),6) = CarCounterData(ib(i),3);
    mDataRaw(ia(i):length(mDataRaw(:,1)),7) = CarCounterData(ib(i),4);
    
    mDataRaw(ia(i),8)   = 1;
end







% timestamp in seconds
tRaw = mDataRaw(:,1);
time = (tRaw - tRaw(1,:))/32000;  % time in seconds 

sentralTimestamp = mDataRaw(:,1);

% mag data
mraw = mDataRaw(:,2:4);     
    


SentralOutput = mDataRaw(:,5:7);









% 
% % RSSIdata = mDataRaw(:,5);
% % 
% % 
% % SentralOutput = CarCounterData;
% % 
% % 
% % 
% % 
% % 
% %compute delta-t vector
% tDels = time(2:end)-time(1:end-1);
% %compute frequency vector
% tFqs = tDels.^(-1);
% %compute mean rate in hz
% % raw_rate = mean(tFqs);
% % raw_rate = mean(tFqs(1:10));
% raw_rate = tFqs(1);






