function ParkingStruct = Parking_structure_reset(ParkingStruct)





ParkingStruct.dx_history          = zeros(8,1,'single');








ParkingStruct.Reset_FLAG              = uint8(1);

ParkingStruct.LS_Trigger_FLAG         = uint8(0);    % go to HS mode


%% reset for absolute mag-based algorithm

% ParkingStruct.dataBuffer              = zeros(8,1,'single');

ParkingStruct.AVGSUM2                 = zeros(1,3,'single');
% % % % % % ParkingStruct.AVGSUM                  = single(0);


% ParkingStruct.SUM2                    = zeros(1,3,'single');
% ParkingStruct.dataBuffer2             = zeros(8,3,'single');
% ParkingStruct.AVGInit2                = zeros(1,3,'single');


% ParkingStruct.AVG                     = single(0);
% ParkingStruct.STD                     = single(0);

% ParkingStruct.AVGInit                 = single(0);

ParkingStruct.Calibration_Counter     = uint16(0);

% ParkingStruct.state1_count            = uint16(0);
% ParkingStruct.state2_count            = uint16(0);
% ParkingStruct.state3_count            = uint16(0);
% ParkingStruct.state4_count            = uint16(0);




% ParkingStruct.STDSUM                  = single(0);



if ParkingStruct.Context_Input == uint8(99)

    ParkingStruct.car_present             = uint8(1);
    ParkingStruct.car_presentBuffer       = ones(4,1,'uint8') * ParkingStruct.car_present;

    ParkingStruct.car_presentCur          = ParkingStruct.car_present;
    ParkingStruct.car_presentPre          = ParkingStruct.car_present;


else
    ParkingStruct.car_present             = ParkingStruct.Context_Input;
    ParkingStruct.car_presentBuffer       = ones(4,1,'uint8') * ParkingStruct.Context_Input;

    ParkingStruct.car_presentCur          = ParkingStruct.Context_Input;
    ParkingStruct.car_presentPre          = ParkingStruct.Context_Input;

end



% ParkingStruct.K2                      = uint8(0);
% ParkingStruct.SUM                     = single(0) ;    % sum
% ParkingStruct.SUMSq                   = single(0);     % sum square


%% reset for phase-based algorithm

% % % % % % % ParkingStruct.dx_history              = zeros(8,1,'single');

ParkingStruct.local_avg               = single(0);
ParkingStruct.moving_avg              = single(0);

% ParkingStruct.state1_count2           = uint16(0);
% ParkingStruct.state2_count2           = uint16(0);
% ParkingStruct.state3_count2           = uint16(0);
% ParkingStruct.state4_count2           = uint16(0);


ParkingStruct.car_presentBuffer2      = ones(4,1,'uint8')*ParkingStruct.Context_Input;
% ParkingStruct.car_presentBufferCount2 = zeros(4,1,'uint8');


ParkingStruct.car_presentCur2         = ParkingStruct.Context_Input;
ParkingStruct.car_presentPre2         = ParkingStruct.Context_Input;


% ParkingStruct.RMSFLAG                 = uint8(0);


ParkingStruct.Calibration_FLAG        = uint8(0);   % 1 - calibration process finished



% ParkingStruct.LS_CheckValueBuffer     = zeros(3,3,'single');
% ParkingStruct.LS_Count                = uint32(0);




