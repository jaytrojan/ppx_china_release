%%% Parking Lot Watch script
% clear; %clc;
% dbstop if error

logPath = '..\..\Data\cameraLogs\';
lotDir = 'FrontLot\';
filename = 'frontLotImageTest';
fmt = 'tif';
urlStr = 'https://parking-dev.pnicloud.com/images/parking_lot_images/?p=ouhwhcS4jExwYzhdn';

% urlStr = 'parkImage.tiff';
% filename0 = 'parkingImage.jpg';
% urlwrite(urlStr,filename0);
% A = imread(filename);

% dstrInit = '19-Dec-2017 06:33:00'
% while datetime(now,'InputFormat','dd-MM-yyyy HH:mm:ss') - datetime(dstrInit,'ConvertFrom','dd-MM-yyyy HH:mm:ss')
%     pause(1)
% end
% fprintf('lkjdsjlfds')


%%% wait delay before start (seconds)
% twait2Start = 12*3600; % seconds to wait
% twaitDelay = 60;
% 
% twait2Start = 1; % seconds to wait
% twaitDelay = 1;

% t0 = tic;
% while toc(t0) < twait2Start
%     pause(twaitDelay); % check once per minute
% %     disp('waiting...')
% end
disp('Initializing Camera Logging...')
datestr(now)

% {tstart logging,   t stop logging}
tSchedList = {...
    '15-Jan-2018 06:00:00', '15-Jan-2018 20:00:00'
    };


%%% Initialize Loop
% 1 image per minute
% 60 images per file
figure(1); clf;
saveImages = 1;
forceSaveDups = 0; % will save every load regardless if still old
imcnt = 0;

% 1 minute page updates
imcntLim = 60;
tint1 = 60; % nominal interval between saves (sec)
tint2 = 10; % guard interval between saves (sec) in case inerval is just missed

% % % % test
% % % forceSaveDups = 1; % will save every load regardless if still old
% % % imcntLim = 5;
% % % tint1 = 1; % nominal interval between saves (sec)
% % % tint2 = 1; % guard interval between saves (sec) in case interval is just missed

%     tstartLog = datetime('21-Dec-2017 17:30:00');

for ilist = 1:length(tSchedList)
    
    tstartLog = tSchedList{ilist,1};
    tstopLog = tSchedList{ilist,2};
    
    testingFlag = 1;
    
    dstrDirFormat = 'mmmyyyy';
    while testingFlag
        tnow = datetime(now,'ConvertFrom','datenum');
%         disp(tnow)
        
        if tnow<tstartLog
            pause(1);
            continue
        elseif  tnow>=tstopLog
            testingFlag = 0;
            pause(1);
            continue
        else
%             disp('test')
            tstart = now;
            dstrFormat = 'yymmdd-HHMMSS';
            tstrStart = datestr(tstart,dstrFormat);
            tstr = tstrStart;
            
            timeAy = [];
            
            parkImageLast = [];
            while saveImages && tnow<tstopLog
                tnow = datetime(now,'ConvertFrom','datenum');
%                 disp(tnow);

                dateStrDir = datestr(tstart,dstrDirFormat); % dif dir every month
                
                saveDir = [logPath lotDir dateStrDir '\'];
                if ~isdir(saveDir), mkdir(saveDir); end
                

                
                
                tspace0 = seconds(60);
                t1 = seconds(3); % time incrment if tEst is short
                t2 = seconds(5); % time to check short of tEst
                
                parkImage = imread(urlStr);
                parkImage = imageResizeInterp(parkImage,0.40); % image size reduction (factor of 1/4 is ~1/16 memory)
                parkImageLast = parkImage;
                tupdateLast = datetime('now') - seconds(0); % initial guess at last update time
                
                % regular loop
                tRef = datetime('now') - tspace0; % prev time
                tEst = tRef + tspace0+t2;
                disp([ datestr(tRef,'HH:MM:SS.fff') '     ' datestr(tEst,'HH:MM:SS.fff')]);
                tupdate = datetime('now');
                for iii=1:1000
                    % wait for it
                    while tupdate <(tEst - t2)
%                         fprintf('%s    %s',tRef, tEst);
                        pause(0.1);
                        tupdate = datetime('now');
                    end

                    readFlag = 0;
                    for itry=1:5
                        try
                            % try several times before giving up
                            parkImage = imread(urlStr);
                            parkImage = imageResizeInterp(parkImage,0.40);
%                             parkImageq2 = imageresize(parkImage,0.40,2)  ;
%                             parkImageq2 = uint8(parkImageq2);

                            tupdate = datetime('now');
                            
                            readFlag = 1;
                            break
                        catch
                            pause(1);
                        end
                    end
                    if ~readFlag, break; end
                    
                    
                    newImageFlag = isempty(parkImageLast) || (~isempty(parkImageLast) && sum(sum(sum(abs(parkImageLast - parkImage)))));
                    newImageFlag
                    
                    tEstErr1 = seconds(tEst - tupdate);
                    tEstErr2 = seconds((tEst-tRef) - tspace0);
                    if newImageFlag
                        disp([ datestr(tRef,'HH:MM:SS.fff') '     ' datestr(tEst,'HH:MM:SS.fff') '     ' num2str(seconds(tEst-tRef))  '     ' num2str((tEstErr2)) ]);
                        tRef = tupdate;
                        tEst = tRef - seconds(tEstErr2) + tspace0;
                        parkImageLast = parkImage;
                        tupdateLast = tupdate;
                    else
                        disp([ datestr(tRef,'HH:MM:SS.fff') '     ' datestr(tEst,'HH:MM:SS.fff') '     ' num2str(seconds(tEst-tRef))  '     ' num2str((tEstErr2)) ]);
                        tEst = tEst + t1;
                    end
                end
                
                
                
 
%                             parkImage = imresizeCust(parkImage,0.33); % image size reduction (factor of 1/4 is ~1/16 memory)
%                             parkImageResize = imresizeCust(parkImage,0.40); % image size reduction (factor of 1/4 is ~1/16 memory)
                            
%                             sXYZ = size(parkImage);
%                             gInt = sXYZ(1)/((sXYZ(1)*0.40));
%                             Xq = round(1:gInt:sXYZ(1));
%                             gInt = sXYZ(2)/(sXYZ(2)*0.40);
%                             Yq = round(1:gInt:sXYZ(2));
%                             [Xq,Yq] = meshgrid(Yq,Xq);
%                             
%                             parkImageResize = [];
%                             parkImageResize(:,:,1) = (interp2(double(parkImage(:,:,1)),Xq,Yq,'spline'));
%                             parkImageResize(:,:,2) = (interp2(double(parkImage(:,:,2)),Xq,Yq,'spline'));
%                             parkImageResize(:,:,3) = (interp2(double(parkImage(:,:,3)),Xq,Yq,'spline'));
%                             parkImage = uint8(parkImageResize);

%                 for iii=1:30
%                     
%                     pause(seconds(tEst));
%                     
%                     tupdate = now;
%                     
%                     parkImage = imread(urlStr);
%                     parkImage = imresizeCust(parkImage,0.33); % image size reduction (factor of 1/4 is ~1/16 memory)
%                     
%                     newImageFlag = isempty(parkImageLast) || (~isempty(parkImageLast) && sum(sum(sum(abs(parkImageLast - parkImage)))));
%                     parkImageLast = parkImage;
%                     
%                     newImageFlag
%                     
%                     tspaceMeas = tupdate - tupdateLast;
%                     if newImageFlag
%                         tEst = tspace0-tspaceMeas-t1; % seconds until next possible update
%                         tupdateLast = tupdate;
%                     else
%                         tEst = t1;
%                     end
%                     disp([tspaceMeas tEst]);
%                     if seconds(tEst) < 1, tEst = seconds(1); end
%                     
%                 end
%                 
                
                
                
                
                parkImage = imread(urlStr);
                parkImage = imageResizeInterp(parkImage,0.40); % image size reduction (factor of 1/4 is ~1/16 memory)
                
                newImageFlag = isempty(parkImageLast) || (~isempty(parkImageLast) && sum(sum(sum(abs(parkImageLast - parkImage)))));
                if newImageFlag || forceSaveDups
                    % only do stuff if new image
                    
                    tupdate = now;
                    timeAy = [timeAy; tupdate];
                    
                    % display image
                    image(parkImage);
                    
                    
                    %%% save image
                    writeFlag = 0;
                    for itry=1:5
                        try
%                             % try several times before giving up
%                             imwrite(parkImage,[logPath filename tstr '.' fmt], 'WriteMode', 'append');
                            
                            % jpg compression about 5-6 times less memory
                            imwrite(parkImage,[saveDir filename tstr '.' fmt], 'Compression', 'jpeg', 'RowsPerStrip',64, 'WriteMode', 'append');
                            
                            writeFlag = 1;
                            break
                        catch
                            pause(2);
                        end
                    end
                    
                    
                    if writeFlag
                        %%% save date/time data
                        writeFlag = 0;
                        for itry=1:5
                            try
                                % try several times before giving up
                                save([saveDir filename tstr '_time'],'timeAy');
                                writeFlag = 1;
                            catch
                                pause(1);
                            end
                        end
                    end
                    
                    %         fileinfo = dir([filename tstr '.' fmt]);
                    %         filesize = fileinfo(1).bytes;
                    
                    if writeFlag
                        % normal write successful
                        imcnt = imcnt+1;
                        tint = tint1;
                        parkImageLast = parkImage;
                    else
                        % Error: write unsuccesful
                        % force new log creation at new time
                        imcnt = imcntLim;
                        tint = tint2; % shorter time
                    end
                    if imcnt>=imcntLim
                        % start new file
                        tstart = now;
                        tstr = datestr(tstart,dstrFormat);
                        imcnt=0;
                        timeAy = [];
                    end
                else
                    tint = tint2; % if no image wait shorter time
                end
                
                pause(tint);
                
            end
        end
    end
end


% save([filename tstrStart],'timeAy')
aaa=999;

% info = imfinfo(filename);
% imwrite(im1, 'myfile.tif');
% imwrite(im2, 'myfile.tif', 'WriteMode', 'append');