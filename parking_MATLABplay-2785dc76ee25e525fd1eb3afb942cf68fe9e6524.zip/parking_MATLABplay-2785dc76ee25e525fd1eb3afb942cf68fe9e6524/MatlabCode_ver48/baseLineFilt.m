function baseFilt = baseLineFilt(baseFilt,data,sRate0)
% baseline moving meas
% moving average
% moving slope


%%% dynamic adjust expfilter alpha based on sample rate
% tconstant = baseFilt.tconstant;
% dt = 1/single(sRate);
% beta = dt/tconstant;
sRate = single(sRate0);
beta = 1/(sRate*baseFilt.tconstant);
alpha = 1-beta;


%% init
if baseFilt.initFilt
    baseFilt.dfiltS.dataFilt = data;
    baseFilt.dfiltwS.dataFilt = data;
    baseFilt.baseLineMeas = data;
    baseFilt.initFilt = uint8(0);
end
dfiltwS_dataFilt_prev = baseFilt.dfiltwS.dataFilt;


%% exp moving stats calc
% average

baseFilt.dfiltS.data = data;
baseFilt.dfiltS = expStatCalcS(baseFilt.dfiltS,alpha,beta);


%% weighting exp moving stats (reduce outliers)
% Rsqr calcs to avoid sqrt
dvarfiltR = sum(baseFilt.dfiltS.dataVarFilt);
dataDevMeasR = sum(baseFilt.dfiltS.dataVar);

if dataDevMeasR==0
    w=single(1);
else
    % wt dataDevMeasR by sigmawt
    w = single(baseFilt.outSigmaWt*dvarfiltR./dataDevMeasR); % sigma limited
    if w<baseFilt.outwtRange(1), w=baseFilt.outwtRange(1); end
    if w>baseFilt.outwtRange(2), w=baseFilt.outwtRange(2); end
end

betaw = w*beta;
alphaw = 1-betaw;

baseFilt.dfiltwS.data=data;
baseFilt.dfiltwS = expStatCalcS(baseFilt.dfiltwS,alphaw,betaw);

% slope calc
baseFilt.dslopefiltwS.data = baseFilt.dfiltwS.dataFilt-dfiltwS_dataFilt_prev; % use filtered meas for smoother slope
baseFilt.dslopefiltwS = expStatCalcS(baseFilt.dslopefiltwS,alpha,beta);


% stability check
stable1 = sum(baseFilt.dslopefiltwS.dataFilt.*baseFilt.dslopefiltwS.dataFilt);
stable2 = sum(baseFilt.dslopefiltwS.dataVarFilt.*baseFilt.dslopefiltwS.dataVarFilt);
stable3 = sum(baseFilt.dfiltwS.dataVar.*baseFilt.dfiltwS.dataVar);
stable4 = sum(baseFilt.dfiltwS.dataVarFilt.*baseFilt.dfiltwS.dataVarFilt);
stableCheck = (...
                stable1   <= baseFilt.slopefiltwS_filt_thr ...
                & stable2 <= baseFilt.slopefiltwS_varFilt_thr...
                & stable3 <= baseFilt.filtwS_var_thr ...
                & stable4 <= baseFilt.filtwS_varFilt_thr ...
              );
if stableCheck
    baseFilt.stableCnt = baseFilt.stableCnt+1; 
else 
    baseFilt.stableCnt = uint32(0);
    baseFilt.baseLineMeasAccum = single([0 0 0]);
end

% accumulate divide average calc to avoid tail problems
if baseFilt.stableCnt
    baseFilt.baseLineMeasAccum = baseFilt.baseLineMeasAccum + baseFilt.dfiltwS.dataFilt; 
end
if baseFilt.stableCnt > (sRate*baseFilt.stableCntTime)
    baseFilt.baseLineMeas = baseFilt.baseLineMeasAccum/single(baseFilt.stableCnt); 
end

% periodic reset cnt to avoid slow stuck probs
if baseFilt.stableCnt > 1000
    baseFilt.stableCnt = uint32(10);
    baseFilt.baseLineMeasAccum = single(baseFilt.stableCnt)*baseFilt.baseLineMeas; 
end


%% save vars
baseFilt.w = w;


