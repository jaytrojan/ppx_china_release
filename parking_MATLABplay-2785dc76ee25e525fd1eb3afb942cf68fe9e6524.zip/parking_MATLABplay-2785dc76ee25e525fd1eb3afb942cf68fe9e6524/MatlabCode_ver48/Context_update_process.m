function ParkingStruct = Context_update_process(ParkingStruct, data)


% ****** FEATURE: Absolute mag value *********
ParkingStruct.dataBuffer      = shifting_array(ParkingStruct.dataBuffer);
ParkingStruct.dataBuffer(end) = single(sqrt(single(data(1)*data(1)+data(2)*data(2)+data(3)*data(3))));

if ParkingStruct.dataBuffer(1) == single(0)
    
    ParkingStruct.AVG = ParkingStruct.dataBuffer(end);
else
    ParkingStruct.AVG = mean(ParkingStruct.dataBuffer);
end



        
ParkingStruct.Calibration_Counter  = ParkingStruct.Calibration_Counter + uint16(1);
ParkingStruct.AVGSUM               = ParkingStruct.AVGSUM  + ParkingStruct.AVG ;             



if ParkingStruct.Calibration_Counter == ParkingStruct.Calibration_Timeout * ParkingStruct.HS_rate
    
    ParkingStruct.AVGInit  = ParkingStruct.AVGSUM / single(ParkingStruct.Calibration_Counter); 
    
    ParkingStruct.Calibration_FLAG = uint8(1);   % calibration process finished
    
    
    % reset 
    ParkingStruct.AVGSUM       = single(0);    
    ParkingStruct.dataBuffer   = zeros(3,1,'single');

    ParkingStruct.AVG          = single(0); 
        
    ParkingStruct.LS_Trigger_FLAG  = uint8(1);    % trigger the Alarm: back to low speed mode
    
    ParkingStruct.LS_TO_HS_FLAG    = uint8(0);    % reset to ZERO when go back to low speed mode
    
    
    
end