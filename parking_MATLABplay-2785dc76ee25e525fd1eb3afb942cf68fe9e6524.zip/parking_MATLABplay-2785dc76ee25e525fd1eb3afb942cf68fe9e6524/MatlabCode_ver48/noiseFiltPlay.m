
dbstop if error

haxDebug = [];

figOff = 10;

% save('mdata2','mx2')
% load('mdata','mx')

% figure(1); clf
% plot(mx,'.'); hold all
% plot(mx2,'.'); hold all
% grid on

% % remove dups
% mx0=[mx mx mx];
% mxc = mx0(1,:);
% for ii=2:length(mx0)
%     if mx0(ii,:) ~= mx0(ii-1,:)
%         mxc = [mxc; mx0(ii,:)];
%     end
% end
% 

% %%% Add Noise
% testSignalFlag = 1; % if 0, turns off all noise and signal changes from default.
% %%% Signal Test (if testSignalFlag is turned on)
% % additive noise
% % periodic noise (sine and square waves)
% % set freq to 0 to turn off
% magSineNoise = [60 0.5 0.5 0.5]; % [freqHz Xut Yut Zut]
% magSquareNoise = [0.5 1 1 1 20]; % [freqHz Xut Yut Zut dutyCyclePosPcnt]
% % gaussian noise
% magGaussNoise = 0.0; % uT
% % 
% % addnoiseScript
% magDataNoise = addnoiseFcn(magData,time_rel,magSineNoise,magSquareNoise,magGaussNoise);

% mxc = magData;
mxc = magDataNoise;

% stability/slope/noise filter
filtStruct = stableFilt_struct_init;


mmn_ay = []; mmnCln_ay = [];
mstd_ay = []; mstdCln_ay = [];
mstdDelta_ay = []; mstdDeltaCln_ay = [];
mstdSlope_ay = []; mstdMoveClnSlope_ay = [];
mslope_ay = []; mslopeCln_ay = [];
mslopeMoveClnMn_ay = [];
mslopeMoveClnStd_ay = [];
mstdMoveClnSlopeMax_ay = [];
mslopeMoveClnMnMax_ay = [];

% filtStruct.ibuf = 0;
% mstdPrev = 0; mstdClnPrev = 0;
for ii=1:length(mxc)
    
    filtStruct = stableFilt(filtStruct,mxc(ii,:));
    
    mstdClnMn = mean(abs(filtStruct.mstdCln));
%     mstdMoveClnSlopeMn = mean(abs(filtStruct.mstdMoveClnSlope));
%     mslopeMoveClnMnMn = mean(abs(filtStruct.mslopeMoveClnMn));
    stableFlag = true; % mstdClnMn<0.75 & abs(mstdMoveClnSlopeMn)<0.03 & abs(mslopeMoveClnMnMn)<0.03;
    
    
%     [maxVal, maxInds] = max(abs(filtStruct.mstdMoveClnSlope),[],2);
%     mstdMoveClnSlopeMax = filtStruct.mstdMoveClnSlope(maxInds);
%     [maxVal, maxInds] = max(abs(filtStruct.mslopeMoveClnMn),[],2);
%     mslopeMoveClnMnMax = filtStruct.mslopeMoveClnMn(maxInds);
    
    mmn_ay = [mmn_ay; filtStruct.mmn];
    mstd_ay = [mstd_ay; filtStruct.mstd];
    mmnCln_ay = [mmnCln_ay; filtStruct.mmnCln];
    mstdCln_ay = [mstdCln_ay; filtStruct.mstdCln];

%     mstdDelta_ay = [mstdDelta_ay; filtStruct.mstdDelta];
%     mstdDeltaCln_ay = [mstdDeltaCln_ay; filtStruct.mstdClnDelta];
%     mstdSlope_ay = [mstdSlope_ay; filtStruct.mstdMoveSlope];
%     mstdMoveClnSlope_ay = [mstdMoveClnSlope_ay; filtStruct.mstdMoveClnSlope];
    
%     mslope_ay = [mslope_ay; filtStruct.mslope];
    mslopeCln_ay = [mslopeCln_ay; filtStruct.mslopeCln];
    
    mslopeMoveClnMn_ay = [mslopeMoveClnMn_ay; filtStruct.mslopeMoveClnMn];
    mslopeMoveClnStd_ay = [mslopeMoveClnStd_ay; filtStruct.mslopeMoveClnStd];
    
%     mstdMoveClnSlopeMax_ay = [mstdMoveClnSlopeMax_ay; mstdMoveClnSlopeMax];
%     mslopeMoveClnMnMax_ay = [mslopeMoveClnMnMax_ay; mslopeMoveClnMnMax];
    
end

% mstdClnMax_ay = max(mstdCln_ay,[],2);

mstdClnMn_ay = mean(abs(mstdCln_ay),2);
% mstdMoveClnSlopeMn_ay = mean(abs(mstdMoveClnSlope_ay),2);
mslopeMoveClnMnMn_ay = mean(abs(mslopeMoveClnMn_ay),2);

% magnitude
mstdR_ay = sqrt(sum(mstd_ay.^2,2));
mstdClnR_ay = sqrt(sum(mstdCln_ay.^2,2));

% mslopeR_ay = sqrt(sum(mslope_ay.^2,2));
mslopeClnMn_ay = mean(abs(mslopeCln_ay),2);
mslopeClnR_ay = sqrt(sum(mslopeCln_ay.^2,2));
% mstdDeltaClnR_ay = sqrt(sum(mstdDeltaCln_ay.^2,2));

% mstdMoveClnSlopeR_ay = sqrt(sum(mstdMoveClnSlope_ay.^2,2));
mslopeMoveClnMnR_ay = sqrt(sum(mslopeMoveClnMn_ay.^2,2));
mslopeMoveClnStdR_ay = sqrt(sum(mslopeMoveClnStd_ay.^2,2));



% stableFlags = abs(mslopeCln_ay<0.01) & mstdCln_ay<0.3;
% stableFlags = mstdClnMn_ay<0.75 & abs(mstdMoveClnSlopeMn_ay)<0.03 & abs(mslopeMoveClnMnMn_ay)<0.03;
stableFlags = mstdClnR_ay<filtStruct.stableThreshDown(1) & abs(mslopeMoveClnMnR_ay)<filtStruct.stableThreshDown(2); % & abs(mslopeMoveClnStdR_ay)<1.0;
unStableFlags = mstdClnR_ay>filtStruct.stableThreshUp(1) | abs(mslopeMoveClnMnR_ay)>filtStruct.stableThreshUp(2); % & abs(mslopeMoveClnStdR_ay)<1.0;



figure(1+figOff); clf
haxDebug = [haxDebug axes];
plot(time2,magData(:,1),'.--'); hold all
plot(time2,mmn_ay(:,1),'--'); hold all
plot(time2,mmnCln_ay(:,1),'-','LineWidth',2); hold all
title('Mag vs. Moving Average')
grid on

figure(2+figOff); clf
haxDebug = [haxDebug axes];
plot(time2,STD_value(:,1),':'); hold all
plot(time2,mstdR_ay(:,1),'.--'); hold all
plot(time2,mstdClnR_ay(:,1),'.-','LineWidth',2); hold all
plot(time2,mstdClnMn_ay(:,1),'.-','LineWidth',2); hold all
plot(time2,stableFlags(:,1),'-','LineWidth',2); hold all
plot(time2,unStableFlags(:,1),'-','LineWidth',2); hold all

grid on
title('mStdR & mStdClnR')
legend('STD','mstd','mstdClnR','mstdClnMn','stableFlags')

% figure(3); clf
% haxDebug(3) = axes;
% % plot(time2,mslope_ay(:,1),'.--'); hold all
% plot(time2,mslopeCln_ay(:,1),'.-','LineWidth',1); hold all
% % plot(time2,mstdDeltaCln_ay(:,1),'.--','LineWidth',1); hold all
% % plot(time2,mstdMoveClnSlopeMn_ay,'-','LineWidth',2); hold all
% plot(time2,mslopeMoveClnMnMn_ay,'-','LineWidth',2); hold all
% plot(time2,0*mslopeCln_ay(:,1),'-k','LineWidth',2); hold all
% grid on
% % ylim([-0.1 0.1])
% title('Slope & Std Slope')
% legend('mslopeCln','mslopeMoveClnMn_ay')
% aaa=999;
% 

figure(4+figOff); clf
haxDebug = [haxDebug axes];
% plot(time2,mslopeR_ay(:,1),'.--'); hold all
plot(time2,mslopeClnMn_ay(:,1),'.-','LineWidth',1); hold all
plot(time2,mslopeClnR_ay(:,1),'.-','LineWidth',1); hold all

plot(time2,mslopeMoveClnMnMn_ay,'-','LineWidth',3); hold all
plot(time2,mslopeMoveClnMnR_ay,'-','LineWidth',3); hold all

plot(time2,mslopeMoveClnStdR_ay,'-','LineWidth',3); hold all
plot(time2,0*mslopeClnR_ay(:,1),'-k','LineWidth',2); hold all
grid on
% ylim([0 0.2])
title('SlopeR & Std SlopeR')
legend('mslopeClnMn','mslopeClnR','mslopeMoveClnMn','mslopeMoveClnMnR','mslopeMoveClnStdR')
aaa=999;

% linkprop([ haxDebug],'xlim');

linkprop([haxAy haxDebug],'xlim');




