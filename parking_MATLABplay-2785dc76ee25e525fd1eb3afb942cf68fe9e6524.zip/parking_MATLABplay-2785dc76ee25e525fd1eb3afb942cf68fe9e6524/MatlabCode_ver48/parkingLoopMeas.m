function [ParkingStruct,filtStruct,resultRecAy] = parkingLoopMeas(ParkingStruct,filtStruct,dataStruct,dataInfo)

% magData = dataRec.magData;
% time = dataRec.time;
% SentralOutput = dataRec.SentralOutput;
% magSenTimestamp = dataRec.magSenTimestamp;

HS_mode_triggerIND = [];

mraw = dataStruct.magDataAy(:,2:4);
time = dataStruct.time;
% SentralOutput = dataStruct.magDataAy(:,6:7);
% raw_rate = dataStruct.magRaw_rate;
magSenTimestamp = dataStruct.magSenTimestamp;
% servTime = dataStruct.magDateTimeAy; % server time

start_ind = 1;
end_ind = size(mraw,1);    %%%% 1690;   %%%%size(mraw,1);  %%%625;
magData       = mraw(start_ind:end_ind,:);
% time          = timeRaw(start_ind:end_ind,:);
% SentralOutput = SentralOutput(start_ind:end_ind,:);
magSenTimestamp = magSenTimestamp(start_ind:end_ind,:);


N3 = length(magData);

% magNdata = zeros(N3,1);
% mag_diff = zeros(N3,1);
% phase_level = zeros(N3,1);
% detection_output = zeros(N3,1);

car_state = zeros(N3,4);

% MEAN_value = zeros(N3,2);
% STD_value = zeros(N3,1);
%
% MEAN_value2 = zeros(N3,3);
%
% moving_avg = zeros(N3,1);
%
% MEAN_Baseline_value = zeros(N3,1);
% STD_Baseline_value = zeros(N3,1);
% MEAN_Occupied_value = zeros(N3,1);
% STD_Occupied_value = zeros(N3,1);

% ALG2Level = zeros(N3,1);
% car_state_alg2 = zeros(N3,1);

% car_state_buffer =zeros(N3,1);

% Alarm_level = zeros(N3,1);
LS_Trigger_FLAG_ay = zeros(N3,1);

% dataBuffer2Ay = zeros(size(ParkingStruct.dataBuffer2,1),size(ParkingStruct.dataBuffer2,2),N3);


% % stability filter track
% mmn_ay = []; mmnCln_ay = [];
% mstd_ay = []; mstdCln_ay = [];
% mstdDelta_ay = []; mstdDeltaCln_ay = [];
% mstdSlope_ay = []; mstdSlopeCln_ay = [];
% mslope_ay = []; mslopeCln_ay = [];
% mslopeMoveClnMn_ay = [];

% add missing fields
ParkingStruct.NUM = single(0);
ParkingStruct.StartNUM = single(0);

% flds to monitor
% status fields
parkFieldsStatusWatch = createParkStructStatusWatchList;
parkStatusS = copyFields(ParkingStruct,parkFieldsStatusWatch);
parkStatusAy = repmat(parkStatusS,N3,1);
% meas fields

parkFieldsMeasWatch = createParkStructMeasWatchList;
parkMeasS = copyFields(ParkingStruct,parkFieldsMeasWatch);
parkMeasAy = repmat(parkMeasS,N3,1);
filtStructAy = repmat(filtStruct,N3,1);


tgapmax = 60;
tgapreplace = 10;
dt = [0; time(2:end) - time(1:end-1)];
dtBigInds = find(dt>=tgapmax);
% [time(dtBigInds-1) time(dtBigInds) time(dtBigInds+1)]

dt2 = dt;
tgapmeas = dt(dtBigInds);
dt2(dtBigInds) = tgapreplace;
time2 = time(1) + cumsum(dt2);


%% Data Loop
testState = 0;

%         startTime = 2200;
if ~isempty(dataInfo.startTime)
    startInd = find(time2>=dataInfo.startTime,1,'first');
else
    startInd = 1;
end
startInd = 1;

for i = startInd:length(magData)
    
    ParkingStruct.NUM               = single(i);
    
    %     % conditional simulates RM3100 hardware mode
    %     if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
    %         ParkingStruct.StartNUM          = ParkingStruct.NUM;
    %     end
    %     % hardware alarm
    %     [ParkingStruct, filtStruct] = Parking_AlgorithmWrap(ParkingStruct, filtStruct, magData(i,:),magSenTimestamp(i),1);
    
    % conditional simulates RM3100 hardware mode
    if ((abs(magData(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
            || (abs(magData(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
            || (abs(magData(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
            || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
            || (~isempty(HS_mode_triggerIND) && any(HS_mode_triggerIND == ParkingStruct.NUM))
        
        if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
            ParkingStruct.StartNUM          = ParkingStruct.NUM;
        end
        
        
        %                 if time2(i)>= 390
        %                     testState=1;
        %                 end
        
        % hardware alarm
        %         ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
        [ParkingStruct, filtStruct] = Parking_AlgorithmWrap(ParkingStruct, filtStruct, magData(i,:),magSenTimestamp(i),1);
        
        
        %          %%%%% downsample to 4 Hz
        %          if ParkingStruct.downsampleFLAG == 1
        %             ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),magSenTimestamp(i),1);
        %             ParkingStruct.downsampleFLAG = 0;
        %          else
        %              ParkingStruct.downsampleFLAG = 1;
        %          end
        if ParkingStruct.lsRecheckEnable >= 0
            ParkingStruct.cPastLsMode = uint16(0);
            ParkingStruct.lsRecheckEnable = int8(1);
        end
    else
        %                 disp('Hardware LS Mode Sim Pt!!!')
        ParkingStruct.cPastLsMode = ParkingStruct.cPastLsMode + uint16(1); % keep track of time since last parking event
        
        if (ParkingStruct.car_present == 3 && ParkingStruct.car_present2 == 3) && ParkingStruct.cPastLsMode > ParkingStruct.LS_rate * ParkingStruct.lsRecheckTime % only perform check if the system is confirmed in parked mode
            ParkingStruct = Parking_isEmptyCheck(ParkingStruct,magData(i,:));
        end
    end
    
    
    %%% Track ParkingStruct field data
    parkStatusAy(i) = copyFields(ParkingStruct,parkFieldsStatusWatch);
    parkMeasAy(i) = copyFields(ParkingStruct,parkFieldsMeasWatch);
    filtStructAy(i) = filtStruct;
    car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2 ParkingStruct.car_present ParkingStruct.car_present2];
    LS_Trigger_FLAG_ay(i,:) = ParkingStruct.LS_Trigger_FLAG;
    
end

resultRecAy.parkStatusAy = parkStatusAy;
resultRecAy.parkMeasAy = parkMeasAy;
resultRecAy.filtStructAy = filtStructAy;
resultRecAy.car_state = car_state;
resultRecAy.LS_Trigger_FLAG_ay = LS_Trigger_FLAG_ay;


