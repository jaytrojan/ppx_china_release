function [ParkingStruct,filtStruct,dataInfo] = preCalLoopFcn(ParkingStruct,filtStruct,dataInfo,magData,time2,magSenTimestamp,HS_mode_triggerIND,Ncal)

if size(magData,1) > Ncal
    calTime = dataInfo.calTime;
    if ~dataInfo.preCalLoop
%         Ncal=30; % target cal samples if all within limits - set shorter because of typical file behavior
        Ncalnative = 40;
        mCalDevLimit = 3; % uT
        magCalInitData =  magData(1:Ncal,:);
        devMedAy = magCalInitData - repmat(median(magCalInitData,1),Ncal,1);
        devMedRAy = sqrt(sum(devMedAy.^2,2));
        icalEnd = find((devMedRAy)<=mCalDevLimit,1,'last');
        if ~isempty(icalEnd) && icalEnd<Ncalnative
            % condition for doing preloop cal to avoid bad mag readings in initial cal.
            if icalEnd<12, icalEnd = 12; end % min number of pts
            calTime = [time2(1) time2(icalEnd)];
            preCalLoop = 1;
            dataInfo.preCalLoop = preCalLoop;
        end
        dataInfo.calTime = calTime;
    end
    
    calContext = 1; % 1=no car; 3 = car;
    if dataInfo.preCalLoop
        %             preCalLoop = 0; % flag to calibrate before running data
        %             calTime = [2920 3000]; % time range to use for calibration
        ParkingStruct.Context_Input = calContext;
        
        tcalRangeInds = find(time2>=calTime(1) & time2<=calTime(2));
        magDataCal = magData(tcalRangeInds,:);
        magSenTimestampCal = magSenTimestamp(tcalRangeInds,:);
        
        for icalLoop = 1:10
            for i = 1:length(magDataCal)
                
                ParkingStruct.NUM               = single(i);
                
                %     ParkingStruct.PreDataBuffer      = shifting_array(ParkingStruct.PreDataBuffer);
                %     ParkingStruct.PreDataBuffer(ParkingStruct.PreDataBufferSize,:)  = magData(i,:);
                
                %             disp(magData(i,:))
                
                % conditional simulates RM3100 hardware mode
                if ((abs(magDataCal(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
                        || (abs(magDataCal(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
                        || (abs(magDataCal(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
                        || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
                        || (~isempty(HS_mode_triggerIND) && any(HS_mode_triggerIND == ParkingStruct.NUM))
                    %         || ParkingStruct.NUM              == 95 ...
                    %         || ParkingStruct.NUM              == 123 ...
                    %         || ParkingStruct.NUM              == 156
                    
                    
                    
                    if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
                        ParkingStruct.StartNUM          = ParkingStruct.NUM;
                    end
                    
                    % Parking Algorithm
                    [ParkingStruct, filtStruct] = Parking_AlgorithmWrap(ParkingStruct, filtStruct, magDataCal(i,:),magSenTimestamp(i),1);
                    
                else
                    %                 disp('Hardware LS Mode Sim Pt!!!')
                end
                
                if ParkingStruct.Calibration_FLAG
                    break
                end
            end
        end
    end
    
else
    preCalLoop = 0;
    dataInfo.preCalLooppreCalLoop = preCalLoop;
end
