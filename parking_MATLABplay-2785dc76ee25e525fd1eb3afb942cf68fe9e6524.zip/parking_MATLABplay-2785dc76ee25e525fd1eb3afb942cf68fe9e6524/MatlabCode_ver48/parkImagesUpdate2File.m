function parkImageShow = parkImagesUpdate2File(figPlotS,plotInfo,dataInfoExtra,parkImageShow)

[time2ImagesMatch, camTimeImagesMatch, camIndsImagesMatch] = mapCamTimes2PlotTimes(dataInfoExtra.time2,dataInfoExtra.servTime,parkImageShow.dateTimeAyAy);

parkImageShow.time2ImagesMatch = time2ImagesMatch;
parkImageShow.camTimeImagesMatch = camTimeImagesMatch;
parkImageShow.camIndsImagesMatch = camIndsImagesMatch;

figFld = 'carStatesTruth';
figN = figPlotS.(figFld)(1);
figure(figN);

% first remove plot line if already there
if isfield(plotInfo,'hTimeTrackLine') && ~isempty(plotInfo.hTimeTrackLine)
    try
        delete(plotInfo.hTimeTrackLine)
    catch
    end
end
plotInfo.hTimeTrackLine = plot(plotInfo.haxS.carStatesTruth,time2ImagesMatch,-0.25*ones(length(time2ImagesMatch),1),'-','LineWidth',3,'MarkerSize',20,'Color',0.7*[1 1 1]); hold all

if parkImageShow.on
    figure(parkImageShow.figN); clf
    hax = axes('parent',parkImageShow.figN);
    parkImageShow.hax = hax;
    
    for ifig = 1:length(parkImageShow.cursFigs)
        dcm_obj4 = datacursormode(parkImageShow.cursFigs(ifig));
        set(dcm_obj4,'UpdateFcn',@dispMkrTimeImage2Fcn);
    end
    
    parkImage = parkImageShow.imageStructAy(1).imageAy(:,:,:,1);
    image(parkImageShow.hax,parkImage);
end
