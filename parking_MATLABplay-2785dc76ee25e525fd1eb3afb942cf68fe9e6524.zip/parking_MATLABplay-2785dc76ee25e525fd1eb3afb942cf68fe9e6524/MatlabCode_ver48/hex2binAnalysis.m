

% % packet id   car status   flags    temp      bat status   na  packet-cnt    time
%      15          03          10    0000D040    9A996940    00    6B         74A12877
     
format long g
hex2dec(lower('74A12877'))/32000
hex2dec(lower('5FBF1992'))/32000
hex2dec(lower('579B3192'))/32000
hex2dec(lower('72067395'))/32000
hex2dec(lower('DF4A8195'))/32000

t =[];
t(1,:) = swapbytes(uint32(hex2dec(lower('74A12877'))))/32000;
t(2,:) = swapbytes(uint32(hex2dec(lower('5FBF1992'))))/32000;
t(3,:) = swapbytes(uint32(hex2dec(lower('579B3192'))))/32000;
t(4,:) = swapbytes(uint32(hex2dec(lower('72067395'))))/32000;
t(5,:) = swapbytes(uint32(hex2dec(lower('DF4A8195'))))/32000;
t(6,:) = swapbytes(uint32(hex2dec(lower('656FB895'))))/32000;

t2 = t - t(1)
t3 = t2 - t2(2)

58-11
1755/60

dt = []
dt = [dt; datetime(datestr(datenum('08:49:52')))]


% 15 0318000084418b6c6740000c6a91e300

% 0011000111010
% 1110000000110
% 1111111111111
% bin2dec('1111111111111')

% %   1  2  3  4  5  6  7  8  9 10 11
% 39 18 eb 98 01 70 1b a5 01 80 00 d0    0d 31 91 e3 00
% %  1   8 16 32 40 48


diagMessageParseHex('392a41f94b8000a9f9800fff0c13170800')

% % dataMag = typecast(uint8(bin2dec('11111111')),'int8')
% dataMag = bitshift(typecast(bitshift(uint16(bin2dec('11111111111111')),2),'int16'),-2)


%%% FS 17 test
% 150318000084418b6c674000109b1b1f03
% 39f46fff511867d2ff80584811311b1f03
diagMessageParseHex('39f46fff511867d2ff80584811311b1f03')


%%% FS 16 test - new
% 15031800009041295c6740000eb8e82002
% 39efcf01c1152858efc048470f31e82002
diagMessageParseHex('39efcf01c1152858efc048470f31e82002')

%%% FS 17 test - new
% 15031800004841295c6740000d97e69900
% 39f40fff9d1a6869f44000070e31e69900
diagMessageParseHex('39f40fff9d1a6869f44000070e31e69900')

% 15011800004841295c6740001128964602
% 39f183fd1d16dc5ff180084c1231964602
diagMessageParseHex('39f183fd1d16dc5ff180084c1231964602')


% test 1358
% 1503380000ac41fca969400021bc32fd01
% 3980037ffdac91ff80000fff223132fd01
diagMessageParseHex('3980037ffdac91ff80000fff223132fd01')
