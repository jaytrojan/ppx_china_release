function [xmn, xstd] = Parking_MnStd(x,validFlags)

% Mean & Standard deviation calc for embedded variable sized arrays
% assumes stats across rows
nrows = size(x,1);
ncols = size(x,2);

nsum = uint8(0);
for ii=1:nrows
    nsum = nsum + validFlags(ii);
end

if nsum<2
    % empty or 1 row case
    xmn = zeros(1,ncols,'single');
    xstd = zeros(1,ncols,'single');
    return
end

% xmn = mean(x,1);
xmn = zeros(1,ncols,'single');
ncnt = single(0);
for ii=1:nrows
    if validFlags(ii)
        xmn = xmn + x(ii,:);
        ncnt = ncnt+1;
    end
end
if ncnt>0
    xmn = xmn./ncnt;
end


xstd = zeros(1,ncols,'single');
ncnt = single(0);
for ii=1:nrows
    if validFlags(ii)
        xdelta = x(ii,:)-xmn;
        xstd = xstd + xdelta.*xdelta;
        ncnt = ncnt+1;
    end
end
if ncnt>0
    xstd = xstd /(ncnt-single(1));
    xstd = sqrt(xstd);
end



