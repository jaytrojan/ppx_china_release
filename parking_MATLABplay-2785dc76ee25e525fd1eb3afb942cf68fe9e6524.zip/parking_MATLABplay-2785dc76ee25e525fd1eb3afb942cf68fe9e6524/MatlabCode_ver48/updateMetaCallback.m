function updateMetaCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global dataInfo cntrlInfo

% reset truth to truth_state_load state


if ~isempty(cntrlInfo.startTimeEdit.String)
    dataInfo.startTime = str2num(cntrlInfo.startTimeEdit.String);
else
    dataInfo.startTime = [];
end

if ~isempty(cntrlInfo.calTimesEdit.String)
    calTimesEdit = cntrlInfo.calTimesEdit.String;
    % calTimesEdit = '24.5, 13.2';

    [token1, remain] = strtok(calTimesEdit, ' ,');
    [token2] = strtok(remain, ' ,');

    dataInfo.calTime = [str2num(token1) str2num(token2)];
end

dataInfo.preCalLoop = cntrlInfo.preCalCheck.Value;


% % update slider
% currentTruth = truth_state_load(logical(cntrlInfo.BrushData),1);
% setVal = currentTruth(1);
% setVal = round(setVal);
% cntrlInfo.sld.Value = setVal;
% cntrlInfo.sldText.String = num2str(setVal);
% 


% % adjust all current brush data to slider value
% currentTruth = dataInfo.truth_state(logical(cntrlInfo.BrushData),1);
% 
% if ~isempty(currentTruth)
%     
%     % set slider to first value
%     setVal = cntrlInfo.sld.Value;
%     
%     setVal = round(setVal);
%     cntrlInfo.sld.Value = setVal;
%     cntrlInfo.sldText.String = num2str(setVal);
%     
%     % make all selected truth match slider
%     hTruthStateLine.YData(logical(cntrlInfo.BrushData)) = setVal;
%     dataInfo.truth_state(logical(cntrlInfo.BrushData),1) = setVal;
% 
% end

