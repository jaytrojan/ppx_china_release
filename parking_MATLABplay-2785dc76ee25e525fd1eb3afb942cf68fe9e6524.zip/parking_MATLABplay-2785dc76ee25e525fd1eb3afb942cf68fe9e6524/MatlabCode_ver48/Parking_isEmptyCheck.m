function ParkingStruct = Parking_isEmptyCheck(ParkingStruct,data)


% if a start parking event is detected, immediately exit
% parking_isemptycheck use mode and enable normal parking case
if ((abs(data(1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
    || (abs(data(2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
    || (abs(data(3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )

    ParkingStruct.exit_lsRecheck_FLAG = uint8(1);
    ParkingStruct.cPastLsMode = uint16(0);
    ParkingStruct.lsRecheckEnable = int8(0);
else
    ParkingStruct.exit_lsRecheck_FLAG = uint8(0);
end

if ParkingStruct.lsRecheckEnable >= 0 && ~ParkingStruct.exit_lsRecheck_FLAG
    % after y seconds into LS mode, rebuffer and check if the
    % system is still parked

    if ParkingStruct.lsRecheckEnable %if turned on
        ParkingStruct.K2                             = ParkingStruct.K2 + uint8(1);
        ParkingStruct.dataBuffer2(ParkingStruct.K2,:)= single(data);

        % if buffer is full, perform calcuations,
        % then shut off until next wakeup time
        if ParkingStruct.K2 == ParkingStruct.dataBufferSize

            % perform buffer calculations
            currentmean = mean(ParkingStruct.dataBuffer2);
            if (ParkingStruct.car_present == 3 && ParkingStruct.car_present2 == 3) && ~ParkingStruct.stateCorrection_type
    %             currentstd = std(ParkingStruct.dataBuffer2);
                relcheck = sum(abs(currentmean - ParkingStruct.LS_StartValue_state1)); % dif since last empty
                abscheck = sum(abs(currentmean - ParkingStruct.AVGInit2)); % dif since last cal
%                 samething = sum(abs(ParkingStruct.LS_StartValue - ParkingStruct.AVGInit2));
    %             disp([single(ParkingStruct.lsRecheckEnable) currentstd relcheck abscheck single(ParkingStruct.LS_StartValue_state1) samething])
    %             disp([relcheck abscheck single(ParkingStruct.LS_StartValue_state1) samething])
                if (relcheck < ParkingStruct.lsMagThr(1) && abscheck < ParkingStruct.lsMagThr(2)) || abscheck < ParkingStruct.lsMagThr(3) %&& relcheck ~= 0 && abscheck ~= 0
            %         ParkingStruct.LS_Trigger_FLAG        = uint8(1);
                    ParkingStruct.car_present            = uint8(1);
                    ParkingStruct.car_present2           = uint8(1);
                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                    ParkingStruct.car_presentCur         = uint8(1);
                    ParkingStruct.car_presentPre         = uint8(1);
                    ParkingStruct.car_presentCur2        = uint8(1);
                    ParkingStruct.car_presentPre2        = uint8(1);
                    ParkingStruct.caseTrackNumb          = uint8(12);
                    ParkingStruct.stateCorrection_FLAG   = uint8(1);
                    ParkingStruct.stateCorrection_type   = uint8(1);
                    ParkingStruct.lsRecheckEnable        = int8(0); % turn off after a decision is made
                end
            elseif (ParkingStruct.car_present == 1 && ParkingStruct.car_present2 == 1) && ~ParkingStruct.stateCorrection_type
                prev_occ_dif = sum(abs(currentmean - ParkingStruct.LS_StartValue_state3_initial));
                if prev_occ_dif < ParkingStruct.MAG_threshLevel7
                    ParkingStruct.car_present            = uint8(3);
                    ParkingStruct.car_present2           = uint8(3);
                    ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);
                    ParkingStruct.car_presentCur         = uint8(3);
                    ParkingStruct.car_presentPre         = uint8(3);
                    ParkingStruct.car_presentCur2        = uint8(3);
                    ParkingStruct.car_presentPre2        = uint8(3);
                    ParkingStruct.caseTrackNumb          = uint8(13);
                    ParkingStruct.stateCorrection_FLAG   = uint8(1);
                    ParkingStruct.stateCorrection_type   = uint8(1);
                    ParkingStruct.lsRecheckEnable        = int8(0); % turn off after a decision is made
                end
            end

            ParkingStruct.dataBuffer2	= zeros(8,3,'single');
            ParkingStruct.K2            = uint8(0);
            ParkingStruct.cPastLsMode	= uint16(0);

            % turn off the recheck after x attempts
            if ParkingStruct.lsRecheckEnable < ParkingStruct.lsRecheckNumber
                ParkingStruct.lsRecheckEnable = ParkingStruct.lsRecheckEnable + int8(1);
%                 ParkingStruct.LS_Trigger_FLAG  = uint8(0); % kickstart the algorithm?
            else
                ParkingStruct.lsRecheckEnable = int8(0); % temporary turn off
%                 ParkingStruct.LS_Trigger_FLAG = uint8(1);
            end
        end
    end
end
