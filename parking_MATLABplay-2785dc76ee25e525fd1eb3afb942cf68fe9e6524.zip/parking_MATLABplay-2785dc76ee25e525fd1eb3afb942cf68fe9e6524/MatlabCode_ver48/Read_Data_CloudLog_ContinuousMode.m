function [mraw,time,SentralOutput,raw_rate,RSSIdata,mDataRaw,sentralTimestamp] = Read_Data_CloudLog_ContinuousMode(FileName)

% [rawData,~] = xlsread(FileName);


delimiter = ',';
startRow = 2;   %10
formatSpec = '%s%s%u%u%u%s%u%f%f%f%s%d%f%[^\n\r]';
fileID = fopen([FileName],'r');
rawData1 = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);

%     size(rawData{1,10},1)
fclose(fileID);

rawData = zeros(size(rawData1{1,13},1),13);



for i =[3:5 7:10 12:13]
    temp = rawData1{1,i};
    rawData(:,i) = temp(1:size(rawData1{1,13},1)); 
end







% ****** load raw mag data
% midx=find(~isnan(rawData(:,8)) & ~isnan(rawData(:,9)) & ~isnan(rawData(:,10)));
mDataRaw= rawData((~isnan(rawData(:,8)) & ~isnan(rawData(:,9)) & ~isnan(rawData(:,10))),[7:10 12]);



%sort data by timestamp
[~, sortedIndexes] = sort(mDataRaw(:,1));
mDataRaw = mDataRaw(sortedIndexes,:); 


%%%% removal of repeated data
[~,ia,~] = unique(mDataRaw(:,1));
mDataRaw = mDataRaw(ia,:); 


mDataRaw=[mDataRaw zeros(size(mDataRaw,1),3)];
mDataRaw(:,8) = 10;

% % %%%%%% SENtral output
SentralOutputRaw1 = rawData((rawData(:,3)>0),[7 3 5]);
[~,ia,~] = unique(SentralOutputRaw1(:,1));
SentralOutputRaw=SentralOutputRaw1(ia,:);


empty_record = [];
for i = 1:length(ia)
    
    iind = find(mDataRaw(:,1)==SentralOutputRaw(i,1));
    
    if ~isempty(iind)
        mDataRaw(iind,6)=SentralOutputRaw(i,2);
        mDataRaw(iind,7)=SentralOutputRaw(i,3);
%         
% 
%         %%% car state
%         if mDataRaw(iind,6) == 0        
%            mDataRaw(iind,6) = 1;
%         elseif mDataRaw(iind,6) == 100        
%             mDataRaw(iind,6) = 3;        
%         elseif mDataRaw(iind,6) == 50        
%             mDataRaw(iind,6) = 2;  
%         elseif mDataRaw(iind,6) == -50        
%             mDataRaw(iind,6) = 4;  
%         end         
%         
        
        
        
    else
        empty_record = [empty_record;i];
    end
end



for i = 2: size(mDataRaw,1)
    
    if mDataRaw(i,6) == 0 && mDataRaw(i,7) == 0 && mDataRaw(i-1,6) ~= 0 && mDataRaw(i-1,7) ~= 0
        
        mDataRaw(i,6) = mDataRaw(i-1,6);
        mDataRaw(i,7) = mDataRaw(i-1,7); 
        mDataRaw(i,8) = 20;
    end
end







% timestamp in seconds
tRaw = mDataRaw(:,1);
time = (tRaw - tRaw(1,:))/32000;  % time in seconds 

sentralTimestamp = mDataRaw(:,1);

% mag data
mraw = mDataRaw(:,2:4);     
    
RSSIdata = mDataRaw(:,5);


SentralOutput = mDataRaw(:,6:7);








%compute the average rate of a single time axis. axis should be
%a column vector.

%compute delta-t vector
tDels = time(2:end)-time(1:end-1);
%compute frequency vector
tFqs = tDels.^(-1);
%compute mean rate in hz
% raw_rate = mean(tFqs);
% raw_rate = mean(tFqs(1:10));
raw_rate = tFqs(1);












% gateway1 = '008000000000c36f';
% gateway2 = '00800000a0000564';
% gateway3 = '008000000000c6a8';
% 
% 
% 
% 
% 
% for i = 1:length(rawData1{1,2})
%     
%     temp1 = rawData1{1,2}(i);
%     rawData(i,2) = str2double(temp1{1,1}([6:7 9:10 12:13 15:16 18:19]));
%     
%     
%     if strcmp(rawData1{1,11}(i),gateway1) 
%        rawData(i,11) =1;
%     elseif strcmp(rawData1{1,11}(i),gateway2) 
%        rawData(i,11) =2;
%     elseif strcmp(rawData1{1,11}(i),gateway3) 
%        rawData(i,11) =3;       
%     end          
% end
%     
% 
% 
% 
% 
% 
% 
% for i = 1:length(rawData1{1,2})
%         
%     
%     if rawData(i,7)>0 
%         index = find(rawData(:,7)==rawData(i,7));
%         
%         
%         for ind = 1:length(index)
%             
%             if isnan(rawData(index(ind),8))
%                index1 = find(rawData(index,11) == rawData(index(ind),11)  & rawData(index,2) == rawData(index(ind),2)  & ~isnan(rawData(index,8))); 
%                
%                if ~isempty(index1)
%                    
%                     rawData(index(ind),8:10) = rawData( index(index1(1)),8:10);
%                end
%             end
%         end
%                
% 
%     end
%           
%         
% end
% 
% 
% rawData = rawData(rawData(:,3)>0 & ~isnan(rawData(:,8)),:);
% 
% [sentralTime,ia,ic] = unique(rawData(:,7));
% 
% rawDataALL = zeros(length(sentralTime),12);
% 
% for i = 1:length(ic)
%     
%     if rawDataALL(ic(i),1)==0
%         
%         rawDataALL(ic(i),1:4)=rawData(i,7:10);
%         rawDataALL(ic(i),5:6)=rawData(i,3:4);
%     end
%     
%     if rawData(i,11)==1
%         rawDataALL(ic(i),7)=rawData(i,12);
%         rawDataALL(ic(i),10)=rawData(i,13);
%         
%     elseif rawData(i,11)==2
%         rawDataALL(ic(i),8)=rawData(i,12);
%         rawDataALL(ic(i),11)=rawData(i,13);
%         
%     elseif rawData(i,11)==3
%         rawDataALL(ic(i),9)=rawData(i,12);
%         rawDataALL(ic(i),12)=rawData(i,13);  
%         
%     end
%     
% end
% 
% 
% for i = 2:size(rawDataALL,1)
%     
%     if rawDataALL(i,7)==0
%         rawDataALL(i,7)=rawDataALL(i-1,7);
%     end
%     
%     if rawDataALL(i,8)==0
%         rawDataALL(i,8)=rawDataALL(i-1,8);
%     end    
%         
%     if rawDataALL(i,9)==0
%         rawDataALL(i,9)=rawDataALL(i-1,9);
%     end   
% end 
% 
% 
% 
% 
% figure;
% subplot(3,1,1);plot(rawDataALL(:,2:4));grid on;
% subplot(3,1,2);plot(rawDataALL(:,7:9));grid on;
% subplot(3,1,3);plot(rawDataALL(:,5));grid on;
%     
%  
% 
% 
%     
% mDataRaw = rawDataALL(:,1:4);  
%     
% % timestamp in seconds
% tRaw = mDataRaw(:,1);
% time = (tRaw - tRaw(1,:))/32000;  % time in seconds    
% 
% % mag data
% mraw = mDataRaw(:,2:4);     
%     
% RSSIdata = rawDataALL(:,7:9); 
% 
% SentralOutput = rawDataALL(:,5); 
% 
% 
% %compute the average rate of a single time axis. axis should be
% %a column vector.
% 
% %compute delta-t vector
% tDels = time(2:end)-time(1:end-1);
% %compute frequency vector
% tFqs = tDels.^(-1);
% %compute mean rate in hz
% % raw_rate = mean(tFqs);
% % raw_rate = mean(tFqs(1:10));
% raw_rate = tFqs(1);
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% % reverseIdx = size(rawData,1):-1:1;
% % rawData = rawData(reverseIdx,:);
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% 
% % 
% % 
% % 
% % reverseIdx = size(rawData,1):-1:1;
% % rawData = rawData(reverseIdx,:);
% % 
% % rawData = rawData(rawData(:,2)~=0,:);
% % 
% % %sort data by timestamp
% % [~, sortedIndexes] = sort(rawData(:,2));
% % rawData = rawData(sortedIndexes,:);  
% % 
% % 
% % % ****** load raw mag data
% % midx=find(~isnan(rawData(:,1)));
% % mDataRaw=rawData(midx,[2 9 10 11 7]); 
% % 
% % %sort data by timestamp
% % [~, sortedIndexes] = sort(mDataRaw(:,1));
% % mDataRaw = mDataRaw(sortedIndexes,:);      
% % 
% % % timestamp in seconds
% % tRaw = mDataRaw(:,1);
% % time = (tRaw - tRaw(1,:))/32000;  % time in seconds    
% % 
% % % mag data
% % mraw = mDataRaw(:,2:4);     
% %     
% % RSSIdata = mDataRaw(:,5);     
% % 
% % 
% % 
% % 
% % % ****** load output on from SENtral
% % % sidx=find(~isnan(rawData(:,5)));
% % % SentralOutputRaw=rawData(~isnan(rawData(:,5)),[5]);
% % 
% % 
% % sidx1=find(~isnan(rawData(:,5)));
% % SentralOutputRaw1=rawData(sidx1,[5 2]);    
% % [~,ia,~] = unique(SentralOutputRaw1(:,2));
% % 
% % sidx = sidx1(ia);
% % SentralOutputRaw=rawData(sidx,[5]);
% % 
% % 
% % SentralOutput = zeros(size(time));
% % 
% % endpoint = 1;
% % index = 1;
% % 
% % for i = 1:length(sidx)
% %     
% %     sentral_index = sidx(i);
% %     
% %     
% %     %%% car state
% %     if SentralOutputRaw(i) == 0        
% %        SentralOutputRaw(i) = 1;
% %     elseif SentralOutputRaw(i) == 100        
% %         SentralOutputRaw(i) = 3;        
% %     elseif SentralOutputRaw(i) == 50        
% %         SentralOutputRaw(i) = 2;  
% %     elseif SentralOutputRaw(i) == -50        
% %         SentralOutputRaw(i) = 4;  
% %     end    
% %     
% %     
% %     
% %     
% %     for j = endpoint:length(time)
% %         
% %         mag_index = midx(j);                  
% %         
% %         if sentral_index > mag_index
% %             
% %             SentralOutput(index) = SentralOutputRaw(i);    
% %             index = index + 1;
% %             
% %         else
% %             
% %            endpoint = j;
% %            break;
% %            
% %         end
% %         
% %     end
% %     
% %     
% % end
% % 
% % if (length(time) > (endpoint-1)) && (~isempty(SentralOutputRaw))    
% %    SentralOutput(endpoint:length(time)) = SentralOutputRaw(end); 
% % end
% % 
% % 
% % 
% % 
% % %compute the average rate of a single time axis. axis should be
% % %a column vector.
% % 
% % %compute delta-t vector
% % tDels = time(2:end)-time(1:end-1);
% % %compute frequency vector
% % tFqs = tDels.^(-1);
% % %compute mean rate in hz
% % % raw_rate = mean(tFqs);
% % % raw_rate = mean(tFqs(1:10));
% % raw_rate = tFqs(1);
% % 
% % 
% % 
% % 
