function carStatusCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global plotInfo dataInfo statusInfo

%%% >  callback for highlighting parking status fields

bkgndMode = 1; % turns on greying out background plot lines

indUpdate = src.Value-1;

carHiLightFcn(indUpdate,bkgndMode,plotInfo.statusPlotS);

% % % %%% restore prev lines to default
% % % indUpdate = plotInfo.statusIndex;
% % % if any(indUpdate)
% % %     for ii=1:length(indUpdate)
% % %         oldStyle = plotInfo.statusRefStyleAy(indUpdate(ii));
% % %         h = plotInfo.hStatusAy(indUpdate(ii));
% % %         h.LineStyle = oldStyle.LineStyle;
% % %         h.Color = oldStyle.Color;
% % %         h.LineWidth = oldStyle.LineWidth;
% % %     end
% % % end
% % % 
% % % 
% % % %%% update new lines
% % % indUpdate = src.Value-1;
% % % plotInfo.statusIndex = indUpdate;
% % % if any(indUpdate)
% % %     clrAy = [...
% % %         0 1 1;... % cyan
% % %         0 0 1;... % b
% % %         0 1 0;... % g
% % %         1 0 0;... % r
% % %         1 0 1;... % m
% % %         1 1 0 ... % y
% % %         ];
% % %     
% % %     nw = length(indUpdate);
% % %     wmin = 8; % min line width
% % %     wspace = 4;
% % %     wAy=wmin;
% % %     wmult = 1.0;
% % %     for ii=2:nw
% % %         wAy(ii) =  wAy(ii-1) + wmult*wspace;
% % %         wmult = wmult + 0.3*wmult;
% % %     end
% % %     wAy = round(wAy(nw:-1:1));
% % %     if length(wAy)<2, wAy = wmin+wspace; end
% % %     
% % %     
% % %     iclr = 0; iw = 0;
% % %     for ii=1:length(indUpdate)
% % %         iclr=iclr+1; iw = iw+1;
% % %         if iclr>length(clrAy), iclr=length(clrAy); end
% % %         h = plotInfo.hStatusAy(indUpdate(ii));
% % %         %             h.LineStyle = styleAy{iclr};
% % %         h.LineStyle = '-';
% % %         h.Color = clrAy(iclr,:);
% % %         h.LineWidth = wAy(iw);
% % %         uistack(h,'top');
% % %     end
% % % end



%     styleAy = {...
%              '-';... % cyan
%              '--';... % b
%              '-.';... % g
%              ':';... %
%              '-';... % r
%              '--'};   % m

