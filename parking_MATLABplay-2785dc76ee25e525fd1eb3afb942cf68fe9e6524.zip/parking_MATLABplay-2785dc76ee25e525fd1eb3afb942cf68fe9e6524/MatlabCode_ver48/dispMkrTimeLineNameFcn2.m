function output_txt = dispMkrTimeLineNameFcn2(obj,event_obj)
% Display the position of the data cursor
% obj          Currently not used (empty)
% event_obj    Handle to event object
% output_txt   Data cursor text string (string or cell array of strings).


global  dataInfoExtra;

% servTime = dataInfoExtra.servTime;


pos = get(event_obj,'Position');
index = get(event_obj,'DataIndex');
nameStr = event_obj.Target.DisplayName;
tserv = dataInfoExtra.servTime(index);


output_txt = {...
    nameStr,...
    ['X: ',num2str(pos(1))],...
    ['Y: ',num2str(pos(2))]...
    ['t: ',char(tserv)]...
    };


