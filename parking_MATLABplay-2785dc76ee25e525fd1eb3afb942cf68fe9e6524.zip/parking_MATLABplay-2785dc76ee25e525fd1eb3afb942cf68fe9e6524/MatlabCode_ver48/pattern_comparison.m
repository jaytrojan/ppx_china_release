function match_flag=pattern_comparison(p1,p2)

L=length(p1);

match_flag = uint8(1);

for i=1:L
    if p1(i) ~= p2(i)
        match_flag = uint8(0);
        break;
    end
end

