function [ParkingStruct, filtStruct] = Parking_struct_init_DriveThru(ParkingStruct, filtStruct)

%%% init of parking structure
%
%#codegen




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% car detection latency related knobs for drive thru case

ParkingStruct.HS_Trigger_thresh        = single(2.5);
ParkingStruct.LS_rate             = uint16(4);  % In Low Speed Mode, Sampling Rate = 1Hz

ParkingStruct.count_thresh               = uint16(2);    % reqiures 2 seconds to avoid spike peak in STD (false trigger the state changing)

ParkingStruct.State_count_thresh         = uint16(4);    % reqiures 3 seconds to confirm the correct state (no car OR car parked)
ParkingStruct.State_count_thresh_timeout = uint16(4);    % TIMEOUT: no state change in 3 secods - BACK TO LOW SPEED MODE

ParkingStruct.DriveThruFLAG              = uint8(1);     %%% 1 -- run algorithm for Drive Thru cases    0 -- run algorithm for normal car parking 

% ParkingStruct.STD_thresh          = single(5); 
% 
% ParkingStruct.MAG_threshUp                = single(13);    %%%% = single(10);    %%%  previously 15
% ParkingStruct.MAG_threshUp2               = single(9);     %%%% (loose threshold)
% 
% 
% ParkingStruct.STD_threshUp                = single(1.5);   % high threshold on STD
% ParkingStruct.STD_threshDown              = single(0.5);   % low threshold on STD
% 
% ParkingStruct.detection_threshUp          = single(1.5);   % high threshold on MA
% ParkingStruct.detection_threshDown        = single(0.5);   % low threshold on MA
% 
% 
% ParkingStruct.MAG_threshLevel1            = single(2.0);   % minus/plus range from initilized AVGInit or local baseline to check the correctness of the state
% ParkingStruct.MAG_threshLevel3            = single(3.0);   % minus/plus range from initilized AVGInit or local baseline to check the correctness of the state
% 
% ParkingStruct.MAG_thresh_ZaxisLevel2      = single(2.5);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state
% ParkingStruct.MAG_thresh_ZaxisLevel3      = single(1.5);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state
% ParkingStruct.MAG_thresh_ZaxisLevel4      = single(5.0);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state
% ParkingStruct.MAG_thresh_ZaxisLevel5      = single(7.5);   % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state
% 
% ParkingStruct.MAG_thresh_ZaxisLevel6      = single(10);    % mag changes on Z axis between current mag with previous local baseline(LS_StartValue_state1) to check the correctness of the state

ParkingStruct.rangeZ_threshold                  = single(4.5);     %%% threshold on the range of all data within window (max - min)
ParkingStruct.diff_baseline_Z_threshold         = single(2.7);   %%% threshold on the average of the difference between data within window and baseline (latest no car state)


% filtStruct.stableMethod:
% 0 = original STD based stability (not using stableFilt measurments)
% 1 = outlier removal STD from stableFilt measurement
% 2 = stableFilt stability measurement based on revised std deviation and slope measurement
filtStruct.stableMethod = int8(0);
ParkingStruct.SecondSensor_Req_FLAG_countMAX   = uint8(2);






