function hax3 = plotMagDataServerTime(servTime,tgapmeas,magData,magDataR,dtBigInds,figN,titleStr)

%%% >>> mag delta data vs time 2

% titleStr = 'Mag Data Vector Delta vs Server Time';
N = size(magData,1);

%     servTime
time3 = servTime;
tdays = day(servTime);
tdd = [0; tdays(2:end)-tdays(1:end-1)];
itdd = find(tdd);

figN = figN+1;
figure(figN); clf
hax3 = axes;
markInds = [dtBigInds; N];
istart=1; istopprev = 0;
for ii=1:length(markInds)
    istop = markInds(ii)-1;
    if istopprev
        plot(hax3,time3(istopprev:istart,:),magData(istopprev:istart,1),':b'); hold all
        plot(hax3,time3(istopprev:istart,:),magData(istopprev:istart,2),':g'); hold all
        plot(hax3,time3(istopprev:istart,:),magData(istopprev:istart,3),':r'); hold all
        plot(hax3,time3(istopprev:istart,:),magDataR(istopprev:istart,:),':k','LineWidth',1)
    end
    plot(hax3,time3(istart:istop,:),magData(istart:istop,1),'.-b','LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax3,time3(istart:istop,:),magData(istart:istop,2),'.-g','LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax3,time3(istart:istop,:),magData(istart:istop,3),'.-r','LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax3,time3(istart:istop,:),magDataR(istart:istop,:),'.-k','LineWidth',3,'MarkerSize',20)
    
    istart = markInds(ii);
    istopprev = istop;
end

%%% add day change markers
yLim = ylim;
ymk3 = 0.9*yLim(2);
iii=1;
tplot = time3(iii);
sTime = datestr(servTime(iii),'yy-mm-dd HH:MM');
text(tplot,ymk3,['[' sTime ']'],'HorizontalAlignment','left')
for ii=1:length(itdd)
    % server time
    iii = itdd(ii);
    tplot = time3(iii);
    sTime = datestr(servTime(iii),'yy-mm-dd HH:MM');
    text(hax3,tserv,ymk3,['[' sTime ']'],'HorizontalAlignment','center')
    
    % plot vertical line at start of each section
    tline = time3(iii);
    plot(hax3,[tline tline],[yLim(1) yLim(2)],':k','LineWidth',1);
end

% add missing time notes
yLim = ylim;
ymk1 = 0.85*yLim(1);
ymk2 = 0.85*yLim(2);
for ii=1:length(dtBigInds)
    istart = dtBigInds(ii)-1;
    istop = dtBigInds(ii);
    tcent = mean(time3(istart:istop));
    tstr = num2str(round(tgapmeas(ii)/60));
    text(hax3,tcent,ymk1,['~' tstr ' min~'],'HorizontalAlignment','center')
    
    % server time
    tserv = mean([tcent time3(istop)]);
    sTime = datestr(servTime(istart),'yy-mm-dd HH:MM');
    text(hax3,tserv,ymk2,['[' sTime ']'],'HorizontalAlignment','center')
    
    % plot vertical line at start of each section
    tline = time3(istop);
    plot(hax3,[tline tline],[yLim(1) yLim(2)],':k','LineWidth',1);
end
title(hax3,titleStr,'FontSize',16,'FontWeight','bold'); grid on;
xlabel(hax3,'datetime','FontSize',14,'FontWeight','bold');
ylabel(hax3,'uT','FontSize',14,'FontWeight','bold');
legend(hax3,'X','Y','Z','vectR')

xtickformat(hax3,'auto')
%%% >>> mag delta data vs time 2