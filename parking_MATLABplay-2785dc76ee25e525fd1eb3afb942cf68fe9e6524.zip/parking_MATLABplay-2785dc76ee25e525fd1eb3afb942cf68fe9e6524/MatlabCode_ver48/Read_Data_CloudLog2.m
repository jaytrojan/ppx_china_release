function [mraw,time,SentralOutput,raw_rate,RSSIdata,mDataRaw,cloud_feature] = Read_Data_CloudLog2(FileName)


PreDataBuffer             = zeros(8,3,'single'); 
PreDataBufferSize         = uint8(8);

LabelBuffer               = zeros(8,1,'uint8'); 




[rawData,~] = xlsread(FileName);

reverseIdx = size(rawData,1):-1:1;
rawData = rawData(reverseIdx,:);


% ****** load raw mag data
midx= ~isnan(rawData(:,1));
mDataRaw=rawData(midx,[2 9 10 11 1]); 



%sort data by timestamp
[~, sortedIndexes] = sort(mDataRaw(:,1));
mDataRaw = mDataRaw(sortedIndexes,:); 


% mag data
mraw = mDataRaw(:,2:4); 

% timestamp in seconds 
mDataRaw(:,1) = (mDataRaw(:,1) - mDataRaw(1,1))/32000;         % time in seconds   





mDataRaw1 = mDataRaw;

mDataRaw1(1,2:5) = mDataRaw1(3,2:5);
mDataRaw1(2,2:5) = mDataRaw1(3,2:5);

for i = 4:size(mDataRaw1,1)

    if abs(mDataRaw1(i,2)-mDataRaw1(i-1,2) )>0.5 && abs(mDataRaw1(i,2)-mDataRaw1(i-1,2) )<1.5        
         
         mDataRaw1(i,2:5) = mDataRaw1(i-1,2:5);
         
    end
    
end
    



for i = 1:size(mDataRaw,1)
    
    PreDataBuffer      = shifting_array(PreDataBuffer);
    PreDataBuffer(PreDataBufferSize,:)  = mDataRaw(i,2:4);
    
    LabelBuffer        = shifting_array(LabelBuffer);
    LabelBuffer(PreDataBufferSize,:)  = uint8(0);   
    
%     if i == 37
%         1;
%     end
    
    
    if i >= 8 && abs(mDataRaw(i,2)-PreDataBuffer(PreDataBufferSize-1,1) )>0.5 && abs(mDataRaw(i,2)-PreDataBuffer(PreDataBufferSize-1,1) )<1.5
        
         LabelBuffer(PreDataBufferSize,:)  = uint8(1);
         
         mDataRaw1(i,2:4) = PreDataBuffer(PreDataBufferSize-1,:);
         
    end
    
    if LabelBuffer(PreDataBufferSize,:)  == uint8(0) && ~isempty(find(LabelBuffer == uint8(1), 1) ) && length(find(LabelBuffer == uint8(1), 2)) ==2
        
        1;
        
        ind = find(LabelBuffer == uint8(1), 2);
        PreDataBuffer(ind(1):(ind(2)-1),:)  =PreDataBuffer(ind(1)-1,:) ;
        
        
        
    end
    
end


1;