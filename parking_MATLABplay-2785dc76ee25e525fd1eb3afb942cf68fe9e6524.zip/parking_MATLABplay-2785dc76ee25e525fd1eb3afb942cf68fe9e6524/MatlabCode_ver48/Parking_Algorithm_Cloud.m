function [Buffer1, Buffer2,ResultBuffer]= Parking_Algorithm_Cloud(EventData, Buffer1, Buffer2,ResultBuffer)   %%% ParkingLotConfig 


%%%%%%%%%
% *** Buffer1 ***  -- store all previous results for drive thru sensor

%          || Drive Thru Time at Entrance   |  Parking FLAG |  Space #  |  Counter 2  | Waiting Time at Entrance |
%  --------------------------------------------------------------------------------------------------------------------
%  car #1  ||                               |               |           |             |                          |  
%  car #2  ||                               |               |           |             |                          | 



% *** Buffer2 ***  -- store all previous results for pakring sensors

%             || Car Entering Time  |  Counter 2 |  Occupied FLAG  |  Total Waiting Time  |
%  -----------------------------------------------------------------------------------------------
%  Sensor #1  ||                    |            |                 |                      | 
%  Sensor #2  ||                    |            |                 |                      | 



% *** ResultBuffer ****  -- other useful values will be used internal

%     ResultBuffer = [counter1 ...
%                     counter2 ...
%                     Buffer1_size ...
%                     Buffer2_size ...
%                     Accumulated_CarCounter];



% *** ParkingLotConfig *** -- parking lot configuration

%            ||  Line1        |  Line2       |  Line3       |
%  --------------------------------------------------------------------------
%  Position1 ||  sensor ID1   |  sensor ID2  |  sensor ID3  |     -- First row after pass drive thru sensor
%  Position2 ||  sensor ID4   |  sensor ID5  |  sensor ID6  |     
%  Position3 ||  sensor ID7   |  sensor ID8  |  sensor ID9  |








%%%%% new event coming from drive thru sensor
if EventData.DriveThruFLAG 
    
    StartRowInd = find(Buffer1(:,4)== 0,1); 

    
    %%%% multiple cars past over the sensor without interval
    if EventData.NumCars_DriveThru - EventData.NumCars_DriveThruPre > 1
        
        Buffer1(StartRowInd:StartRowInd+(EventData.NumCars_DriveThru-EventData.NumCars_DriveThruPre-1),1) = EventData.GatewayTime;
        Buffer1(StartRowInd:StartRowInd+(EventData.NumCars_DriveThru-EventData.NumCars_DriveThruPre-1),2) = 0;
        Buffer1(StartRowInd:StartRowInd+(EventData.NumCars_DriveThru-EventData.NumCars_DriveThruPre-1),3) = 0;
        Buffer1(StartRowInd:StartRowInd+(EventData.NumCars_DriveThru-EventData.NumCars_DriveThruPre-1),4) = (ResultBuffer(1)+1) : (ResultBuffer(1) + EventData.NumCars_DriveThru - EventData.NumCars_DriveThruPre);
        Buffer1(StartRowInd:StartRowInd+(EventData.NumCars_DriveThru-EventData.NumCars_DriveThruPre-1),5) = 0;        
   
    else
        
        Buffer1(StartRowInd,1) = EventData.GatewayTime;
        Buffer1(StartRowInd,2) = 0;
        Buffer1(StartRowInd,3) = 0;
        Buffer1(StartRowInd,4) = ResultBuffer(1)+1;
        Buffer1(StartRowInd,5) = 0;
        
    end
    
    
    ResultBuffer(1) = ResultBuffer(1) + EventData.NumCars_DriveThru - EventData.NumCars_DriveThruPre;
    
%%%%% new event coming from parking sensor    
elseif ~EventData.DriveThruFLAG
    
    
    %%% car parks at space
    if EventData.Status == 3
    
        Buffer2(EventData.SensorID,1) = EventData.GatewayTime;
        Buffer2(EventData.SensorID,2) = ResultBuffer(2)+1;
        Buffer2(EventData.SensorID,3) = 1; 
        Buffer2(EventData.SensorID,4) = 0; 
        
        
        RowInd = find(Buffer1(:,2)== 0,1); 
        
        if ~isempty(RowInd)
        
            Buffer1(RowInd,2) = 1;
            Buffer1(RowInd,3) = EventData.SensorID;

            if EventData.GatewayTime > Buffer1(RowInd,1)
                Buffer1(RowInd,5) = EventData.GatewayTime - Buffer1(RowInd,1); 
            else
                Buffer1(RowInd,5) = EventData.GatewayTime + 60 - Buffer1(RowInd,1); 
            end

            
            if Buffer1(RowInd,5) > 30

                %%%%% false detection on car drive through, remove 1 from the drive through counter (Accumulated_CarCounter) 
                if Buffer1(RowInd+1,4) > 0 ...
                    && (  ((EventData.GatewayTime - Buffer1(RowInd+1,1))< 30 && (EventData.GatewayTime - Buffer1(RowInd+1,1))>0) ...
                           || ((EventData.GatewayTime + 60 - Buffer1(RowInd+1,1))< 30 && (EventData.GatewayTime - Buffer1(RowInd+1,1))<0)   )
                     

                    Buffer1(RowInd:ResultBuffer(3)-1,:) = Buffer1(RowInd+1:ResultBuffer(3),:);
                    Buffer1(ResultBuffer(3),:) = zeros(1,5); 
                    
                    Buffer1(RowInd,2) = 1;
                    Buffer1(RowInd,3) = EventData.SensorID;                    
                    Buffer1(RowInd,4) = ResultBuffer(1)-1; 
                    
                    if EventData.GatewayTime > Buffer1(RowInd,1)
                        Buffer1(RowInd,5) = EventData.GatewayTime - Buffer1(RowInd,1); 
                    else
                        Buffer1(RowInd,5) = EventData.GatewayTime + 60 - Buffer1(RowInd,1); 
                    end   
                    
                    
                    ResultBuffer(1) = ResultBuffer(1)-1;
                    ResultBuffer(5) = ResultBuffer(5)-1;
                    
                    
                else
                    
                    Buffer1(RowInd,5) = 0;
                    
                end

                
            end


            Buffer2(EventData.SensorID,4) = Buffer1(RowInd,5); 
            
            
        
        else
        %%%%% miss detection on car drive through, add 1 to the drive through counter (Accumulated_CarCounter) 
            
            ResultBuffer(5) = ResultBuffer(5)+1;
            
            StartRowInd = find(Buffer1(:,4)== 0,1); 
            
            Buffer1(StartRowInd,1) = EventData.GatewayTime;
            Buffer1(StartRowInd,2) = 1;
            Buffer1(StartRowInd,3) = EventData.SensorID;
            Buffer1(StartRowInd,4) = ResultBuffer(1)+1;
            Buffer1(StartRowInd,5) = 0;            
            
            ResultBuffer(1) = ResultBuffer(1)+1;
            
            
        end
            
          
        
        ResultBuffer(2) = ResultBuffer(2)+1;
   
        
    %%% car leaves the space, clear the info in Buffer2  
    elseif EventData.Status == 1
        
        Buffer2(EventData.SensorID,1) = 0;
        Buffer2(EventData.SensorID,2) = 0;
        Buffer2(EventData.SensorID,3) = 0; 
        Buffer2(EventData.SensorID,4) = 0;
        
        
        RowInd = Buffer1(:,3)== EventData.SensorID; 
        
        Buffer1(RowInd:ResultBuffer(3)-1,:) = Buffer1(RowInd+1:ResultBuffer(3),:);
        Buffer1(ResultBuffer(3),:) = zeros(1,5);
        
        
        
        
        
    end
    
end



%%%%%% reset buffer and counter

%%%% Case 1: When all sensors at pick up location are shown as vacant, then reset Buffer1, Buffer 2, counter1, and counter2
if all(Buffer2(:,3) == 0) && EventData.DriveThruFLAG == 0 
    
    
    %%% adjust drive thru car counter based on the difference between counter1 and counter2
    ResultBuffer(5) = ResultBuffer(5)-(ResultBuffer(1) - ResultBuffer(2));  
    
    % reset Buffer 1, Buffer 2, counter 1, and counter 2
    Buffer1 = zeros(ResultBuffer(3),5);
    Buffer2 = zeros(ResultBuffer(4),4);     
    ResultBuffer(1) = 0;
    ResultBuffer(2) = 0;

end




% %%%% case 1: When counter 1 == counter 2, 
% %%%%          && latest K parking_FLAG are all ONE (K = the total number of occupied spaces at pick up location) 
% %%%%          then reset Buffer 1, counter 1, and counter 2
% 
% if ResultBuffer(1) == ResultBuffer(2) && sum(Buffer1(:,2)) == sum(Buffer2(:,3))
%     
%     Buffer1 = zeros(20,5);
%     Buffer2 = zeros(20,4);
%     ResultBuffer = [0 0];
    
    
    

        
        
    