
haxBaseAyList = [];
% 
% figNstart = 980;
% baseFiltAyPlot = baseFilt0Ay;
% 
figNstart = 990;
baseFiltAyPlot = baseFilt1Ay;


haxBaseAy = [];

% plot baseline measurements
figN = figNstart;
figure(figN); clf
hax = axes;
lineStyles = {':','-.','--','-','.:','.-.','.--','.-'};
istyle = 0;
hlines = [];
Nvals = length(baseFiltAyPlot);
legAy = [];
baseMeasFlds = fieldnames(baseFiltAyPlot);

% baseFiltFieldsPlot = {...
%     'data'...
%     'dfilt'...
%     'dfiltw'...
%     'dfiltw'...
%     };
baseFiltFieldsPlot = {...
    'dfiltS' 'data';...
    'dfiltS' 'dataFilt';...
    'dfiltwS' 'dataFilt';...
    'dfiltwS' 'dataFilt';...
    };
fieldsRPlot = [...
    0 ...
    0 ...
    0 ...
    1 ...
    ];

    
for ifld = 1:length(baseFiltFieldsPlot)
    %                 fldSize = size(baseFiltAyPlot(1).(parkMeasFlds{ifld}));
    data = [baseFiltAyPlot.(baseFiltFieldsPlot{ifld,1})]';
    if ~isempty(baseFiltFieldsPlot{ifld,2})
        data = [data.(baseFiltFieldsPlot{ifld,2})]';
    end
    data = reshape(data,[],Nvals)';
    
    if fieldsRPlot(ifld)
        data = sqrt(sum(data.^2,2));
    end
    
    fldSize = size(data);
    % style only if nonzero data
    if any(sum(data))
        istyle=istyle+1;
        if istyle>length(lineStyles), istyle = 1; end
        lstyle = lineStyles{istyle};
        lwidth = 2;
    else
        lstyle = ':k';
        lwidth = 1;
    end
    
    hlines = [hlines; plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)];
    %                 hlines = [hlines; {plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)}];
    
    legLine = [];
    if fldSize(2)<2
        legLine = [legLine {[baseFiltFieldsPlot{ifld,1} '.' baseFiltFieldsPlot{ifld,2}]}];
    else
        for iax=1:fldSize(2)
            legLine = [legLine {[[baseFiltFieldsPlot{ifld,1} '.' baseFiltFieldsPlot{ifld,2}] '-' num2str(iax)]}];
        end
    end
    legAy = [legAy legLine];
    hold all
end
hMeasAy = hlines;
% haxS.(figFld) = hax;
title(hax,['Baseline Meas Move Ave:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
ylabel(hax,'meas','FontSize',12,'FontWeight','bold');
grid on
legend(legAy);
% ylim([-60 60]);
ylim('auto')
haxBaseAy = [haxBaseAy hax];



% plot baseline measurements
figN = figNstart+1;
figure(figN); clf
hax = axes;
lineStyles = {':','-.','--','-','.:','.-.','.--','.-'};
istyle = 0;
hlines = [];
Nvals = length(baseFiltAyPlot);
legAy = [];
baseMeasFlds = fieldnames(baseFiltAyPlot);

% baseFiltFieldsPlot = {...
%     'dslope'...
%     'dslopew'...
%     'dslopefilt'...
%     'dslopewfilt'...
%     };
baseFiltFieldsPlot = {...
    'dslopefiltwS' 'data';...
    'dslopefiltwS' 'dataFilt';...
    };
%     'dslopefiltS' 'data';...
%     'dslopefiltS' 'dataFilt';...
%     'dfiltslopefiltS' 'data';...
%     'dfiltslopefiltS' 'dataFilt';...
fieldsRPlot = [...
    1 ...
    1 ...
    1 ...
    1 ...
    1 ...
    1 ...
    ];




for ifld = 1:length(baseFiltFieldsPlot)
    %                 fldSize = size(baseFiltAyPlot(1).(parkMeasFlds{ifld}));
    data = [baseFiltAyPlot.(baseFiltFieldsPlot{ifld,1})]';
    if ~isempty(baseFiltFieldsPlot{ifld,2})
        data = [data.(baseFiltFieldsPlot{ifld,2})]';
    end
    data = reshape(data,[],Nvals)';
    
    if fieldsRPlot(ifld)
        data = sqrt(sum(data.^2,2));
    end
    
    fldSize = size(data);
    % style only if nonzero data
    if any(sum(data))
        istyle=istyle+1;
        if istyle>length(lineStyles), istyle = 1; end
        lstyle = lineStyles{istyle};
        lwidth = 2;
    else
        lstyle = ':k';
        lwidth = 1;
    end
    
    hlines = [hlines; plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)];
    %                 hlines = [hlines; {plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)}];
    
    legLine = [];
    if fldSize(2)<2
        legLine = [legLine {[baseFiltFieldsPlot{ifld,1} '.' baseFiltFieldsPlot{ifld,2}]}];
    else
        for iax=1:fldSize(2)
            legLine = [legLine {[[baseFiltFieldsPlot{ifld,1} '.' baseFiltFieldsPlot{ifld,2}] '-' num2str(iax)]}];
        end
    end
    legAy = [legAy legLine];
    hold all
end
hMeasAy = hlines;
% haxS.(figFld) = hax;
title(hax,['Baseline Slope:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
ylabel(hax,'meas','FontSize',12,'FontWeight','bold');
grid on
legend(legAy);
% ylim([-60 60]);
ylim('auto')
haxBaseAy = [haxBaseAy hax];



% plot baseline measurements
figN = figNstart+2;
figure(figN); clf
hax = axes;
lineStyles = {':','-.','--','-','.:','.-.','.--','.-'};
istyle = 0;
hlines = [];
Nvals = length(baseFiltAyPlot);
legAy = [];
baseMeasFlds = fieldnames(baseFiltAyPlot);

% baseFiltFieldsPlot = {...
%     'cntref'...
%     'dvarfilt'...
%     'dvarfiltw'...
%     };
baseFiltFieldsPlot = {...
    'dfiltS' 'dataVar';...
    'dfiltS' 'dataVarFilt';...
    'dfiltwS' 'dataVar';...
    'dfiltwS' 'dataVarFilt';...
    };
fieldsRPlot = [...
    1 ...
    1 ...
    1 ...
    1 ...
    ];

%     'dvarfiltref'...
    
for ifld = 1:length(baseFiltFieldsPlot)
    %                 fldSize = size(baseFiltAyPlot(1).(parkMeasFlds{ifld}));
    data = [baseFiltAyPlot.(baseFiltFieldsPlot{ifld,1})]';
    if ~isempty(baseFiltFieldsPlot{ifld,2})
        data = [data.(baseFiltFieldsPlot{ifld,2})]';
    end
    data = reshape(data,[],Nvals)';
    
    if fieldsRPlot(ifld)
        data = sqrt(sum(data.^2,2));
    end
    
    fldSize = size(data);
    % style only if nonzero data
    if any(sum(data))
        istyle=istyle+1;
        if istyle>length(lineStyles), istyle = 1; end
        lstyle = lineStyles{istyle};
        lwidth = 2;
    else
        lstyle = ':k';
        lwidth = 1;
    end
    
    hlines = [hlines; plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)];
    %                 hlines = [hlines; {plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)}];
    
    legLine = [];
    if fldSize(2)<2
        legLine = [legLine {[baseFiltFieldsPlot{ifld,1} '.' baseFiltFieldsPlot{ifld,2}]}];
    else
        for iax=1:fldSize(2)
            legLine = [legLine {[[baseFiltFieldsPlot{ifld,1} '.' baseFiltFieldsPlot{ifld,2}] '-' num2str(iax)]}];
        end
    end
    legAy = [legAy legLine];
    hold all
end
hMeasAy = hlines;
% haxS.(figFld) = hax;
title(hax,['Baseline Meas Variance:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
ylabel(hax,'meas','FontSize',12,'FontWeight','bold');
grid on
legend(legAy);
% ylim([-60 60]);
ylim('auto')
haxBaseAy = [haxBaseAy hax];


% plot baseline measurements
figN = figNstart+3;
figure(figN); clf
hax = axes;
lineStyles = {':','-.','--','-','.:','.-.','.--','.-'};
istyle = 0;
hlines = [];
Nvals = length(baseFiltAyPlot);
legAy = [];
baseMeasFlds = fieldnames(baseFiltAyPlot);

% baseFiltFieldsPlot = {...
%     'dslopevarfilt'...
%     'dslopewvarfilt'...
%     };
baseFiltFieldsPlot = {...
    'dslopefiltwS' 'dataVar';...
    'dslopefiltwS' 'dataVarFilt';...
    };
%     'dslopefiltS' 'dataVar';...
%     'dslopefiltS' 'dataVarFilt';...
%     'dfiltslopefiltS' 'dataVar';...
%     'dfiltslopefiltS' 'dataVarFilt';...
fieldsRPlot = [...
    1 ...
    1 ...
    1 ...
    1 ...
    1 ...
    1 ...
    ];

for ifld = 1:length(baseFiltFieldsPlot)
    %                 fldSize = size(baseFiltAyPlot(1).(parkMeasFlds{ifld}));
    data = [baseFiltAyPlot.(baseFiltFieldsPlot{ifld,1})]';
    if ~isempty(baseFiltFieldsPlot{ifld,2})
        data = [data.(baseFiltFieldsPlot{ifld,2})]';
    end
    data = reshape(data,[],Nvals)';
    
    if fieldsRPlot(ifld)
        data = sqrt(sum(data.^2,2));
    end
    
    fldSize = size(data);
    % style only if nonzero data
    if any(sum(data))
        istyle=istyle+1;
        if istyle>length(lineStyles), istyle = 1; end
        lstyle = lineStyles{istyle};
        lwidth = 2;
    else
        lstyle = ':k';
        lwidth = 1;
    end
    
    hlines = [hlines; plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)];
    %                 hlines = [hlines; {plot(time2,data,lstyle,'LineWidth',lwidth,'MarkerSize',14)}];
    
    legLine = [];
    if fldSize(2)<2
        legLine = [legLine {[baseFiltFieldsPlot{ifld,1} '.' baseFiltFieldsPlot{ifld,2}]}];
    else
        for iax=1:fldSize(2)
            legLine = [legLine {[[baseFiltFieldsPlot{ifld,1} '.' baseFiltFieldsPlot{ifld,2}] '-' num2str(iax)]}];
        end
    end
    legAy = [legAy legLine];
    hold all
end
hMeasAy = hlines;
% haxS.(figFld) = hax;
title(hax,['Baseline Slope Variance:  ' fNameTitle],'FontSize',16,'FontWeight','bold'); grid on;
xlabel(hax,'t(sec)','FontSize',12,'FontWeight','bold');
ylabel(hax,'meas','FontSize',12,'FontWeight','bold');
grid on
legend(legAy);
% ylim([-60 60]);
ylim('auto')
haxBaseAy = [haxBaseAy hax];



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% pull data for threshhold testing

% >>>
baseFiltFieldsThresh = {...
    'dfiltwS' 'dataFilt';...
    };
ifld = 1;
data = [baseFiltAyPlot.(baseFiltFieldsThresh{ifld,1})]';
if ~isempty(baseFiltFieldsThresh{ifld,2})
    data = [data.(baseFiltFieldsThresh{ifld,2})]';
end
data = reshape(data,[],Nvals)';
% data = sqrt(sum(data.^2,2));
dfiltwS_dataFilt = data;

% >>>
baseFiltFieldsThresh = {...
    'dslopefiltwS' 'dataFilt';...
    };
ifld = 1;
data = [baseFiltAyPlot.(baseFiltFieldsThresh{ifld,1})]';
if ~isempty(baseFiltFieldsThresh{ifld,2})
    data = [data.(baseFiltFieldsThresh{ifld,2})]';
end
data = reshape(data,[],Nvals)';
data = sqrt(sum(data.^2,2));
dslopefiltwS_dataFilt = data;

% >>>
baseFiltFieldsThresh = {...
    'dfiltwS' 'dataVar';...
    };
ifld = 1;
data = [baseFiltAyPlot.(baseFiltFieldsThresh{ifld,1})]';
if ~isempty(baseFiltFieldsThresh{ifld,2})
    data = [data.(baseFiltFieldsThresh{ifld,2})]';
end
data = reshape(data,[],Nvals)';
data = sqrt(sum(data.^2,2));
dfiltwS_dataVar = data;

% >>>
baseFiltFieldsThresh = {...
    'dfiltwS' 'dataVarFilt';...
    };
ifld = 1;
data = [baseFiltAyPlot.(baseFiltFieldsThresh{ifld,1})]';
if ~isempty(baseFiltFieldsThresh{ifld,2})
    data = [data.(baseFiltFieldsThresh{ifld,2})]';
end
data = reshape(data,[],Nvals)';
data = sqrt(sum(data.^2,2));
dfiltwS_dataVarFilt = data;

% >>>
baseFiltFieldsThresh = {...
    'dslopefiltwS' 'dataVarFilt';...
    };
ifld = 1;
data = [baseFiltAyPlot.(baseFiltFieldsThresh{ifld,1})]';
if ~isempty(baseFiltFieldsThresh{ifld,2})
    data = [data.(baseFiltFieldsThresh{ifld,2})]';
end
data = reshape(data,[],Nvals)';
data = sqrt(sum(data.^2,2));
dslopefiltwS_dataVarFilt = data;


% >>>
baseFiltFieldsThresh = {...
    'stableCnt' '';...
    };
ifld = 1;
data = [baseFiltAyPlot.(baseFiltFieldsThresh{ifld,1})]';
if ~isempty(baseFiltFieldsThresh{ifld,2})
    data = [data.(baseFiltFieldsThresh{ifld,2})]';
end
data = reshape(data,[],Nvals)';
% data = sqrt(sum(data.^2,2));
stableCnt = data;

% >>>
baseFiltFieldsThresh = {...
    'baseLineMeas' '';...
    };
ifld = 1;
data = [baseFiltAyPlot.(baseFiltFieldsThresh{ifld,1})]';
if ~isempty(baseFiltFieldsThresh{ifld,2})
    data = [data.(baseFiltFieldsThresh{ifld,2})]';
end
data = reshape(data,[],Nvals)';
% data = sqrt(sum(data.^2,2));
baseLineMeas = data;


stableIndsRecurse = stableCnt >= 8;

dslopefiltwS_dataFilt_thr = 0.04;
dslopefiltwS_dataVarFilt_thr = 0.01;
dfiltwS_dataVar_thr = 2.5;
dfiltwS_dataVarFilt_thr = 0.5;

% unstableInds = dfiltwS_dataVar > dfiltwS_dataVar_thr;
stableInds =      dfiltwS_dataVar <= dfiltwS_dataVar_thr ...
       &    dslopefiltwS_dataFilt <= dslopefiltwS_dataFilt_thr ...
       &      dfiltwS_dataVarFilt <= dfiltwS_dataVarFilt_thr ...
       & dslopefiltwS_dataVarFilt <= dslopefiltwS_dataVarFilt_thr;
   
sum(abs(stableIndsRecurse - stableIndsRecurse))

figure(990);
h = plot(time2(:,:),baseLineMeas(:,:),'ok','LineWidth',1.5,'MarkerSize',6);
uistack(h,'bottom');
h = plot(time2(stableIndsRecurse,:),dfiltwS_dataFilt(stableIndsRecurse,:),'oc','LineWidth',2,'MarkerSize',10);
uistack(h,'bottom');
h = plot(time2(stableInds,:),dfiltwS_dataFilt(stableInds,:),'og','LineWidth',2,'MarkerSize',18);
uistack(h,'bottom');

figure(991);
h = plot(time2(stableIndsRecurse,:),0*time2(stableIndsRecurse,:),'oc','LineWidth',2,'MarkerSize',10);
uistack(h,'bottom');
h = plot(time2(stableInds,:),0*time2(stableInds,:),'og','LineWidth',2,'MarkerSize',18);
uistack(h,'bottom');

figure(992);
h = plot(time2(stableIndsRecurse,:),0*time2(stableIndsRecurse,:),'oc','LineWidth',2,'MarkerSize',10);
uistack(h,'bottom');
h = plot(time2(stableInds,:),0*time2(stableInds,:),'og','LineWidth',2,'MarkerSize',18);
uistack(h,'bottom');

figure(993);
h = plot(time2(stableIndsRecurse,:),0*time2(stableIndsRecurse,:),'oc','LineWidth',2,'MarkerSize',10);
uistack(h,'bottom');
h = plot(time2(stableInds,:),0*time2(stableInds,:),'og','LineWidth',2,'MarkerSize',18);
uistack(h,'bottom');


haxBaseAyList0 = haxBaseAy(isvalid(haxBaseAy));
haxBaseAyList = [haxBaseAyList haxBaseAyList0];
linkprop(haxBaseAyList,'xlim');


