%%% Algorithm using SSA and SSR with real-time functionality
% No motion data


disp('Viewing Parking Data Logs...')

% close all;
% clear all; %clc;
clearvars -except parkImageShow
dbstop if error

parkImagesFlagInit = 0; % initialize loading parking lot images - doesn't matter if already loaded
fillDataFront = 0;
plotDataFlag = 1; % for multiple files a question dialog will pop-up

% additive noise
% periodic noise (sine and square waves)
% set freq to 0 to turn off
magSineNoise = [60 0.5 0.5 0.5]*0; % [freqHz Xut Yut Zut]
magSquareNoise = [0.5 1 1 1 20]*0; % [freqHz Xut Yut Zut dutyCyclePosPcnt]
% gaussian noise
magGaussNoise = 0.0; % uT

% stability filter testing
stableMethod = 0; % 0=original;1=new



waitTime = 0.1; % seconds to pause after each file
% if 0, pause indefinitley

% choose and open data file
% dataDir = 'C:\Users\dfigaro\Documents\Parking\Data\All Test Vectors\Field Test Vector_Cloud\issue_cases\';
% dataDir = 'C:\Users\jtrojan\Desktop\Data\Parking\baseline_logs\';
dataDir = '..\..\Data\';


%%% >>>Problem File List<<<
% move this list to csv ...
% FrontLot\2017dec18-24\Front8_valid_2017_12_19_testDblBufAck1


%%% >> Figure Plot Settings
% [fignum  dock  link]
figPlotS = [];
figPlotS.magDeltaVectorSample = [101 1 0];
figPlotS.Time = [0 1 0];
figPlotS.magDeltaVectorTime = [120 0 1];
figPlotS.magS2SDeltaVectorTime = [0 0 1]; % sample to sample delta vector
figPlotS.magDataFull = [122 0 1];
figPlotS.magDeltaVectorServTime = [0 0 0]; % vs server time
figPlotS.deltaTime = [130 1 1];
figPlotS.rssiTime = [140 0 1];
figPlotS.temperatureTime = [150 1 1];
figPlotS.HSmode = [0*160 0 1];
figPlotS.carStates = [0 0 1];
figPlotS.carStatesTruth = [162 1 1];
figPlotS.parkStatus = [170 1 1];
figPlotS.parkMeas = [180 1 1];
figPlotS.magDeltaVector3D = [0 0 1];


% plot axis struct for linking
% uses same fields as figPlotS
haxS = [];
flds = fieldnames(figPlotS);
for ifld=1:length(flds)
    fld = flds{ifld};
    haxS.(fld)=[];
end

parkImageShow0.on = parkImagesFlagInit;
parkImageShow0.figN = 200;
parkImageShow0.imageStructAy = [];
parkImageShow0.cursFigs = [figPlotS.carStatesTruth(1)]; % list of figures to use cursor for updateing image plot
%%% >> Figure Plot Settings



% % % Load PPG and Accel data (need to select multiple data files)
% [FileName,PathName] = uigetfile({[dataDir '*.csv']},'Choose Log File -mag data');


[alldatfiles,PathName] = uigetfile({[dataDir '*.*']},'Choose Multiple Logs', 'MultiSelect', 'on');

if isnumeric(PathName)
    return
end



if ~iscell(alldatfiles)
    alldatfiles = {alldatfiles};
end
numfiles=length(alldatfiles);

if numfiles>1
    % ask if plot data should be on
    button = questdlg('Show Parking Data Plots?','Parking Algorithm','Yes');
    switch button
        case 'Yes'
            plotDataFlag = 1;
        case 'No'
            plotDataFlag = 0;
        otherwise
            return
    end
end
%
%
for file_index=1:numfiles

    if iscell(alldatfiles)
        FileName=char(alldatfiles(file_index));
    elseif ischar(alldatfiles)
        FileName=alldatfiles;
    else
        return
    end

    disp(['File:  ' FileName])

    % id columns by hdr text
    hdr.iSentralTime = {'SentralTime'};
    hdr.iSensorID = {'sensorId'};
    hdr.iServeTime = {'ServerTime','ServerTime_PST'};
    hdr.iCarStat = {'CarPresence'};
    hdr.iTemp = {'Temperature'};
    hdr.iRSSI = {'rx_rssi','LoraWan_rssi'};
    hdr.iConf = {'Confidence'};
    hdr.iData = {'x','y','z'};

    indS.hdr = hdr;

    global plotInfo dataInfo cntrlInfo dataInfoExtra parkImageShow figPlotS

    dataInfo = [];
    dataInfoExtra = [];

    if isempty(parkImageShow)
        parkImageShow = parkImageShow0;
    end

    [pathstr,name,ext] = fileparts(FileName);


    %%% truth state data file
    dataInfo_load = []; % initialize

    if strcmpi(ext,'.csv')
        % csv
        % original parser
        % [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw,sentralTimestamp] = Read_Data_CloudLog_Conti([PathName FileName]);

        %     [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw, sentralTimestamp, servTime] = Read_Data_CloudLog_flexHdr([PathName FileName],indS);
        %     [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw, sentralTimestamp, servTime, SentralOutputRaw] = Read_Data_CloudLog_flexHdr_work([PathName FileName],indS);
        dataStruct = Read_Data_CloudLog_flexHdr([PathName FileName],indS);

        %%% truth state data file
        [pathstr,fileName,ext] = fileparts(FileName);
        fMatName = [PathName fileName '.mat'];
        if exist(fMatName,'file')
            % copy over truth from state file
            dataFileLoad = load(fMatName);
            if isfield(dataFileLoad, 'dataInfo')
                dataInfo_load = dataFileLoad.dataInfo;
            end
        end
    elseif strcmpi(ext,'.mat')
        % mat
        dataFileLoad = load([PathName FileName]);
        if isfield(dataFileLoad, 'dataStruct')
            dataStruct = dataFileLoad.dataStruct;
        else
            disp('Unknown File Type!!!')
            continue
        end
        if isfield(dataFileLoad, 'dataInfo')
            dataInfo_load = dataFileLoad.dataInfo;
        end
    else
        disp('Unknown File Type!!!')
        continue
    end



    if ~isempty(dataStruct) % && ~isempty(timeRaw)

%         clear plotInfo dataInfo cntrlInfo


        %%% dataInfo_load
        if ~isempty(dataInfo_load)
            dataInfo = dataInfo_load;
        end
        dataInfo.fileName = FileName;
        dataInfo.pathName = PathName;


        % Pre cal initialize
        % if .mat present with setting then that will be used
        % if not than no precal will be performed
        preCalLoop = 0; % flag to pre-calibrate before running data - off unless set by .mat
        calTime = []; % time range to use for pre-calibration, if present
        startTime = [];
        if ~isempty(dataInfo_load) && isfield(dataInfo_load,'preCalLoop')
        else
            dataInfo.preCalLoop = preCalLoop;
        end
        if ~isempty(dataInfo_load) && isfield(dataInfo_load,'startTime')
        else
            dataInfo.startTime = startTime;
        end
        if ~isempty(dataInfo_load) && isfield(dataInfo_load,'calTime')
        else
            dataInfo.calTime = calTime;
        end


%         if dataInfo.preCalLoop ~= preCalLoop
%             button = questdlg('Override file preCal Setting?');
%             if ~isempty(button)
%                 switch button
%                     case 'Yes'
%                         % update file setting to new setting
%                         dataInfo.preCalLoop = preCalLoop;
%                     case 'No'
%                     case 'Cancel'
%                 end
%             end
%         end
        preCalLoop = dataInfo.preCalLoop;
        calTime = dataInfo.calTime;

        mraw = dataStruct.magDataAy(:,2:4);
        timeRaw = dataStruct.time;
        SentralOutput = dataStruct.magDataAy(:,6:7);
        raw_rate = dataStruct.magRaw_rate;
        magSenTimestamp = dataStruct.magSenTimestamp;
        servTime = dataStruct.magDateTimeAy; % server time

        if fillDataFront
            N = length(timeRaw);
            mraw = [mraw((N-fillDataFront+1):N,:); mraw];
            timeRaw = [(0:(fillDataFront-1))'; timeRaw+fillDataFront];
            SentralOutput = [repmat(SentralOutput(1,:),fillDataFront,1); SentralOutput];
            magSenTimestamp = [(0:32000:((fillDataFront-1)*32000))'; magSenTimestamp+fillDataFront*32000];
            st1s = 1.2e-5;
            servTime = [(servTime(1):st1s:(servTime(1)+st1s*(fillDataFront-1)))'; servTime+fillDataFront*st1s];
        end

        dataInfoExtra.servTime = servTime;


        HS_mode_triggerIND = [];

        %% Setup data structures
        ParkingStruct = Parking_struct_init;


        %%%%% update knobs setting for drive thru algo
        if ParkingStruct.DriveThruFLAG
            ParkingStruct = Parking_struct_init_DriveThru(ParkingStruct);
        end


        %%% >>> Stability Filter Development
        % stability/slope/noise filter
        ParkingStruct.filtStruct = stableFilt_init;
        ParkingStruct.filtStruct.stableMethod = stableMethod; % 0=original;1=new

%         ParkingStruct.STD_threshDown = 0.7;
%         ParkingStruct.State_count_thresh = uint16(4);


        %%% settings update test
%         % default
%         ParkingStruct.STD_threshUp = 1.5;
%         ParkingStruct.STD_threshDown = 0.5;

%         % high noise system test
%         ParkingStruct.STD_threshUp = 2.5;
%         ParkingStruct.STD_threshDown = 1.5;



        %%% create initial calibration
        % time in pseudo sec of calibration data to run first
%         calTime = [2970 3000];
%         calContext = 1; % 1=no car; 3 = car;
%         ParkingStruct.Context_Input = calContext;

        % if raw_rate <= ParkingStruct.HS_rate
        %
        %     warning('upsampling is not supported');
        %
        % else
        %
        %     factor = floor(raw_rate/ ParkingStruct.HS_rate);
        %     sprintf('Down Sampling Factor: %f',factor);
        %
        %     magData       = downsample(mraw,factor);
        %     time          = downsample(timeRaw,factor);
        %     SentralOutput = downsample(SentralOutput,factor);
        % end



        start_ind = 1;
        end_ind = size(mraw,1);    %%%% 1690;   %%%%size(mraw,1);  %%%625;


        magData       = mraw(start_ind:end_ind,:);
        time          = timeRaw(start_ind:end_ind,:);
        SentralOutput = SentralOutput(start_ind:end_ind,:);
        magSenTimestamp = magSenTimestamp(start_ind:end_ind,:);

        time_rel = time - time(1);

        %%% add sine noise
        if magSineNoise(1)
            % generate sine wave at desired frequency at high time resolution
            f = magSineNoise(1); % hz
            Ax = magSineNoise(2); % uT amplitude
            Ay = magSineNoise(3); % uT amplitude
            Az = magSineNoise(4); % uT amplitude
            T = 1/f; % sec
            tres = T/10; % sec
            tRange = time_rel(end) - time_rel(1); % sec
            t = 0:tres:tRange;
            th = 2*pi*t*f; % radians

            % sine and interp to mag data times
            swave0 = sin(th);
            swave = interp1(t,swave0,time_rel,'linear','extrap'); % interp times
            swaveNoiseX = Ax*swave;
%             swaveNoiseX = interp1(t,swaveX,time_rel,'linear','extrap');
            swaveNoiseY = Ay*swave;
%             swaveNoiseY = interp1(t,swaveY,time_rel,'linear','extrap');
            swaveNoiseZ = Az*swave;
%             swaveNoiseZ = interp1(t,swaveZ,time_rel,'linear','extrap');
%             figure
%             plot(t,swave0); hold all
%             plot(time_rel,swaveNoiseX,'.','MarkerSize',12); hold all
%             plot(time_rel,swaveNoiseY,'.','MarkerSize',12); hold all
%             plot(time_rel,swaveNoiseZ,'.','MarkerSize',12); hold all

            clear swave0  t th

            magData = magData + [swaveNoiseX swaveNoiseY swaveNoiseZ];
        end

        %%% add square noise
        if magSquareNoise(1)
            % generate sine wave at desired frequency at high time resolution
            f = magSquareNoise(1); % hz
            Ax = magSquareNoise(2); % uT amplitude
            Ay = magSquareNoise(3); % uT amplitude
            Az = magSquareNoise(4); % uT amplitude
            dc = magSquareNoise(5); % duty cycle
            T = 1/f; % sec
            tres = T/10; % sec
            tRange = time_rel(end) - time_rel(1); % sec
            t = 0:tres:tRange;
            th = 2*pi*t*f; % radians

            % square and interp to mag data times
            swave = square(th,dc);
%             swave(swave>0)=1; % make square
%             swave(swave<0)=-1; % make square
            swave = interp1(t,swave,time_rel,'linear','extrap'); % interp times
            sqwaveNoiseX = Ax*swave;
%             swaveNoiseX = interp1(t,swaveX,time_rel,'linear','extrap');
            sqwaveNoiseY = Ay*swave;
%             swaveNoiseY = interp1(t,swaveY,time_rel,'linear','extrap');
            sqwaveNoiseZ = Az*swave;
%             swaveNoiseZ = interp1(t,swaveZ,time_rel,'linear','extrap');
%             figure
%             plot(sqwaveNoiseX); hold all
%             plot(sqwaveNoiseY); hold all
%             plot(sqwaveNoiseZ); hold all

            clear swave t th

            magData = magData + [sqwaveNoiseX sqwaveNoiseY sqwaveNoiseZ];
        end


        %%% add gaussian noise
        if magGaussNoise
            magData = magData + magGaussNoise*randn(length(magData),3);
        end



        dt = [0; time(2:end) - time(1:end-1)];

        % time2: replace large time gaps
        tgapmax = 60;
        dtBigInds = find(dt>=tgapmax);
        tgapreplace = 10;
        % [time(dtBigInds-1) time(dtBigInds) time(dtBigInds+1)]

        dt2 = dt;
        tgapmeas = dt(dtBigInds);
        dt2(dtBigInds) = tgapreplace;
        time2 = time(1) + cumsum(dt2);
        dataInfoExtra.time2 = time2;


        %% Pre-Cal Loop
        % check initial data for cleanliness
        % on PP cal is 40 samples at HS rate
        % here we may have LS data in short bursts updated only occasionally
        % Start with 40 samples
        if ~dataInfo.preCalLoop
            Ncal=30; % target cal samples if all within limits - set shorter because of typical file behavior
            Ncalnative = 40;
            mCalDevLimit = 3; % uT
            magCalInitData =  magData(1:Ncal,:);
            devMedAy = magCalInitData - repmat(median(magCalInitData,1),Ncal,1);
            devMedRAy = sqrt(sum(devMedAy.^2,2));
            icalEnd = find((devMedRAy)<=mCalDevLimit,1,'last');
            if ~isempty(icalEnd) && icalEnd<Ncalnative
                % condition for doing preloop cal to avoid bad mag readings in initial cal.
                if icalEnd<12, icalEnd = 12; end % min number of pts
                calTime = [time2(1) time2(icalEnd)];
                preCalLoop = 1;
                dataInfo.preCalLoop = preCalLoop;
            end
        end

        calContext = 1; % 1=no car; 3 = car;
        if dataInfo.preCalLoop
%             preCalLoop = 0; % flag to calibrate before running data
%             calTime = [2920 3000]; % time range to use for calibration
            ParkingStruct.Context_Input = calContext;

            tcalRangeInds = find(time2>=calTime(1) & time2<=calTime(2));
            magDataCal = magData(tcalRangeInds,:);
            magSenTimestampCal = magSenTimestamp(tcalRangeInds,:);

            for icalLoop = 1:10
                for i = 1:length(magDataCal)

                    ParkingStruct.NUM               = single(i);

                    %     ParkingStruct.PreDataBuffer      = shifting_array(ParkingStruct.PreDataBuffer);
                    %     ParkingStruct.PreDataBuffer(ParkingStruct.PreDataBufferSize,:)  = magData(i,:);

                    %             disp(magData(i,:))

                    % conditional simulates RM3100 hardware mode
                    if ((abs(magDataCal(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
                            || (abs(magDataCal(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
                            || (abs(magDataCal(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
                            || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
                            || (~isempty(HS_mode_triggerIND) && any(HS_mode_triggerIND == ParkingStruct.NUM))
                        %         || ParkingStruct.NUM              == 95 ...
                        %         || ParkingStruct.NUM              == 123 ...
                        %         || ParkingStruct.NUM              == 156



                        if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
                            ParkingStruct.StartNUM          = ParkingStruct.NUM;
                        end

                        % Parking Algorithm
                        ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magDataCal(i,:),magSenTimestamp(i),1);

                    else
                        %                 disp('Hardware LS Mode Sim Pt!!!')
                    end

                    if ParkingStruct.Calibration_FLAG
                        break
                    end
                end
            end
        end





        %%
        magNdata = sqrt(sum(magData.^2,2));
        magNdata2 = sqrt(sum(magData(:,2:3).^2,2));

        range_X = max(magData(:,1)) - min(magData(:,1));
        range_Y = max(magData(:,2)) - min(magData(:,2));
        range_Z = max(magData(:,3)) - min(magData(:,3));

        disp('magXYZ ranges')
        disp([range_X range_Y range_Z])

        figN = 100;

        %%% plot deltas and vector deltas
        set(0,'DefaultFigureWindowStyle','normal') %docked figures

        % adapt time gaps for other sentral times
        % insert time gap at closest time
        tTempAy = dataStruct.dataTempAy(:,1);
        dtTemp = [0; tTempAy(2:end) - tTempAy(1:end-1)];
        for ii=1:length(dtBigInds)
            tfind = time(dtBigInds(ii));
            [minVal, minInd] = min(abs(tTempAy-tfind));
            dtTemp(minInd) = tgapreplace;
        end
        time2Temp = tTempAy(1) + cumsum(dtTemp);


        [pathstr,fNameTitle,ext] = fileparts(FileName);
        idlm1 = find(FileName == '_',1,'first');
        if ~isempty(idlm1)
            fNameTitle = FileName(1:idlm1-1);
        else
            fNameTitle = FileName;
        end
        if length(fNameTitle)>14
            fNameTitle = fNameTitle(1:14);
        end


        diffTime = [0; diff(time)];
        diffTime(1) = diffTime(2);
        HS_label = diffTime<0.5;

        N3 = length(magData);

        magNdata = zeros(N3,1);
        mag_diff = zeros(N3,1);
        phase_level = zeros(N3,1);
        detection_output = zeros(N3,1);

        car_state = zeros(N3,4);

        MEAN_value = zeros(N3,2);
        STD_value = zeros(N3,1);

        MEAN_value2 = zeros(N3,3);

        moving_avg = zeros(N3,1);

        MEAN_Baseline_value = zeros(N3,1);
        STD_Baseline_value = zeros(N3,1);
        MEAN_Occupied_value = zeros(N3,1);
        STD_Occupied_value = zeros(N3,1);

        ALG2Level = zeros(N3,1);
        car_state_alg2 = zeros(N3,1);

        car_state_buffer =zeros(N3,1);

        Alarm_level = zeros(N3,1);
        LS_Trigger_FLAG_ay = zeros(N3,1);

        % stability filter track
        mmn_ay = []; mmnCln_ay = [];
        mstd_ay = []; mstdCln_ay = [];
        mstdDelta_ay = []; mstdDeltaCln_ay = [];
        mstdSlope_ay = []; mstdSlopeCln_ay = [];
        mslope_ay = []; mslopeCln_ay = [];
        mslopeMoveClnMn_ay = [];

        % add missing fields
        ParkingStruct.NUM = single(0);
        ParkingStruct.StartNUM = single(0);

        % flds to monitor
        % status fields
        parkFieldsStatusWatch = createParkStructStatusWatchList;
        parkStatusS = copyFields(ParkingStruct,parkFieldsStatusWatch);
        parkStatusAy = repmat(parkStatusS,N3,1);
        % meas fields

        parkFieldsMeasWatch = createParkStructMeasWatchList;
        parkMeasS = copyFields(ParkingStruct,parkFieldsMeasWatch);
        parkMeasAy = repmat(parkMeasS,N3,1);

        %% Data Loop
%         startTime = 2200;
        if ~isempty(dataInfo.startTime)
            startInd = find(time2>=dataInfo.startTime,1,'first');
        else
            startInd = 1;
        end
        for i = startInd:length(magData)

            ParkingStruct.NUM               = single(i);


            % conditional simulates RM3100 hardware mode
            if ((abs(magData(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
                    || (abs(magData(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
                    || (abs(magData(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
                    || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
                    || (~isempty(HS_mode_triggerIND) && any(HS_mode_triggerIND == ParkingStruct.NUM))

                if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
                    ParkingStruct.StartNUM          = ParkingStruct.NUM;
                end


                %%% stability filter testing
                filtStruct = stableFilt(ParkingStruct.filtStruct,magData(i,:));
                ParkingStruct.filtStruct = filtStruct;

%                 mmn_ay = [mmn_ay; filtStruct.mmn];
%                 mstd_ay = [mstd_ay; filtStruct.mstd];
%                 mmnCln_ay = [mmnCln_ay; filtStruct.mmnCln];
%                 mstdCln_ay = [mstdCln_ay; filtStruct.mstdCln];
%
%                 mstdDelta_ay = [mstdDelta_ay; filtStruct.mstdDelta];
%                 mstdDeltaCln_ay = [mstdDeltaCln_ay; filtStruct.mstdClnDelta];
%                 mstdSlope_ay = [mstdSlope_ay; filtStruct.mstdMoveSlope];
%                 mstdSlopeCln_ay = [mstdSlopeCln_ay; filtStruct.mstdMoveClnSlope];
%
%                 mslope_ay = [mslope_ay; filtStruct.mslope];
%                 mslopeCln_ay = [mslopeCln_ay; filtStruct.mslopeCln];
%                 mslopeMoveClnMn_ay = [mslopeMoveClnMn_ay; filtStruct.mslopeMoveClnMn];


                % hardware alarm
                %         ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
                ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),magSenTimestamp(i),1);

                %          %%%%% downsample to 4 Hz
                %          if ParkingStruct.downsampleFLAG == 1
                %             ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),magSenTimestamp(i),1);
                %             ParkingStruct.downsampleFLAG = 0;
                %          else
                %              ParkingStruct.downsampleFLAG = 1;
                %          end

                ParkingStruct.cPastLsMode = uint16(0);
                ParkingStruct.lsRecheckEnable = int8(1);
            else
%                 disp('Hardware LS Mode Sim Pt!!!')
                ParkingStruct.cPastLsMode = ParkingStruct.cPastLsMode + uint16(1); % keep track of time since last parking event
                if (ParkingStruct.car_present == 3 && ParkingStruct.car_present2 == 3) && ParkingStruct.cPastLsMode > ParkingStruct.LS_rate * ParkingStruct.lsRecheckTime % only perform check if the system is confirmed in parked mode
                    ParkingStruct = Parking_isEmptyCheck(ParkingStruct,magData(i,:));
                end
            end

            %%% Track ParkingStruct field data
            parkStatusAy(i) = copyFields(ParkingStruct,parkFieldsStatusWatch);
            parkMeasAy(i) = copyFields(ParkingStruct,parkFieldsMeasWatch);

            %     % software alarm
            %     ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),magSenTimestamp(i),0);

            magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
            %    MEAN_value(i,1) = ParkingStruct.AVG;
            STD_value(i,1)  = ParkingStruct.STD;

            %    STD_value(i,2)  = ParkingStruct.STDz;

            MEAN_value2(i,:) = ParkingStruct.AVG2;

            MEAN_value(i,1) = ParkingStruct.moving_avg;

            moving_avg(i,1)=ParkingStruct.moving_avg;


            car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2 ParkingStruct.car_present ParkingStruct.car_present2];
            Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG;

            %    RMS(i,1) = ParkingStruct.RMS;

            SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;

            LS_Trigger_FLAG_ay(i,:) = ParkingStruct.LS_Trigger_FLAG;

        end



            %%% process run dependent variables
            % load dataInfo state file if present
            if ~isempty(dataInfo_load) && isfield(dataInfo_load,'truth_state')
% % %                 dataInfo = dataInfo_load;
                truth_state = dataInfo_load.truth_state;
            else
                truth_state = car_state;
            end

            if fillDataFront && length(time2) ~= length(truth_state)
                truth_state = [repmat(truth_state(1,:),fillDataFront,1); truth_state];
            end


            dataInfo.truth_state = truth_state;
            dataInfo.truth_state_load = truth_state;

            % use new (recalculated) car and sen_states
            dataInfo.car_state = car_state;
            dataInfo.sen_state = SentralOutput;



        %%% Plotting
        N = size(magData,1);
%         iRefInds = 1:4;
        if ~dataInfo.preCalLoop
            % cal section defined by 'Calibration_FLAG'
            dataCalFlags = single([parkStatusAy.('Calibration_FLAG')]');
            if ~isempty(dataInfo.startTime)
                runFlags = time2>=dataInfo.startTime;
                tcalRangeInds = find(runFlags & ~dataCalFlags);
            else
                tcalRangeInds = find(~dataCalFlags);
            end
            calTime = [time2(tcalRangeInds(1)) time2(tcalRangeInds(end))];
        else
            tcalRangeInds = find(time2>=calTime(1) & time2<=calTime(2));
        end
%         iRefInds = tcalRangeInds;


        dataInfo.preCalLoop = preCalLoop;
        dataInfo.calTime = calTime;
        tcalRangeInds = find(time2>=calTime(1) & time2<=calTime(2));
        magDataCal = magData(tcalRangeInds,:);


%         magDataRef = mean(magData(iRefInds,:),1);
        magDataRef = ParkingStruct.AVGInit2; % use park algor cal as reference
        magDataDelta = magData - repmat(magDataRef,N,1);
        magDataDeltaR = sqrt(sum(magDataDelta.^2,2));

        magDataDeltaDiff = [0 0 0; diff(magDataDelta)];
        magDataDeltaDiffR = sqrt(sum(magDataDeltaDiff.^2,2));

        magDataR = sqrt(sum(magData.^2,2));

        dataStruct.magDataRef = magDataRef;
        dataStruct.magDataCal = magDataCal;
        dataStruct.magDataCalStd = std(magDataCal,0,1);

        %%% Plotting
        if plotDataFlag
            plotData.fNameTitle = fNameTitle;
            plotData.timeRaw = timeRaw;
            plotData.time2 = time2;
            plotData.dt = dt;
            plotData.servTime = servTime;
            plotData.tgapmeas = tgapmeas;
            plotData.dtBigInds = dtBigInds;
            plotData.LS_Trigger_FLAG_ay = LS_Trigger_FLAG_ay;
            plotData.parkStatusAy = parkStatusAy;
            plotData.parkMeasAy = parkMeasAy;
            plotData.startInd = startInd;
            plotData.time2Temp = time2Temp;
            plotData.car_state = car_state;
            plotData.truth_state = truth_state;
            plotData.SentralOutput = SentralOutput;
            plotData.tcalRangeInds = tcalRangeInds;
            plotData.magData = magData;
            plotData.magDataRef = magDataRef;
            plotData.magDataDelta = magDataDelta;
            plotData.magDataDeltaR = magDataDeltaR;
            plotData.magDataDeltaDiff = magDataDeltaDiff;
            plotData.magDataDeltaDiffR = magDataDeltaDiffR;
            plotData.magDataR = magDataR;

            [plotInfo,figPlotS,cntrlInfo,haxS] = parkingDataPlot(plotData,dataStruct,dataInfo,cntrlInfo,parkImageShow,plotInfo,figPlotS,haxS);
        end

%         if length(dataInfo.calTime)>1
%             cntrlInfo.calTimesEdit.String = [num2str(dataInfo.calTime(1)) ', ' num2str(dataInfo.calTime(2))];
%         end


        %%% docking
        plotflds = fieldnames(figPlotS);
        for ifld = 1:length(plotflds)
            try
                if figPlotS.(plotflds{ifld})(1)
                    if figPlotS.(plotflds{ifld})(2)
                        set(figPlotS.(plotflds{ifld})(1),'WindowStyle','docked')
                    else
                        set(figPlotS.(plotflds{ifld})(1),'WindowStyle','normal')
                    end
                end
            catch
                disp('Figure Docking Error!!!\n');
            end
        end

        %%% link plots
        %     linkaxes([hax1 hax2 hax4 hax3q],'x')
%         linkprop([hax0 hax1 hax2 hax4 hax5 hax3q],'xlim');
%         linkprop([hax hax hax hax],'xlim');

        plotInfo.haxS = haxS;
        linkflds = fieldnames(haxS);
        haxAy = [];
        for ifld=1:length(linkflds)
            if ~isempty(haxS.(linkflds{ifld})) && figPlotS.(linkflds{ifld})(3)
                haxAy = [haxAy haxS.(linkflds{ifld})];

                % add server time to datatip display
                % create custom data cursor display
                if ~strcmp(linkflds{ifld},'parkStatus') && ~strcmp(linkflds{ifld},'parkMeas')
                    dcm_obj3 = datacursormode(figPlotS.(linkflds{ifld})(1));
                    set(dcm_obj3,'UpdateFcn',@dispMkrTimeFcn);
                end
            end
        end
        plotInfo.haxAy = haxAy;

        haxDebug = [];
        if ~isempty(haxAy)
            linkprop([haxAy haxDebug],'xlim');
%             linkParkPlots;
        end


        %%% >>> load parking camera images
        if parkImagesFlagInit
            camDir = [PathName 'cameraLogs\'];
            parkImageShow = loadMatchingParkingImagesAll(parkImageShow,camDir,servTime);
        end
        if parkImageShow.on && isfield(parkImageShow,'dateTimeAyAy') && ~isempty(parkImageShow.dateTimeAyAy)
            parkImageShow = parkImagesUpdate2File(figPlotS,plotInfo,dataInfoExtra,parkImageShow);
        end
        %%% >>> load parking camera images

        %%% Display noise
        disp('Mag Calibration Noise (uT): ')
        disp(dataStruct.magDataCalStd)

        %%% Save Data
        % this file will be overwritten by a truth eidt file if the truth file is saved.
        [pathstr,fileName,ext] = fileparts(dataInfo.fileName);
        save([dataInfo.pathName fileName '.mat'],'dataInfo','dataStruct')


    else
        disp('No Valid Data...')


    end
    if file_index>=numfiles
        % continue...
    elseif waitTime
        pause(waitTime)
    else
        disp('Hit any key to continue...');
        pause % hit key to continue
    end

end

return







%%% >>> for saving a screenshot with multiple figures
screenImages = captureScreen; % images of all monitor screens

iscreen = 2;
imwrite(screenImages{iscreen},['carStates4' '.png']);
%%% >>> for saving a screenshot with multiple figures





