function [mraw,time,SentralOutput,raw_rate,RSSIdata,mDataRaw, sentralTimestamp, servTime] = Read_Data_CloudLog_Conti_stime_valid(FileName, indS)

% [rawData,~] = xlsread(FileName);

% load all data into str columns
% magR  SENtralTime  SensorId  ServerTime_PST  CarPresence  Temperature  LoraWan_rssi  Confidence  magx magy magz
[dataStrArray, hdrArray0] = loadcsvTextCols('',FileName,2);

indS0 = indS; % default indexes

% % sstr = serverTimeStr{1}
% % yuan
% iSentralTime = 2;
% iSensorID = 3;
% iServeTime = 4;
% iCarStat = 5;
% iTemp = 6;
% iRSSI = 7;
% iConf = 8;
% iData = 9:11;
% 
% % validation files
% iSentralTime = 7;
% iSensorID = 6;
% iServeTime = 2;
% iCarStat = 9;
% iTemp = 10;
% iRSSI = 12;
% iConf = 8;
% iData = 3:5;

% % validation files
% indS.iSentralTime = 7;
% indS.iSensorID = 6;
% indS.iServeTime = 2;
% indS.iCarStat = 9;
% indS.iTemp = 10;
% indS.iRSSI = 12;
% indS.iConf = 8;
% indS.iData = 3:5;
% 
% % yuan
% indS.iSentralTime = 2;
% indS.iSensorID = 3;
% indS.iServeTime = 4;
% indS.iCarStat = 5;
% indS.iTemp = 6;
% indS.iRSSI = 7;
% indS.iConf = 8;
% indS.iData = 9:11;


% read hdr from file
if isfield(indS,'hdr') && ~isempty(indS.hdr)
    hdrArray = [];
    for ii=1:length(hdrArray0)
        hdrArray = [hdrArray hdrArray0{ii}(1)];
    end
    excludeFlds = {'hdr'};
    flds = fieldnames(indS.hdr);
    for ii=1:length(flds)
        fldName = flds{ii};
        if ~any(strcmp(excludeFlds,fldName))
            colNames = indS.hdr.(fldName);
            icols = [];
            for jj=1:length(colNames)
                icol = find(strcmp(hdrArray,colNames{jj}),1,'first');
                if ~isempty(icol)
                    icols(jj) = find(strcmp(hdrArray,colNames{jj}),1,'first');
                end
            end
            if ~isempty(icols)
                indS.(fldName) = icols; % reassign column
            end
        end
    end
end

iSentralTime = indS.iSentralTime;
iSensorID = indS.iSensorID;
iServeTime = indS.iServeTime;
iCarStat = indS.iCarStat;
iTemp = indS.iTemp;
iRSSI = indS.iRSSI;
iConf = indS.iConf;
iData = indS.iData;


% 
% hdr.iSentralTime = {'SentralTime'};
% hdr.iSensorID = {'sensorId'};
% hdr.iServeTime = {'ServerTime'};
% hdr.iCarStat = {'CarPresence'};
% hdr.iTemp = {'Temperature'};
% hdr.iRSSI = 'rx_rssi';
% hdr.iConf = {'Confidence'};
% hdr.iData = {'x','y','z'};
% 
% % unused fields
% GatewayTime
% rx_gateway
% rx_snr
% tx_spreadFactor
% tx_bandwidth
% tx_modulation
% tx_frequency
% 




% build cell data array
dataCellAy = [];
for ii=1:length(dataStrArray)
    dataCellAy = [dataCellAy dataStrArray{ii}];
end
N = size(dataCellAy,1);

% reverse all data
reverseIdx = N:-1:1;
dataCellAy = dataCellAy(reverseIdx,:);

dataCellAy0 = dataCellAy;

% % build mag data
% iay = [iSentralTime iData iRSSI];
% mDataRaw = [];
% for ii = 1:length(iay)
%    mDataRaw=[mDataRaw   str2double(cell2mat(dataCellAy(:,iay(ii))))];
% end

% build data arrays
iay = [iSentralTime iData iRSSI];
% mDataRaw = [];
% for ii=1:N
%     dline = [];
%     for jj=1:length(iay)
%         dline=[dline  str2double(cell2mat(dataCellAy(ii,iay(jj))))];
%     end
%    mDataRaw=[mDataRaw;   dline];
% end
       
mDataRaw = buildDataFromCellAy(dataCellAy,iay);

% mDataRaw=[cell2mat(dataCellAy(:,iSentralTime))  cell2mat(dataCellAy(:,iData))  cell2mat(dataCellAy(:,iRSSI))]; 
% mDataRaw=[dataCellAy(:,iSentralTime) dataCellAy(:,iData)  dataCellAy(:,iRSSI)]; 
% mDataRaw=[[dataStrArray{iSentralTime}] dataStrArray{[iData]}  dataStrArray{[iRSSI]}]; 
% cell2mat(dataCellAy)


% reverseIdx = size(rawData,1):-1:1;
% rawData = rawData(reverseIdx,:);
% serverTimeStr = serverTimeStr(reverseIdx,:);

it = 1;
inds = mDataRaw(:,it)~=0;
mDataRaw = mDataRaw(inds,:);
dataCellAy = dataCellAy(inds,:);


diffT = diff(mDataRaw(:,it));
tind = find(diffT< -10^9);

% if ~isempty(tind)
%     if length(tind)>1
%         1;
%     end
%     
%     for i = 1:length(tind)
%         rawData(tind(i)+1:end,iSentralTime)=rawData(tind(i)+1:end,iSentralTime)+rawData(tind(i),iSentralTime);
%     end
% end

%sort data by timestamp
[~, sortedIndexes] = sort(mDataRaw(:,it));
mDataRaw = mDataRaw(sortedIndexes,:);

dataCellAy = dataCellAy(sortedIndexes,:);





% ****** load raw mag data
midx=find(~isnan(mDataRaw(:,1)) & ~isnan(mDataRaw(:,2)) & ~isnan(mDataRaw(:,3)) & ~isnan(mDataRaw(:,4)));

% mDataRaw=rawData(midx,[iSentralTime  iData  iRSSI]); 
% serverTimeStr = serverTimeStr(midx);

mDataRaw = mDataRaw(midx,:);
dataCellAy = dataCellAy(midx,:);


%sort data by timestamp
[~, sortedIndexes] = sort(mDataRaw(:,1));
mDataRaw = mDataRaw(sortedIndexes,:); 
dataCellAy = dataCellAy(sortedIndexes,:);


%%%% removal of repeated data
[~,ia,~] = unique(mDataRaw(:,1));
mDataRaw = mDataRaw(ia,:); 
dataCellAy = dataCellAy(ia,:); 


mDataRaw=[mDataRaw zeros(size(mDataRaw,1),3)];
mDataRaw(:,8) = 10;

% %%%%%% SENtral output

dataCarStat = buildDataFromCellAy(dataCellAy,[iSentralTime iCarStat iConf]);


sidx1=find(~isnan(dataCarStat(:,2)));
SentralOutputRaw1=dataCarStat(sidx1,:);    
[~,ia,~] = unique(SentralOutputRaw1(:,2));

sidx = sidx1(ia);
SentralOutputRaw=dataCarStat(sidx,:);

empty_record = [];
for i = 1:length(sidx)
    
    iind = find(mDataRaw(:,1)==SentralOutputRaw(i,1));
    
    if ~isempty(iind)
        mDataRaw(iind,6)=SentralOutputRaw(i,2);
        mDataRaw(iind,7)=SentralOutputRaw(i,3);
        

        %%% car state
        if mDataRaw(iind,6) == 0        
           mDataRaw(iind,6) = 1;
        elseif mDataRaw(iind,6) == 100        
            mDataRaw(iind,6) = 3;        
        elseif mDataRaw(iind,6) == 50        
            mDataRaw(iind,6) = 2;  
        elseif mDataRaw(iind,6) == -50        
            mDataRaw(iind,6) = 4;  
        end         
        
        
    else
        empty_record = [empty_record;i];
    end
end



for i = 2: size(mDataRaw,1)
    
    if mDataRaw(i,6) == 0 && mDataRaw(i,7) == 0 && mDataRaw(i-1,6) ~= 0 && mDataRaw(i-1,7) ~= 0
        
        mDataRaw(i,6) = mDataRaw(i-1,6);
        mDataRaw(i,7) = mDataRaw(i-1,7); 
        mDataRaw(i,8) = 20;
    end
end


% timestamp in seconds
tRaw = mDataRaw(:,1);
time = (tRaw - tRaw(1,:))/32000;  % time in seconds 

sentralTimestamp = mDataRaw(:,1);

% mag data
mraw = mDataRaw(:,2:4);     
    
RSSIdata = mDataRaw(:,5);


SentralOutput = mDataRaw(:,6:7);


% server time convert from str
serverTimeStr = dataCellAy(:,iServeTime);

clear dateTimeAy
for ii=1:length(serverTimeStr)
    sStr = serverTimeStr{ii};
    iplus = strfind(sStr,'+');
    iminus = strfind(sStr,'-');
    iT = strfind(sStr,'T');
    iColon = strfind(sStr,':');
    timeCheck = length(iminus)>=2 & ~isempty(iT);
    iend = iColon(2)+2; % ... needs work ...
    sStr = sStr(1:iend);
    if timeCheck
%         if ~isempty(iplus)
%             sStr = sStr(1:iplus-1);
%         end
        y = str2num(sStr(1:iminus(1)-1));
        m = str2num(sStr(iminus(1)+1:iminus(2)-1));
        d = str2num(sStr(iminus(2)+1:iT(1)-1));
        thr = str2num(sStr(iT(1)+1:iColon(1)-1));
        tmin = str2num(sStr(iColon(1)+1:iColon(2)-1));
        tsec0 = str2num(sStr(iColon(2)+1:end));
        %     DateNumber = datenum(y,m,d,thr,tmin,tsec0) ; % matlab date/time format
        tsec = floor(tsec0);
        tmsec = 1000*(tsec0-tsec);
        dateTime = datetime(y,m,d,thr,tmin,tsec,tmsec);
    else
        dateTime = [];
    end
    dateTimeAy(ii,:) = dateTime;
end

servTime = dateTimeAy;



% % ****** load output on from SENtral
% % sidx=find(~isnan(rawData(:,5)));
% % SentralOutputRaw=rawData(~isnan(rawData(:,5)),[5]);
% 
% 
% sidx1=find(~isnan(rawData(:,5)));
% SentralOutputRaw1=rawData(sidx1,[5 2]);    
% [~,ia,~] = unique(SentralOutputRaw1(:,2));
% 
% sidx = sidx1(ia);
% SentralOutputRaw=rawData(sidx,[5 8]);
% 
% 
% SentralOutput = zeros(size(time,1),2);
% 
% endpoint = 1;
% index = 1;
% 
% for i = 1:length(sidx)
%     
%     sentral_index = sidx(i);
%     
%     
%     %%% car state
%     if SentralOutputRaw(i,1) == 0        
%        SentralOutputRaw(i,1) = 1;
%     elseif SentralOutputRaw(i,1) == 100        
%         SentralOutputRaw(i,1) = 3;        
%     elseif SentralOutputRaw(i,1) == 50        
%         SentralOutputRaw(i,1) = 2;  
%     elseif SentralOutputRaw(i,1) == -50        
%         SentralOutputRaw(i,1) = 4;  
%     end    
%     
%     
%     
%     
%     for j = endpoint:length(time)
%         
%         mag_index = midx(j);                  
%         
%         if sentral_index > mag_index
%             
%             SentralOutput(index,:) = SentralOutputRaw(i,:);    
%             index = index + 1;
%             
%         else
%             
%            endpoint = j;
%            break;
%            
%         end
%         
%     end
%     
%     
% end
% 
% if (length(time) > (endpoint-1)) && (~isempty(SentralOutputRaw)) 
%     
%     for i = endpoint:length(time)
%        SentralOutput(i,:) = SentralOutputRaw(end,:); 
%     end
% end
% 



%compute the average rate of a single time axis. axis should be
%a column vector.

%compute delta-t vector
tDels = time(2:end)-time(1:end-1);
%compute frequency vector
tFqs = tDels.^(-1);
%compute mean rate in hz
% raw_rate = mean(tFqs);
% raw_rate = mean(tFqs(1:10));
raw_rate = tFqs(1);






