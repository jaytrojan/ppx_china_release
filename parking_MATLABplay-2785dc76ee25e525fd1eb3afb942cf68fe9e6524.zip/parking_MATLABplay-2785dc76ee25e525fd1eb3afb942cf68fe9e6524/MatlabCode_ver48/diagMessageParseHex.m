function diagMessageParseHex(diagMessageHex)

%%%
% %   1  2  3  4  5  6  7  8  9 10 11
% 39 18 eb 98 01 70 1b a5 01 80 00 d0    0d 31 91 e3 00
% 39 2a 41 f9 4b 80 00 a9 f9 80 0f ff    0c 13 17 08 00
%  1   8 16 32 40 48

messageHex = diagMessageHex(3:24);

binStr = num2str(hex2bin(messageHex));
binStr = binStr(find(~isspace(binStr)))
% binStrMag = binStr(1:46);
binStrDiag = binStr;
% sx = -1*bin2dec(binStrDiag(1)); if sx==0,sx=1; end
% sy = -1*bin2dec(binStrDiag(17)); if sy==0,sy=1; end
% sz = -1*bin2dec(binStrDiag(33)); if sz==0,sz=1; end
dataMagXstr = binStrDiag(1:14);
dataMagYstr = binStrDiag(17:30);
dataMagZstr = binStrDiag(33:46);
% dataMagX = sx*typecast(uint16(bin2dec(dataMagXstr(2:end))),'int16')
dataMagX = bitshift(typecast(bitshift(uint16(bin2dec(dataMagXstr)),2),'int16'),-2);
dataMagY = bitshift(typecast(bitshift(uint16(bin2dec(dataMagYstr)),2),'int16'),-2);
dataMagZ = bitshift(typecast(bitshift(uint16(bin2dec(dataMagZstr)),2),'int16'),-2);

magDataUnits = single([dataMagX dataMagY dataMagZ])/32


dataMaxAxis = bin2dec(binStrDiag(15:16))
dataMinAxis = bin2dec(binStrDiag(31:32))

dataMaxStr = (binStrDiag(47:56));
dataMinStr = (binStrDiag(57:66));
dataMax = bitshift(typecast(bitshift(uint16(bin2dec(dataMaxStr)),6),'int16'),-6);
dataMin = bitshift(typecast(bitshift(uint16(bin2dec(dataMinStr)),6),'int16'),-6);
dataMaxUnits = single(dataMax)/2
dataMinUnits = single(dataMin)/2


dataStd = bin2dec(binStrDiag(67:77));
dataStdMax = bin2dec(binStrDiag(78:88));
dataStdUnits = single(dataStd)/32
dataStdMaxUnits = single(dataStdMax)/32
