%% Algorithm using SSA and SSR with real-time functionality 
% No motion data


close all;
clear; clc;
dbstop if error


% choose and open data file
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\original')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\original')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\app_data')






% [alldatfiles,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File', 'MultiSelect', 'on');
% numfiles=length(alldatfiles);
% 
% 
% for file_index=1:numfiles
% 
%     FileName=char(alldatfiles(file_index));



% % Load PPG and Accel data (need to select multiple data files)
[FileName,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File');

[mraw,time,SentralOutput,markerTimes,markNames,LSHS] = Read_Data_APP(FileName);

% [rawData,~] = xlsread(FileName);
% 
% 
% % ****** load raw mag data
% midx=find(rawData(:,1)== 21);
% mraw1=rawData(rawData(:,1)==21,[5 6 7]);
% 
% CAR_state_APP = rawData(rawData(:,1)==21,[3]);
% 
% magN = sqrt(sum(mraw1.^2,2));
% 
% 
% % plot: mag data with markers
% figure;   
% subplot(3,1,1);plot(mraw1); grid on;
% xlabel('Time(seconds)');
% ylabel('raw mag data');
% legend('mag-x', 'mag-y', 'mag-z');
% 
% subplot(3,1,2); plot(magN); grid on;
% subplot(3,1,3); plot(CAR_state_APP); grid on;
% 
% 
% 
% 
% 
% 
% mraw=rawData((rawData(:,3)~=17 & rawData(:,3)~=13),[1 5 6 7 3]);



tic;



%% Setup data structures
ParkingStruct = Parking_struct_init;



N3 = size(mraw,1);
car_state = ones(N3,1);

% magNdata = zeros(N3,1);
% mag_diff = zeros(N3,1);
% phase_level = zeros(N3,1);
% detection_output = zeros(N3,1);
% 

% 
% MEAN_value = zeros(N3,1);
% STD_value = zeros(N3,1);
% 
% MEAN_value2 = zeros(N3,3);
% 
% moving_avg = zeros(N3,1);
% 
% MEAN_Baseline_value = zeros(N3,1);
% STD_Baseline_value = zeros(N3,1);
% MEAN_Occupied_value = zeros(N3,1);
% STD_Occupied_value = zeros(N3,1);
% 
% 
% 
% ALG2Level = zeros(N3,1);
% car_state_alg2 = zeros(N3,1);
% 
% car_state_buffer =zeros(N3,1);
% 
% Alarm_level = zeros(N3,1);

HS_FLAG = 0;
index = 0;



for i = 9:28 
    

   ParkingStruct = Calibration_process(ParkingStruct, mraw(i,:));

    
end


ParkingStruct.NUM = 20;

HS_FLAG = 1;

for i = 29:N3
    
    
    if i == 280
        1;
    end
    
    
    ParkingStruct.NUM = i;
    ParkingStruct.time = time(i);   
    
    
if ~ParkingStruct.Calibration_FLAG  

   ParkingStruct = Calibration_process(ParkingStruct, mraw(i,:));

else    
    

       
    if ParkingStruct.LS_Trigger_FLAG  == uint8(1) && ( LSHS(i) == 8 ||   (LSHS(i) == 24 && LSHS(i-1) == 8) )           %% && time(i)-time(i-1) < 0.5


        ParkingStruct.LS_Trigger_FLAG     = uint8(0);

        ParkingStruct.LS_TO_HS_FLAG       = uint8(1);                 
        ParkingStruct.LS_TO_HS_FLAG2      = uint8(1); 


        ParkingStruct.Car_State_last_HS   = ParkingStruct.car_presentCur;

        ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);


    %             ParkingStruct = Parking_Algorithm(ParkingStruct, data);



    elseif ParkingStruct.LS_Trigger_FLAG  == uint8(0)


        ParkingStruct = Parking_Algorithm(ParkingStruct, mraw(i,:));




    elseif ParkingStruct.LS_Trigger_FLAG  == uint8(1) && ParkingStruct.LS_Count < ParkingStruct.LS_CheckInTime && ParkingStruct.car_presentCur == uint8(1)

          ParkingStruct.LS_Count = ParkingStruct.LS_Count + uint32(1);


          if ParkingStruct.LS_Count == ParkingStruct.LS_CheckInTime

            ParkingStruct.LS_CheckValueBuffer      = shifting_array(ParkingStruct.LS_CheckValueBuffer);                        
            ParkingStruct.LS_CheckValueBuffer(3,:) = mraw(i,:);

            ParkingStruct.LS_Count                 = uint32(0);


            % case of slowing drift on the mag value in the no car state
            if ParkingStruct.LS_CheckValueBuffer(1,1) ~= single(0) ...
                    && (   (ParkingStruct.LS_CheckValueBuffer(1,1) > ParkingStruct.LS_CheckValueBuffer(2,1) && ParkingStruct.LS_CheckValueBuffer(2,1) > ParkingStruct.LS_CheckValueBuffer(3,1) ...
                    && abs(ParkingStruct.LS_CheckValueBuffer(3,1) - ParkingStruct.AVGInit2(1)) > (ParkingStruct.MAG_thresh / single(2))) ...
                    || (ParkingStruct.LS_CheckValueBuffer(1,1) < ParkingStruct.LS_CheckValueBuffer(2,1) && ParkingStruct.LS_CheckValueBuffer(2,1) < ParkingStruct.LS_CheckValueBuffer(3,1) ...
                    && abs(ParkingStruct.LS_CheckValueBuffer(3,1) - ParkingStruct.AVGInit2(1)) > (ParkingStruct.MAG_thresh / single(2)))   ...
                    || (ParkingStruct.LS_CheckValueBuffer(1,2) > ParkingStruct.LS_CheckValueBuffer(2,2) && ParkingStruct.LS_CheckValueBuffer(2,2) > ParkingStruct.LS_CheckValueBuffer(3,2) ...
                    && abs(ParkingStruct.LS_CheckValueBuffer(3,2) - ParkingStruct.AVGInit2(2)) > (ParkingStruct.MAG_thresh / single(2)))   ...
                    || (ParkingStruct.LS_CheckValueBuffer(1,2) < ParkingStruct.LS_CheckValueBuffer(2,2) && ParkingStruct.LS_CheckValueBuffer(2,2) < ParkingStruct.LS_CheckValueBuffer(3,2) ...
                    && abs(ParkingStruct.LS_CheckValueBuffer(3,2) - ParkingStruct.AVGInit2(2)) > (ParkingStruct.MAG_thresh / single(2)))  ...
                    || (ParkingStruct.LS_CheckValueBuffer(1,3) > ParkingStruct.LS_CheckValueBuffer(2,3) && ParkingStruct.LS_CheckValueBuffer(2,3) > ParkingStruct.LS_CheckValueBuffer(3,3) ...
                    && abs(ParkingStruct.LS_CheckValueBuffer(3,3) - ParkingStruct.AVGInit2(3)) > (ParkingStruct.MAG_thresh / single(2)))   ...
                    || (ParkingStruct.LS_CheckValueBuffer(1,3) < ParkingStruct.LS_CheckValueBuffer(2,3) && ParkingStruct.LS_CheckValueBuffer(2,3) < ParkingStruct.LS_CheckValueBuffer(3,3) ...
                    && abs(ParkingStruct.LS_CheckValueBuffer(3,3) - ParkingStruct.AVGInit2(2)) > (ParkingStruct.MAG_thresh / single(2)))  )


%                 1;
%                 ParkingStruct.LS_CheckValueBuffer     = zeros(3,3,'single'); 
%                 ParkingStruct.LS_Count                = uint32(0);            

                ParkingStruct.Context_Input = uint8(1);
                ParkingStruct = Parking_structure_reset(ParkingStruct);   % reset the calibration FLAG == 0  for re-calibration


            % case of one of the mag value in buffer trigger the 1.5nT threshold    
            elseif ParkingStruct.LS_CheckValueBuffer(1,1) ~= single(0) ...
                    && (  (abs(min(ParkingStruct.LS_CheckValueBuffer(:,1)) - ParkingStruct.AVGInit2(1)) > (ParkingStruct.MAG_thresh / single(2)) ...
                         && max(ParkingStruct.LS_CheckValueBuffer(:,1)) - min(ParkingStruct.LS_CheckValueBuffer(:,1)) < ParkingStruct.MAG_thresh/ single(2)) ...
                    || (abs(min(ParkingStruct.LS_CheckValueBuffer(:,2)) - ParkingStruct.AVGInit2(2)) > (ParkingStruct.MAG_thresh / single(2)) ...
                         && max(ParkingStruct.LS_CheckValueBuffer(:,2)) - min(ParkingStruct.LS_CheckValueBuffer(:,2)) < ParkingStruct.MAG_thresh/ single(2)) ...
                    || (abs(min(ParkingStruct.LS_CheckValueBuffer(:,3)) - ParkingStruct.AVGInit2(3)) > (ParkingStruct.MAG_thresh / single(2)) ...
                         && max(ParkingStruct.LS_CheckValueBuffer(:,3)) - min(ParkingStruct.LS_CheckValueBuffer(:,3)) < ParkingStruct.MAG_thresh/ single(2)) ...                   
                    || (abs(max(ParkingStruct.LS_CheckValueBuffer(:,1)) - ParkingStruct.AVGInit2(1)) > (ParkingStruct.MAG_thresh / single(2)) ...
                         && max(ParkingStruct.LS_CheckValueBuffer(:,1)) - min(ParkingStruct.LS_CheckValueBuffer(:,1)) < ParkingStruct.MAG_thresh/ single(2)) ...
                    || (abs(max(ParkingStruct.LS_CheckValueBuffer(:,2)) - ParkingStruct.AVGInit2(2)) > (ParkingStruct.MAG_thresh / single(2)) ...
                         && max(ParkingStruct.LS_CheckValueBuffer(:,2)) - min(ParkingStruct.LS_CheckValueBuffer(:,2)) < ParkingStruct.MAG_thresh/ single(2)) ...
                    || (abs(max(ParkingStruct.LS_CheckValueBuffer(:,3)) - ParkingStruct.AVGInit2(3)) > (ParkingStruct.MAG_thresh / single(2)) ...
                         && max(ParkingStruct.LS_CheckValueBuffer(:,3)) - min(ParkingStruct.LS_CheckValueBuffer(:,3)) < ParkingStruct.MAG_thresh/ single(2)) )




                ParkingStruct.Context_Input = uint8(1);
                ParkingStruct = Parking_structure_reset(ParkingStruct);   % reset the calibration FLAG == 0  for re-calibration






            end 

          end



    end


end


%         end


    %     fprintf('Results from Algo1: %d \n\n', ParkingStruct.car_presentCur2);
        fprintf('Results from Algo2: %d \n\n', ParkingStruct.car_presentCur);


%        magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
       MEAN_value(i,1) = ParkingStruct.AVG;
       STD_value(i,1)  = ParkingStruct.STD;

       MEAN_value2(i,:) = ParkingStruct.AVG2;
       
       RMS_value(i,1) = ParkingStruct.RMS;


       moving_avg(i,1)=ParkingStruct.moving_avg;


       car_state(i,:) = [ParkingStruct.car_presentCur];
       car_state2(i,:) = [ParkingStruct.car_presentCur2];
       
       Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG; 
       
       SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;

    
end





% for i = 10:29        %% 18:37 -test1         9:28 - test2
%     
% 
%    ParkingStruct = Calibration_process(ParkingStruct, mraw(i,:));
% 
%     
% end
% 
% 
% ParkingStruct.NUM = 21;
% 
% HS_FLAG = 1;
% 
% for i = 30:N3             % 38:N3 - test1         29:N3 -test2
%     
%     
%     if i == 767
%         1;
%     end
%     
% 
%        
% if ParkingStruct.LS_Trigger_FLAG  == uint8(1) && ( LSHS(i) == 8 ||   (LSHS(i) == 24 && LSHS(i-1) == 8) )           %% time(i)-time(i-1) < 0.5
% 
% 
%     ParkingStruct.LS_Trigger_FLAG     = uint8(0);
% 
%     ParkingStruct.LS_TO_HS_FLAG       = uint8(1);                 
%     ParkingStruct.LS_TO_HS_FLAG2      = uint8(1); 
% 
% 
%     ParkingStruct.Car_State_last_HS   = ParkingStruct.car_presentCur;
% 
%     ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);
% 
% 
% %             ParkingStruct = Parking_Algorithm(ParkingStruct, data);
% 
% 
% 
% elseif ParkingStruct.LS_Trigger_FLAG  == uint8(0)
% 
% 
%     ParkingStruct = Parking_Algorithm2(ParkingStruct, mraw(i,:));
% 
% 
% 
% end
% 
% 
%         fprintf('Results from Algo2: %d \n\n', ParkingStruct.car_presentCur);
% 
% 
% %        magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
%        MEAN_value(i,1) = ParkingStruct.AVG;
%        STD_value(i,1)  = ParkingStruct.STD;
% 
%        MEAN_value2(i,:) = ParkingStruct.AVG2;
% 
% 
%        moving_avg(i,1)=ParkingStruct.moving_avg;
% 
% 
%        car_state(i,:) = [ParkingStruct.car_presentCur]; 
%        Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG; 
%        
%        RMS_value(i,1) = ParkingStruct.RMS;
%        
% 
%     
% end










figure;
% subplot(4,1,1); plot(time,magNdata),title('absolute mag'); grid on;
subplot(3,1,1); plot(time,MEAN_value),title('MEAN'); grid on;
subplot(3,1,2); plot(time,STD_value),title('STD'); grid on;
subplot(3,1,3); plot(time,Alarm_level),title('Alarm Trigger Level'); grid on;



figure;
subplot(3,1,1); plot(time,moving_avg),title('Feature: Magnetic Counts Change');  grid on;
subplot(2,1,1); plot(time,car_state),title('Parking States from MATLAB'); grid on; 
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
% xlabel('Time (Seconds)');



subplot(2,1,2); plot(time,SentralOutput),title('Parking States from SENtral'); grid on;
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
xlabel('Time (Seconds)');






% subplot(4,1,4); plot(time,detection_output),title('Theshold Detection'); grid on;
% set(gca,'YTick',0:3);
% labels = [
%         'Under Thresh   ';
%         'Over Thresh (t)';
%         'Over Thresh (s)';
%         'Anomaly        ';
%         ];
% set(gca,'YTickLabel',labels)