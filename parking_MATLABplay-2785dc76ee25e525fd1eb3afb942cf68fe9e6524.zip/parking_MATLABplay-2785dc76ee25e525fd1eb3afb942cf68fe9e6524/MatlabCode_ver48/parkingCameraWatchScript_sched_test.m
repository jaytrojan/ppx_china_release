%%% Parking Lot Watch script
% clear; %clc;
% dbstop if error

camLocalStore = '..\..\Data\cameraLocal\';
lotDir = 'FrontLot\';
filename = 'frontLotImage';
fmt = 'tif';
urlStr = 'https://parking-dev.pnicloud.com/images/parking_lot_images/?p=ouhwhcS4jExwYzhdn';

% urlStr = 'parkImage.tiff';
% filename0 = 'parkingImage.jpg';
% urlwrite(urlStr,filename0);
% A = imread(filename);

% dstrInit = '19-Dec-2017 06:33:00'
% while datetime(now,'InputFormat','dd-MM-yyyy HH:mm:ss') - datetime(dstrInit,'ConvertFrom','dd-MM-yyyy HH:mm:ss')
%     pause(1)
% end
% fprintf('lkjdsjlfds')


%%% wait delay before start (seconds)
% twait2Start = 12*3600; % seconds to wait
% twaitDelay = 60;
%
% twait2Start = 1; % seconds to wait
% twaitDelay = 1;

% t0 = tic;
% while toc(t0) < twait2Start
%     pause(twaitDelay); % check once per minute
% %     disp('waiting...')
% end
disp('Initializing Camera Logging...')
datestr(now)

dayLightCheck = 1; % log during daylight (1hr before and after)
% {tstart logging,   t stop logging}
% tSchedList = {...
%     '15-Jan-2018 06:00:00', '15-Jan-2018 23:00:00'
%     };
tlogTimes = [6 24]; % only used if not daylight option

%%% date start stop
% times will be all daylight workday hours in this date range
tSchedList = {...
    '15-Jan-2018', '31-Jan-2018'
    };

long = -122.7;                                     % longitude
lat  = 38.4404;                                    % latitude
UTCoff = -8;                                       % UTC offset
% d = datetime('now');
% doy = day(d,'dayofyear');
% sunRiseSetTimes = sunRiseSet(long,lat,UTCoff,doy);

%%% Initialize Loop
% 1 image per minute
% 60 images per file
figure(1); clf;
saveImages = 1;
forceSaveDups = 0; % will save every load regardless if still old
imcnt = 0;

% 1 minute page updates
imcntLim = 60;
tint1 = 60; % nominal interval between saves (sec)
tint2 = 10; % guard interval between saves (sec) in case inerval is just missed

ilist=1;
tstartStr = tSchedList{ilist,1};
tstopStr = tSchedList{ilist,2};
t0 = datetime(tstartStr);
t1 = datetime(tstopStr);
dDays = (t0:t1)';
doweek = day(dDays,'dayofweek'); % starts Sunday
busDays = doweek >= 2 & doweek <= 6;
dDays = dDays(busDays);

% YY = year(dTime);
% MM = month(dTime);
% dTime = datetime(dStr);
% dFirst = 1;
% dLast = eomday(YY,MM);
% DDD = (dFirst:dLast)';
% n = length(DDD);
% YYY = repmat(YY,n,1);
% MMM = repmat(MM,n,1);
% tMonth = datetime(YY,MM,DDD);
% doweek = day(dTime,'dayofweek');

% % % % test
% % % forceSaveDups = 1; % will save every load regardless if still old
% % % imcntLim = 5;
% % % tint1 = 1; % nominal interval between saves (sec)
% % % tint2 = 1; % guard interval between saves (sec) in case interval is just missed

%     tstartLog = datetime('21-Dec-2017 17:30:00');

%%% Open FTP
% close(ftpObj)
ftpObj = ftp('download.pnicorp.com','wdWYsnRPIB','CvjMMsjDlp');
%                         cd(ftpObj, '/share/AMC000XK_Q5654C');
%                         cd(ftpObj, '2018-01-17/001/jpg/19/47');
%                         cd(ftpObj, '../../../../../'); % back to share/cam
%                         cd(ftpObj) % display current folder 
%                         mget(ftpObj,'54[R][0@0][0].jpg','testJPG.jpg') 

for ilist = 1:length(dDays)
    
    t0 = dDays(ilist);
    
    if dayLightCheck
        doy = day(t0,'dayofyear');
        sunRiseSetTimes = sunRiseSet(long,lat,UTCoff,doy);
        
        hh0 = floor(sunRiseSetTimes(1));
        mm = round((sunRiseSetTimes(1)- hh0)*60);
        hh = hh0 - 1; % start 1 hr before sunrise
        tstartLog = datetime(year(t0),month(t0),day(t0),hh,mm,0);
        
        hh0 = floor(sunRiseSetTimes(2));
        mm = round((sunRiseSetTimes(2)- hh0)*60);
        hh = hh0 + 1; % stop 1 hr after sunrise
        tstopLog = datetime(year(t0),month(t0),day(t0),hh,mm,0);
    else
        tstartLog = datetime(year(t0),month(t0),day(t0),tlogTimes(1),0,0);
        tstopLog  = datetime(year(t0),month(t0),day(t0),tlogTimes(2),0,0);
    end
    
    
    testingFlag = 1;
    
    dstrDirFormat = 'mmmyyyy';
    while testingFlag
        tnow = datetime(now,'ConvertFrom','datenum');
        %         disp(tnow)
        
        if tnow<tstartLog
            pause(1);
            continue
        elseif  tnow>=tstopLog
            testingFlag = 0;
            pause(1);
            continue
        else
            %             disp('test')
            tstart = now;
            dstrFormatFile = 'yymmdd-HHMMSS';
            tstrStart = datestr(tstart,dstrFormatFile);
            tstr = tstrStart;
            
            fprintf('Logging Camera for Day: '); disp(t0)
            timeAy = [];
            
            
            tspace0 = seconds(60);
            t1 = seconds(3); % time increment if tEst is short
            t2 = seconds(5); % time to check short of tEst
            
            
            parkImageLast = [];
            
            tupdateLast = datetime('now') - seconds(0); % initial guess at last update time
            tRef = datetime('now') - tspace0; % prev time
            tEst = tRef + tspace0+t2;
            disp([ datestr(tRef,'HH:MM:SS.fff') '     ' datestr(tEst,'HH:MM:SS.fff')]);
            tupdate = datetime('now');
            
            while saveImages && tnow<tstopLog
                tnow = datetime(now,'ConvertFrom','datenum');
                %                 disp(tnow);
                
                dateStrDir = datestr(tstart,dstrDirFormat); % dif dir every month
                
                saveDir = [logPath lotDir dateStrDir '\'];
                if ~isdir(saveDir), mkdir(saveDir); end
                
                
                % wait for it
                while tupdate <(tEst - t2)
                    pause(0.5);
                    tupdate = datetime('now');
                end
                
                readFlag = 0;
                for itry=1:5
                    try
                        % try several times before giving up
%                         parkImage = imread(urlStr);
                        
                        % ftp image file load when available
                        dirListS = []; loopcnt = 0;
                        while isempty(dirListS)
                            tgmt = datetime('now') + hours(8); % gmt (utc) time
                            dstrFormat = 'yyyy-mm-dd';
                            tstrStart = datestr(tgmt,dstrFormat);
                            targDir = [tstrStart '/001/jpg/'];
                            
                            cd(ftpObj, '/share/AMC000XK_Q5654C'); % front parking lot camera
                            cd(ftpObj, targDir);
                            
                            % last dir
                            dirListS = dir(ftpObj);
                            dirListName = {dirListS.name};
                            [dirListName, inds] = sort(dirListName);
                            dirListIsdir = [dirListS.isdir];
                            dirListIsdir = dirListIsdir(inds); % now sortedd, last at end
                            dirListName = dirListName(dirListIsdir);
                            
                            dirLast1 = dirListName{end};
                            cd(ftpObj, dirLast1);
                            
                            % last dir
                            dirListS = dir(ftpObj);
                            dirListName = {dirListS.name};
                            [dirListName, inds] = sort(dirListName);
                            dirListIsdir = [dirListS.isdir];
                            dirListIsdir = dirListIsdir(inds); % now sortedd, last at end
                            dirListName = dirListName(dirListIsdir);
                            
                            dirLast2 = dirListName{end};
                            cd(ftpObj, dirLast2);
                            
                            dirListS = dir(ftpObj);
                            loopcnt = loopcnt+1;
                            disp([num2str(loopcnt) '  dir ' dirLast2])
                            pause(1)
                        end
                        disp(dirListS)
                        mget(ftpObj,dirListS.name,camLocalStore);
                        
                        
                        parkImage = imread([camLocalStore dirListS.name]);
                        parkImage = imageResizeInterp(parkImage,0.40);
                        
                        tupdate = datetime('now');
                        readFlag = 1;
                        break
                    catch
                        pause(1);
                    end
                end
                if ~readFlag
                    disp('read error')
                    break;
                end
                
                
                newImageFlag = isempty(parkImageLast) || (~isempty(parkImageLast) && sum(sum(sum(abs(parkImageLast - parkImage)))));
                newImageFlag
                
                tEstErr1 = seconds(tEst - tupdate);
                tEstErr2 = seconds((tEst-tRef) - tspace0);
                if newImageFlag
                    disp([ datestr(tRef,'HH:MM:SS.fff') '     ' datestr(tEst,'HH:MM:SS.fff') '     ' num2str(seconds(tEst-tRef))  '     ' num2str((tEstErr2)) ]);
                    tRef = tupdate;
                    tEst = tRef - seconds(tEstErr2) + tspace0;
                    %                         parkImageLast = parkImage;
                    tupdateLast = tupdate;
                else
                    disp([ datestr(tRef,'HH:MM:SS.fff') '     ' datestr(tEst,'HH:MM:SS.fff') '     ' num2str(seconds(tEst-tRef))  '     ' num2str((tEstErr2)) ]);
                    tEst = tEst + t1;
                end
                
                if newImageFlag || forceSaveDups
                    % only do stuff if new image
                    
                    timeAy = [timeAy; tupdate];
                    
                    % display image
                    image(parkImage);
                    
                    
                    %%% save image
                    writeFlag = 0;
                    for itry=1:5
                        try
                            %                             % try several times before giving up
                            %                             imwrite(parkImage,[logPath filename tstr '.' fmt], 'WriteMode', 'append');
                            
                            % jpg compression about 5-6 times less memory
                            imwrite(parkImage,[saveDir filename tstr '.' fmt], 'Compression', 'jpeg', 'RowsPerStrip',64, 'WriteMode', 'append');
                            
                            writeFlag = 1;
                            break
                        catch
                            pause(2);
                        end
                    end
                    
                    
                    if writeFlag
                        %%% save date/time data
                        writeFlag = 0;
                        for itry=1:5
                            try
                                % try several times before giving up
                                save([saveDir filename tstr '_time'],'timeAy');
                                writeFlag = 1;
                            catch
                                pause(1);
                            end
                        end
                    end
                    
                    %         fileinfo = dir([filename tstr '.' fmt]);
                    %         filesize = fileinfo(1).bytes;
                    if writeFlag
                        % normal write successful
                        imcnt = imcnt+1;
%                         tint = tint1;
                        parkImageLast = parkImage;
                    else
                        % Error: write unsuccesful
                        % force new log creation at new time
                        imcnt = imcntLim;
%                         tint = tint2; % shorter time
                    end
                    if imcnt>=imcntLim
                        % start new file
                        tstart = now;
                        tstr = datestr(tstart,dstrFormatFile);
                        imcnt=0;
                        timeAy = [];
                    end
                    
                    if writeFlag
                        try
                            delete([camLocalStore '*.jpg'])
                        catch
                        end
                    end
                    
                else
%                     tint = tint2; % if no image wait shorter time
                end
                
                %                 pause(tint);
                
            end
        end
    end
end


% save([filename tstrStart],'timeAy')
aaa=999;

% info = imfinfo(filename);
% imwrite(im1, 'myfile.tif');
% imwrite(im2, 'myfile.tif', 'WriteMode', 'append');