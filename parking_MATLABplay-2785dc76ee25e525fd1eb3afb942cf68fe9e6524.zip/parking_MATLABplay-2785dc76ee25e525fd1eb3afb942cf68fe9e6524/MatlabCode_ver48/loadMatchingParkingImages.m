function parkImageShow = loadMatchingParkingImages(parkImageShow,camDir,servTime)

imageStructAy = loadImageTimeData(camDir,servTime);

%%% id images matching server times
imStart = 1; ipage = 0;
dateTimeAyAy = []; % covers all times in imageStructAy in one long array list
for im=1:length(imageStructAy)
    dateTimeAy = imageStructAy(im).dateTimeAy;
    
    ipage = ipage+1;
    pageTrack = repmat(ipage,length(dateTimeAy),1);
    if isempty(dateTimeAyAy)
        dateTimeAyAy = dateTimeAy;
        pageTrackAyAy = pageTrack;
    else
        dateTimeAyAy = [dateTimeAyAy; dateTimeAy];
        pageTrackAyAy = [pageTrackAyAy; pageTrack];
    end
end

% for each servtime, find closest in image times
if ~isempty(dateTimeAyAy)
    tpad = 120; % seconds of padding for time matching
    imageTimeTrack = NaT(length(servTime),1,'Format','dd-MMM-yyyy HH:mm:ss');
    imageIndsTrack = zeros(length(servTime),2); % [page ind]
    for ist = 1:length(servTime)
        inds = find(dateTimeAyAy >= servTime(ist)-seconds(tpad) & dateTimeAyAy <= servTime(ist)+seconds(tpad));
        if ~isempty(inds)
            minInd = inds(end); % pick later match since image load time can be delayed
            %                     minInd = round(mean(inds));
        else
            [minVal, minInd] = min(abs(dateTimeAyAy - servTime(ist)));
        end
        ipage = pageTrackAyAy(minInd(1));
        %                 [minVal, iInd] = min(abs(imageStructAy(ipage).dateTimeAy - servTime(ist)));
        inds = find(imageStructAy(ipage).dateTimeAy >= servTime(ist)-seconds(tpad) & imageStructAy(ipage).dateTimeAy <= servTime(ist)+seconds(tpad));
        imageFlag = true;
        if ~isempty(inds)
            if length(inds)<3
                iInd = inds(end); % pick later match since image load time can be delayed
            else
                iInd = inds(round(0.7*length(inds))); % weighting towards later
            end
        elseif ist==1 % first
            inds = find(imageStructAy(ipage).dateTimeAy <= servTime(ist)+seconds(tpad),1,'first');
            if isempty(inds)
                imageFlag = false;
            else
                iInd = inds(1);
            end
        elseif ist==length(servTime) % last case
            inds = find(imageStructAy(ipage).dateTimeAy >= servTime(ist)-seconds(tpad),1,'first');
            if isempty(inds)
                imageFlag = false;
            else
                iInd = inds(1);
            end
        else
            %                     [minVal, iInd] = min(abs(imageStructAy(ipage).dateTimeAy - servTime(ist)));
            imageFlag = false;
        end
        if imageFlag
            imageTimeTrack(ist,:) = imageStructAy(ipage).dateTimeAy(iInd);
            imageIndsTrack(ist,:) = [ipage iInd];
        else
            imageTimeTrack(ist,:) = NaT;
            imageIndsTrack(ist,:) = [nan nan];
        end
    end
    parkImageShow.servTime = servTime;
    parkImageShow.imageStructAy = imageStructAy;
    parkImageShow.imageTimeTrack = imageTimeTrack;
    parkImageShow.imageIndsTrack = imageIndsTrack;
end

% % init figure
% if parkImageShow.on
%     figure(parkImageShow.figN); clf
%     hax = axes;
%     parkImageShow.hax = hax;
%     
%     for ifig = 1:length(parkImageShow.cursFigs)
%         dcm_obj4 = datacursormode(parkImageShow.cursFigs(ifig));
%         set(dcm_obj4,'UpdateFcn',@dispMkrTimeImageFcn);
%     end
% end

%%% >>> load parking camera images
