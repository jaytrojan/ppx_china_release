function ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct)


%% save current mag related info for cloud (if cloud request)
%
% ParkingStruct.AVGSUM_LAST              = ParkingStruct.AVGSUM;
% ParkingStruct.AVGSUM2_LAST             = ParkingStruct.AVGSUM2;
% ParkingStruct.state1_count_LAST        = ParkingStruct.state1_count;
% ParkingStruct.state3_count_LAST        = ParkingStruct.state3_count;





ParkingStruct.dataBuffer          = zeros(8,1,'single');
ParkingStruct.dataBuffer2         = zeros(8,3,'single');

ParkingStruct.dx_history          = zeros(8,1,'single');




%% reset for absolute mag-based algorithm

% % % % % ParkingStruct.dataBuffer              = zeros(8,1,'single');

ParkingStruct.state1_count            = uint16(0);
ParkingStruct.state2_count            = uint16(0);
ParkingStruct.state3_count            = uint16(0);
ParkingStruct.state4_count            = uint16(0);

ParkingStruct.SecondSensor_Req_FLAG_count = uint8(0);


% % % ParkingStruct.AVGSUM                  = single(0);



ParkingStruct.car_presentCur          = ParkingStruct.car_present;
ParkingStruct.car_presentPre          = ParkingStruct.car_present;

ParkingStruct.car_presentBuffer       = ones(4,1,'uint8') *ParkingStruct.car_present;
ParkingStruct.car_presentBufferCount  = zeros(4,1,'uint8');

ParkingStruct.LS_TO_HS_FLAG           = uint8(0);

ParkingStruct.K2                      = uint8(0);
ParkingStruct.SUM                     = single(0) ;    % sum
ParkingStruct.SUMSq                   = single(0);     % sum square


ParkingStruct.AVGSUM2                 = zeros(1,3,'single');
% ParkingStruct.SUM2                    = zeros(1,3,'single');
% % % % % % % ParkingStruct.dataBuffer2             = zeros(8,3,'single');


% ParkingStruct.SUM2                    = zeros(1,3,'single');
% ParkingStruct.SUMSq2                  = zeros(1,3,'single');
% ParkingStruct.STD2                    = zeros(1,3,'single');


% ParkingStruct.SUMXY                  = single(0) ;
% ParkingStruct.SUMSqXY                = single(0) ;
% ParkingStruct.STDXY                  = single(0) ;
%
% ParkingStruct.dataBufferXY           = zeros(8,1,'single');


%% reset for phase-based algorithm

% % % % % % % % % ParkingStruct.dx_history              = zeros(8,1,'single');



%%%%% moving average on magnitude (X+Y+Z)
% turn off local average reset to allow first meas in dx_hist to be relative to previous HS
ParkingStruct.local_avg               = single(0);

ParkingStruct.moving_avg              = single(0);


% %%%%% moving average on X/Y/Z axis seperately
% ParkingStruct.local_avg2              = zeros(1,3,'single');
% ParkingStruct.moving_avg2             = zeros(1,3,'single');
% ParkingStruct.dx_history2             = zeros(8,3,'single');


% %%%%% moving average on magnitude (X+Y) only
% ParkingStruct.local_avgXY             = single(0);
% ParkingStruct.moving_avgXY            = single(0);
% ParkingStruct.dx_historyXY            = zeros(8,1,'single');



ParkingStruct.state1_count2           = uint16(0);
ParkingStruct.state2_count2           = uint16(0);
ParkingStruct.state3_count2           = uint16(0);
ParkingStruct.state4_count2           = uint16(0);


ParkingStruct.car_presentBuffer2      = ones(4,1,'uint8')*ParkingStruct.car_present2;
% ParkingStruct.car_presentBufferCount2 = zeros(4,1,'uint8');


ParkingStruct.car_presentCur2         = ParkingStruct.car_present2;
ParkingStruct.car_presentPre2         = ParkingStruct.car_present2;

ParkingStruct.LS_TO_HS_FLAG2          = uint8(0);



% ParkingStruct.RMSFLAG                 = uint8(0);

ParkingStruct.LastTransitionState     = uint8(0);

% ParkingStruct.LS_CheckValueBuffer     = zeros(3,3,'single');
% ParkingStruct.LS_Count                = uint32(0);

ParkingStruct.BLE_Trigger_Enable        = uint8(1);


ParkingStruct.middleState_count     = uint16(0);  %%% number of sample in [thresholdUp >  STD >thresholdDown]


ParkingStruct.TransitionState_count        = uint16(0);
ParkingStruct.TransitionState_count2       = uint16(0);

% ParkingStruct.Diff_mag_baseline       = zeros(1,3,'single');







end