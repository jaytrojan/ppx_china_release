function [dataAy, dataFldAy] = buildFldData(dataStruct, dataFieldList)

% dataFieldList = {'iSensorID'  'iCarStat'  'iTemp'  'iRSSI'   'irx_snr'  'iConf'  'iCarCounter'  'ibattery'  'iData'};

dataFldAyFull = dataStruct.dataFldAy;
% dataFldAyFull = dataStruct.dataAy;

dataAy = []; dataFldAy = [];
for ifld = 1:length(dataFieldList)
    dataFld = dataFieldList{ifld};
    dataFldCells = strfind(dataFldAyFull,dataFld);
    dataFldInds = ~cellfun(@isempty,dataFldCells);

    if any(dataFldInds)
        fieldData = dataStruct.dataAy(:,dataFldInds);
        dataFlds = {dataFld};
        dataAy = [dataAy fieldData];
        dataFldAy = [dataFldAy dataFlds];
    end
end
