function filtStruct = stableFilt(filtStruct,mxyz)

% slope/noise filter
% filtStruct
% filt init
% 
%     Nbuf = 40;
%     filtStruct.outRatio = 0.20;
%     filtStruct.outLimit = [0.4  3]; % [min max] of outlier removal
%     
%     filtStruct.Nbuf = Nbuf;
%     filtStruct.mbuf = zeros(Nbuf,3);
%     filtStruct.mstdbuf = zeros(Nbuf,3);
%     filtStruct.mstdClnbuf = zeros(Nbuf,3);
%     filtStruct.ibuf = 0;
%     
%     filtStruct.mmn = [0 0 0];
%     filtStruct.mstd = [0 0 0];
%     filtStruct.mmnCln = [0 0 0];
%     filtStruct.mstdCln = [0 0 0];
%     
%     filtStruct.mstdDelta = [0 0 0];
%     filtStruct.mstdClnDelta = [0 0 0];
%     filtStruct.mstdSlope = [0 0 0];
%     filtStruct.mstdClnSlope = [0 0 0];
%     
%     filtStruct.mslope = [0 0 0];
%     filtStruct.mslopeCln = [0 0 0];
%     
%     filtStruct.mstdPrev = [0 0 0];
%     filtStruct.mstdClnPrev = [0 0 0];
% 
    
% outRatio = 0.20;
% outLimit = [0.4  3]; % [min max] of outlier removal
% Nbuf = 40;
% mbuf = zeros(Nbuf,1);
% mstdbuf = zeros(Nbuf,1); mstdClnbuf = zeros(Nbuf,1);
nmax0 = round(filtStruct.outRatio*filtStruct.Nbuf);


if filtStruct.ibuf<filtStruct.Nbuf
    filtStruct.ibuf = filtStruct.ibuf+1;
    filtStruct.mbuf(filtStruct.ibuf,:) = mxyz;
else
    filtStruct.mbuf = [filtStruct.mbuf(2:end,:); mxyz]; % drop oldest, add new at end
end
mmeas = filtStruct.mbuf(1:filtStruct.ibuf,:);

%%% stats
filtStruct.mmn = mean(mmeas,1);
filtStruct.mstd = std(mmeas,0,1);
filtStruct.mstdDelta = filtStruct.mstd - filtStruct.mstdPrev;

% slope
% filtStruct.mslope = sum(mmeas(2:end,:) - mmeas(1:end-1,:),1)./filtStruct.ibuf; % change per sample
filtStruct.mslope = sum(mmeas(2:end,:) - mmeas(1:end-1,:),1);


%%%%% rem outliers
mdeltaMn = abs(filtStruct.mbuf(1:filtStruct.ibuf,:) - filtStruct.mmn);
% N = filtStruct.ibuf;
validFlags = true(filtStruct.ibuf,1);
indsOut0 = find(mdeltaMn > filtStruct.outLimit(1) & mdeltaMn < filtStruct.outLimit(2));
if ~isempty(indsOut0)
    [mdeltaMnSort, indsSort] = sort(mdeltaMn,'descend'); % indsSort is original index sorting
    if length(indsOut0)<nmax0, nmax = length(indsOut0); else nmax=nmax0; end
    indsOut = indsSort(1:nmax);
    validFlags(indsOut,:) = false;
end

%%% stats
mmeasCln = filtStruct.mbuf(validFlags,:);
filtStruct.mmnCln = mean(mmeasCln,1);
filtStruct.mstdCln = std(mmeasCln,0,1);


%%% weighted stats
Nbuf = filtStruct.Nbuf;
outLimWt = single(0.667*filtStruct.outLimit(2)); % wt to outlim2, then wt=0;
% outLimWt = single(1*filtStruct.outLimit(1)); % wt to outlim2, then wt=0;
wtFlags = ~validFlags;
% wtFlags = logical(0*wtFlags);
w = ones(Nbuf,3,'single');
mdOut0 = mdeltaMn(wtFlags,:);
% mdOut0 = [0.5; 1; 2; 3.5;4];
mdOut1 = (mdOut0 - filtStruct.outLimit(1))./outLimWt;
flagsOutOut = mdOut0>outLimWt;
wout = (1-mdOut1).^2;
wout(flagsOutOut) = 0;
w(wtFlags,:) = wout;
wadj = Nbuf./sum(w,1);
w2 = w .* repmat(wadj,Nbuf,1);
sum(w2,1)
mmeasCln = filtStruct.mbuf;

% weighted mean
filtStruct.mmnCln = sum(mmeasCln.*w2,1)/Nbuf;
mstdCln = sqrt(sum(w2.*((mmeasCln - repmat(filtStruct.mmnCln,Nbuf,1)).^2),1)./(Nbuf-1));
   
    

filtStruct.mstdClnDelta = filtStruct.mstdCln - filtStruct.mstdClnPrev;
% filtStruct.mslopeCln = sum(mmeasCln(2:end,:) - mmeasCln(1:end-1,:),1)./filtStruct.ibuf; % change per sample
filtStruct.mslopeCln = sum(mmeasCln(2:end,:) - mmeasCln(1:end-1,:),1);


%%% track full buf moving measurements
% these meas will include effect of previous buffer length in the result,
% so will have a latency. But should be smoother

% moving std
if filtStruct.ibuf<filtStruct.Nbuf
    filtStruct.mstdbuf(filtStruct.ibuf,:) = filtStruct.mstd;
else
    filtStruct.mstdbuf = [filtStruct.mstdbuf(2:end,:); filtStruct.mstd]; % drop oldest, add new at end
end
mstdmeas = filtStruct.mstdbuf(1:filtStruct.ibuf,:);
% filtStruct.mstdMoveSlope = sum(mstdmeas(2:end,:) - mstdmeas(1:end-1,:),1)./filtStruct.ibuf; % change per sample
filtStruct.mstdMoveSlope = sum(mstdmeas(2:end,:) - mstdmeas(1:end-1,:),1);

% moving std Cln
if filtStruct.ibuf<filtStruct.Nbuf
    filtStruct.mstdClnbuf(filtStruct.ibuf,:) = filtStruct.mstdCln;
else
    filtStruct.mstdClnbuf = [filtStruct.mstdClnbuf(2:end,:); filtStruct.mstdCln]; % drop oldest, add new at end
end
mstdmeasCln = filtStruct.mstdClnbuf(1:filtStruct.ibuf,:);
% filtStruct.mstdMoveClnSlope = sum(mstdmeasCln(2:end,:) - mstdmeasCln(1:end-1,:),1)./filtStruct.ibuf; % change per sample
filtStruct.mstdMoveClnSlope = sum(mstdmeasCln(2:end,:) - mstdmeasCln(1:end-1,:),1); 

% moving slope Cln
if filtStruct.ibuf<filtStruct.Nbuf
    filtStruct.mslopeClnbuf(filtStruct.ibuf,:) = filtStruct.mslopeCln;
else
    filtStruct.mslopeClnbuf = [filtStruct.mslopeClnbuf(2:end,:); filtStruct.mslopeCln]; % drop oldest, add new at end
end
mslopemeasCln = filtStruct.mslopeClnbuf(1:filtStruct.ibuf,:);
% filtStruct.mslopeMoveClnSlope = sum(mslopemeasCln(2:end,:) - mslopemeasCln(1:end-1,:),1)./filtStruct.ibuf; % change per sample
filtStruct.mslopeMoveClnMn = mean(mslopemeasCln,1); % average slope


filtStruct.mstdPrev = filtStruct.mstd;
filtStruct.mstdClnPrev = filtStruct.mstdCln;

