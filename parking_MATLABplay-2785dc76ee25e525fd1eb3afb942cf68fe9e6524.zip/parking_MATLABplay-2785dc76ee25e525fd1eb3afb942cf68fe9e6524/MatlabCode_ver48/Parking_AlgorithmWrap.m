function [ParkingStruct, filtStruct] = Parking_AlgorithmWrap(ParkingStruct, filtStruct, data, timestamp, AlarmSourceFLAG)

ParkingStruct.time                              = single(timestamp);

ParkingStruct.multipleCarsFLAG                  = uint8(0);
ParkingStruct.multipleCarsFLAG_DriveThru        = uint8(0);     %%% aggressive drive thru detection FLAG




%%  &&&&&&&&&&&&& Hardware Alarm Mode  -- trigger HS mode in hardware    &&&&&&&&&&&&
% if AlarmSourceFLAG

    if ParkingStruct.Context_Input == uint8(1)  % context input in NO CAR state  -- Re-calibration

        if ~ParkingStruct.Reset_FLAG
            ParkingStruct = Parking_structure_reset(ParkingStruct);
        end

        if ParkingStruct.LS_Trigger_FLAG  == uint8(0)
%             ParkingStruct = Calibration_process(ParkingStruct, data);
            [ParkingStruct, filtStruct] = Calibration_process(ParkingStruct, filtStruct, data);
        end

        %         ParkingStruct.Calibration_Delay_FLAG     = uint8(0);


    elseif ParkingStruct.Context_Input == uint8(3)  % context input in CAR parked state

        ParkingStruct.car_present      = uint8(3);
        ParkingStruct.car_present2     = uint8(3);


        %%%%%%%%%
        % update 5/17

        if AlarmSourceFLAG
            %%%%% baseline update
            ParkingStruct.LS_StartValue               = ParkingStruct.AVGInit2;
            ParkingStruct.LS_StartValue_state1        = ParkingStruct.AVGInit2;  %% rewrite local baseline (force local baseline (state 1 baseline) == initial baseline
            ParkingStruct.LS_StartValue_state3        = single(data);            %% current mag value as state 3 baseline
        end

        ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);


        ParkingStruct.Context_Input    = uint8(0);    % RESET context input
        ParkingStruct.LS_Trigger_FLAG  = uint8(1);    % trigger the Alarm: back to low speed mode

        %         ParkingStruct.Calibration_Delay_FLAG     = uint8(1);



    elseif ParkingStruct.Context_Input == uint8(5)  % context input for HS trigger threshold adjustment request

        ParkingStruct.K2                             = ParkingStruct.K2 + uint8(1);
        ParkingStruct.dataBuffer2(ParkingStruct.K2,:)= single(data);


        if ParkingStruct.K2 == ParkingStruct.dataBufferTCSize


            STDx = Parking_std(ParkingStruct.dataBuffer2(1:ParkingStruct.dataBufferTCSize,1),ParkingStruct.dataBufferTCSize);
            STDy = Parking_std(ParkingStruct.dataBuffer2(1:ParkingStruct.dataBufferTCSize,2),ParkingStruct.dataBufferTCSize);
            STDz = Parking_std(ParkingStruct.dataBuffer2(1:ParkingStruct.dataBufferTCSize,3),ParkingStruct.dataBufferTCSize);


            %%%% updating LS_StartValue(defining the next HS mode trigger threshold = LS_StartValue +/- 3uT)
            %%%% updating value only when the mag data in dataBufferTC  is stable (no car event or noise)
            if STDx < ParkingStruct.STD_threshDown && STDy < ParkingStruct.STD_threshDown && STDz < ParkingStruct.STD_threshDown

                ParkingStruct.LS_StartValue = mean(ParkingStruct.dataBuffer2(1:ParkingStruct.dataBufferTCSize,:));

                %%%% updating local baseline
                if ParkingStruct.LocalBaseline_Update_Enable && ParkingStruct.car_present == uint8(1)

                    ParkingStruct.LS_StartValue_state1 = ParkingStruct.LS_StartValue;

                elseif ParkingStruct.LocalBaseline_Update_Enable && ParkingStruct.car_present == uint8(3)

                    ParkingStruct.LS_StartValue_state3 = ParkingStruct.LS_StartValue;

                end

            end

            ParkingStruct.Context_Input    = uint8(0);    % RESET context input
            ParkingStruct.LS_Trigger_FLAG  = uint8(1);    % trigger the Alarm: back to low speed mode

            ParkingStruct.dataBuffer2      = zeros(8,3,'single');
            ParkingStruct.K2               = uint8(0);

        end





        %
        %         ParkingStruct.dataBufferTC      = shifting_array(ParkingStruct.dataBufferTC);
        %         ParkingStruct.dataBufferTC(ParkingStruct.dataBufferTCSize,:)= single(data);
        %
        %
        %         if  all( ParkingStruct.dataBufferTC(1,:) ~= 0)
        %
        %             STDx = Parking_std(ParkingStruct.dataBufferTC(:,1),ParkingStruct.dataBufferTCSize);
        %             STDy = Parking_std(ParkingStruct.dataBufferTC(:,2),ParkingStruct.dataBufferTCSize);
        %             STDz = Parking_std(ParkingStruct.dataBufferTC(:,3),ParkingStruct.dataBufferTCSize);
        %
        %             %%%% updating LS_StartValue(defining the next HS mode trigger threshold = LS_StartValue +/- 3uT)
        %             %%%% updating value only when the mag data in dataBufferTC  is stable (no car event or noise)
        %             if STDx < ParkingStruct.STD_threshDown && STDy < ParkingStruct.STD_threshDown && STDz < ParkingStruct.STD_threshDown
        %
        %                 ParkingStruct.LS_StartValue = mean(ParkingStruct.dataBufferTC);
        %
        %                 %%%% updating local baseline
        %                 if ParkingStruct.LocalBaseline_Update_Enable && ParkingStruct.car_present == uint8(1)
        %
        %                    ParkingStruct.LS_StartValue_state1 = ParkingStruct.LS_StartValue;
        %
        %                 elseif ParkingStruct.LocalBaseline_Update_Enable && ParkingStruct.car_present == uint8(3)
        %
        %                    ParkingStruct.LS_StartValue_state3 = ParkingStruct.LS_StartValue;
        %
        %                 end
        %
        %             end
        %
        %             ParkingStruct.Context_Input    = uint8(0);    % RESET context input
        %             ParkingStruct.LS_Trigger_FLAG  = uint8(1);    % trigger the Alarm: back to low speed mode
        %
        %             ParkingStruct.dataBufferTC     = zeros(4,3,'single');
        %
        %         end










    elseif ParkingStruct.Context_Input == uint8(99)  % context input in NO CAR state  -- Re-calibration

        if ~ParkingStruct.Reset_FLAG

            ParkingStruct = Parking_structure_reset(ParkingStruct);

        end

        if ParkingStruct.LS_Trigger_FLAG  == uint8(0)
            [ParkingStruct, filtStruct] = Calibration_process(ParkingStruct, filtStruct, data);
        end





    else


        if ~ParkingStruct.Calibration_FLAG

            %            if ParkingStruct.HS_startTime == single(0)
            if ~ParkingStruct.Calibration_InitFLAG

                ParkingStruct.HS_startTime          = ParkingStruct.time;
                %                ParkingStruct.HS_startValue         = single(data);


                if ParkingStruct.HS_startTime >=  ParkingStruct.HS_endTime
                    ParkingStruct.HS_totalTimeLS       = (ParkingStruct.HS_startTime - ParkingStruct.HS_endTime)/single(32000);    %%% time interval from last HS mode
                else
                    ParkingStruct.HS_totalTimeLS       = (ParkingStruct.HS_startTime + single(4294967296) - ParkingStruct.HS_endTime)/single(32000);     %%% time interval from last HS mode
                end







                % max-min mag data on X/Y/Z
                ParkingStruct.HS_DataMax            = single(data);
                ParkingStruct.HS_DataMin            = single(data);


                % STD + Moving Avg (magnitude of X+Y+Z)
                ParkingStruct.HS_STDmax             = single(0);              %%% max STD value, magnitude of X+Y+Z
                ParkingStruct.HS_MAmax              = single(0);              %%% max MA value, magnitude of X+Y+Z


                ParkingStruct.Calibration_InitFLAG  = uint8(1);

            end





            [ParkingStruct, filtStruct] = Calibration_process(ParkingStruct, filtStruct, data);



            if ParkingStruct.Calibration_FLAG

                ParkingStruct.HS_endTime           = ParkingStruct.time;
                ParkingStruct.LastTransitionState2 = uint8(5);

                ParkingStruct.HS_Datadiff          = ParkingStruct.HS_DataMax - ParkingStruct.HS_DataMin;


                % if isempty(coder.target)
                %
                %
                %
                %     temp = [single(ParkingStruct.Car_State_last_HS) single(ParkingStruct.car_present) ...
                %         single(ParkingStruct.SecondSensor_Req_FLAG) single(ParkingStruct.LastTransitionState2) ...
                %         ParkingStruct.HS_STDmax ...
                %         ParkingStruct.HS_MAmax ...
                %         ParkingStruct.HS_STDmaxZ ...
                %         ParkingStruct.Diff_mag_baseline ...
                %         ParkingStruct.HS_Datadiff ...
                %         ParkingStruct.HS_Datadiff_baseline1...  %%ParkingStruct.HS_Datadiff_baselineInit ...
                %         ParkingStruct.HS_totalTimeLS...
                %         ParkingStruct.StartNUM...
                %         ParkingStruct.NUM ...
                %         single(ParkingStruct.NumCars_DriveThru) ...
                %         single(ParkingStruct.NumCars_DriveThruPre) ...
                %         single(ParkingStruct.multipleCarsFLAG_DriveThru) ...
                %         single(ParkingStruct.NumCars) ];
                %
                %
                %
                %     ParkingStruct.CloudDataALL                      = [ParkingStruct.CloudDataALL;temp];
                %
                % end

            end



        else


            HStrigCheck = ParkingStruct.LS_Trigger_FLAG  == uint8(1);
            if ~AlarmSourceFLAG
                HStrigCheck = HStrigCheck ...
                    && ((abs(data(1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
                    || (abs(data(2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
                    || (abs(data(3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) );
            end

            if HStrigCheck


                ParkingStruct.LS_Trigger_FLAG        = uint8(0);

                ParkingStruct.LS_TO_HS_FLAG          = uint8(1);
                ParkingStruct.LS_TO_HS_FLAG2         = uint8(1);


                ParkingStruct.Car_State_last_HS      = ParkingStruct.car_presentCur;

                ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);
                ParkingStruct.BLE_Trigger_FLAG       = uint8(0);


                ParkingStruct.BLE_Trigger_PatternPre_FLAG  = uint8(0);
                ParkingStruct.BLE_Trigger_Buffer   = zeros(12,1,'uint8');


                % store baseline meas on entry into HS
%                 filtStruct.baseFilt.baseLineMeas_HSstart = filtStruct.baseFilt.baseLineMeas;



                %%% update 2/6/2017
                %%% values for cloud algorithm
                %                 ParkingStruct.HS_startValue        = single(data);
                ParkingStruct.HS_startTime         = ParkingStruct.time;


                if ParkingStruct.HS_startTime >=  ParkingStruct.HS_endTime
                    ParkingStruct.HS_totalTimeLS       = (ParkingStruct.HS_startTime - ParkingStruct.HS_endTime)/single(32000);    %%% time interval from last HS mode
                else
                    ParkingStruct.HS_totalTimeLS       = (ParkingStruct.HS_startTime + single(4294967296) - ParkingStruct.HS_endTime)/single(32000);     %%% time interval from last HS mode
                end


                %%%% For Nexus6 phone logs ONLY
                %  ParkingStruct.HS_totalTimeLS       = (ParkingStruct.HS_startTime - ParkingStruct.HS_endTime);    %%% time interval from last HS mode




%                 % max-min mag data on X/Y/Z
%                 ParkingStruct.HS_DataMax           = single(data);
%                 ParkingStruct.HS_DataMin           = single(data);


                % STD + Moving Avg (magnitude of X+Y+Z)
                ParkingStruct.HS_STDmax             = single(0);              %%% max STD value, magnitude of X+Y+Z
                ParkingStruct.HS_MAmax              = single(0);              %%% max MA value, magnitude of X+Y+Z

                ParkingStruct.HS_STDmaxZ            = single(0);


                %                 % max-min mag data (magnitude of X+Y+Z)
                %                 ParkingStruct.HS_DataNMax           = single(sqrt(data(1)*data(1)+data(2)*data(2)+data(3)*data(3)));
                %                 ParkingStruct.HS_DataNMin           = ParkingStruct.HS_DataNMax;





                %%%% update on 7/05/2017
                %%%% special case for demo:  add previous LS_StartValue into buffer as the first data for calculation ((adding the previous LS_StartValue as the first data in current HS mode))

                if  bitand(ParkingStruct.DemoFLAG,1)                == uint8(1)

                    ParkingStruct.dataBuffer2      = shifting_array(ParkingStruct.dataBuffer2);
                    ParkingStruct.dataBuffer2(ParkingStruct.dataBufferSize,:)= ParkingStruct.LS_StartValue;

                    data1 = single(sqrt(ParkingStruct.LS_StartValue(1)*ParkingStruct.LS_StartValue(1)...
                        +ParkingStruct.LS_StartValue(2)*ParkingStruct.LS_StartValue(2)+ParkingStruct.LS_StartValue(3)*ParkingStruct.LS_StartValue(3)));

                    ParkingStruct.dataBuffer      = shifting_array(ParkingStruct.dataBuffer);
                    % ParkingStruct.dataBuffer(end) = single(sqrt(ParkingStruct.LS_StartValue(1)*ParkingStruct.LS_StartValue(1)...
                    %     +ParkingStruct.LS_StartValue(2)*ParkingStruct.LS_StartValue(2)+ParkingStruct.LS_StartValue(3)*ParkingStruct.LS_StartValue(3)));
                    ParkingStruct.dataBuffer(end) = data1;


                    % max-min mag data on X/Y/Z
                    ParkingStruct.HS_DataMax           = ParkingStruct.LS_StartValue;
                    ParkingStruct.HS_DataMin           = ParkingStruct.LS_StartValue;


                    %%%% included into STD calculation
                    ParkingStruct.K2       = ParkingStruct.K2 + uint8(1);
                    ParkingStruct.SUM      = ParkingStruct.SUM   + data1 ;             % sum
                    ParkingStruct.SUMSq    = ParkingStruct.SUMSq + data1 * data1;      % sum square



                    %%%%% included into MA calculation
                    ParkingStruct.local_avg      = data1;



                    %%%% shorter response time for DEMO only

                    ParkingStruct.count_thresh               = ParkingStruct.count_threshDEMO;    % reqiures 2 seconds to avoid spike peak in STD (false trigger the state changing)

                    ParkingStruct.State_count_thresh         = ParkingStruct.State_count_threshDEMO;          % reqiures 2 seconds to confirm the correct state (no car OR car parked)
                    ParkingStruct.State_count_thresh_timeout = ParkingStruct.State_count_thresh_timeoutDEMO;  % TIMEOUT: no state change in 2 secods - BACK TO LOW SPEED MODE

                end






                % %%%% update on 7/18/2017 (Jira: PMG-112)
                % %%% knob setting for 3-inch sensor
                % if ParkingStruct.Sensor3Inch               == uint8(1)
                %
                %     ParkingStruct = Parking_structure_3inch(ParkingStruct);
                %
                % end








%                               ParkingStruct = Parking_Algorithm(ParkingStruct, data);
                [ParkingStruct, filtStruct] = Parking_Algorithm(ParkingStruct, filtStruct, data);


            elseif ParkingStruct.LS_Trigger_FLAG  == uint8(0)

%                               ParkingStruct = Parking_Algorithm(ParkingStruct, data);
                [ParkingStruct, filtStruct] = Parking_Algorithm(ParkingStruct, filtStruct, data);

                %                 if ParkingStruct.DriveThruFLAG
                %                     ParkingStruct = Parking_Algorithm_Drive_Thru(ParkingStruct, data);
                %                 else
                %                     ParkingStruct = Parking_Algorithm(ParkingStruct, data);
                %                 end


            end

            %             if ParkingStruct.LS_Trigger_FLAG == uint8(1) && ParkingStruct.Calibration_Delay_FLAG  == uint8(1) ...
            %                     && ParkingStruct.car_presentCur == uint8(1)
            %
            %                 ParkingStruct.Context_Input   = uint8(1);  % context input in NO CAR state  -- Re-calibration
            %                 ParkingStruct.LS_Trigger_FLAG = uint8(0);   % stay in high speed mode
            %
            %             end


        end


    end
% end

