function setSay = loadSettingsStruct(dirName,fileName)

[dataStrArray, hdrArray0] = loadcsvTextCols(dirName,fileName,2,30);

hdrArray = [];
for ii=1:length(hdrArray0)
    hdCell =  hdrArray0{ii}(1);
    if ~isempty(hdCell{1})
        hdrArray = [hdrArray hdCell];
    end
end
Ncols = length(hdrArray);

% build cell data array
dataCellAy = [];
for ii=1:Ncols
    dataCellAy = [dataCellAy dataStrArray{ii}];
end
N = size(dataCellAy,1);

iay = 1:Ncols;

% build data arrays
N = size(dataCellAy,1);
% iay = [iSentralTime iData iRSSI];
dataAy = [];
for ii=1:N
    dline = [];
    for jj=1:length(iay)
        dline=[dline  str2double(cell2mat(dataCellAy(ii,iay(jj))))];
    end
    dataAy=[dataAy;   dline];
end

% find string cols
% anything all nans saved as string
nanCols = all(isnan(dataAy),1);
% dataCellAy(:,nanCols)

% create struct array with col for fields
setSay = [];
for ii=1:N
    for ifld=1:length(hdrArray)
        fldName = hdrArray{ifld};
        %         fldBrk = tokfind(fldName,'.');
        if nanCols(ifld)
            setSay(ii).(fldName) = dataCellAy{ii,ifld};
        else
            [token, remain] = strtok(fldName, '.');
            if ~isempty(remain)
                % sub struct
                eval([fldName ' = dataAy(ii,ifld);']);
                setSay(ii).(token) = eval(token);
            else
                [token, remain] = strtok(fldName, '(');
                if ~isempty(remain)
                    eval([fldName ' = dataAy(ii,ifld);']);
                    setSay(ii).(token) = eval(token);
                else
                    setSay(ii).(fldName) = dataAy(ii,ifld);
                end
            end
        end
    end
end

