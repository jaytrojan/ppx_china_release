function [mraw,time,SentralOutput,raw_rate,markerTimes,markNames] = Read_Data(FileName)

[rawData,~] = xlsread(FileName);


% ****** load raw mag data
midx=find(rawData(:,4)==65538);
midx1=find(rawData(:,4)==65568, 1);

if ~isempty(midx)
    if rawData(midx(1),12) == 0
       mDataRaw=rawData(rawData(:,4)==65538,[3 6 7 8])    *0.026;
    else
    %    mDataRaw=rawData(rawData(:,4)==65538,[3 13 14 15])   *0.026; 
       mDataRaw=rawData(rawData(:,4)==65538,[3 6 7 8]); 
    end
    
    
    % sentral time, unrolled
    mDataRaw(:,1)=rawData(rawData(:,4)==65538,11)+rawData(rawData(:,4)==65538,10)*65536; 
    mDataRaw(:,1)=mDataRaw(:,1)*32000*10^-9;


    % mag data
    mraw = mDataRaw(:,2:4); 

    % timestamp in seconds
    tRaw = mDataRaw(:,1);
    time = tRaw - tRaw(1,:);  % time in seconds    
    
    
elseif ~isempty(midx1)
    
    midx=find(rawData(:,4)==65568);
    mDataRaw=rawData(rawData(:,4)==65568,[3 6 7 8]); 

    % timestamp in seconds
    tRaw = mDataRaw(:,1)*10^-9;
    time = tRaw - tRaw(1,:);  % time in seconds    
    
    % mag data
    mraw = mDataRaw(:,2:4);     
    
end
    
% 
% % mDataRaw=rawData(rawData(:,4)==65538,[3 6 7 8]);    %mDataRaw=rawData(rawData(:,4)==65538,[3 13 14 15]);   
% 
% 
% 
% % sentral time, unrolled
% mDataRaw(:,1)=rawData(rawData(:,4)==65538,11)+rawData(rawData(:,4)==65538,10)*65536; 
% mDataRaw(:,1)=mDataRaw(:,1)*32000*10^-9;
% 
% 
% % mag data
% mraw = mDataRaw(:,2:4); 
% 
% % timestamp in seconds
% tRaw = mDataRaw(:,1);
% time = tRaw - tRaw(1,:);  % time in seconds



% ****** load output on from SENtral
SentralOutputRaw=rawData(rawData(:,4)==65557,[6]);    %mDataRaw=rawData(rawData(:,4)==65538,[3 13 14 15]);  
sidx=find(rawData(:,4)==65557);

SentralOutput = zeros(size(time));

endpoint = 1;
index = 1;

for i = 1:length(sidx)
    
    sentral_index = sidx(i);
    
    for j = endpoint:length(time)
        
        mag_index = midx(j);                  
        
        if sentral_index > mag_index
            
            SentralOutput(index) = SentralOutputRaw(i);    
            index = index + 1;
            
        else
            
           endpoint = j;
           break;
           
        end
        
    end
    
    
end

if (length(time) > (endpoint-1)) && (~isempty(SentralOutputRaw))    
   SentralOutput(endpoint:length(time)) = SentralOutputRaw(end); 
end




%compute the average rate of a single time axis. axis should be
%a column vector.

%compute delta-t vector
tDels = time(2:end)-time(1:end-1);
%compute frequency vector
tFqs = tDels.^(-1);
%compute mean rate in hz
% raw_rate = mean(tFqs);
% raw_rate = mean(tFqs(1:10));
raw_rate = tFqs(1);

% magN1 = sqrt(sum(mraw(:,1:2).^2,2));
% magN = sqrt(sum(mraw.^2,2));






% ****** load markers
markersind = find(rawData(:,4)==65665);

markersInMag = markersind;

for i=1:length(markersind)
    
    temp = find (midx<markersind(i));
    markersInMag(i)=temp(end);
end
        


% % plot: mag data with markers
% figure;   
% subplot(3,1,1);plot(time,mraw); grid on;
% xlabel('Time(seconds)');
% ylabel('raw mag data');
% legend('mag-x', 'mag-y', 'mag-z');
% 
% hold on; 
% y1=get(gca,'ylim');
markerTimes(1) = 0;

for i=1:length(markersind)
%     plot([time(markersInMag(i)),time(markersInMag(i))],y1);hold on;
    markerTimes(i) = time(markersInMag(i)); 
end

file = fopen(FileName);

markNames = cell(length(markerTimes),1);
i = 1;
l = fgetl(file);
while ~feof(file)
    if(l(1) == '#')
        markNames(i) = cellstr(l(2:end));
        i = i+1;
    end
    l = fgetl(file);
end
% 
% 
% subplot(3,1,2); plot(time,magN); grid on;
% 
% subplot(3,1,3); plot(time,magN1); grid on;

