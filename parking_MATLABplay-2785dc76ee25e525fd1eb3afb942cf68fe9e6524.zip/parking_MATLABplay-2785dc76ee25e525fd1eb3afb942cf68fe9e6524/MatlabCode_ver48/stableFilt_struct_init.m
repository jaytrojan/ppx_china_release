function filtStruct = stableFilt_struct_init
% stability/slope/noise measurement filter initialization


Nbuf = single(20); % buffer size

% filtStruct.stableMethod:
% 0 = original STD based stability (not using stableFilt measurments)
% 1 = outlier removal STD from stableFilt measurement
% 2 = stableFilt stability measurement based on revised std deviation and slope measurement
filtStruct.stableMethod = int8(2);

filtStruct.outRatio = single(0.25); % ratio of allowed outliers to be removed for stats
filtStruct.outLimit = single([0.4 3]); % [min max] uT of outlier removal
filtStruct.stableThreshDown = single([1.2  0.5]); %  [mstdClnR   mslopeMoveClnMnR] (and)
filtStruct.stableThreshUp = single([2.0  1.5]); %  [mstdClnR   mslopeMoveClnMnR] (or)
% stableFlags = mstdClnR_ay<1.2 & abs(mslopeMoveClnMnR_ay)<0.5; % & abs(mslopeMoveClnStdR_ay)<1.0;
% filtStruct.State_count_thresh         = uint16(2);    % reqiures 5 seconds to confirm the correct state (no car OR car parked)
% filtStruct.State_count_thresh_timeout = uint16(2);    % TIMEOUT: no state change in 5 secods - BACK TO LOW SPEED MODE



filtStruct.Nbuf = single(Nbuf);
filtStruct.mbuf = zeros(Nbuf,3,'single');
filtStruct.mslopeClnbuf = zeros(Nbuf,3,'single');
filtStruct.mtempbuf1 = zeros(Nbuf,1,'single');
% filtStruct.validFlags = zeros(Nbuf,1,'uint8');
filtStruct.ibuf = uint8(0);

filtStruct.mmn = single([0 0 0]);
filtStruct.mstd = single([0 0 0]);

filtStruct.mmnCln = single([0 0 0]);
filtStruct.mstdCln = single([0 0 0]);
filtStruct.mslopeCln = single([0 0 0]);

filtStruct.mslopeMoveClnMn = single([0 0 0]);
filtStruct.mslopeMoveClnStd = single([0 0 0]);

%%% Mag State History Filters
% track history of stable fields in states 1 & 3
Nhist = uint8(3); % state history buffer size
filtStruct.histFiltEnable = uint8(1);
filtStruct.hist13FldThresh = single([6 120]); % [uT sec]
filtStruct.hist31FldThresh = single([1.6 180]); % [uT sec]
filtStruct.Nhist = Nhist;
filtStruct.ihist1 = uint8(0);
% filtStruct.ihist3 = uint8(0);
% filtStruct.car_presentPersist = uint8(0); % persistent car present track until actual state change recorded
filtStruct.mhisttime1 = zeros(Nhist,1,'single'); % should be uint32
filtStruct.mhiststate1 = zeros(Nhist,3,'single');
% filtStruct.mhisttime3 = zeros(Nhist,1,'single'); % should be uint32
% filtStruct.mhiststate3 = zeros(Nhist,3,'single');



% %%%%% baseline filter has two moving recursive filters - one short and one long
% %%% baseFilt0 - short
% filtStruct.baseStruct.baseFilt0.initFilt = uint8(1);
% filtStruct.baseStruct.baseFilt0.alpha = single(0.70);
% filtStruct.baseStruct.baseFilt0.outSigmaWt = single(0.3);
% filtStruct.baseStruct.baseFilt0.outwtRange = single([0.05 1]);
%
% filtStruct.baseStruct.baseFilt0.w = single(0);
% filtStruct.baseStruct.baseFilt0.dfiltS = expStatStruc_Init;
% filtStruct.baseStruct.baseFilt0.dfiltwS = expStatStruc_Init;
% filtStruct.baseStruct.baseFilt0.dslopefiltwS = expStatStruc_Init;

% %%% baseFilt1 - long
% % values chosen for 4Hz LS rate
% % filter set
% filtStruct.baseFilt.initFilt = uint8(1);
% filtStruct.baseFilt.tconstant = single(0.85); % ~63% time constant for exp filter
% filtStruct.baseFilt.outSigmaWt = single(0.3);
% filtStruct.baseFilt.outwtRange = single([0.05 1]);
% 
% % stable set
% filtStruct.baseFilt.slopefiltwS_filt_thr = single(0.04*0.04); % sqr version
% filtStruct.baseFilt.slopefiltwS_varFilt_thr = single(0.01*0.01); % sqr version
% filtStruct.baseFilt.filtwS_var_thr = single(2.5*2.5); % sqr version
% filtStruct.baseFilt.filtwS_varFilt_thr = single(0.5*0.5); % sqr version
% filtStruct.baseFilt.stableCntTime = single(2);
% % dslopefiltwS_dataFilt_thr = 0.04;
% % dslopefiltwS_dataVarFilt_thr = 0.01;
% % dfiltwS_dataVar_thr = 2.5;
% % dfiltwS_dataVarFilt_thr = 0.5;
% % stableCheck = (...
% %             dslopefiltwS_dataFilt  <= slopefiltwS_filt_thr ...
% %        & dslopefiltwS_dataVarFilt  <= slopefiltwS_varFilt_thr...
% %        &           dfiltwS_dataVar <= filtwS_var_thr ...
% %        &       dfiltwS_dataVarFilt <= filtwS_varFilt_thr ...
% %        );
% 
% % calc
% filtStruct.baseFilt.stableCnt = uint32(0);
% filtStruct.baseFilt.w = single(0);
% filtStruct.baseFilt.dfiltS = expStatStruc_Init;
% filtStruct.baseFilt.dfiltwS = expStatStruc_Init;
% filtStruct.baseFilt.dslopefiltwS = expStatStruc_Init;
% filtStruct.baseFilt.baseLineMeasAccum = single([0 0 0]);
% filtStruct.baseFilt.baseLineMeas = single([0 0 0]);
% filtStruct.baseFilt.baseLineMeas_HSstart = single([0 0 0]);





