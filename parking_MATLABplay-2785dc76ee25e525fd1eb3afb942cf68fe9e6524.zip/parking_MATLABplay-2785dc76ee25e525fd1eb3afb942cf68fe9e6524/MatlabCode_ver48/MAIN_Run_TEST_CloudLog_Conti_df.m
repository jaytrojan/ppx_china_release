%% Algorithm using SSA and SSR with real-time functionality 
% No motion data


% close all;
clear; clc;
dbstop if error


% choose and open data file
dataDir = 'C:\Users\dfigaro\Documents\Parking\Data\All Test Vectors\Field Test Vector_Cloud\issue_cases\';


% % Load PPG and Accel data (need to select multiple data files)
[FileName,PathName] = uigetfile({[dataDir '*.csv']},'Choose Log File -mag data');


% [alldatfiles,PathName] = uigetfile({[dataDir '*.csv']},'Choose Multiple Logs', 'MultiSelect', 'on');
% numfiles=length(alldatfiles);
% % 
% for file_index=1:numfiles


FileName=char(alldatfiles(file_index));

[mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw,sentralTimestamp] = Read_Data_CloudLog_Conti(FileName);



HS_mode_triggerIND = [];


%% Setup data structures
ParkingStruct = Parking_struct_init;


%%%%% update knobs setting for drive thru algo
if ParkingStruct.DriveThruFLAG
    ParkingStruct = Parking_struct_init_DriveThru(ParkingStruct);
end







% if raw_rate <= ParkingStruct.HS_rate
%     
%     warning('upsampling is not supported');
%     
% else
%    
%     factor = floor(raw_rate/ ParkingStruct.HS_rate);
%     sprintf('Down Sampling Factor: %f',factor);    
%     
%     magData       = downsample(mraw,factor);
%     time          = downsample(timeRaw,factor);
%     SentralOutput = downsample(SentralOutput,factor);
% end
    


if strcmp(PathName, 'C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\continuous_mode_logs\')
   
    if (FileName(2) == '7' && FileName(3) == '_') || (FileName(2) == '1' && FileName(3) == '2') ...
            || (FileName(2) == '1' && FileName(3) == '9')
        start_ind = 130;

    elseif (FileName(2) == '8' && FileName(3) == '_') || (FileName(2) == '1' && FileName(3) == '0')...
            || (FileName(2) == '1' && FileName(3) == '1') || (FileName(2) == '1' && FileName(3) == '4')|| (FileName(2) == '1' && FileName(3) == '7')...
            || (FileName(2) == '2' && FileName(3) == '2') || (FileName(2) == '2' && FileName(3) == '3')|| (FileName(2) == '2' && FileName(3) == '4')...
            || (FileName(2) == '2' && FileName(3) == '7')
        start_ind = 50;

    else
        start_ind = 1;
    end

    
elseif strcmp(PathName, 'C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\issue_cases\')  
    
    if (FileName(2) == '2' && FileName(3) == '0') 
        
        start_ind = 323;    
        
    elseif (FileName(2) == '2' && FileName(3) == '5') 
        
        start_ind = 20; 
        
    elseif (FileName(2) == '2' && FileName(3) == '_') 
        
        start_ind = 1;
        
        ParkingStruct.State_count_thresh         = uint16(4);    % reqiures 1 seconds to confirm the correct state (no car OR car parked)
        ParkingStruct.State_count_thresh_timeout = uint16(4);    % TIMEOUT: no state change in 5 secods - BACK TO LOW SPEED MODE 
 
        
        
        
        
        
        
        
        
        
        
    elseif (FileName(2) == '4' && FileName(3) == '5') 
        
        start_ind = 1;         
        HS_mode_triggerIND = [33 72 119 154];         
               
        
    elseif (FileName(2) == '4' && FileName(3) == '6') 
        
        start_ind = 1;         
        HS_mode_triggerIND = [49 92 132 183 295];                              
        
    elseif (FileName(2) == '4' && FileName(3) == '7') 
        
        start_ind = 1;         
        HS_mode_triggerIND = [75 95 123 156];
        
        
     elseif (FileName(2) == '4' && FileName(3) == '8') 
        
        start_ind = 1;         
        HS_mode_triggerIND = [25 61 106 144 189];       
        
        
     elseif (FileName(2) == '4' && FileName(3) == '9') 
        
        start_ind = 1;         
        HS_mode_triggerIND = [29 90 142]; 
        
        
     elseif (FileName(2) == '5' && FileName(3) == '0') 
        
        start_ind = 1;         
        HS_mode_triggerIND = [33 100 ];  
        
        
     elseif (FileName(2) == '5' && FileName(3) == '1') 
        
        start_ind = 1;         
        HS_mode_triggerIND = [29 81]; 
        
        
    
    else
        start_ind = 1;
    end
    
    
    
else
    start_ind = 1;
end    




% start_ind = 1;   % 323;  %% 130;  %%%%670;   %%%1400;


end_ind = size(mraw,1);    %%%% 1690;   %%%%size(mraw,1);  %%%625;


magData       = mraw(start_ind:end_ind,:);
time          = timeRaw(start_ind:end_ind,:);
SentralOutput = SentralOutput(start_ind:end_ind,:);
sentralTimestamp = sentralTimestamp(start_ind:end_ind,:);


magNdata = sqrt(sum(magData.^2,2));
magNdata2 = sqrt(sum(magData(:,2:3).^2,2));

range_X = max(magData(:,1)) - min(magData(:,1))
range_Y = max(magData(:,2)) - min(magData(:,2))
range_Z = max(magData(:,3)) - min(magData(:,3))


figN = 100;

%%% plot deltas and vector deltas
dt = [0; time(2:end) - time(1:end-1)];

N = size(magData,1);
iRefInds = 1:5;
magDataRef = mean(magData(iRefInds,:),1);
magDataDelta = magData - repmat(magDataRef,N,1);
magDataDeltaR = sqrt(sum(magDataDelta.^2,2));


% figure
% plot(dt)
% grid on

set(0,'DefaultFigureWindowStyle','normal') %docked figures

% replace large time gaps
tgapmax = 60;
dtBigInds = find(dt>=tgapmax);
tgapreplace = 10;
% [time(dtBigInds-1) time(dtBigInds) time(dtBigInds+1)]

dt2 = dt;
tgapmeas = dt(dtBigInds);
dt2(dtBigInds) = tgapreplace;
time2 = time(1) + cumsum(dt2);


% % time2 = time;
% for ii=1:length(dtBigInds)
%     time2(dtBigInds(ii):end) = time2(dtBigInds(ii)-1:end)+tgapreplace;
% end



figN = figN+1;
figure(figN); clf   
% plot(time,magDataDelta,'.-')
% plot(magDataDelta,'.-'); hold all
% plot(magDataDeltaR,'-k','LineWidth',2)
plot(magDataDelta(:,1),'.-b','LineWidth',1.5,'MarkerSize',18); hold all
plot(magDataDelta(:,2),'.-g','LineWidth',1.5,'MarkerSize',18); hold all
plot(magDataDelta(:,3),'.-r','LineWidth',1.5,'MarkerSize',18); hold all
plot(magDataDeltaR(:,:),'.-k','LineWidth',3,'MarkerSize',20)
title('Mag Data Delta vs Sample','FontSize',16,'FontWeight','bold'); grid on;
xlabel('Sample Index','FontSize',14,'FontWeight','bold');
ylabel('uT','FontSize',14,'FontWeight','bold');
legend('X','Y','Z','R')


set(0,'DefaultFigureWindowStyle','docked') %docked figures

figN = figN+1;
figure(figN); clf  
markInds = [dtBigInds; N];
istart=1; istopprev = 0;
for ii=1:length(markInds)
    istop = markInds(ii)-1;
    if istopprev
        plot(time2(istopprev:istart,:),magDataDelta(istopprev:istart,1),':b'); hold all
        plot(time2(istopprev:istart,:),magDataDelta(istopprev:istart,2),':g'); hold all
        plot(time2(istopprev:istart,:),magDataDelta(istopprev:istart,3),':r'); hold all
        plot(time2(istopprev:istart,:),magDataDeltaR(istopprev:istart,:),':k','LineWidth',1)
    end
    plot(time2(istart:istop,:),magDataDelta(istart:istop,1),'.-b','LineWidth',1.5,'MarkerSize',18); hold all
    plot(time2(istart:istop,:),magDataDelta(istart:istop,2),'.-g','LineWidth',1.5,'MarkerSize',18); hold all
    plot(time2(istart:istop,:),magDataDelta(istart:istop,3),'.-r','LineWidth',1.5,'MarkerSize',18); hold all
    plot(time2(istart:istop,:),magDataDeltaR(istart:istop,:),'.-k','LineWidth',3,'MarkerSize',20)
    
    istart = markInds(ii);
    istopprev = istop;
end

% add missing time notes
yLim = ylim;
ymk = 0.85*yLim(1);
for ii=1:length(dtBigInds)
    istart = dtBigInds(ii)-1;
    istop = dtBigInds(ii);
    tcent = mean(time2(istart:istop));
    tstr = num2str(round(tgapmeas(ii)/60));
    text(tcent,ymk,['~' tstr ' min~'],'HorizontalAlignment','center')
end
title('Mag Data Delta vs Time','FontSize',16,'FontWeight','bold'); grid on;
xlabel('t(sec)','FontSize',14,'FontWeight','bold');
ylabel('uT','FontSize',14,'FontWeight','bold');
legend('X','Y','Z','vectR')




% % % figN = figN+1;
% % % figure(figN); clf   
% % % subplot(3,1,1);
% % % plot(magData),title('mag data of X/Y/Z'); grid on;
% % % xlabel('Time(seconds)');
% % % ylabel('raw mag data');
% % % legend('mag-x', 'mag-y', 'mag-z');
% % % 
% % % hold on; 
% % % y1=get(gca,'ylim');
% % % % subplot(4,1,2); plot(magNdata2),title('magnitude of X+Y'); grid on;
% % % subplot(3,1,2); plot(magNdata),title('magnitude of X+Y+Z');  grid on;
% % % subplot(3,1,3); plot(SentralOutput),title('Sentral Output'); grid on;




diffTime = [0; diff(time)];
diffTime(1) = diffTime(2);
HS_label = diffTime<0.5;



N3 = length(magData);


magNdata = zeros(N3,1);
mag_diff = zeros(N3,1);
phase_level = zeros(N3,1);
detection_output = zeros(N3,1);

car_state = zeros(N3,4);

MEAN_value = zeros(N3,2);
STD_value = zeros(N3,1);

MEAN_value2 = zeros(N3,3);

moving_avg = zeros(N3,1);

MEAN_Baseline_value = zeros(N3,1);
STD_Baseline_value = zeros(N3,1);
MEAN_Occupied_value = zeros(N3,1);
STD_Occupied_value = zeros(N3,1);



ALG2Level = zeros(N3,1);
car_state_alg2 = zeros(N3,1);

car_state_buffer =zeros(N3,1);

Alarm_level = zeros(N3,1);

for i = 1:length(magData)
    
    

    
    
    ParkingStruct.NUM               = single(i);
    
    
%     ParkingStruct.PreDataBuffer      = shifting_array(ParkingStruct.PreDataBuffer);
%     ParkingStruct.PreDataBuffer(ParkingStruct.PreDataBufferSize,:)  = magData(i,:);    
    
    
    
    
    if ((abs(magData(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
        || (abs(magData(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
        || (abs(magData(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
        || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
        || (~isempty(HS_mode_triggerIND) && any(HS_mode_triggerIND == ParkingStruct.NUM)) 
%         || ParkingStruct.NUM              == 95 ... 
%         || ParkingStruct.NUM              == 123 ... 
%         || ParkingStruct.NUM              == 156        
    
        


        if ParkingStruct.LS_Trigger_FLAG  == uint8(1)
            ParkingStruct.StartNUM          = ParkingStruct.NUM;
        end
        
        
        

        
        
        
        % hardware alarm 
%         ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
        ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),sentralTimestamp(i),1);        
        
        
%          %%%%% downsample to 4 Hz
%          if ParkingStruct.downsampleFLAG == 1
%             ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),sentralTimestamp(i),1);               
%             ParkingStruct.downsampleFLAG = 0;        
%          else             
%              ParkingStruct.downsampleFLAG = 1;            
%          end
         
    end



%     % software alarm 
%     ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),sentralTimestamp(i),0);    
    
    

   magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
%    MEAN_value(i,1) = ParkingStruct.AVG;
   STD_value(i,1)  = ParkingStruct.STD;
   
%    STD_value(i,2)  = ParkingStruct.STDz;
   
   MEAN_value2(i,:) = ParkingStruct.AVG2;
   
   MEAN_value(i,1) = ParkingStruct.moving_avg;
   
   moving_avg(i,1)=ParkingStruct.moving_avg;
   
   
   car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2 ParkingStruct.car_present ParkingStruct.car_present2]; 
   Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG; 
   
%    RMS(i,1) = ParkingStruct.RMS;
   
   SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;
    
end



% static_state1 = [ParkingStruct.AVGInit2 single(1)];
% static_state = [static_state1; ParkingStruct.LS_StartValue_stateALL];
% 
% for i = 1:size(static_state,1)
%     static_state(i,5) = sum(abs(static_state(i,1:3) - static_state(1,1:3)));
%     static_state(i,6) = sqrt(sum(static_state(i,1:3).^2)) - sqrt(sum(static_state(1,1:3).^2));
% end




figN = figN+1;
figure(figN); clf  
markInds = [dtBigInds; N];
istart=1; istopprev = 0;
for ii=1:length(markInds)
    istop = markInds(ii)-1;
    if istopprev
        plot(time2(istopprev:istart,:),car_state(istopprev:istart,1),':b'); hold all
%         plot(time2(istopprev:istart,:),car_state(istopprev:istart,2),':g'); hold all
%         plot(time2(istopprev:istart,:),car_state(istopprev:istart,3),':r'); hold all
%         plot(time2(istopprev:istart,:),magDataDeltaR(istopprev:istart,:),':k','LineWidth',1)
    end
    plot(time2(istart:istop,:),car_state(istart:istop,1),'.-b','LineWidth',2,'MarkerSize',20); hold all
%     plot(time2(istart:istop,:),car_state(istart:istop,2),'.-g','LineWidth',1.5,'MarkerSize',18); hold all
%     plot(time2(istart:istop,:),car_state(istart:istop,3),'.-r','LineWidth',1.5,'MarkerSize',18); hold all
%     plot(time2(istart:istop,:),magDataDeltaR(istart:istop,:),'.-k','LineWidth',3,'MarkerSize',20)
    
    istart = markInds(ii);
    istopprev = istop;
end

% add missing time notes
ylim([0 4])
yLim = ylim;
ymk = 0.7;
for ii=1:length(dtBigInds)
    istart = dtBigInds(ii)-1;
    istop = dtBigInds(ii);
    tcent = mean(time2(istart:istop));
    tstr = num2str(round(tgapmeas(ii)/60));
    text(tcent,ymk,['~' tstr ' min~'],'HorizontalAlignment','center')
end
title('Matlab Car States vs Time','FontSize',16,'FontWeight','bold'); grid on;
xlabel('t(sec)','FontSize',14,'FontWeight','bold');
% ylabel('uT','FontSize',14,'FontWeight','bold');
% legend('X','Y','Z','vectR')
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)

end


return





% figure;
% subplot(4,1,1); plot(time,magNdata),title('absolute mag'); grid on;
% subplot(4,1,2); plot(time,MEAN_value(:,2)),title('Feature: Magnetic Counts Change'); grid on;
% subplot(4,1,3); plot(time,STD_value),title('Feature: STD'); grid on;
% subplot(4,1,4); plot(time,Alarm_level),title('Alarm Trigger Level'); grid on;
% 
% 
% 
% figure;
% subplot(2,1,1); plot(time,moving_avg),title('Feature: Magnetic Counts Change');  grid on;
% subplot(2,1,2); plot(time,car_state(:,1)),title('Car States from MATLAB'); grid on; 
% set(gca,'YTick',1:4);
% labels = {
%         'Empty';
%         'Car Entering';
%         'Occupied';
%         'Car Leaving';
%         };
% set(gca,'YTickLabel',labels)
% % xlabel('Time (Seconds)');


% % subplot(3,1,3); plot(time,SentralOutput(1:length(time))),title('Car States from SENtral'); grid on;
% % set(gca,'YTick',1:4);
% % labels = {
% %         'Empty';
% %         'Car Entering';
% %         'Occupied';
% %         'Car Leaving';
% %         };
% % set(gca,'YTickLabel',labels)
% % xlabel('Time (Seconds)');





% figure;
% subplot(4,1,1); plot(magNdata),title('absolute mag'); grid on;
% subplot(4,1,2); plot(MEAN_value(:,2)),title('Feature: Magnetic Counts Change'); grid on;
% subplot(4,1,3); plot(STD_value),title('Feature: STD'); grid on;
% subplot(4,1,4); plot(Alarm_level),title('Alarm Trigger Level'); grid on;



figN = figN+1;
figure(figN); clf   
% subplot(3,1,1); plot(moving_avg),title('Feature: Magnetic Counts Change');  grid on;

subplot(3,1,1);  plot(magData),title('mag data of X/Y/Z'); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');


subplot(3,1,2); plot(car_state(:,1)),title('Car States from MATLAB'); grid on; 
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)



subplot(3,1,3); plot(SentralOutput(1:length(time))),title('Car States from SENtral'); grid on;
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)







figN = figN+1;
figure(figN); clf   

subplot(2,1,1);  plot(magData),title('mag data of X/Y/Z'); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');


subplot(2,1,2); plot(car_state(:,1),'r'),title('Car States'); grid on; hold on;
plot(SentralOutput(1:length(time)))
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
legend('MATLAB','SENtral');

