function resetTruthCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global dataInfo dataInfoExtra plotInfo cntrlInfo

% reset truth to calculated car state

% truth_state_load = dataInfo.truth_state_load;
dataInfo.truth_state = dataInfo.car_state;


plotInfo.hTruthStateLine.YData = dataInfo.truth_state(:,1);
if ~isempty(plotInfo.hTruthStateLineStart)
    startInd = find(dataInfoExtra.time2>=dataInfo.startTime,1,'first');
    plotInfo.hTruthStateLineStart.YData = dataInfo.truth_state(1:startInd-1,1);
end

% update slider
if isfield(cntrlInfo,'BrushData') && ~isempty(cntrlInfo.BrushData)
    currentTruth = dataInfo.truth_state(logical(cntrlInfo.BrushData),1);
    if ~isempty(currentTruth)
        setVal = currentTruth(1);
        setVal = round(setVal);
        cntrlInfo.sld.Value = setVal;
        cntrlInfo.sldText.String = num2str(setVal);
    end
end



% % adjust all current brush data to slider value
% currentTruth = dataInfo.truth_state(logical(cntrlInfo.BrushData),1);
% 
% if ~isempty(currentTruth)
%     
%     % set slider to first value
%     setVal = cntrlInfo.sld.Value;
%     
%     setVal = round(setVal);
%     cntrlInfo.sld.Value = setVal;
%     cntrlInfo.sldText.String = num2str(setVal);
%     
%     % make all selected truth match slider
%     hTruthStateLine.YData(logical(cntrlInfo.BrushData)) = setVal;
%     dataInfo.truth_state(logical(cntrlInfo.BrushData),1) = setVal;
% 
% end

