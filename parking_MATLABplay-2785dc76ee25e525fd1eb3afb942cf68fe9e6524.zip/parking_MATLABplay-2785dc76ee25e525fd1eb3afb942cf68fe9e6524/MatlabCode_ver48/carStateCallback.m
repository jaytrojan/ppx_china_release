function carStateCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global plotInfo dataInfo cntrlInfo
hTruthStateLine = plotInfo.hTruthStateLine;
% hCarStateLine = plotInfo.hCarStateLine;
% hSenStateLine = plotInfo.hSenStateLine;
% truth_state = dataInfo.truth_state;

% BrushData = hTruthStateLine.BrushData;

% adjust all current brush data to slider value
currentTruth = dataInfo.truth_state(logical(cntrlInfo.BrushData),1);

if ~isempty(currentTruth)
    
    % set slider to first value
    setVal = cntrlInfo.sld.Value;
    
    setVal = round(setVal);
    
    % text for val
    carStateListAy = {
        'Empty';
        'Entering';
        'Occupied';
        'Leaving';
        };
    if setVal
        carStateStr = carStateListAy{setVal};
    else
        carStateStr = 'Unknown';
    end
    
    cntrlInfo.sld.Value = setVal;
    cntrlInfo.sldText.String = carStateStr;
    
    % make all selected truth match slider
    hTruthStateLine.YData(logical(cntrlInfo.BrushData)) = setVal;
    dataInfo.truth_state(logical(cntrlInfo.BrushData),1) = setVal;

end

