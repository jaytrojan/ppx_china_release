%%% Algorithm using SSA and SSR with real-time functionality
% No motion data


disp('Viewing Parking Data Logs...')

% close all;
clear; %clc;
dbstop if error

fillDataFront = 0;

waitTime = 0; % seconds to pause after each file
% if 0, pause indefinitley

% choose and open data file
% dataDir = 'C:\Users\dfigaro\Documents\Parking\Data\All Test Vectors\Field Test Vector_Cloud\issue_cases\';
dataDir = 'C:\Users\jtrojan\Desktop\Data\Parking\';
dataDir = '..\..\';


%%% >>>Problem File List<<<
% move this list to csv ...
% FrontLot\2017dec18-24\Front8_valid_2017_12_19_testDblBufAck1


%%% >> Figure Plot Settings
% [fignum  dock  link]
figPlotS = [];
figPlotS.dServSentTime = [10100 1 0];
figPlotS.measAy = [10110 1 0];
figPlotS.flagDataAy = [10120 1 0];
figPlotS.caarStatusAy = [10130 1 0];
figPlotS.rfAy = [10140 1 0];
figPlotS.MagVtServ = [10150 1 0];
figPlotS.MagVtSen = [10151 0 0];
figPlotS.MagVsamples = [10152 0 0];
        

% plot axis struct for linking
% uses same fields as figPlotS
haxS = [];
flds = fieldnames(figPlotS);
for ifld=1:length(flds)
    fld = flds{ifld};
    haxS.(fld)=[];
end


%%% >> Figure Plot Settings



% % % Load PPG and Accel data (need to select multiple data files)
% [FileName,PathName] = uigetfile({[dataDir '*.csv']},'Choose Log File -mag data');


[alldatfiles,PathName] = uigetfile({[dataDir '*.*']},'Choose Multiple Logs', 'MultiSelect', 'on');

if isnumeric(PathName)
    return
end

if ~iscell(alldatfiles)
    alldatfiles = {alldatfiles};
end
numfiles=length(alldatfiles);
%
%
measAy = [];
measFldAy = [];

for file_index=1:numfiles
    
    if iscell(alldatfiles)
        FileName=char(alldatfiles(file_index));
    elseif ischar(alldatfiles)
        FileName=alldatfiles;
    else
        return
    end
    
    disp(['File:  ' FileName])
    
    % id columns by hdr text
    hdr.iGatewayTime = {'GatewayTime'};
    hdr.iSentralTime = {'SentralTime'};
    hdr.iSensorID = {'sensorId'};
    hdr.iServeTime = {'ServerTime'};
    hdr.iCarStat = {'CarPresence'};
    hdr.iCarCounter = {'CarCounter'};
    hdr.iTemp = {'Temperature'};
    hdr.ibattery = {'battery'};
    hdr.iRSSI = {'rx_rssi'};
    hdr.irx_snr = {'rx_snr'};
    hdr.iFlags = {'Confidence'};
    hdr.iData = {'x','y','z'};
    
    indS.hdr = hdr;
    
    %     % yuan magnitude data logs for default
    %     indS.iGatewayTime = 1;
    %     indS.iSentralTime = 2;
    %     indS.iSensorID = 3;
    %     indS.iServeTime = 4;
    %     indS.iCarStat = 5;
    %     indS.iTemp = 6;
    %     indS.iRSSI = 7;
    %     indS.iConf = 8;
    %     indS.iData = [];
    
    
    global plotInfo dataInfo cntrlInfo dataInfoExtra 
    
    dataInfo = [];
    dataInfoExtra = [];
    
    [pathstr,name,ext] = fileparts(FileName);
    
    
    %%% truth state data file
    dataInfo_load = []; % initialize
    
    if strcmpi(ext,'.csv')
        % csv
        % original parser
        % [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw,sentralTimestamp] = Read_Data_CloudLog_Conti([PathName FileName]);
        
        %     [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw, sentralTimestamp, servTime] = Read_Data_CloudLog_flexHdr([PathName FileName],indS);
        %     [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw, sentralTimestamp, servTime, SentralOutputRaw] = Read_Data_CloudLog_flexHdr_work([PathName FileName],indS);
        dataStruct = Read_CloudHist_flexHdr([PathName FileName],indS);
        
        [pathstr,fileName,ext] = fileparts(FileName);
        save([PathName fileName '_sum.mat'],'dataInfo','dataStruct')
        
    elseif strcmpi(ext,'.mat')
        % mat
        dataFileLoad = load([PathName FileName]);
        if isfield(dataFileLoad, 'dataStruct')
            dataStruct = dataFileLoad.dataStruct;
        else
            disp('Unknown File Type!!!')
            continue
        end
        if isfield(dataFileLoad, 'dataInfo')
            dataInfo_load = dataFileLoad.dataInfo;
        end
    else
        disp('Unknown File Type!!!')
        continue
    end
    
    
    dataStruct
    
    if ~isempty(dataStruct) % && ~isempty(timeRaw)
        
        %         clear plotInfo dataInfo cntrlInfo
        
        %%%%% Build Data - only fields that are present
        
        
        %%% Time Zone Server Time Adjust
        % incoming time assumed to be PST
        dateTimePST = dataStruct.dateTimeAy;
        dateTimeAy = dateTimePST + hours(3);
        
        % sentral - server time compare
        sentTimeAySecs = dataStruct.sentTimeAySecs;
        servTimeAySecs = seconds(seconds(dateTimeAy - dateTimeAy(1)));
        sentTimeAySecsRel = sentTimeAySecs - sentTimeAySecs(1);
        dServSentTime = servTimeAySecs - sentTimeAySecs;
        dServSentTimePcnt = 100*seconds(dServSentTime)/seconds(servTimeAySecs(end));
        % find night times
        niteFlags = hour(dateTimeAy)>=2 & hour(dateTimeAy)<=5;
        
        %%% decode Flags field (called 'Confidence' in the data log)
        % Bit 7	 Bit 6  Bit 5 |  Bit 4  | Bit 3    | Bit 2 Bit 1 Bit 0
        % Mag Sig Detect      | LS Mode | Cal Comp | Confidance Level
        flagFld = {'iFlags'};
        [flagAy, flagFldAy] = buildFldData(dataStruct, flagFld);
        flagAy = uint8(flagAy);
        %         (dec2bin(flagAy(1),8))
        confAy = bitand(flagAy,uint8(7));
        calCompleteAy = bitshift(bitand(flagAy,uint8(8)),-3);
        lsModeAy = bitshift(bitand(flagAy,uint8(16)),-4);
        magSigAy = bitshift(bitand(flagAy,uint8(224)),-5);
        flagDataAy = [confAy magSigAy];
        flagDataFldAy = {'iconf' 'imagSig'};
        %         figure
        %         plot(confAy); hold all
        %         plot(calCompleteAy); hold all
        %         plot(lsModeAy); hold all
        %         plot(magSigAy); hold all
        
        
        %         dataFieldList = {'iSensorID'  'iCarStat'  'iTemp'  'iRSSI'  'irx_snr'  'iConf'  'iDataX'  'iDataY'  'iDataZ'}
        legAyFull = {'iSensorID'  'iCarStat'  'iTemp'  'iRSSI'   'irx_snr'  'iConf'  'iCarCounter'  'ibattery'  'iData'};
        %         legAyMeas = {'iTemp'  'iConf'  'iCarCounter'  'ibattery'};
        %         legAyRF = {'iRSSI'   'irx_snr'};
        
        caarStatusFlds = {'iCarStat'};
        [caarStatusAy, caarStatusFldAy] = buildFldData(dataStruct, caarStatusFlds);
        %         caarStatusAy = dataStruct.dataAy(:,2);
        
        measFlds = {'iTemp'  'iCarCounter'  'ibattery'};
        [measAy, measFldAy] = buildFldData(dataStruct, measFlds);
        %         measAy = [measAy flagDataAy];
        %         measFldAy = [measFldAy flagDataFldAy];
        
        %         measAy = dataStruct.dataAy(:,[3 6 7 8]);
        
        rfFlds = {'iRSSI'   'irx_snr'};
        [rfAy, rfFldAy] = buildFldData(dataStruct, rfFlds);
        %         rfAy = dataStruct.dataAy(:,[4 5]);
        
        % mag data
        magXYZFlds = {'iDataX'  'iDataY'  'iDataZ'};
        [magXYZAy, magXYZFldAy] = buildFldData(dataStruct, magXYZFlds);
        
        %%% Plot Data
        haxAy = [];
        
        
        figFld = 'dServSentTime';
        figN = figPlotS.(figFld)(1);
        if figN && ~isempty(dServSentTime)
            figure(figN); clf
            hax = axes;
            haxAy = [haxAy hax];
            yyaxis(hax,'left')
            plot(dateTimeAy, dServSentTime,'-p', 'LineWidth', 2); hold all
            xlabel('DateTime')
            ylabel('delta t(sec)')
            title('Delta Serv - Sentral Time')
            grid on
            yyaxis(hax,'right')
            plot(dateTimeAy, dServSentTimePcnt, '--', 'LineWidth', 1); hold all
            ylabel('% delta t(sec)')
        end
        
        
        figFld = 'measAy';
        figN = figPlotS.(figFld)(1);
        if figN && ~isempty(measAy)
            figure(figN); clf
            hax = axes;
            haxAy = [haxAy hax];
            plot(dateTimeAy, measAy, 'LineWidth', 2); hold all
            %         plot(dateTimeEST,  statAy(:,2)); hold all
            legend(measFldAy);
            title('History Log Meas')
            grid on
        end
        
        
        figFld = 'flagDataAy';
        figN = figPlotS.(figFld)(1);
        if figN && ~isempty(flagDataAy)
            figure(figN); clf
            hax = axes;
            haxAy = [haxAy hax];
            hline = [];
            %         plot(dateTimeEST, flagDataAy, 'LineWidth', 2); hold all
            hline(1) = plot(dateTimeAy,  flagDataAy(:,2),'o','LineWidth',2.5,'MarkerSize',8,'Color',[0.95 0.10 0.10]); hold all
            hline(2) = plot(dateTimeAy,  flagDataAy(:,2),'-','LineWidth',1.0,'MarkerSize',8,'Color',[0.95 0.10 0.10]); hold all
            hline(3) = plot(dateTimeAy,  flagDataAy(:,1),'.-','LineWidth',1.0,'MarkerSize',25,'Color',[0.25 0.30 0.90]); hold all
            %         plot(dateTimeEST,  flagDataAy(:,:),'--','Color',[0.7 0.7 0.7],'LineWidth',1.5,'MarkerSize',25); hold all
            legend([hline(3) hline(1)], flagDataFldAy);
            title('History Log Flags')
            grid on
        end
        
        
        figFld = 'caarStatusAy';
        figN = figPlotS.(figFld)(1);
        if figN && ~isempty(caarStatusAy)
            figure(figN); clf
            hax = axes;
            haxAy = [haxAy hax];
            plot(dateTimeAy,  caarStatusAy(:,1),'-','Color',[0.65 0.65 0.65],'LineWidth',1.0,'MarkerSize',25); hold all
            plot(dateTimeAy,  caarStatusAy(:,1),'.','Color',[0.95 0.10 0.10],'LineWidth',1.5,'MarkerSize',25); hold all
            plot(dateTimeAy(niteFlags), caarStatusAy(niteFlags,1),'.','Color',[0.7 0 0],'LineWidth',2,'MarkerSize',40); hold all
            title('Car States vs Server Time','FontSize',16,'FontWeight','bold')
            xlabel('DateTime')
            ylabel('Car Status')
            set(hax,'YTick',0:4);
            ylim([0 4])
            labels = {
                'Unknown';
                'Empty';
                'Car Entering';
                'Occupied';
                'Car Leaving';
                };
            set(hax,'YTickLabel',labels)
            grid on
        end
        
        
        figFld = 'rfAy';
        figN = figPlotS.(figFld)(1);
        if figN && ~isempty(rfAy)
            figure(figN); clf
            hax = axes;
            haxAy = [haxAy hax];
            plot(dateTimeAy, rfAy,'.','LineWidth',2,'MarkerSize',10); hold all
            legend(rfFldAy);
            plot(dateTimeAy, rfAy,'-','LineWidth',1,'Color',[0.7 0.7 0.7])
            title('History Log RF')
            grid on
        end
        
        
        figFld = 'MagVtServ';
        figN = figPlotS.(figFld)(1);
        if figN && ~isempty(magXYZAy)
            figure(figN); clf
            hax = axes;
            haxAy = [haxAy hax];
            plot(dateTimeAy, magXYZAy, '.', 'MarkerSize', 10); hold all
            plot(dateTimeAy, magXYZAy, '-', 'LineWidth', 1, 'Color', [0.7 0.7 0.7]); hold all
            legend(magXYZFldAy);
            title('MagXYZ vs. Server Time')
            xlabel('Server DateTime')
            ylabel('uT')
            grid on
        end
        
        figFld = 'MagVtSen';
        figN = figPlotS.(figFld)(1);
        if figN && ~isempty(magXYZAy)
            figure(figN); clf
            hax = axes;
            %         sentTimeAySecs_rel = sentTimeAySecs - sentTimeAySecs(1);
            plot(sentTimeAySecsRel, magXYZAy, '.', 'MarkerSize', 10); hold all
            plot(sentTimeAySecsRel, magXYZAy, '-', 'LineWidth', 1, 'Color', [0.7 0.7 0.7]); hold all
            legend(magXYZFldAy);
            title('MagXYZ vs. Sentral Time')
            xlabel('Sentral Time (sec)')
            ylabel('uT')
            grid on
        end
        
        figFld = 'MagVsamples';
        figN = figPlotS.(figFld)(1);
        if figN && ~isempty(magXYZAy)
            figure(figN); clf
            hax = axes;
            plot(magXYZAy, '.', 'MarkerSize', 10); hold all
            plot(magXYZAy, '-', 'LineWidth', 1, 'Color', [0.7 0.7 0.7]); hold all
            legend(magXYZFldAy);
            title('MagXYZ vs. Samples')
            xlabel('Samples')
            ylabel('uT')
            grid on
        end
        
        %%% docking
        plotflds = fieldnames(figPlotS);
        for ifld = 1:length(plotflds)
            try
                if figPlotS.(plotflds{ifld})(2)
                    set(figPlotS.(plotflds{ifld})(1),'WindowStyle','docked')
                else
                    set(figPlotS.(plotflds{ifld})(1),'WindowStyle','normal')
                end
            catch
            end
        end
        
        
        if ~isempty(haxAy)
            linkprop(haxAy,'xlim');
        end
        
        
        
    else
        disp('No Valid Data...')
        
        
    end
    if file_index>=numfiles
        % continue...
    elseif waitTime
        pause(waitTime)
    else
        disp('Hit any key to continue...');
        pause % hit key to continue
    end
    
end

return







%%% >>> for saving a screenshot with multiple figures
screenImages = captureScreen; % images of all monitor screens

iscreen = 2;
imwrite(screenImages{iscreen},['carStates4' '.png']);
%%% >>> for saving a screenshot with multiple figures





