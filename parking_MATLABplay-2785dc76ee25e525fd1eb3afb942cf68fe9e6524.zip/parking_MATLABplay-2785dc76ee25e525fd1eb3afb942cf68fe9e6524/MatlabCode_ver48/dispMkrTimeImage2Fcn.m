function output_txt = dispMkrTimeImageFcn(obj,event_obj)
% Display the position of the data cursor
% obj          Currently not used (empty)
% event_obj    Handle to event object
% output_txt   Data cursor text string (string or cell array of strings).


global  dataInfoExtra parkImageShow

% servTime = dataInfoExtra.servTime;


pos = get(event_obj,'Position');
index = get(event_obj,'DataIndex');

% find matching index
tcam = parkImageShow.camTimeImagesMatch(index);
icam = parkImageShow.camIndsImagesMatch(index);

% tserv = dataInfoExtra.servTime(index);
% tcam2 =  parkImageShow.dateTimeAyAy(icam);
% tcam = parkImageShow.imageTimeTrack(index);

% find closest tserv before tcam within tpad
tpad = 120; % seconds of padding for time matching

% tserv = dataInfoExtra.servTime(index);

% inds = find(dataInfoExtra.servTime >= (tcam-seconds(tpad)) & dataInfoExtra.servTime <= tcam+0*seconds(tpad));
inds = find(dataInfoExtra.servTime <= tcam+0*seconds(tpad),1,'last');
if ~isempty(inds)
    servInd = inds(end);
    tserv = dataInfoExtra.servTime(servInd);
else
    tserv = [];
%     [minVal, minInd] = min(abs(parkImageShow.dateTimeAyAy - tserv)); % closest...
end


% minInd = index;

if ~isempty(icam) && icam~=0
    

    ipage = parkImageShow.pageTrackAyAy(icam);
    iind = parkImageShow.indTrackAyAy(icam);
    %                 [minVal, iInd] = min(abs(imageStructAy(ipage).dateTimeAy - tserv));
    % inds = parkImageShow.imageStructAy
    
    % (ipage).dateTimeAy >= tserv-seconds(tpad) & imageStructAy(ipage).dateTimeAy <= tserv+seconds(tpad));
%     tcam2 = parkImageShow.imageStructAy(ipage).dateTimeAy(iind);
else
    tcam = [];
end


% show parking image
try
    if parkImageShow.on && isfield(parkImageShow,'imageStructAy') && ~isempty(parkImageShow.imageStructAy)
%         inds = parkImageShow.imageIndsTrack(index,:); % [page ind]
        % dim match check
        Nimpages = length(parkImageShow.imageStructAy);
        Nimages = size(parkImageShow.imageStructAy(ipage).imageAy,4);
        if ~isempty(inds) && ipage<=Nimpages && iind<=Nimages 
%             ipage = inds(1); iind = inds(2);
            parkImage = parkImageShow.imageStructAy(ipage).imageAy(:,:,:,iind);
            image(parkImageShow.hax,parkImage);
        else
%             % no images close enough
%             imSize = size(parkImageShow.imageStructAy(1).imageAy);
%             parkImage = 0.7*255*ones(imSize(1:3),'uint8');
%             image(parkImageShow.hax,parkImage);
              tcam = [];
        end
    end
catch
    disp('image display problem!!!')
end

if ~isempty(tserv)
    tservDisp = char(tserv,'dd-MMM-yyyy HH:mm:ss');
else
    tservDisp = '';
end

if ~isempty(tcam)
    tcamDisp = char(tcam,'dd-MMM-yyyy HH:mm:ss');
else
    tcamDisp = '';
end

output_txt = {...
    ['X: ',num2str(pos(1))],...
    ['Y: ',num2str(pos(2))]...
    ['tserv: ',tservDisp]...
    ['tcam: ',tcamDisp]...
    };

