function hax1 = plotMagDataTime(time2,servTime,tgapmeas,magData,magDataR,dtBigInds,figN,titleStr,startInd)

%%% >>> mag data vs time

% titleStr = 'Mag Data Full vs Time';

N = size(magData,1);
if nargin<9
    startInd = 1;
end

% figN = figPlotS.magDataFull(1);
figure(figN); clf
hax1 = axes;
markInds = [dtBigInds; N];
istart=1; istopprev = 0;
for ii=1:length(markInds)
    istop = markInds(ii)-1;
    if istop > startInd
        xclr = 'b'; yclr = 'g'; zclr = 'r';
    else
        xclr = [0 0 0.5]; yclr = [0 0.5 0]; zclr = [0.5 0 0];
    end
    if istopprev
        plot(hax1,time2(istopprev:istart,:),magData(istopprev:istart,1),':','Color',xclr); hold all
        plot(hax1,time2(istopprev:istart,:),magData(istopprev:istart,2),':','Color',yclr); hold all
        plot(hax1,time2(istopprev:istart,:),magData(istopprev:istart,3),':','Color',zclr); hold all
        plot(hax1,time2(istopprev:istart,:),magDataR(istopprev:istart,:),':k','LineWidth',1)
    end
    plot(hax1,time2(istart:istop,:),magData(istart:istop,1),'.-','Color',xclr,'LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax1,time2(istart:istop,:),magData(istart:istop,2),'.-','Color',yclr,'LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax1,time2(istart:istop,:),magData(istart:istop,3),'.-','Color',zclr,'LineWidth',1.5,'MarkerSize',18); hold all
    plot(hax1,time2(istart:istop,:),magDataR(istart:istop,:),'.-k','LineWidth',1,'MarkerSize',18)
    
    istart = markInds(ii);
    istopprev = istop;
end

% % add second axis with server time on x axis
% ax1_pos = hax1.Position; % position of first axes
% hax2 = axes('Position',ax1_pos,...
%     'XAxisLocation','top',...
%     'YAxisLocation','right',...
%     'YTick',[],...
%     'Color','none');

%     'YAxisLocation','right',...
% hax2.YTick = []

% add missing time notes
yLim = ylim;
ymk1 = 0.85*yLim(1);
ymk2 = 0.85*yLim(2);
for ii=1:length(dtBigInds)
    istart = dtBigInds(ii)-1;
    istop = dtBigInds(ii);
    tcent = mean(time2(istart:istop));
    tstr = num2str(round(tgapmeas(ii)/60));
    text(hax1,tcent,ymk1,['~' tstr ' min~'],'HorizontalAlignment','center')
    
    % server time
    tserv = mean([tcent time2(istop)]);
    sTime = datestr(servTime(istart),'yy-mm-dd HH:MM');
    text(hax1,tserv,ymk2,['[' sTime ']'],'HorizontalAlignment','center')
    
    % plot vertical line at start of each section
    tline = time2(istop);
    plot(hax1,[tline tline],[yLim(1) yLim(2)],':k','LineWidth',1);
end
title(hax1,titleStr,'FontSize',16,'FontWeight','bold'); grid on;
xlabel(hax1,'t(sec)','FontSize',14,'FontWeight','bold');
ylabel(hax1,'uT','FontSize',14,'FontWeight','bold');
legend(hax1,'X','Y','Z','vectR')


% % % % create custom data cursor display
% % % dcm_obj = datacursormode(figN);
% % % set(dcm_obj,'UpdateFcn',@dispMkrTimeFcn)
% set(dcm_obj,'Enable','on')
% set(dcm_obj,'DisplayStyle','datatip')
% dispMkrStruct.dcm_obj1 = dcm_obj;
% 
% hTarget = handle(hplot);
% hDatatip1 = dcm_obj.createDatatip(hTarget);
% %         pause(0.1); drawnow
% hDatatip2 = dcm_obj.createDatatip(hTarget);
% %         pause(0.1); drawnow
% 
% % dispMkrStruct.dcm_obj1 = dcm_obj1;
% 
% % add on to curseAy
% % if ~isfield(dispMkrStruct,'curseAy') || isempty(dispMkrStruct.curseAy)
% %     dispMkrStruct.curseAy = [];
% % end
% dispMkrStruct.hTarget = hTarget;
% dispMkrStruct.hDatatip1 = hDatatip1;
% dispMkrStruct.hDatatip2 = hDatatip2;
% % dispMkrStruct.curseAy = [dispMkrStruct.curseAy, curseAy1];
% 
% 
% % Update the datatip marker appearance
% set(hDatatip1, 'MarkerSize',msizes(1), 'MarkerFaceColor',mfclrs(1,:), ...
%     'MarkerEdgeColor',meclrs(1,:), 'Marker','>', 'HitTest','off');
% set(hDatatip2, 'MarkerSize',msizes(2), 'MarkerFaceColor',mfclrs(2,:), ...
%     'MarkerEdgeColor',meclrs(2,:), 'Marker','<', 'HitTest','off');


%%% >>> mag data vs time

