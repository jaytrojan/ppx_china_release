function ParkingStruct = Parking_struct_init_3inch(ParkingStruct)


ParkingStruct.STD_threshUp          = single(1.0);   % high threshold on STD for 3inch sensor
ParkingStruct.detection_threshUp    = single(1.0);   % high threshold on MA  for 3inch sensor
