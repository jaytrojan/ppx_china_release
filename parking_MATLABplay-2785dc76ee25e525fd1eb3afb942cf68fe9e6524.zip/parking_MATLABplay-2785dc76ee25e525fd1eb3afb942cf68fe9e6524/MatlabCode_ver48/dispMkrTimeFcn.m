function output_txt = dispMkrTimeFcn(obj,event_obj)
% Display the position of the data cursor
% obj          Currently not used (empty)
% event_obj    Handle to event object
% output_txt   Data cursor text string (string or cell array of strings).


global  dataInfoExtra;

% servTime = dataInfoExtra.servTime;


pos = get(event_obj,'Position');
index = get(event_obj,'DataIndex');

tserv = dataInfoExtra.servTime(index);


output_txt = {...
    ['X: ',num2str(pos(1))],...
    ['Y: ',num2str(pos(2))]...
    ['t: ',char(tserv)]...
    };


