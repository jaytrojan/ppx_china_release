%% Algorithm using SSA and SSR with real-time functionality 
% No motion data


% close all;
clear; clc;
dbstop if error


% choose and open data file
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\original')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\app_data')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors3')



% [alldatfiles,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File', 'MultiSelect', 'on');
% numfiles=length(alldatfiles);
% 
% 
% for file_index=1:numfiles
% 
%     FileName=char(alldatfiles(file_index));



% % Load PPG and Accel data (need to select multiple data files)
[FileName,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File');


[mraw,timeRaw,SentralOutput,raw_rate,markerTimes,markNames] = Read_Data(FileName);


magN = sqrt(sum(mraw.^2,2));



% plot: mag data with markers
figure;   
subplot(2,1,1);plot(timeRaw,mraw); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');

for i=1:length(markerTimes)
    plot([markerTimes(i),markerTimes(i)],y1);hold on;
end



subplot(2,1,2); plot(timeRaw,magN); grid on;










tic;



%% Setup data structures
ParkingStruct = Parking_struct_init;



if raw_rate <= ParkingStruct.HS_rate
    
    warning('upsampling is not supported');   
    
    magData       = mraw;
    time          = timeRaw;
    SentralOutput = SentralOutput;  
    
else
   
    factor = floor(raw_rate/ ParkingStruct.HS_rate);
    sprintf('Down Sampling Factor: %f',factor);    
    
    magData       = downsample(mraw,factor);
    time          = downsample(timeRaw,factor);
    SentralOutput = downsample(SentralOutput,factor);
end
    


% magData       = magData(61:end,:);
% time          = time(61:end);
% SentralOutput = SentralOutput(61:end);



N3 = length(magData);


magNdata = zeros(N3,1);
mag_diff = zeros(N3,1);
phase_level = zeros(N3,1);
detection_output = zeros(N3,1);

car_state = zeros(N3,2);

MEAN_value = zeros(N3,1);
STD_value = zeros(N3,1);

MEAN_value2 = zeros(N3,3);

moving_avg = zeros(N3,1);

MEAN_Baseline_value = zeros(N3,1);
STD_Baseline_value = zeros(N3,1);
MEAN_Occupied_value = zeros(N3,1);
STD_Occupied_value = zeros(N3,1);



ALG2Level = zeros(N3,1);
car_state_alg2 = zeros(N3,1);

car_state_buffer =zeros(N3,1);

Alarm_level = zeros(N3,1);

for i = 1:length(magData)
    
    
    if i == 200
        1;
    end
    
    
% %     if i == 220
% %         ParkingStruct.Context_Input = uint8(3);
% % %         ParkingStruct.LS_Trigger_FLAG  = uint8(0);    % trigger the Alarm: jump to high speed mode  
% %     end
    
    
    ParkingStruct.NUM = i;
    ParkingStruct.time = time(i);
    
    
    data = sqrt(sum(magData(i,:).^2,2));
    


    
%     % ^^^^^^ rewrite the threshold  ^^^^^^^^^^^^^^^^
%     ParkingStruct.HS_Trigger_thresh   = single(3);
%     
%     % ^^^^^^ rewrite the context input value  ^^^^^^^^^^^^^    
%     ParkingStruct.Context_Input       = uint8(0);

    
    
    
    ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),0);

                
%     if ParkingStruct.Context_Input == uint8(1)  % context input in NO CAR state  -- Re-calibration
% 
%         if ~ParkingStruct.Reset_FLAG
% 
%             ParkingStruct = Parking_structure_reset(ParkingStruct);
% 
%         end           
% 
%         ParkingStruct = Calibration_process(ParkingStruct, magData(i,:));
%         
% 
%         
%     elseif ParkingStruct.Context_Input == uint8(3)  % context input in NO CAR state  -- Re-calibration
% 
%         ParkingStruct.LS_Trigger_FLAG  = uint8(1);    % trigger the Alarm: back to low speed mode
%         ParkingStruct.LS_TO_HS_FLAG    = uint8(0);    % reset to ZERO when go back to low speed mode            
%             
%         ParkingStruct.Context_Input    = uint8(0);        
%         
%         
%         ParkingStruct.dataBuffer          = zeros(3,1,'single');
% 
%         ParkingStruct.AVG                 = single(0);
%         ParkingStruct.STD                 = single(0);
% 
%         ParkingStruct.AVGSUM              = single(0);
%         ParkingStruct.STDSUM              = single(0);
% 
%         ParkingStruct.state0_count        = uint16(0);
%         ParkingStruct.state1_count        = uint16(0);
%         ParkingStruct.state2_count        = uint16(0);
%         ParkingStruct.state3_count        = uint16(0);
% 
% 
%         ParkingStruct.car_present2        = ParkingStruct.Context_Input;    
% 
%         ParkingStruct.car_presentBuffer   = ones(4,1,'uint8') * ParkingStruct.Context_Input;     
% 
%         ParkingStruct.car_presentCur      = ParkingStruct.Context_Input;  
%         ParkingStruct.car_presentPre      = ParkingStruct.Context_Input;        
%         
%         
%    
%     else
%     
%     
%        if ~ParkingStruct.Calibration_FLAG  
% 
%            ParkingStruct = Calibration_process(ParkingStruct, magData(i,:));
% 
%        else
% 
%             if ParkingStruct.LS_Trigger_FLAG  == uint8(1) ...
%                     && ((abs(magData(i,1)-magData(i-1,1))> ParkingStruct.HS_Trigger_thresh) || (abs(magData(i,2)-magData(i-1,2))> ParkingStruct.HS_Trigger_thresh) ...
%                     || (abs(magData(i,3)-magData(i-1,3))> ParkingStruct.HS_Trigger_thresh) )
% 
%                 ParkingStruct.LS_Trigger_FLAG     = uint8(0);
%                 
%                 ParkingStruct.LS_TO_HS_FLAG       = uint8(1);                 
%                 ParkingStruct.LS_TO_HS_FLAG2      = uint8(1); 
%                 
% 
%                 ParkingStruct.Car_State_last_HS   = ParkingStruct.car_presentCur;
%                 
%                 ParkingStruct.SecondSensor_Req_FLAG  = uint8(0);
%                 
%                 
%                 ParkingStruct = Parking_Algorithm(ParkingStruct, magData(i,:));
%                 
% %                 ParkingStruct = update_car_detector_Alg1(ParkingStruct, data);
% %                 ParkingStruct = update_car_detector_Alg2(ParkingStruct, magData(i,:));
%                 
% 
%             elseif ParkingStruct.LS_Trigger_FLAG  == uint8(0)
%                 
%                 
%                 ParkingStruct = Parking_Algorithm(ParkingStruct, magData(i,:));
%                 
% %                 ParkingStruct = update_car_detector_Alg1(ParkingStruct, data);
% %                 ParkingStruct = update_car_detector_Alg2(ParkingStruct, magData(i,:));
% 
% 
%             end
% 
%        end
%        
%        
%     end
    
    
%     fprintf('Results from Algo1: %d \n\n', ParkingStruct.car_presentCur2);
%     fprintf('Results from Algo2: %d \n\n', ParkingStruct.car_presentCur);

    
   magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
   MEAN_value(i,1) = ParkingStruct.AVG;
   MEAN_value(i,2) = ParkingStruct.moving_avg;
   STD_value(i,1)  = ParkingStruct.STD;
   
   MEAN_value2(i,:) = ParkingStruct.AVG2;
   
   
   moving_avg(i,1)=ParkingStruct.moving_avg;
   
   
   car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2]; 
   Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG; 
   
   RMS(i,1) = ParkingStruct.RMS;
   
   SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;
    
end


static_state1 = [ParkingStruct.AVGInit2 single(1)];
static_state = [static_state1; ParkingStruct.LS_StartValue_stateALL];

for i = 1:size(static_state,1)
    static_state(i,5) = sum(abs(static_state(i,1:3) - static_state(1,1:3)));
end





figure;
subplot(4,1,1); plot(time,magNdata),title('absolute mag'); grid on;
subplot(4,1,2); plot(time,MEAN_value(:,2)),title('MEAN'); grid on;
subplot(4,1,3); plot(time,STD_value),title('STD'); grid on;
subplot(4,1,4); plot(time,Alarm_level),title('Alarm Trigger Level'); grid on;



figure;
subplot(3,1,1); plot(time,moving_avg),title('Feature: Magnetic Counts Change');  grid on;
subplot(3,1,2); plot(time,car_state),title('Car States from MATLAB'); grid on; 
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
% xlabel('Time (Seconds)');



subplot(3,1,3); plot(time,car_state(:,1)),title('Car States from SENtral'); grid on;
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
xlabel('Time (Seconds)');



% figure;plot(SecondSensor_Req_FLAG);


% subplot(4,1,4); plot(time,detection_output),title('Theshold Detection'); grid on;
% set(gca,'YTick',0:3);
% labels = [
%         'Under Thresh   ';
%         'Over Thresh (t)';
%         'Over Thresh (s)';
%         'Anomaly        ';
%         ];
% set(gca,'YTickLabel',labels)