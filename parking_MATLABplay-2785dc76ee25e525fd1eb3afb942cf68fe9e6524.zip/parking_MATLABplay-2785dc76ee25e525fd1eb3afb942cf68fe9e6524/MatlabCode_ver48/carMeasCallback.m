function carMeasCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global plotInfo % dataInfo measInfo

%%% >>> callback for highlighting parking meas fields

bkgndMode = 1; % turns on greying out background plot lines

% %%% restore prev lines to default
% indUpdateOld = plotInfo.measIndex;
% if any(indUpdateOld)
%     for ii=1:length(indUpdateOld)
%         oldStyle = plotInfo.measRefStyleAy(indUpdateOld(ii));
%         h = plotInfo.hMeasAy(indUpdateOld(ii));
%         h.LineStyle = oldStyle.LineStyle;
%         h.Color = oldStyle.Color;
%         h.LineWidth = oldStyle.LineWidth;
%     end
% end

% % % %%% restore all lines to default
% % % for ii=1:length(plotInfo.hMeasAy)
% % %     oldStyle = plotInfo.measRefStyleAy(ii);
% % %     h = plotInfo.hMeasAy(ii);
% % %     h.LineStyle = oldStyle.LineStyle;
% % %     h.Color = oldStyle.Color;
% % %     h.LineWidth = oldStyle.LineWidth;
% % % end



indUpdate = src.Value-1;

carHiLightFcn(indUpdate,bkgndMode,plotInfo.measPlotS);

% % % plotInfo.measIndex = indUpdate;
% % % 
% % % %%% Set all lines to background first
% % % if bkgndMode
% % %     clrBkgnd = [1 1 1]*0.75; % background line color
% % %     if any(indUpdate)
% % %         for ii=1:length(plotInfo.hMeasAy)
% % %             h = plotInfo.hMeasAy(ii);
% % %             h.Color = clrBkgnd;
% % %         end
% % %     end
% % % end
% % % 
% % % 
% % % %%% update new lines
% % % if any(indUpdate)
% % %     clrAy = [...
% % %         0 1 1;... % cyan
% % %         0 0 1;... % b
% % %         0 1 0;... % g
% % %         1 0 0;... % r
% % %         1 0 1;... % m
% % %         1 1 0 ... % y
% % %         ];
% % %     
% % % %     styleAy = {...
% % % %              '-';... % cyan
% % % %              '--';... % b
% % % %              '-.';... % g
% % % %              ':';... %
% % % %              '-';... % r
% % % %              '--'};   % m
% % % 
% % %     nw = length(indUpdate);
% % %     wmin = 3; % min line width
% % %     wspace = 1.75;
% % %     wAy=wmin;
% % %     wmult = 1.0;
% % %     for ii=2:nw
% % %         wAy(ii) =  wAy(ii-1) + wmult*wspace;
% % %         wmult = wmult + 0.25*wmult;
% % %     end
% % % %     wAy = round(wAy(nw:-1:1));
% % %     wAy = (wAy(nw:-1:1));
% % %     if length(wAy)<2, wAy = wmin+wspace; end
% % %     
% % %     
% % %     iclr = 0; iw = 0;
% % %     for ii=1:length(indUpdate)
% % %         iclr=iclr+1; iw = iw+1;
% % %         if iclr>length(clrAy), iclr=length(clrAy); end
% % %         h = plotInfo.hMeasAy(indUpdate(ii));
% % % %         h.LineStyle = styleAy{iclr};
% % %         h.LineStyle = '-';
% % %         h.Color = clrAy(iclr,:);
% % %         h.LineWidth = wAy(iw);
% % %         uistack(h,'top');
% % %     end
% % % end




