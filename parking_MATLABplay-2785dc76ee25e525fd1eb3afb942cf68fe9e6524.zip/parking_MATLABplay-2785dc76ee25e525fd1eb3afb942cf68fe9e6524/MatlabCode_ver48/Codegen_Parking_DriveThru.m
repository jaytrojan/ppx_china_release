%emlc CompileAlgorithm -eg {[0 0 0]',[0 0 0]',[0 0 0]',0}  -c -report -T rtw:lib


% Switch to current directory & restore default path
p = mfilename('fullpath');
[pathstr, name, ext] = fileparts(p)
cd(pathstr)
restoredefaultpath
% warning on

close all
clear all

commandwindow

fprintf('\nGenerating AutoCode...\n')
warning off

% % load 'SPwrap_sample_data.mat'; % load sample data variables
% addpath('stepCounterMatlabCode');

addpath('em_overrides'); % only add this path
addpath('em_hw_api');
% addpath('Gestures');


%%% real time workshop config object
% rtwcfg = emlcoder.RTWConfig;
% rtwcfg = emlcoder.RTWConfig('ert'); % Engineering Laptop ert setting
cfg = coder.config('lib');
% cfg = coder.config('lib','ecoder',false);
% rtwcfg.ObjectivePriorities = 'Efficiency';
cfg.FilePartitionMethod = 'MapMFileToCFile'; % MapMFileToCFile or SingleFile
cfg.CCompilerOptimization = 'Off';
cfg.EnableVariableSizing = true;
cfg.InlineThreshold = int32(0);
cfg.HardwareImplementation.ProdHWDeviceType = 'ARM Compatible->ARM Cortex';
cfg.HardwareImplementation.TargetHWDeviceType = 'ARM Compatible->ARM Cortex';
cfg.HardwareImplementation.ProdLargestAtomicFloat = 'Float';
cfg.GenCodeOnly = true;

cfg.CustomSymbolStrFcn = 'Parking_$M$N';


% set to tool chain configuration - to remove code gen warning
cfg.GenerateMakefile = true;
cfg.MakeCommand = 'make_rtw';
cfg.TemplateMakefile = 'default_tmf';
cfg.CCompilerOptimization = 'Off';




ParkingStruct = Parking_struct_init_DriveThru;
data = zeros(1,3,'single');
AlarmSourceFLAG = uint8(0);
timestamp = uint32(0);

% set_allstruct_names2 -args {walkStruct}...
codegen  Parking_set_allstruct_names -args {ParkingStruct}...
         Parking_struct_init_DriveThru -args {}...
         Parking_AlgorithmWrap_DriveThru -args {ParkingStruct, data, timestamp,AlarmSourceFLAG}...
         -config cfg -c -report


fprintf('\nCode Generation Complete!\n')
