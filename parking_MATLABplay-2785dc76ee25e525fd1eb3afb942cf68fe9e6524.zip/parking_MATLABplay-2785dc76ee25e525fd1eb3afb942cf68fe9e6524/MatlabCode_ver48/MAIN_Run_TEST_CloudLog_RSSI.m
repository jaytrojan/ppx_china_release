%% Algorithm using SSA and SSR with real-time functionality 
% No motion data


close all;
clear; clc;
dbstop if error


% choose and open data file
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\continuous_mode_logs')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\issue_cases')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\power_line_simulation')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\regular_mode_logs_RSSI')





% % Load PPG and Accel data (need to select multiple data files)
[FileName,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File -mag data');


[mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw,sentralTimestamp,rawData_car_status] = Read_Data_CloudLog_RSSI(FileName);




% plot: mag data with markers
figure;   
subplot(3,1,1);
plot(mraw); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');


% subplot(3,1,2); plot(RSSIdata); grid on;
subplot(3,1,2); plot(SentralOutput); hold on; grid on; plot(DataRaw(:,8));
subplot(3,1,3); plot(RSSIdata); grid on;


figure;
subplot(2,1,1);plot(rawData_car_status(:,2)); grid on; 
subplot(2,1,2);plot(rawData_car_status(:,4)); grid on; 



tic;



%% Setup data structures
ParkingStruct = Parking_struct_init;


start_ind = 1;  %% 130;  %%%%670;   %%%1400;

magData       = mraw(start_ind:end,:);
time          = timeRaw(start_ind:end,:);
SentralOutput = SentralOutput(start_ind:end,:);
sentralTimestamp = sentralTimestamp(start_ind:end,:);
mode_type = DataRaw(start_ind:end,8);


magNdata = sqrt(sum(magData.^2,2));

figure;   
subplot(3,1,1);
plot(magData); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');


subplot(3,1,2); plot(magNdata); grid on;
subplot(3,1,3); plot(SentralOutput); grid on;




diffTime = [0; diff(time)];
diffTime(1) = diffTime(2);

HS_label = diffTime<0.5;





N3 = length(magData);


magNdata = zeros(N3,1);
mag_diff = zeros(N3,1);
phase_level = zeros(N3,1);
detection_output = zeros(N3,1);

car_state = zeros(N3,4);

MEAN_value = zeros(N3,2);
STD_value = zeros(N3,1);

MEAN_value2 = zeros(N3,3);

moving_avg = zeros(N3,1);

MEAN_Baseline_value = zeros(N3,1);
STD_Baseline_value = zeros(N3,1);
MEAN_Occupied_value = zeros(N3,1);
STD_Occupied_value = zeros(N3,1);



ALG2Level = zeros(N3,1);
car_state_alg2 = zeros(N3,1);

car_state_buffer =zeros(N3,1);

Alarm_level = zeros(N3,1);

for i = 1:length(magData)
    
    
    if i == 768
        1;
    end
    
    
    ParkingStruct.NUM               = single(i);

    
    
    if ((abs(magData(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
        || (abs(magData(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
        || (abs(magData(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
        || ParkingStruct.LS_Trigger_FLAG  == uint8(0)...
        || (i>1 && mode_type(i) == 20 &&  mode_type(i-1) == 10 )
    

    
        % hardware alarm 
%         ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
        ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),sentralTimestamp(i),1);
    end



%     % software alarm 
%     ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),sentralTimestamp(i),0);    
    
    

   magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
   MEAN_value(i,1) = ParkingStruct.AVG;
   STD_value(i,1)  = ParkingStruct.STD;
   
   MEAN_value2(i,:) = ParkingStruct.AVG2;
   
   MEAN_value(i,2) = ParkingStruct.moving_avg;
   
   moving_avg(i,1)=ParkingStruct.moving_avg;
   
   
   car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2 ParkingStruct.car_present ParkingStruct.car_present2]; 
   Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG; 
   
   RMS(i,1) = ParkingStruct.RMS;
   
   SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;
    
end



% static_state1 = [ParkingStruct.AVGInit2 single(1)];
% static_state = [static_state1; ParkingStruct.LS_StartValue_stateALL];
% 
% for i = 1:size(static_state,1)
%     static_state(i,5) = sum(abs(static_state(i,1:3) - static_state(1,1:3)));
%     static_state(i,6) = sqrt(sum(static_state(i,1:3).^2)) - sqrt(sum(static_state(1,1:3).^2));
% end







% figure;
% subplot(4,1,1); plot(time,magNdata),title('absolute mag'); grid on;
% subplot(4,1,2); plot(time,MEAN_value(:,2)),title('Feature: Magnetic Counts Change'); grid on;
% subplot(4,1,3); plot(time,STD_value),title('Feature: STD'); grid on;
% subplot(4,1,4); plot(time,Alarm_level),title('Alarm Trigger Level'); grid on;
% 
% 
% 
% figure;
% subplot(2,1,1); plot(time,moving_avg),title('Feature: Magnetic Counts Change');  grid on;
% subplot(2,1,2); plot(time,car_state(:,1)),title('Car States from MATLAB'); grid on; 
% set(gca,'YTick',1:4);
% labels = {
%         'Empty';
%         'Car Entering';
%         'Occupied';
%         'Car Leaving';
%         };
% set(gca,'YTickLabel',labels)
% % xlabel('Time (Seconds)');


% % subplot(3,1,3); plot(time,SentralOutput(1:length(time))),title('Car States from SENtral'); grid on;
% % set(gca,'YTick',1:4);
% % labels = {
% %         'Empty';
% %         'Car Entering';
% %         'Occupied';
% %         'Car Leaving';
% %         };
% % set(gca,'YTickLabel',labels)
% % xlabel('Time (Seconds)');





figure;
subplot(4,1,1); plot(magNdata),title('absolute mag'); grid on;
subplot(4,1,2); plot(MEAN_value(:,2)),title('Feature: Magnetic Counts Change'); grid on;
subplot(4,1,3); plot(STD_value),title('Feature: STD'); grid on;
subplot(4,1,4); plot(Alarm_level),title('Alarm Trigger Level'); grid on;



figure;
subplot(3,1,1); plot(moving_avg),title('Feature: Magnetic Counts Change');  grid on;
subplot(3,1,2); plot(car_state(:,1)),title('Car States from MATLAB'); grid on; 
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)



subplot(3,1,3); plot(SentralOutput(1:length(time))),title('Car States from SENtral'); grid on;
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
