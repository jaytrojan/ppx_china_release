function imageStructAy = loadImageTimeData(camDir,servTime)
%%% Load Images overlapping file times

imageStructAy = [];
% camDir = '..\..\Data\cameraLogs';

try
    dirList = dir(camDir);
    
    % find all logs with overlapping times to data server time
    timeStructAy = [];
    jj=0;
    for ii = 1:length(dirList)
        fname = dirList(ii).name;
        dirname = [dirList(ii).folder '\'];
        if ~(dirList(ii).isdir) && ~isempty(strfind(fname,'_time'))
            fnameTime  = fname;
            ifnd = (strfind(fnameTime,'_time'));
            fname = fnameTime(1:ifnd-1);
            
            timeAyLoad = load([dirname fnameTime],'timeAy');
            timeAyLoad = timeAyLoad.timeAy;
            
            jj=jj+1;
%             if jj==32
%                 aaa=000;
%             end
            timeStructAy(jj).dirname = dirname;
            timeStructAy(jj).fname = fname;
            timeStructAy(jj).fnameTime = fnameTime;
            timeStructAy(jj).timeAy = timeAyLoad;
        end
    end
    
    
    % build image vs time struct from matching times and load associated images
    tfileStart = servTime(1);
    tfileStop = servTime(end);
    
    tinds = [];
    
    % set pad large to get file on either side of log file times to cover end pts.
    tpad = 70*60; % pad time
    for ii = 1:length(timeStructAy)
        
        timeAy = timeStructAy(ii).timeAy;
        
        % convert to datetime format
        dateTimeAy = datetime(timeAy,'ConvertFrom','datenum');
        
        % check within data file time range
        timeFlags = dateTimeAy >= tfileStart - seconds(tpad) & dateTimeAy <= tfileStop + seconds(tpad);
        
%         if ii==32
%             aaa=000;
%         end
        
        if any(timeFlags)
            tinds = [tinds ii];
        end
    end
    tinds =  unique(tinds);
     
    fmt = 'tif';
    imageStructAy = timeStructAy(tinds);
    for ii = 1:length(imageStructAy)
        dirname = imageStructAy(ii).dirname;
        fname = imageStructAy(ii).fname;
        
        timeAy = imageStructAy(ii).timeAy;
        imageStructAy(ii).dateTimeAy = datetime(timeAy,'ConvertFrom','datenum');
        imageStructAy(ii).imageAy = loadImageArray([dirname fname],fmt);
        
%         if ii==32
%             aaa=000;
%         end
    end
    
    
catch
    disp('Load Parking Images Error!!!')
end