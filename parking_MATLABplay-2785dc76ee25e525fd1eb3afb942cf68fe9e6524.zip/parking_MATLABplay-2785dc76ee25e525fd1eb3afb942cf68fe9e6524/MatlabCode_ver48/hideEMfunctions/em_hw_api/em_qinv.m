% @file qinv.m
%
%

function q = qinv(q)
  %#codegen
  if isempty(coder.target)
    q(1:3) = -q(1:3);
  else
    coder.inline('always');

  if isa(q, 'single')
      %%% single precision
      coder.ceval('em_qinv', coder.ref(q));

    end
  end
end
