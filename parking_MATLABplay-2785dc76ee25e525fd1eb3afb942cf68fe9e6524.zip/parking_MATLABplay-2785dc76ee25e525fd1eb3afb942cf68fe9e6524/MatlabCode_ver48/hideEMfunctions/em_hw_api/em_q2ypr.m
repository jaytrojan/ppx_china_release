% @file q2ypr_eml.m
%
%

function ypr = q2ypr2_eml(q)
  %#codegen
  if isempty(coder.target)
    % Q2DCM(Q) converts a quaternion into heading(y), pitch(p) and roll(r)
    sqx = q(1)*q(1);
    sqy = q(2)*q(2);
    sqz = q(3)*q(3);
    sqw = q(4)*q(4);

    y = single(atan2(2.0 * (q(1)*q(2) + q(3)*q(4)),(sqx - sqy - sqz + sqw)));

    p = single(asin(-2.0 * (q(1)*q(3) - q(2)*q(4))));

    r = single(atan2(2.0 * (q(2)*q(3) + q(1)*q(4)),(-sqx - sqy + sqz + sqw)));
    
    ypr = [y p r];
  else
    coder.inline('always');

  if isa(q, 'single')
      %%% single precision
      ypr = single([0 0 0]);
      coder.ceval('em_q2ypr', coder.rref(q), coder.wref(ypr));

    end
  end
end
