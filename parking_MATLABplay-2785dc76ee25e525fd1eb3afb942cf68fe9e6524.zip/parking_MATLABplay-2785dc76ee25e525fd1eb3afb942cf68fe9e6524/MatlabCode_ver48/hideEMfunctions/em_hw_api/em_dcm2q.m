% @file dcm2q_eml.m
%
%

function q = dcm2q_eml(dcm)
  %#codegen
  if isempty(coder.target)
    % SP library version (single)
    q = single([single(0.5)*sqrt(max(single(0),single(1) + dcm(1,1) - dcm(2,2) - dcm(3,3))).*sign_eml(dcm(2,3)-dcm(3,2));...
                single(0.5)*sqrt(max(single(0),single(1) - dcm(1,1) + dcm(2,2) - dcm(3,3))).*sign_eml(dcm(3,1)-dcm(1,3));...
                single(0.5)*sqrt(max(single(0),single(1) - dcm(1,1) - dcm(2,2) + dcm(3,3))).*sign_eml(dcm(1,2)-dcm(2,1));...
                single(0.5)*sqrt(max(single(0),single(1) + dcm(1,1) + dcm(2,2) + dcm(3,3)))]');

  else
    coder.inline('always');

  if isa(dcm, 'single')
      %%% single precision
      q = single(zeros(1,4));
      coder.ceval('em_dcm2q', coder.rref(dcm), coder.wref(q));

    end
  end
end
