% @file isequal.m
%
%

function z = isequal(x, y)
  %#codegen
  if isempty(coder.target)
    z = builtin('isequal', x, y);
  else
    coder.inline('always');
    z = logical(0);
    
    if isa(x, 'double')
      %%% Double precision
      z = coder.ceval('em_fisequal', coder.rref(x), coder.rref(y), uint8(length(x)));

    elseif isa(x, 'single')
      %%% single precision
      z = coder.ceval('em_fisequalf', coder.rref(x), coder.rref(y), uint8(length(x)));

    elseif isinteger(x)
      %%% Integer
      z = coder.ceval('em_isequal', coder.rref(x), coder.rref(y), uint8(length(x)));

    else
      %%% Unable to determine type, using the maco EM_ISEQUAL
      coder.ceval('EM_ISEQUAL', coder.rref(x), coder.rref(y), uint8(length(x)));
    end
  end
end
