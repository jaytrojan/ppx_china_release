% @file rad2deg.m
%
%

function y = rad2deg(x)
  %#codegen
  if isempty(coder.target)
    y = x * 180 / pi;
  else
    coder.inline('always');

    if isa(x, 'double')
      %%% Double precision
      y = coder.ceval('em_rad2deg', x);

    elseif isa(x, 'single')
      %%% single precision
      y = coder.ceval('em_rad2degf', x);

    end
  end
end
