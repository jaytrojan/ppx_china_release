% @file q2ENU.m
%
%

function q = q2ENU(q)
  %#codegen
  if isempty(coder.target)
    %
    % q2ENU
    % Convert NED quaternion to ENU quaternion
    % algorithm and outputs Windows 8 quaternion, DCM, and azimuth pitch roll
    % 
    % INPUTS:
    % q         -> NED referenced q
    %
    % OUTPUTS:
    % qENU      -> ENU referenced q
    % ENU       -> ENU referenced DCM
    % apr       -> azimuth, pitch, roll in ENU except for reversed azimuth

    apr = EP2Euler312(q)'; % find ENU based apr from NED based q

    % reverse azimuth to match compass definition
    % apr = [e(1) -e(3) -e(2)]; % android version
    apr = [-apr(1) apr(3) apr(2)]; % windows 8 version - apr

    NED2ENU = single([0  1  0;
                      1  0  0;
                      0  0 -1]); % general rotation from NED to ENU
    NED = q2dcm_eml(q); % convert our quaternion to a dcm
    ENU = NED*NED2ENU; % change dcm frames

    qENU = dcm2q_eml(ENU); % convert enu to a quaternion  else
    q = qENU;
  else
    coder.inline('always');
    
    if isa(q, 'single')
      %%% single precision
      coder.ceval('em_NEDq2ENUq', coder.ref(q));

    end
  end
end
