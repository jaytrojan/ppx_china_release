% @file qdecomp_eml.m
%
%

function [v phi] = qdecomp_eml(q)
  %#codegen
  if isempty(coder.target)
    q=qnorm_eml(q);

    hfPhi=acos(q(:,4));
    sin_hfPhi=sin(hfPhi);

    if sin_hfPhi == 0
      v = [q(1) q(2) q(3)];
    else
      sin_hfPhi_inv = single(1)./sin_hfPhi;
      v = q(1:3).*sin_hfPhi_inv;
    end

    phi=2*hfPhi;

  else
    coder.inline('always');

  if isa(q, 'single')
      %%% single precision
      v = single([0 0 0]);
      phi = single(0);
      coder.ceval('em_qdecomp', coder.rref(q), coder.wref(v), coder.wref(phi));

    end
  end
end
