% @file q2dcm.m
%
%

function dcm = q2dcm(q)
  %#codegen
  if isempty(coder.target)
    q1q1=q(1).*q(1);
    q1q2=q(1).*q(2);
    q1q3=q(1).*q(3);
    q1q4=q(1).*q(4);

    q2q2=q(2).*q(2);
    q2q3=q(2).*q(3);
    q2q4=q(2).*q(4);

    q3q3=q(3).*q(3);
    q3q4=q(3).*q(4);
  
    q4q4=q(4).*q(4);

    % Build DCM
    dcm = single(zeros(3,3));
    dcm(1,1) =  q1q1 - q2q2 - q3q3 + q4q4;
    dcm(2,2) = -q1q1 + q2q2 - q3q3 + q4q4;
    dcm(3,3) = -q1q1 - q2q2 + q3q3 + q4q4;
        
    dcm(1,2) = single(2)*(q1q2 + q3q4);
    dcm(1,3) = single(2)*(q1q3 - q2q4);
  
    dcm(2,1) = single(2)*(q1q2 - q3q4);
    dcm(2,3) = single(2)*(q2q3 + q1q4);
  
    dcm(3,1) = single(2)*(q1q3 + q2q4);
    dcm(3,2) = single(2)*(q2q3 - q1q4);
    
  else
    coder.inline('always');

  if isa(q, 'single')
      %%% single precision
      dcm = single(zeros(3,3));
      coder.ceval('em_q2dcm', coder.rref(q), coder.wref(dcm));

    end
  end
end
