% @file q2apr.m
%
%

function arp = q2apr(q)
  %#codegen
  if isempty(coder.target)
    apr = q2apr(q);
  else
    coder.inline('always');

  if isa(q, 'single')
      %%% single precision
      coder.ceval('em_q2apr', code.rref(q), coder.wref(apr));
      
    end
  end
end
