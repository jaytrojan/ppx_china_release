% @file deg2rad.m
%
%

function y = deg2rad(x)
  %#codegen
  if isempty(coder.target)
    y = x * pi / 180;
  else
    coder.inline('always');

    if isa(x, 'double')
      %%% Double precision
      y = coder.ceval('em_deg2rad', x);

    elseif isa(x, 'single')
      %%% single precision
      y = coder.ceval('em_deg2radf', x);

    end
  end
end
