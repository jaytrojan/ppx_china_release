% @file qmult_eml.m
%
%

function qb = qmult_eml(qa, qb)
  %#codegen
  if isempty(coder.target)
    % q_out = q2 X q1
    % q1 (first input) rotation applied first [on right];
    % q2 (second input) rotation applied second, [on left]
    % this is reverse of rotation matrix rotation from the left convention
    qa = [qa(1)  qa(2)  qa(3)  qa(4)]*...
         [qb(4) -qb(3)  qb(2) -qb(1)
          qb(3)  qb(4) -qb(1) -qb(2)
         -qb(2)  qb(1)  qb(4) -qb(3)
          qb(1)  qb(2)  qb(3)  qb(4)];
	  
  else
    coder.inline('always');

  if isa(qa, 'single')
      %%% single precision
      coder.ceval('em_qmult', coder.rref(qa), coder.ref(qb));

    end
  end
end
