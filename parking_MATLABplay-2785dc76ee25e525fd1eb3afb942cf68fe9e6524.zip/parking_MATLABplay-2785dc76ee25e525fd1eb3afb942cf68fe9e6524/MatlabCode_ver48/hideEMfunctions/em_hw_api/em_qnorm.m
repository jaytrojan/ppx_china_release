% @file qnorm_eml.m
%
%

function q = qnorm_eml(q)
  %#codegen
  if isempty(coder.target)
    q = q/sqrt(sum(q.*q));
  else
    coder.inline('always');

  if isa(q, 'single')
      %%% single precision
      coder.ceval('em_qnorm', coder.ref(q));

    end
  end
end
