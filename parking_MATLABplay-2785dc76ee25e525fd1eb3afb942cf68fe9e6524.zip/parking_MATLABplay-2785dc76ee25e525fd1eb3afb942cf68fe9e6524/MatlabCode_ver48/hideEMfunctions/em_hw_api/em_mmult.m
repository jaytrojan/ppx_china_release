% @file mmult.m
%
%

function y = mmult(a, b)
  %#codegen
  if isempty(coder.target)
    y = builtin('mmult', a, b);
  else
    coder.inline('always');
  
  if isa(a, 'double')
      %%% single precision
      coder.ceval('em_mmult', coder.rref(a), length(a(0,:)), length(a(:,0)), coder.rref(b), length(b(0,:)), length(b(:,0)), coder.ref(y));

    end
    
  elseif isa(a, 'single')
      %%% single precision
      coder.ceval('em_mmultf', coder.rref(a), length(a(0,:)), length(a(:,0)), coder.rref(b), length(b(0,:)), length(b(:,0)), coder.ref(y));

    end
  end
end
