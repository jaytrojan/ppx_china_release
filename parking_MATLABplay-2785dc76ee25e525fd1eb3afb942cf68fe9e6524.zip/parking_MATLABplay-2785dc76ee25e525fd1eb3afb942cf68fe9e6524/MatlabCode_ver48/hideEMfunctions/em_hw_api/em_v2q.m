% @file v2quat.m
%
%

function q = v2quat(v1, v2)
  %#codegen
  if isempty(coder.target)
    % creates body frame quaternion from the two vector inputs
    % normalized here internally
    mcal = v1;
    acal = v2;
    mR = sqrt(sum(mcal.^2,2));
    aR = sqrt(sum(acal.^2,2));
    mcaln = mcal./repmat(mR,1,3);
    acaln = acal./repmat(aR,1,3);

    down_bf = acaln; %up = -G
    down_bf = down_bf/norm(down_bf); %normalize
    e_bf = cross(acaln,mcaln); %east = G x mag
    e_bf = e_bf/norm(e_bf);
    n_bf = cross(e_bf,down_bf);
    T_nb = [n_bf ; e_bf ; down_bf]; % rotation nav to body
    q_nb = dcm2q_eml(T_nb); % create orientation quaternion
    q = q_nb;
  else
    coder.inline('always');

  if isa(v1, 'single')
      %%% single precision
      q = single([0 0 0 0]);
      coder.ceval('em_v2q', coder.rref(v1), coder.rref(v2), coder.wref(q));
    end
  end
end
