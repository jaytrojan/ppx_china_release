% @file mean.m
%
%

function y = mean(x)
  %#codegen
  if isempty(coder.target)
    y = builtin('mean', x);
  else
    coder.inline('always');

    if isa(x, 'double')
      %%% Double precision
      y = coder.ceval('em_vmean', coder.rref(x), uint8(length(x)));

    elseif isa(x, 'single')
      %%% single precision
      y = coder.ceval('em_vmeanf', coder.rref(x), uint8(length(x)));

    else
      %%% Unable to determine type, using the maco EM_MEAN
      coder.ceval('EM_MEAN', coder.rref(x), uint8(length(x)));
    end
  end
end
