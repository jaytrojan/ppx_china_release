% @file sum.m
%
%

function y = sum(x)
  %#codegen
  if isempty(coder.target)
    y = builtin('sum', x);
  else
    coder.inline('always');

    if isa(x, 'double')
      %%% Double precision
      y = coder.ceval('em_vfsum', coder.rref(x), uint8(length(x)));

    elseif isa(x, 'single')
      %%% single precision
      y = coder.ceval('em_vfsumf', coder.rref(x), uint8(length(x)));

    elseif isinteger(x)
      %%% Integer: todo uint32 / uint16 / uint8
      y = coder.ceval('em_vsum', coder.rref(x), uint8(length(x)));

    else
      %%% Unable to determine type, using the maco EM_ABS
      coder.ceval('EM_ABS', coder.rref(x), uint8(length(x)));
    end
  end
end
