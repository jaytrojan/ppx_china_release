% @file abs.m
%
%

function x = sign(x)
  %#codegen
  if isempty(coder.target)
    x = builtin('sign', x);
  else
    coder.inline('always');

    size_input = size(x);
    size_x = size_input(1);
    size_y = size_input(2);

    if isa(x, 'double')
       xout = double(0);
    elseif isa(x, 'single')
       xout = single(0);
    elseif isinteger(x)
       xout = int32(0);
    end
    
    
    if (uint8(size_x * size_y) == uint8(1))
    
      % Single Input
      if isa(x, 'double')
        xout = coder.ceval('em_fsign', x);
      elseif isa(x, 'single')
        xout = coder.ceval('em_fsignf', x);
      elseif isinteger(x)  
        xout = coder.ceval('em_sign', x);
      end
      x = xout;   
    else
    
      % Vector Input
      if isa(x, 'double')
        coder.ceval('em_vfsign', coder.ref(x), uint8(size_x * size_y));
      elseif isa(x, 'single')
        coder.ceval('em_vfsignf', coder.ref(x), uint8(size_x * size_y));
      elseif isinteger(x)  
        coder.ceval('em_sign', coder.ref(int32(x)), uint8(size_x * size_y));     
      else
        %%% Unable to determine type, using the maco EM_ABS
        coder.ceval('EM_SINE', coder.ref(x), uint8(size_x * size_y));
      end
      
    end
  end
end
