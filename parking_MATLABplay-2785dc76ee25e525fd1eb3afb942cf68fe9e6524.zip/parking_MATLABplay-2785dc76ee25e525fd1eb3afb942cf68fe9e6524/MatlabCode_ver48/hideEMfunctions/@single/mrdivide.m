% @file em_mdiv.m
%
%

function x = mdiv(a_in, b_in)
  %#codegen
  if isempty(coder.target)
    x = builtin('mrdivide', a_in, b_in);
  else
    coder.inline('always');
    size_a = size(a_in);
    size_b = size(b_in);
    
    sizex = max(size_a(1), size_b(1));
    sizey = max(size_a(2), size_b(2));
    
    a_check = a_in;
    b_check = b_in;   
    
    if(~isa(a_check, class(b_check)))
      if(isa(a_check, 'single'))
        b = single(b_check);
	a = a_check;
      elseif(isa(b_check, 'single'))
        a = single(a_in);
	b = b_check;
      else
        a = a_check;
	b = b_check;
      end
    else
      a = a_check;
      b = b_check;
    end


    if isa(a, 'double')
      %%% double precision
      if (uint8(sizex * sizey) == uint8(1))
        x = double(0);
        x = coder.ceval('em_div', a, b);    
      elseif(all(size(a) == size(1)))
        x = double(zeros(size_a));
        for i=1:(sizex * sizey)
          x(i) = coder.ceval('em_divf', a, b(i));	  
	end
      elseif(all(size(b) == size(1)))
        x = double(zeros(size_a));
        coder.ceval('em_vfdivfs', coder.ref(a), b, uint8(sizex * sizey));
	x = a;
      else        %%% Not implimented.      
        x = ones(size(a), class(a));	
        coder.ceval('EM_MDIVD', coder.rref(a_in), coder.rref(b_in), coder.wref(x), uint8(sizex * sizey));    
      end
    elseif isa(a, 'single')
      %%% single precision
      if (uint8(sizex * sizey) == uint8(1))
        x = single(0);
        x = coder.ceval('em_divf', a, b);    
      elseif(all(size(a) == size(1)))
        x = single(zeros(size_a));
        for i=1:(sizex * sizey)
          x(i) = coder.ceval('em_divf', a, b(i));	  
	end
      elseif(all(size(b) == size(1)))
        x = single(zeros(size_a));	
        coder.ceval('em_vfdivfs', coder.ref(a), b, uint8(sizex * sizey));
	x = a;
      else
        %%% Not implimented.
        x = ones(size(a), class(a));     
        coder.ceval('EM_MDIVS', coder.rref(a_in), coder.rref(b_in), coder.wref(x), uint8(sizex * sizey));    
      end
    else
      %%% Unable to determine type, using the maco EM_MDIV
      x = ones(size(a), class(a));
      coder.ceval('EM_MDIV', coder.rref(a_in), coder.rref(b_in), coder.wref(x), uint8(sizex * sizey));
    end
  end
end


    
