% @file norm.m
%
%

function a = norm(x, normtype)
  %#codegen
  if isempty(coder.target)
    if(nargin == 2)
      a = builtin('norm', x, normtype);
    else
      a = builtin('norm', x);
    end
  else
  
    coder.inline('always');

    size_input = size(x);
    size_x = size_input(1);
    size_y = size_input(2);

    if (uint8(size_x * size_y) == uint8(1))
      a = x;
    else
      if isa(x, 'double')
	a = double(0);
        coder.ceval('em_norm', coder.ref(x), uint8(size_x * size_y));
      elseif isa(x, 'single')
        a = single(0);
        a = coder.ceval('em_normf', coder.ref(x), uint8(size_x * size_y));
      else
        %%% Unable to determine type, using the maco EM_NORM
        coder.ceval('EM_NORM', coder.ref(x), uint8(size_x * size_y));
      end
    end
  end
end
