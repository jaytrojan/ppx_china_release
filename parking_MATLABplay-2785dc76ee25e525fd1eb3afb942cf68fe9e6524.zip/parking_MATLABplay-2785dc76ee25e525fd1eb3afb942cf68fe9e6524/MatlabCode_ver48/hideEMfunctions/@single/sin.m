% @file sin.m
%
%

function y = sin(x)
  %#codegen
  if isempty(coder.target)
    y = builtin('sin', x);
  else
    coder.inline('always');

    size_in = size(x);
    size_x = size_in(1);
    size_y = size_in(2);
    

    if isa(x, 'double')
      %%% Double precision
      y = double(zeros(size_in));      
      for i = 1:size_x
        for j = 1:size_y
          y(i,j) = coder.ceval('em_sin', x(i,j));
        end
      end
      

    elseif isa(x, 'single')
      %%% single precision
      y = single(zeros(size_in));      
      for i = 1:size_x
        for j = 1:size_y
          y(i,j) = coder.ceval('em_sinf', x(i,j));
        end
      end

    end
  end
end
