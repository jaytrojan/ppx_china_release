% @file sqrt.m
%
%

function x = sqrt(x)
  %#codegen
  if isempty(coder.target)
    x = builtin('realsqrt', x);
  else
    coder.inline('always');

    size_a = size(x);
    sizex = size_a(1);
    sizey = size_a(2);
    
    if isa(x, 'double')
      %%% Double precision
      if (uint8(length(x)) == uint8(1))
        x = coder.ceval('em_sqrt', x);
      else
        coder.ceval('em_vsqrt', coder.ref(x), uint8(sizex * sizey));
      end

    elseif isa(x, 'single')
      %%% single precision
      if (uint8(length(x)) == uint8(1))
	x = coder.ceval('em_sqrtf', x);
      else
        coder.ceval('em_vsqrtf', coder.ref(x), uint8(sizex * sizey));
      end

    else
      %%% Unable to determine type, using the maco EM_SQRT
      coder.ceval('EM_SQRT', coder.ref(x), uint8(sizex * sizey));
    end
  end
end
