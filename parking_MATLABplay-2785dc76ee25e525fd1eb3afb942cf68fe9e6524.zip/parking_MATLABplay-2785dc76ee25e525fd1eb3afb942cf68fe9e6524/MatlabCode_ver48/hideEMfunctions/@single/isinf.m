% @file isinf.m
%
%

function y = isinf(x)
  %#codegen
  if isempty(coder.target)
    y = builtin('isinf', x);
  else
    coder.inline('always');
    
    size_in = size(x);
    size_x = size_in(1);
    size_y = size_in(2);
    
    y = logical(zeros(size_in));
    
    
    
    %%% em_isinff is the only supported api call at the moment.
    
    if isa(x, 'double')
      for i = 1:size_x
        for j = 1:size_y
          y(i,j) = coder.ceval('em_isinf', x(i,j));
        end
      end


    elseif isa(x, 'single')
      for i = 1:size_x
        for j = 1:size_y
          y(i,j) = coder.ceval('em_isinff', x(i,j));
        end
      end

    else
      for i = 1:size_x
        for j = 1:size_y
          y(i,j) = coder.ceval('EM_ISINF', x(i,j));
        end
      end
    end
  end
end
