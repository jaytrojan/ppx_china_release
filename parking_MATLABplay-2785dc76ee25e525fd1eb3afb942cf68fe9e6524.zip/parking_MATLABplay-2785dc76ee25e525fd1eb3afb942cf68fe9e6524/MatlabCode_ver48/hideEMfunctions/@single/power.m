% @file sqr.m
%
%

function x = power(x, y)
  %#codegen
  if isempty(coder.target)
    x = builtin('power', x, y);
  else
    coder.inline('always');

    size_in = size(x);
    size_x = size_in(1);
    size_y = size_in(2);

    if(y == 2)
    if isa(x, 'double')
      if (uint8(size_x * size_y) == uint8(1))
        x = coder.ceval('em_fsqr', x);
      else
        %%% Double precision
        coder.ceval('em_vfsqr', coder.ref(x), uint8(size_x * size_y));
      end

    elseif isa(x, 'single')
      if (uint8(size_x * size_y) == uint8(1))
	x = coder.ceval('em_fsqrf', x);
      else
        %%% single precision
        coder.ceval('em_vfsqrf', coder.ref(x), uint8(size_x * size_y));
      end

    elseif isinteger(x)
      %%% Integer, todo: check for uint8 vs uint16 vs uint32
      if (uint8(length(x)) == uint8(1))
        x = coder.ceval('em_sqr', x);
      else
        coder.ceval('em_vsqr', coder.ref(uint32(x)), uint8(size_x * size_y));
      end

    else
      %%% Unable to determine type, using the maco EM_SQR
      coder.ceval('EM_SQR', coder.ref(x), uint8(size_x * size_y));
    end
    else
      for i=1:size_x * size_y
      x(i) = coder.ceval('pow', x(i), y);
    end
  end
end
