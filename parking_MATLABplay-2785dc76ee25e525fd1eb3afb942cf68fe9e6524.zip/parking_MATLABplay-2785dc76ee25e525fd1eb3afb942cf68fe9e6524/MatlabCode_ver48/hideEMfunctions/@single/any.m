% @file any.m
%
%

function y = any(x, dim)
  %#codegen
  if isempty(coder.target)
    if(nargin == 1)
        y = builtin('any', x);
    else
        y = builtin('any', x, dim);
    end
  else
    coder.inline('always');

    if(nargin == 1)
      dim = 1;
    end

    size_a = size(x);
    sizex = size_a(1);
    sizey = size_a(2);
    
    if isa(x, 'double')
      %%% Double precision
      if(sizex == 1 || sizey == 1)
          y = logical(0);
	  y = coder.ceval('em_fany', coder.rref(x), uint8(sizex * sizey));
	  
      elseif(dim == 1)
        y = logical(zeros(1,sizey));
        for i = 1:sizex
  	  xin = x(i,:);
	  y(i) = coder.ceval('em_fany', coder.rref(xin), uint8(sizey));
	end
      else % dim = 2
        y = double(zeros(sizex,1));
        for i = 1:sizey
  	  xin = x(:,i);
	  y(i) = coder.ceval('em_fany', coder.rref(xin), uint8(sizex));
	end
      end

    elseif isa(x, 'single')
      %%% Double precision
      if(sizex == 1 || sizey == 1)
          y = logical(0);
	  y = coder.ceval('em_fanyf', coder.rref(x), uint8(sizex * sizey));
	  
      elseif(dim == 1)
        y = logical(zeros(1,sizey));
        for i = 1:sizex
 	  xin = x(i,:);
	  y(i) = coder.ceval('em_fanyf', coder.rref(xin), uint8(sizey));
	end
      else % dim = 2
        y = logical(zeros(sizex,1));
        for i = 1:sizey
	  xin = x(:,i);
	  y(i) = coder.ceval('em_fanyf', coder.rref(xin), uint8(sizex));
	end
      end

    else
      %%% Unable to determine type, using the maco EM_ABS
      coder.ceval('EM_ANY', coder.rref(x), uint8(length(x)));
    end
  end
end
