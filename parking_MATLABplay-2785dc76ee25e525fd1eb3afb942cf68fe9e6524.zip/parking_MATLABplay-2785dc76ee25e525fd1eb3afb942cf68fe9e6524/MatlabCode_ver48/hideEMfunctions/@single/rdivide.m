% @file em_div.m
%
%

function x = div(a_in, b_in)
  %#codegen
  if isempty(coder.target)
    x = builtin('rdivide', a_in, b_in);
  else
    coder.inline('always');

    size_a = size(a_in);
    size_b = size(b_in);
    
    sizex = max(size_a(1), size_b(1));
    sizey = max(size_a(2), size_b(2));
    
    a_check = a_in;
    b_check = b_in;
    
    
    if(~isa(a_check, class(b_check)))
      if(isa(a_check, 'single'))
        b = single(b_check);
	a = a_check;
      elseif(isa(b_check, 'single'))
        a = single(a_in);
	b = b_check;
      else
        a = a_check;
	b = b_check;
      end
    else
      a = a_check;
      b = b_check;
    end
    
    
    if isa(a, 'double')
      %%% Double precision
      if (uint8(sizex * sizey) == uint8(1))
        x = double(0);
        x = coder.ceval('em_div', a, b);
      else
         x = double(zeros(size_a));
        if(all(size(a) == size(1)))
          for i=1:(sizex * sizey)
            x(i) = coder.ceval('em_div', a, b(i));	  
	  end
        elseif(all(size(b) == size(1)))
          coder.ceval('em_vfdivs', coder.ref(a), b, uint8(sizex * sizey));
	  x = a;
	else
          coder.ceval('em_vfdiv', coder.ref(a), coder.rref(b), uint8(sizex * sizey));
	  x = a;
	end
      end

    elseif isa(a, 'single')
      %%% single precision
      if (uint8(sizex * sizey) == uint8(1))
        x = single(0);
	x = coder.ceval('em_divf', a, b);
      else
         x = single(zeros(size_a));
        if(all(size(a) == size(1)))
          for i=1:(sizex * sizey)
            x(i) = coder.ceval('em_divf', a, b(i));	  
	  end
        elseif(all(size(b) == size(1)))
          coder.ceval('em_vfdivfs', coder.ref(a), b, uint8(sizex * sizey));
	  x = a;
	else
          coder.ceval('em_vfdivf', coder.ref(a), coder.rref(b), uint8(sizex * sizey));
	  x = a;
	end
      end

    else
      %%% Unable to determine type, using the maco EM_SQRT
      x = ones(size(a), class(a));
      coder.ceval('EM_DIV', a, b, x, uint8(sizex * sizey));
    end
  end
end
