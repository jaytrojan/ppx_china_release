% @file isnan.m
%
%

function y = isnan(x)
  %#codegen
  if isempty(coder.target)
    y = builtin('isnan', x);
  else
    coder.inline('always');

    size_a = size(x);
    sizex = size_a(1);
    sizey = size_a(2);
    
    y = logical(zeros(size_a));
   
    if isa(x, 'double')
      %%% Double precision
      for i = 1:sizex
        for j = 1:sizey
          y(i,j) = coder.ceval('em_isnan', x(i,j));
        end
      end

    elseif isa(x, 'single')
      %%% single precision
      for i = 1:sizex
        for j = 1:sizey
          y(i,j) = coder.ceval('em_isnanf', x(i,j));
        end	
      end

    else
      %%% Unable to determine type, using the maco EM_ISNAN
      coder.ceval('EM_ISNAN', coder.rref(x), uint8(size(x)), uint8(length(size(x))));
    end
  end
end
