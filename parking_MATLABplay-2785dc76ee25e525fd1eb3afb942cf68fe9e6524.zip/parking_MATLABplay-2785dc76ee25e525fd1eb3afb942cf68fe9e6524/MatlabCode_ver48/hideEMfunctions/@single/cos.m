% @file cos.m
%
%

function y = cos(x)
  %#codegen
  if isempty(coder.target)
    y = builtin('cos', x);
  else
    coder.inline('always');

    size_a = size(x);
    sizex = size_a(1);
    sizey = size_a(2);
    
    if isa(x, 'double')
      %%% Double precision
      y = double(zeros(size(x)));
      for i = 1:sizex
        for j = 1:sizey
          y(i,j) = coder.ceval('em_cos', x(i,j));
	end
      end

    elseif isa(x, 'single')
      %%% single precision
      y = single(zeros(size(x)));
      for i = 1:sizex
        for j = 1:sizey
          y(i,j) = coder.ceval('em_cosf', x(i,j));
	end
      end

    end
  end
end
