% @file floor.m
%
%

function x = floor(x)
  %#codegen
  if isempty(coder.target)
    x = builtin('floor', x);
  else
    coder.inline('always');

    size_in = size(x);
    size_x = size_in(1);
    size_y = size_in(2);
    
    if isa(x, 'double')
      %%% Double precision
      if (uint8(length(x)) == uint8(1))
        x = coder.ceval('em_floor', x);
      else
        coder.ceval('em_vfloor', coder.ref(x), uint8(size_x * size_y));
      end

    elseif isa(x, 'single')
      %%% single precision
      if (uint8(length(x)) == uint8(1))
	x = coder.ceval('em_floorf', x);
      else
        coder.ceval('em_vfloorf', coder.ref(x), uint8(size_x * size_y));
      end

    else
      %%% Unable to determine type, using the maco EM_FLOOR
      coder.ceval('EM_FLOOR', coder.ref(x), uint8(size_x * size_y));
    end
  end
end
