% @file cross.m
%
%

function y = cross(a, b, dim)
  %#codegen
  if isempty(coder.target)
    if(nargin == 2)
      y = builtin('cross', a, b);
    else
      y = builtin('cross', a, b, dim);
    end
  else
    coder.inline('always');
  
    if(nargin == 2)
      dim = 2;
    end
  
    size_a = size(b);
    sizex = size_a(1);
    sizey = size_a(2);
  
    if isa(a, 'double')
      %%% double precision     
      if(sizex * sizey == 3)
          y = double([0 0 0]);
	      coder.ceval('em_cross3', coder.rref(a), coder.rref(b), coder.wref(y));
      else
          y = double([0 0 0]);
	      coder.ceval('em_cross', coder.rref(a), coder.rref(b), length(size_a), sizex, sizey, coder.wref(y));
      end
   
    elseif isa(a, 'single')
      %%% single precision
      if(sizex * sizey == 3)
          y = single([0 0 0]);
	      coder.ceval('em_cross3f', coder.rref(a), coder.rref(b), coder.wref(y));
      else
          y = single([0 0 0]);
	      coder.ceval('em_crossf', coder.rref(a), coder.rref(b), length(size_a), sizex, sizey, coder.wref(y));
      end

    end
  end
end
