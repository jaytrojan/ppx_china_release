% @file atan2.m
%
%

function y = atan2(a, b)
  %#codegen
  assert(all(size(a) == size(b)));
  if isempty(coder.target)
    y = builtin('atan2', a, b);
  else
    coder.inline('always');

    size_a = size(a);
    sizex = size_a(1);
    sizey = size_a(2);
    
    if isa(a, 'double')
      %%% Double precision
      y = double(zeros(size(a)));
      for i = 1:sizex
        for j = 1:sizey
          y(i,j) = coder.ceval('em_atan2', a(i,j), b(i,j));
	end
      end
      
    elseif isa(a, 'single')
      %%% single precision
      y = single(zeros(size(a)));
      for i = 1:sizex
        for j = 1:sizey
          y(i,j) = coder.ceval('em_atan2f', a(i,j), b(i,j));
	end
      end

    end
  end
end
