function ParkingStruct = Parking_Algorithm2(ParkingStruct, data)


ParkingStruct.car_presentPre   = ParkingStruct.car_presentCur; 
ParkingStruct.car_presentPre2  = ParkingStruct.car_presentCur2; 


data1                          = single(data);
ParkingStruct.dataBuffer2      = shifting_array(ParkingStruct.dataBuffer2);
ParkingStruct.dataBuffer2(ParkingStruct.dataBufferSize,:)= data1;


data1                         = single(sqrt(data1(1)*data1(1)+data1(2)*data1(2)+data1(3)*data1(3)));
ParkingStruct.dataBuffer      = shifting_array(ParkingStruct.dataBuffer);
ParkingStruct.dataBuffer(end) = data1;



%% **************  Phase based Algorithm  **************************



%setup bias or calc avg.
if(ParkingStruct.local_avg == single(0))
   ParkingStruct.local_avg = data1;
   
else
    %take local average
    ParkingStruct.local_avg = ParkingStruct.filter_alpha*ParkingStruct.local_avg + ParkingStruct.filter_beta*data1;
end

% ****** FEATURE: DIFFERENCE between current mag and previous mag *********
ParkingStruct.dx_history      = shifting_array(ParkingStruct.dx_history);
ParkingStruct.dx_history(end) = single((data1 - ParkingStruct.local_avg)*(data1 - ParkingStruct.local_avg));


%get new moving average, compare to last, set new
if ParkingStruct.dx_history(1) > single(0)

    ParkingStruct.moving_avg = mean(ParkingStruct.dx_history);
    
else
    
    ParkingStruct.moving_avg = ParkingStruct.dx_history(end);
    
end


% ParkingStruct.level = ParkingStruct.moving_avg > ParkingStruct.detection_thresh;
% 
% % ParkingStruct.level

if ParkingStruct.moving_avg < ParkingStruct.detection_thresh
    
    
    % Previous STATE:  State 1- no car 
    if ParkingStruct.car_present2   == uint8(1)  %% NO CAR STATE  -- CALCULATE the baseline mean & STD value
        
        ParkingStruct.state1_count2  = ParkingStruct.state1_count2 + uint16(1);
                     
        
               
     % Previous STATE:  State 2 - Car In   
     elseif ParkingStruct.car_present2   == uint8(2)   
         
         
        if ParkingStruct.state2_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate 
            
            ParkingStruct.car_present2   = uint8(3);              
            ParkingStruct.state3_count2  = uint16(1);
            
            
            ParkingStruct.state1_count2  = uint16(0);
            ParkingStruct.state2_count2  = uint16(0);
            ParkingStruct.state4_count2  = uint16(0);                
                            
        else
             
             ParkingStruct.state2_count2 = ParkingStruct.state2_count2 + uint16(1);
        end
        
        
    % Previous STATE:  State 3 - Car Parked    
    elseif ParkingStruct.car_present2   == uint8(3)
       
        
        ParkingStruct.state3_count2 = ParkingStruct.state3_count2 + uint16(1);
        
        
        
    % Previous STATE:  State 4 - Car Out     
    elseif ParkingStruct.car_present2   == uint8(4)    
        
        if ParkingStruct.state4_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate
        
            ParkingStruct.car_present2   = uint8(1);               
            ParkingStruct.state1_count2  = uint16(1);
            
            
            ParkingStruct.state2_count2  = uint16(0);
            ParkingStruct.state3_count2  = uint16(0);
            ParkingStruct.state4_count2  = uint16(0);                              
            
        else
            
            ParkingStruct.state4_count2  = ParkingStruct.state4_count2 + uint16(1);
            
        end
                     
    end
    
    
    
else
    
    % Previous STATE:  State 1 - No Car 
    if ParkingStruct.car_present2   == uint8(1)
        
        if ParkingStruct.LS_TO_HS_FLAG2

            ParkingStruct.car_present2   = uint8(2); 
            ParkingStruct.state2_count2  = uint16(1);

            ParkingStruct.state1_count2  = uint16(0);
            ParkingStruct.state3_count2  = uint16(0);
            ParkingStruct.state4_count2  = uint16(0);             
            
            ParkingStruct.LS_TO_HS_FLAG2 = uint8(0);
            

        else

           if ParkingStruct.state1_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate

                ParkingStruct.car_present2   = uint8(2); 
                ParkingStruct.state2_count2  = uint16(1);

                ParkingStruct.state1_count2  = uint16(0);
                ParkingStruct.state3_count2  = uint16(0);
                ParkingStruct.state4_count2  = uint16(0);             

           else

                ParkingStruct.car_present2    = uint8(4);
                ParkingStruct.state4_count2   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                ParkingStruct.state1_count2   = uint16(0);
                ParkingStruct.state2_count2   = uint16(0);
                ParkingStruct.state3_count2   = uint16(0);             

           end

        end
        
    elseif ParkingStruct.car_present2    == uint8(2)
        
        ParkingStruct.car_present2   = uint8(2);        
        ParkingStruct.state2_count2  = ParkingStruct.state2_count2 + uint16(1);
        
                
    elseif ParkingStruct.car_present2    == uint8(3)
        
        
        if ParkingStruct.LS_TO_HS_FLAG2   
            
            ParkingStruct.car_present2    = uint8(4);
            ParkingStruct.state4_count2   = uint16(1);
            
            ParkingStruct.state1_count2   = uint16(0);
            ParkingStruct.state2_count2   = uint16(0);
            ParkingStruct.state3_count2   = uint16(0);  
            
            ParkingStruct.LS_TO_HS_FLAG2  = uint8(0);
            
            
        else
            
        
            if ParkingStruct.state3_count2 > ParkingStruct.count_thresh * ParkingStruct.HS_rate

                ParkingStruct.car_present2    = uint8(4);
                ParkingStruct.state4_count2   = uint16(1);

                ParkingStruct.state1_count2   = uint16(0);
                ParkingStruct.state2_count2   = uint16(0);
                ParkingStruct.state3_count2   = uint16(0);              


            else

                ParkingStruct.car_present2    = uint8(2);
                ParkingStruct.state2_count2   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                ParkingStruct.state1_count2   = uint16(0);
                ParkingStruct.state3_count2   = uint16(0);
                ParkingStruct.state4_count2   = uint16(0);                            

            end
            
        end
        
    elseif ParkingStruct.car_present2    == uint8(4)
        
        ParkingStruct.car_present2   = uint8(4);        
        ParkingStruct.state4_count2  = ParkingStruct.state4_count2 + uint16(1);      

    end
    
    
        
end




    

    
    
FLAG = uint8(1);
ParkingStruct.car_presentBufferCount = zeros(4,1,'uint8');

ParkingStruct.car_presentBuffer2      = shifting_array(ParkingStruct.car_presentBuffer2);
ParkingStruct.car_presentBuffer2(end) = ParkingStruct.car_present2;



for i = 1:4

    ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) =  ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) + uint8(1);

    if ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer2(i)) == uint8(3)

        ParkingStruct.car_presentCur2  = ParkingStruct.car_presentBuffer2(i);
        FLAG = uint8(0);
        break;        
    end
end


if FLAG    
    ParkingStruct.car_presentCur2  = ParkingStruct.car_presentPre2;
end









%% **************  Absolute MAG based Algorithm  **************************






if ParkingStruct.K2 < ParkingStruct.dataBufferSize - uint8(1)
    
    ParkingStruct.K2 = ParkingStruct.K2 + uint8(1);
    
    ParkingStruct.SUM         = ParkingStruct.SUM   + data1 ;             % sum
    ParkingStruct.SUMSq       = ParkingStruct.SUMSq + data1 * data1;      % sum square         
    ParkingStruct.AVG         = ParkingStruct.SUM / single(ParkingStruct.K2);
        
    ParkingStruct.SUM2        = ParkingStruct.SUM2  + data ;             % sum
    ParkingStruct.AVG2        = ParkingStruct.SUM2 / single(ParkingStruct.K2);
    
    ParkingStruct.RMS         = sqrt(ParkingStruct.SUMSq / single(ParkingStruct.K2));
    
    if ParkingStruct.K2 == uint8(1)
        
        ParkingStruct.STD = single(0);
    else
        
        ParkingStruct.STD = sqrt(abs(ParkingStruct.SUMSq -ParkingStruct.SUM*ParkingStruct.SUM/single(ParkingStruct.K2))...
            /(single(ParkingStruct.K2 - uint8(1)))); 
        
%         sqrt(abs(ParkingStruct.SUMSq -ParkingStruct.SUM*ParkingStruct.SUM/single(ParkingStruct.K2))/(single(ParkingStruct.K2 - uint8(1))))        
%         std(ParkingStruct.dataBuffer(end-(ParkingStruct.K2-1):end))
        
    end
    
else
    

    ParkingStruct.AVG = mean(ParkingStruct.dataBuffer);    
    ParkingStruct.AVG2= mean(ParkingStruct.dataBuffer2);
        
    ParkingStruct.STD = Parking_std(ParkingStruct.dataBuffer);
    ParkingStruct.RMS = sqrt(mean(ParkingStruct.dataBuffer.* ParkingStruct.dataBuffer));

end




% ^^^^^ save the RMS value for no car state 
if ParkingStruct.RMSFLAG == uint8(0) && ParkingStruct.car_present2 == uint8(1) ...
        && ParkingStruct.car_presentCur2 == uint8(1) && ParkingStruct.Car_State_last_HS == uint8(3)
    
    ParkingStruct.RMSBuffer      = shifting_array(ParkingStruct.RMSBuffer); 
    ParkingStruct.RMSBuffer(end) = ParkingStruct.RMS;
    
    
    ParkingStruct.AVGBuffer      = shifting_array(ParkingStruct.AVGBuffer); 
    ParkingStruct.AVGBuffer(end) = ParkingStruct.AVG;   
    
    ParkingStruct.RMSFLAG        = uint8(1);
    
end












% ParkingStruct.ALG2level = ParkingStruct.STD > ParkingStruct.STD_thresh;
% % ParkingStruct.ALG2level
if ParkingStruct.STD < ParkingStruct.STD_thresh   %% no car or car occupied
    
    
    % Previous STATE:  State 1- no car 
    if ParkingStruct.car_present   == uint8(1)  %% NO CAR STATE  -- CALCULATE the baseline mean & STD value
        
        ParkingStruct.state1_count  = ParkingStruct.state1_count + uint16(1);
        ParkingStruct.AVGSUM        = ParkingStruct.AVGSUM  + ParkingStruct.AVG ;             
%         ParkingStruct.STDSUM        = ParkingStruct.STDSUM  + ParkingStruct.STD ;
        
        ParkingStruct.AVGSUM2       = ParkingStruct.AVGSUM2 + ParkingStruct.AVG2 ;
         
        
        % checking in the proposed no car state, the absolute mag is in the initilized mag range
        % if current MEAN of mag is not in the init range, jump to state 3 (car occupied)
        if ParkingStruct.state1_count == ParkingStruct.State_count_thresh * ParkingStruct.HS_rate 
%                 && ParkingStruct.car_present ~= ParkingStruct.Car_State_last_HS
            
            
            if abs(ParkingStruct.AVGSUM/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit) > ParkingStruct.MAG_threshUp ...
                    && abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) > ParkingStruct.MAG_threshUp


                ParkingStruct.car_present  = uint8(3);        % jump to state 3  (car parked) 
                
                
                
            
            elseif abs(ParkingStruct.AVGSUM2(1)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(1)) > ParkingStruct.MAG_threshUp2 ...
                    || abs(ParkingStruct.AVGSUM2(2)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(2)) > ParkingStruct.MAG_threshUp2 ...
                    || abs(ParkingStruct.AVGSUM2(3)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(3)) > ParkingStruct.MAG_threshUp2
                
                
                 ParkingStruct.car_present  = uint8(3);        % jump to state 3  (car parked)                
                
                
                
            elseif abs(ParkingStruct.AVGSUM/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit) >= ParkingStruct.MAG_thresh ...
                    && abs(ParkingStruct.AVGSUM/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit) <= ParkingStruct.MAG_threshUp ...
                    && ParkingStruct.car_present2  == uint8(3)
                
                
                ParkingStruct.car_present  = uint8(3);        % jump to state 3  (car parked)    - trust algo 1 
%                 
%            
%             else
%                 
%                 1;
                
                
            end
                
            
            ParkingStruct.LS_Trigger_FLAG  = uint8(1);  
            
            
            
           % case of the outputs from 2 algorithms are not the same
           if  ParkingStruct.car_present  ~= ParkingStruct.car_present2
               
               
                if ParkingStruct.RMSBuffer(1) > single(0) && max(ParkingStruct.RMSBuffer) - min(ParkingStruct.RMSBuffer)< ParkingStruct.RMS_thresh

                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(8);   
                   
                end               
                
               

               % algo 1  -- car parked    &&  algo 2 --- no car
               if ParkingStruct.car_present == uint8(1) && ParkingStruct.car_present2 == uint8(3)
                   
                   

                   if abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) <= ParkingStruct.MAG_thresh

                       ParkingStruct.car_present2 = uint8(1);   % trust algo 2
                       
                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(10);
                                              
                       
                   elseif abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) <= ParkingStruct.MAG_threshUp

                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(1);
                       
                   elseif abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) <= ParkingStruct.MAG_threshUp2

                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(2);  
                       
                   else
                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(3);
                       

                   end





               % algo 1  -- no car   &&  algo 2 --- car parked   
               elseif ParkingStruct.car_present == uint8(3) && ParkingStruct.car_present2 == uint8(1)
                   
                   

                   if abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) > ParkingStruct.MAG_threshUp


                       ParkingStruct.car_present2 = uint8(3);   % trust algo 2
                       
                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(10);

                   elseif abs(ParkingStruct.AVGSUM2(1)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(1)) > ParkingStruct.MAG_threshUp2 ...
                       || abs(ParkingStruct.AVGSUM2(2)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(2)) > ParkingStruct.MAG_threshUp2 ...
                       || abs(ParkingStruct.AVGSUM2(3)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(3)) > ParkingStruct.MAG_threshUp2  


                       ParkingStruct.car_present2 = uint8(3);   % trust algo 2
                       
                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(10);                      


                   else

                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);

                   end           


               end


           end            
            
            
            
            
            
        
        % TIMEOUT CASE:
        elseif ParkingStruct.state1_count == ParkingStruct.State_count_thresh_timeout * ParkingStruct.HS_rate ...
                && ParkingStruct.car_present == ParkingStruct.Car_State_last_HS
            
            
            ParkingStruct.LS_Trigger_FLAG  = uint8(1);            
                       
           
        end              
        
        
               
     % Previous STATE:  State 2 - Car In   
     elseif ParkingStruct.car_present   == uint8(2)   
         
         
        if ParkingStruct.state2_count > ParkingStruct.count_thresh * ParkingStruct.HS_rate 
            
            ParkingStruct.car_present   = uint8(3);              
            ParkingStruct.state3_count  = uint16(1);
            
            
            ParkingStruct.state1_count  = uint16(0);
            ParkingStruct.state2_count  = uint16(0);
            ParkingStruct.state4_count  = uint16(0);   
            
            
            ParkingStruct.AVGSUM        = ParkingStruct.AVGSUM  + ParkingStruct.AVG ;             
%             ParkingStruct.STDSUM        = ParkingStruct.STDSUM  + ParkingStruct.STD ;   
            
            ParkingStruct.AVGSUM2       = ParkingStruct.AVGSUM2 + ParkingStruct.AVG2 ;
                            
        else
             
             ParkingStruct.state2_count = ParkingStruct.state2_count + uint16(1);
        end
        
        
    % Previous STATE:  State 3 - Car Parked    
    elseif ParkingStruct.car_present   == uint8(3)
        
        
        ParkingStruct.AVGSUM        = ParkingStruct.AVGSUM  + ParkingStruct.AVG ;             
%         ParkingStruct.STDSUM        = ParkingStruct.STDSUM  + ParkingStruct.STD ; 
        
        ParkingStruct.AVGSUM2       = ParkingStruct.AVGSUM2 + ParkingStruct.AVG2 ;
        
        ParkingStruct.state3_count = ParkingStruct.state3_count + uint16(1);
        
        
        % checking in the proposed no car state, the absolute mag is in the initilized mag range
        % if current MEAN of mag is in the init range, jump to state 1 (NO car)
        if ParkingStruct.state3_count == ParkingStruct.State_count_thresh * ParkingStruct.HS_rate
%                 && ParkingStruct.car_present ~= ParkingStruct.Car_State_last_HS
            
            if abs(ParkingStruct.AVGSUM/single(ParkingStruct.state3_count) - ParkingStruct.AVGInit) < ParkingStruct.MAG_thresh...      
               && abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) < ParkingStruct.MAG_thresh ...
               && all(abs(ParkingStruct.AVGSUM2/single(ParkingStruct.state3_count) - ParkingStruct.AVGInit2) < ParkingStruct.MAG_threshUp )...
               && all(max(ParkingStruct.dataBuffer2) - min(ParkingStruct.dataBuffer2) < ParkingStruct.MAG_thresh2)
                
                ParkingStruct.car_present  = uint8(1);    % jump to state 1 (NO car) 
                
                
            elseif abs(ParkingStruct.AVGSUM/single(ParkingStruct.state3_count) - ParkingStruct.AVGInit) < ParkingStruct.MAG_threshUp ...
                    && abs(ParkingStruct.AVGSUM/single(ParkingStruct.state3_count) - ParkingStruct.AVGInit) > ParkingStruct.MAG_thresh ...
                    && ParkingStruct.car_present2  == uint8(1)

                ParkingStruct.car_present  = uint8(1);    % jump to state 1 (NO car)  - trust algo 1 
                
                
%             else
%                 
%                 1;                
                
                
                
            end
                
            ParkingStruct.LS_Trigger_FLAG  = uint8(1);   
            
            
            
           % case of the outputs from 2 algorithms are not the same
           if  ParkingStruct.car_present  ~= ParkingStruct.car_present2
               
               
                if ParkingStruct.RMSBuffer(1) > single(0) && max(ParkingStruct.RMSBuffer) - min(ParkingStruct.RMSBuffer) < ParkingStruct.RMS_thresh
                    
                   ParkingStruct.SecondSensor_Req_FLAG  = uint8(8);    
                   
                end                   
               


               % algo 1  -- car parked    &&  algo 2 --- no car
               if ParkingStruct.car_present == uint8(1) && ParkingStruct.car_present2 == uint8(3)


                   if abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) <= ParkingStruct.MAG_thresh

                       ParkingStruct.car_present2 = uint8(1);   % trust algo 2
                       
                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(10);                        
                                              

                   elseif abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) <= ParkingStruct.MAG_threshUp

                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(5);
                       
                   elseif abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) <= ParkingStruct.MAG_threshUp2

                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(6);  
                       
                   else
                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(7);

                   end





               % algo 1  -- no car   &&  algo 2 --- car parked   
               elseif ParkingStruct.car_present == uint8(3) && ParkingStruct.car_present2 == uint8(1)


                   if abs(mean(ParkingStruct.dataBuffer) - ParkingStruct.AVGInit) > ParkingStruct.MAG_threshUp


                       ParkingStruct.car_present2 = uint8(3);   % trust algo 2
                       
                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(10);
                       
                       
                   elseif abs(ParkingStruct.AVGSUM2(1)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(1)) > ParkingStruct.MAG_threshUp2 ...
                       || abs(ParkingStruct.AVGSUM2(2)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(2)) > ParkingStruct.MAG_threshUp2 ...
                       || abs(ParkingStruct.AVGSUM2(3)/single(ParkingStruct.state1_count) - ParkingStruct.AVGInit2(3)) > ParkingStruct.MAG_threshUp2  


                       ParkingStruct.car_present2 = uint8(3);   % trust algo 2
                       
                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(10);                   
                                              
                       
                   else

                       ParkingStruct.SecondSensor_Req_FLAG  = uint8(4);

                   end           


               end


           end            
            

            
        
        % TIMEOUT CASE:
        elseif ParkingStruct.state3_count == ParkingStruct.State_count_thresh_timeout * ParkingStruct.HS_rate ...
                && ParkingStruct.car_present == ParkingStruct.Car_State_last_HS
            
            
            ParkingStruct.LS_Trigger_FLAG  = uint8(1);            
            
        end         
    
        
        
    % Previous STATE:  State 4 - Car Out     
    elseif ParkingStruct.car_present   == uint8(4)    
        
        if ParkingStruct.state4_count > ParkingStruct.count_thresh * ParkingStruct.HS_rate
        
            ParkingStruct.car_present   = uint8(1);               
            ParkingStruct.state1_count  = uint16(1);
            
            
            ParkingStruct.state2_count  = uint16(0);
            ParkingStruct.state3_count  = uint16(0);
            ParkingStruct.state4_count  = uint16(0);     
            

            ParkingStruct.AVGSUM        = ParkingStruct.AVGSUM  + ParkingStruct.AVG ;             
%             ParkingStruct.STDSUM        = ParkingStruct.STDSUM  + ParkingStruct.STD ;   
            
            ParkingStruct.AVGSUM2       = ParkingStruct.AVGSUM2 + ParkingStruct.AVG2 ;
            
        else
            
            ParkingStruct.state4_count  = ParkingStruct.state4_count + uint16(1);
            
        end
                     
    end
    
    
    
else
    
    % Previous STATE:  State 1 - No Car 
    if ParkingStruct.car_present   == uint8(1)
        
        if ParkingStruct.LS_TO_HS_FLAG

            ParkingStruct.car_present   = uint8(2); 
            ParkingStruct.state2_count  = uint16(1);

            ParkingStruct.state1_count  = uint16(0);
            ParkingStruct.state3_count  = uint16(0);
            ParkingStruct.state4_count  = uint16(0);             

            ParkingStruct.AVGSUM        = single(0);
%             ParkingStruct.STDSUM        = single(0);  
            
            ParkingStruct.AVGSUM2       = zeros(1,3,'single');
            
            ParkingStruct.LS_TO_HS_FLAG = uint8(0);
            

        else

           if ParkingStruct.state1_count > ParkingStruct.count_thresh * ParkingStruct.HS_rate

                ParkingStruct.car_present   = uint8(2); 
                ParkingStruct.state2_count  = uint16(1);

                ParkingStruct.state1_count  = uint16(0);
                ParkingStruct.state3_count  = uint16(0);
                ParkingStruct.state4_count  = uint16(0);             

                ParkingStruct.AVGSUM        = single(0);
%                 ParkingStruct.STDSUM        = single(0); 
                
                ParkingStruct.AVGSUM2       = zeros(1,3,'single');


           else

                ParkingStruct.car_present    = uint8(4);
                ParkingStruct.state4_count   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                ParkingStruct.state1_count   = uint16(0);
                ParkingStruct.state2_count   = uint16(0);
                ParkingStruct.state3_count   = uint16(0);    

                ParkingStruct.AVGSUM         = single(0);
%                 ParkingStruct.STDSUM         = single(0); 
                
                ParkingStruct.AVGSUM2        = zeros(1,3,'single');

           end

        end
        
    elseif ParkingStruct.car_present    == uint8(2)
        
        ParkingStruct.car_present   = uint8(2);        
        ParkingStruct.state2_count  = ParkingStruct.state2_count + uint16(1);
        
                
    elseif ParkingStruct.car_present    == uint8(3)
        
        
        if ParkingStruct.LS_TO_HS_FLAG   
            
            ParkingStruct.car_present    = uint8(4);
            ParkingStruct.state4_count   = uint16(1);
            
            ParkingStruct.state1_count   = uint16(0);
            ParkingStruct.state2_count   = uint16(0);
            ParkingStruct.state3_count   = uint16(0);  
            
            ParkingStruct.AVGSUM         = single(0);
%             ParkingStruct.STDSUM         = single(0); 
            
            ParkingStruct.AVGSUM2        = zeros(1,3,'single');
            
            ParkingStruct.LS_TO_HS_FLAG  = uint8(0);
            
            
        else
            
        
            if ParkingStruct.state3_count > ParkingStruct.count_thresh * ParkingStruct.HS_rate

                ParkingStruct.car_present    = uint8(4);
                ParkingStruct.state4_count   = uint16(1);

                ParkingStruct.state1_count   = uint16(0);
                ParkingStruct.state2_count   = uint16(0);
                ParkingStruct.state3_count   = uint16(0);  

                ParkingStruct.AVGSUM         = single(0);
%                 ParkingStruct.STDSUM         = single(0); 
                
                ParkingStruct.AVGSUM2        = zeros(1,3,'single');


            else

                ParkingStruct.car_present    = uint8(2);
                ParkingStruct.state2_count   = ParkingStruct.count_thresh * ParkingStruct.HS_rate + uint16(1);

                ParkingStruct.state1_count   = uint16(0);
                ParkingStruct.state3_count   = uint16(0);
                ParkingStruct.state4_count   = uint16(0);               

                ParkingStruct.AVGSUM         = single(0);
%                 ParkingStruct.STDSUM         = single(0);   
                
                ParkingStruct.AVGSUM2        = zeros(1,3,'single');

            end
            
        end
        
    elseif ParkingStruct.car_present    == uint8(4)
        
        ParkingStruct.car_present   = uint8(4);        
        ParkingStruct.state4_count  = ParkingStruct.state4_count + uint16(1);

        ParkingStruct.AVGSUM        = single(0);
%         ParkingStruct.STDSUM        = single(0); 
        
        ParkingStruct.AVGSUM2       = zeros(1,3,'single');

    end
    
    
        
end




    
    
if ~ParkingStruct.LS_Trigger_FLAG       % ParkingStruct.LS_Trigger_FLAG = 0  -- still in HS MODE
    
    if ParkingStruct.car_present == uint8(2) || ParkingStruct.car_present == uint8(4)
    
    
        FLAG = uint8(1);
        ParkingStruct.car_presentBufferCount = zeros(4,1,'uint8');

        ParkingStruct.car_presentBuffer      = shifting_array(ParkingStruct.car_presentBuffer);
        ParkingStruct.car_presentBuffer(end) = ParkingStruct.car_present;



        for i = 1:4

            ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) =  ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) + uint8(1);

            if ParkingStruct.car_presentBufferCount(ParkingStruct.car_presentBuffer(i)) == uint8(3)

                ParkingStruct.car_presentCur  = ParkingStruct.car_presentBuffer(i);
                FLAG = uint8(0);
                break;        
            end
        end


        if FLAG    
            ParkingStruct.car_presentCur  = ParkingStruct.car_presentPre;
        end
        
        
    else
        
        ParkingStruct.car_presentBuffer      = shifting_array(ParkingStruct.car_presentBuffer);
        ParkingStruct.car_presentBuffer(end) = ParkingStruct.car_presentPre;        
        
    end
    
    
    
else    % ParkingStruct.LS_Trigger_FLAG = 1  -- WILL MOVE TO LS mode
        
    % reset
    ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct);    
   
    
end