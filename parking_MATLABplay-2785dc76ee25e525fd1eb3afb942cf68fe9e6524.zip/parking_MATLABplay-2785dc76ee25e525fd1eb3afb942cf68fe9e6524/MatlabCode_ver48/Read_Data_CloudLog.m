function [mraw,time,SentralOutput,raw_rate,RSSIdata,mDataRaw,cloud_feature] = Read_Data_CloudLog(FileName)

[rawData,~] = xlsread(FileName);

reverseIdx = size(rawData,1):-1:1;
rawData = rawData(reverseIdx,:);




% ****** load raw mag data 
index1 = 1; midx = [];

for i = 1:size(rawData,1)-1
    
    if  isnan(rawData(i,1)) && ~isnan(rawData(i+1,1))
        
        %%% mag data start index
        midx(index1,1) = i+1;
                
    elseif isnan(rawData(i+1,1)) && ~isnan(rawData(i,1))
        
        %%% mag data ending index
        midx(index1,2) = i; 
        
        %%% car state
        if rawData(i+1,5) == 0        
            midx(index1,3) = 1;
        elseif rawData(i+1,5) == 100        
            midx(index1,3) = 3;        
        elseif rawData(i+1,5) == 50        
            midx(index1,3) = 2;  
        elseif rawData(i+1,5) == -50        
            midx(index1,3) = 4;  
        end
        
        
        index1 = index1+1;
        
    end

end  

midxtt= midx;

for i = 1:17
% for i = 1:size(midx,1)-1
    
    if (midx(i+1,1) - midx(i,2) == 2 || midx(i+1,1) - midx(i,2) == 3) && abs(rawData(midx(i+1,1),2)-rawData(midx(i,2),2))/32000 < 4  
        
%         timediff = abs(rawData(midx(i+1,1),2)-rawData(midx(i,2),2))/32000
        
       midx(i+1,1) = midx(i,1);
       midx(i,1)   = 0;
    end
end

midx = midx(midx(:,1)~=0,:);
        
     

        



mDataRaw = [];
cloud_feature = [];
for i = 1:size(midx,1)
    
    if i == 9
        1;
    end
    
    mDataRaw1 = rawData(midx(i,1):midx(i,2),[2 7 9 10 11 1]); 
    
    mDataRaw1 = mDataRaw1(~isnan(mDataRaw1(:,3)),:);
    
    
    %sort data by timestamp
    [~, sortedIndexes] = sort(mDataRaw1(:,1));
    mDataRaw1 = mDataRaw1(sortedIndexes,:);  
    
    
    [~,ia,~] = unique(mDataRaw1(:,1));                            
    mDataRaw1 = mDataRaw1(ia,:);  
    
    
    % % timestamp in seconds
    mDataRaw1(:,1) = (mDataRaw1(:,1) - mDataRaw1(1,1))/32000;  % time in seconds 
    
    if ~isempty(mDataRaw)
        mDataRaw1(:,1) = mDataRaw1(:,1) + mDataRaw(end,1) + 5;  % time in seconds 
    end

    
    carState = midx(i,3)*ones(size(mDataRaw1,1),1);    
    mDataRaw1 = [mDataRaw1(:,1:5) carState mDataRaw1(:,6)]; 
    
    
    [cloud_feature1] = cloud_feature_parking(mDataRaw1);
    
    diff_mag2 = 0;   diff_mag3 = 0; 
    
    if i == 1
        
        previous_state = 1;       
        diff_mag = 0;  
        
        dataind = size(mDataRaw1,1); 
    else
        previous_state = midx(i-1,3);
        
        diff_mag = sum(abs(cloud_feature1(7:9) - cloud_feature(i-1,8:10)));
        
        dataind = cloud_feature(end,end)+size(mDataRaw1,1);
        
%         if cloud_feature1(1) == 1
            if ~isempty(find(cloud_feature(:,2)==1, 1))
                
                ind = find(cloud_feature(:,2)==1);
                diff_mag2 = sum(abs(cloud_feature1(7:9) - cloud_feature(ind(end),8:10)));
                
                if length(ind)>1
                    
                    diff_mag3 = sum(abs(cloud_feature1(7:9) - cloud_feature(ind(end-1),8:10)));
                end
                    
                
            end
%         end
                
                
    end
    
    cloud_feature1 = [previous_state cloud_feature1 diff_mag diff_mag2 diff_mag3 midx(i,1) midx(i,2) dataind];
    cloud_feature = [cloud_feature; cloud_feature1];
  
    
        
    mDataRaw = [mDataRaw;mDataRaw1];
    
end
    
 


figure;
subplot(3,1,1); plot(mDataRaw(:,3:5),'DisplayName','mDataRaw(:,3:5)'),title('mag data');grid on;
subplot(3,1,2); plot(mDataRaw(:,2)),title('RSSI');grid on;
subplot(3,1,3); plot(mDataRaw(:,6)),title('car state');grid on;ylim([0.5 3.5])



% figure;
% % subplot(2,1,1); 
% yyaxis left 
% plot(mDataRaw(:,3:5),'DisplayName','mDataRaw(:,3:5)'),title('mag data');grid on; 
% yyaxis right
% plot(mDataRaw(:,6)),title('car state');ylim([0.5 3.5])
% 
% subplot(2,1,2); plot(mDataRaw(:,2)),title('RSSI');grid on;
% 
% 
% 
% 
% 
% 
% x= 1:1:size(mDataRaw,1);
% figure;
% plotyy(x,mDataRaw(:,3:5),x,mDataRaw(:,6),'plot'); grid on;





% %%% time arrangement
% overflowNUM = 1;
% 
% for i = 2:length(mDataRaw(:,1))
%     
%     if mDataRaw(i,1) < mDataRaw(i-1,1)
%         
%         mDataRaw(i:end,1) = mDataRaw(i:end,1) + 2^32*overflowNUM;
%         overflowNUM = overflowNUM +1;
%         
%     end
%     
% end
% 
% 
% % % timestamp in seconds
% mDataRaw(:,1) = (mDataRaw(:,1) - mDataRaw(1,1))/32000;  % time in seconds  










% ****** load RSSI data
RSSIdata=mDataRaw(:,2); 


% ****** load raw mag data
% mag data
mraw = mDataRaw(:,3:5); 
% timestamp in seconds 
time = mDataRaw(:,1);         % time in seconds   


% ****** load output on from SENtral
SentralOutput=mDataRaw(:,6);    



%compute the average rate of a single time axis. axis should be
%a column vector.

%compute delta-t vector
tDels = time(2:10)-time(1:9);
%compute frequency vector
tFqs = tDels.^(-1);
%compute mean rate in hz
% raw_rate = mean(tFqs);
% raw_rate = mean(tFqs(1:10));
raw_rate = tFqs(1);





% % midx2= isnan(rawData(:,1));
% % RSSIdata=rawData(midx2,7); 
% % 
% % 
% % diff(RSSIdata)
% % 
% % RSSIdataMA = zeros(length(RSSIdata)-2,1);
% % i1=0;
% % for i = 3:length(RSSIdata)
% %     
% %     i1= i1+1;    
% %     RSSIdataMA(i1) = mean(RSSIdata(i-2:i));
% % 
% % end
%     
% 
% 
% 
% 
% 
% 
% 
% % ****** load raw mag data
% midx= ~isnan(rawData(:,1));
% mDataRaw=rawData(midx,[2 9 10 11]); 
% 
% 
% % mag data
% mraw = mDataRaw(:,2:4); 
% 
% % timestamp in seconds 
% time = mDataRaw(:,1);         % time in seconds   
% 
% 
% 
% % ****** load output on from SENtral
% SentralOutput=rawData(isnan(rawData(:,1)),[2 5 8]);    %mDataRaw=rawData(rawData(:,4)==65538,[3 13 14 15]);  
% 
% for i = 1:size(SentralOutput,1)
%     
%     if SentralOutput(i,2) == 0        
%         SentralOutput(i,2) = 1;
%     elseif SentralOutput(i,2) == 100        
%         SentralOutput(i,2) = 3;        
%     elseif SentralOutput(i,2) == 50        
%         SentralOutput(i,2) = 2;  
%     elseif SentralOutput(i,2) == -50        
%         SentralOutput(i,2) = 4;  
%     end
% end
% 
% 
% 
% 
% 
% %compute the average rate of a single time axis. axis should be
% %a column vector.
% 
% %compute delta-t vector
% tDels = time(2:end)-time(1:end-1);
% %compute frequency vector
% tFqs = tDels.^(-1);
% %compute mean rate in hz
% % raw_rate = mean(tFqs);
% % raw_rate = mean(tFqs(1:10));
% raw_rate = tFqs(1);









