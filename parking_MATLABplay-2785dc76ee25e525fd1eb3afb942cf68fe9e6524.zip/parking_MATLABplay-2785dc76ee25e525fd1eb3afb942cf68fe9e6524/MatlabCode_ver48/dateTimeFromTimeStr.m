function dateTimeAy = dateTimeFromTimeStr(serverTimeCellStr)

if ~isempty(serverTimeCellStr)
    clear dateTimeAy
    for ii=1:length(serverTimeCellStr)
        sStr = serverTimeCellStr{ii};
        if ~isempty(sStr)
            iplus = strfind(sStr,'+');
            iminus = strfind(sStr,'-');
            iT = strfind(sStr,'T');
            iColon = strfind(sStr,':');
            timeCheck = length(iminus)>=2 & ~isempty(iT);
            iend = iColon(2)+2; % ... needs work ...
            sStr = sStr(1:iend);
            if timeCheck
                %         if ~isempty(iplus)
                %             sStr = sStr(1:iplus-1);
                %         end
                y = str2num(sStr(1:iminus(1)-1));
                m = str2num(sStr(iminus(1)+1:iminus(2)-1));
                d = str2num(sStr(iminus(2)+1:iT(1)-1));
                thr = str2num(sStr(iT(1)+1:iColon(1)-1));
                tmin = str2num(sStr(iColon(1)+1:iColon(2)-1));
                tsec0 = str2num(sStr(iColon(2)+1:end));
                %     DateNumber = datenum(y,m,d,thr,tmin,tsec0) ; % matlab date/time format
                tsec = floor(tsec0);
                tmsec = 1000*(tsec0-tsec);
                dateTime = datetime(y,m,d,thr,tmin,tsec,tmsec);
            else
                dateTime = [];
            end
            dateTimeAy(ii,:) = dateTime;
        else
            dateTime = [];
            dateTimeAy = [];
        end
    end
    servTime = dateTimeAy;
else
    servTime = [];
end
