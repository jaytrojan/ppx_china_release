%%% Algorithm using SSA and SSR with real-time functionality
% No motion data


disp('Viewing Parking Data Logs...')

% close all;
% clear all; %clc;
clearvars -except parkImageShow
dbstop if error

parkImagesFlagInit = 0; % initialize loading parking lot images - doesn't matter if already loaded
fillDataFront = 0;
plotDataFlag = 1; % for multiple files a question dialog will pop-up
csvParserMethod = 'normal'; % 'normal', 'fakeServerTime'

testSignalFlag = 0; % if 0, turns off all noise and signal changes from default.
testSettingsFlag = 0; % if 0=default settings; 1=custom settings; -1 goes back to r03 stability STD

fillMissingDataCheck = 1; % turns on mag data interp for missing/extending stable mag data
% this flag enables dialog check
downSample = 0; % downsample to LS and HS rates

%%% Signal Test (if testSignalFlag is turned on)
% additive noise
% periodic noise (sine and square waves)
% set freq to 0 to turn off
magSineNoise = [60 0.5 0.5 0.5]; % [freqHz Xut Yut Zut]
magSquareNoise = [0.5 0.5 0.5 0.5 20]; % [freqHz Xut Yut Zut dutyCyclePosPcnt]
% gaussian noise
magGaussNoise = 0.0; % uT

numcarprev = uint16(0); % previous number of cars
triggertwoevent = uint8(1); % trigger empty then occupied on subsequent knobs


%%% Settings Test  (if testSettingsFlag is turned on)
% STD_threshDown = 1.75; % ut
% STD_threshUp = 2.5;

% % >>> stability filter testing
% stableMethod = 2; % 0=original;1=remOut; 2=very  new
% STD_threshDown = 0.5; % ut
% STD_threshUp = 1.5;
% State_count_thresh = 2;

% LS Recheck on/off custom
% lsRecheckEnableFlag = 0; % -1 turns off lsRecheckEnable


% override cal with fixed cal numbers
% if empty, not used
preCalFixed_AVGInit2 = [];
% preCalFixed_AVGInit2 = [-55.66 24.6 38.4];%[-30.3 45 30.7];% % china team logs 3/13
% preCalFixed_AVGInit2 = [-23.58 -46.9 41.87]; % china team 3/8
% preCalFixed_AVGInit2 = [-25.833 -8.71 43.817]; % space 2
% preCalFixed_AVGInit2 = [-31.8 -5.11 40.9]; % space 16
% %         preCalFixed_AVGInit2 = [22.527  33.228  40.526];
% preCalFixed_AVGInit2 = [22.783342361450195  33.273704528808594  40.496620178222656];



waitTime = 0; % seconds to pause after each file
% if 0, pause indefinitley

% choose and open data file
% dataDir = 'C:\Users\dfigaro\Documents\Parking\Data\All Test Vectors\Field Test Vector_Cloud\issue_cases\';
dataDir = 'C:\Users\jtrojan\Desktop\Data\Parking\baseline_logs\';
% dataDir = '..\..\Data\';

% paths
restoredefaultpath
% add path for metrics
addpath('..\..\MATLABouter\MatlabCode')

%%% >>>Problem File List<<<
% move this list to csv ...
% FrontLot\2017dec18-24\Front8_valid_2017_12_19_testDblBufAck1


%%% >> Figure Plot Settings
%                           [fignum  dock  link]
figPlotS = [];
figPlotS.magDeltaVectorSample = [101 0 0];
figPlotS.Time = [0 0 0];
figPlotS.magDeltaVectorTime = [120 1 1];
figPlotS.magS2SDeltaVectorTime = [0 0 1]; % sample to sample delta vector
figPlotS.magDataFull = [122 0 1];
figPlotS.magDeltaVectorServTime = [0 0 0]; % vs server time
figPlotS.deltaTime = [130 0 1];
figPlotS.rssiTime = [140 0 1];
figPlotS.temperatureTime = [150 0 1];
figPlotS.HSmode = [0*160 0 1];
figPlotS.carStates = [0 0 1];
figPlotS.carStatesTruth = [162 1 1];
figPlotS.parkStatus = [170 1 1];
figPlotS.parkMeas = [180 1 1];
figPlotS.magDeltaVector3D = [0 0 1];

figPlotS.magStableMeas = [190 1 1];


% plot axis struct for linking
% uses same fields as figPlotS
haxS = [];
flds = fieldnames(figPlotS);
for ifld=1:length(flds)
    fld = flds{ifld};
    haxS.(fld)=[];
end

parkImageShow0.on = parkImagesFlagInit;
parkImageShow0.figN = 200;
parkImageShow0.imageStructAy = [];
parkImageShow0.cursFigs = [figPlotS.carStatesTruth(1)]; % list of figures to use cursor for updateing image plot
%%% >> Figure Plot Settings



% % % Load PPG and Accel data (need to select multiple data files)
% [FileName,PathName] = uigetfile({[dataDir '*.csv']},'Choose Log File -mag data');


[alldatfiles,PathName] = uigetfile({[dataDir '*.*']},'Choose Multiple Logs', 'MultiSelect', 'on');

if isnumeric(PathName)
    return
end



if ~iscell(alldatfiles)
    alldatfiles = {alldatfiles};
end
numfiles=length(alldatfiles);

if numfiles>1
    % ask if plot data should be on
    button = questdlg('Show Parking Data Plots?','Parking Algorithm','Yes');
    switch button
        case 'Yes'
            plotDataFlag = 1;
        case 'No'
            plotDataFlag = 0;
        otherwise
            return
    end
end
%


%%% fillMissingDataCheck
% only for csv files
% if doing mag data interp, must delete .mat file
fillMissingData = 0; % default unless engaged
csvCheck = strfind(alldatfiles,'.csv');
if ~isempty(csvCheck{1}) && fillMissingDataCheck
    fillMissingButton = questdlg(sprintf(['Interp Missing Mag Data? \nThis will be performed on all csv files in list.']),'Interp Missing Mag Data','No');
    switch lower(fillMissingButton)
        case 'yes'
            fillMissingData = 1;
        case 'no'
            fillMissingData = 0;
    end
end


%
for file_index=1:numfiles

    if iscell(alldatfiles)
        FileName=char(alldatfiles(file_index));
    elseif ischar(alldatfiles)
        FileName=alldatfiles;
    else
        return
    end

    disp(['File:  ' FileName])

    % id columns by hdr text
    hdr.iSentralTime = {'SentralTime'};
    hdr.iSensorID = {'sensorId'};
    hdr.iServeTime = {'ServerTime','ServerTime_PST'};
    hdr.iCarStat = {'CarPresence'};
    hdr.iTemp = {'Temperature'};
    hdr.iRSSI = {'rx_rssi','LoraWan_rssi'};
    hdr.iConf = {'Confidence'};
    hdr.iData = {'x','y','z'};
    hdr.iDiag = {'maxAxis', 'minAxis', 'dataMax', 'dataMin', 'std', 'stdMax'};

    indS.hdr = hdr;

    global plotInfo dataInfo cntrlInfo dataInfoExtra parkImageShow figPlotS

    dataInfo = [];
    dataInfoExtra = [];

    if isempty(parkImageShow)
        parkImageShow = parkImageShow0;
    end

    [pathstr,name,ext] = fileparts(FileName);


    %%% truth state data file
    dataInfo_load = []; % initialize
    if strcmpi(ext,'.csv')
        % csv
        % original parser
        % [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw,sentralTimestamp] = Read_Data_CloudLog_Conti([PathName FileName]);

        %     [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw, sentralTimestamp, servTime] = Read_Data_CloudLog_flexHdr([PathName FileName],indS);
        %     [mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw, sentralTimestamp, servTime, SentralOutputRaw] = Read_Data_CloudLog_flexHdr_work([PathName FileName],indS);

        switch csvParserMethod
            case 'normal'
        dataStruct = Read_Data_CloudLog_flexHdr([PathName FileName],indS);
            case 'fakeServerTime'
                dataStruct = Read_Data_CloudLog_flexHdr_fakeServerTime([PathName FileName],indS);
        end

        [pathstr,fileName,ext] = fileparts(FileName);
        fMatName = [PathName fileName '.mat'];

        %%% truth state data file
        if exist(fMatName,'file')
            % copy over truth from state file
            dataFileLoad = load(fMatName);
            if isfield(dataFileLoad, 'dataInfo')
                dataInfo_load = dataFileLoad.dataInfo;
            end
        end


    elseif strcmpi(ext,'.mat')
        % mat
        dataFileLoad = load([PathName FileName]);
        if isfield(dataFileLoad, 'dataStruct')
            dataStruct = dataFileLoad.dataStruct;
        else
            disp('Unknown File Type!!!')
            continue
        end
        if isfield(dataFileLoad, 'dataInfo')
            dataInfo_load = dataFileLoad.dataInfo;
        end
    else
        disp('Unknown File Type!!!')
        continue
    end


    fsuffix = '';
    if ~isempty(dataStruct) % && ~isempty(timeRaw)

        %%% dataInfo_load
        if ~isempty(dataInfo_load)
            dataInfo = dataInfo_load;
        end
        dataInfo.fileName = FileName;
        dataInfo.pathName = PathName;
        if ~isfield(dataInfo,'fillMissingData')
            dataInfo.fillMissingData = fillMissingData;
        end

        % Pre cal initialize
        % if .mat present with setting then that will be used
        % if not than no precal will be performed
        preCalLoop = 0; % flag to pre-calibrate before running data - off unless set by .mat
        calTime = []; % time range to use for pre-calibration, if present
        startTime = [];
        if ~isempty(dataInfo_load) && isfield(dataInfo_load,'preCalLoop')
        else
            dataInfo.preCalLoop = preCalLoop;
        end
        if ~isempty(dataInfo_load) && isfield(dataInfo_load,'startTime')
        else
            dataInfo.startTime = startTime;
        end
        if ~isempty(dataInfo_load) && isfield(dataInfo_load,'calTime')
        else
            dataInfo.calTime = calTime;
        end


        preCalLoop = dataInfo.preCalLoop;
        calTime = dataInfo.calTime;


        %% Setup data structures
        %%% Parking Struct
        ParkingStruct = Parking_struct_init;

        %%% Stable Filter Struct & Settings
        filtStruct = stableFilt_struct_init;


        %%%%% update knobs setting for drive thru algo
        if ParkingStruct.DriveThruFLAG
            [ParkingStruct, filtStruct] = Parking_struct_init_DriveThru(ParkingStruct, filtStruct);
        end


        %         %%% >>> Stability Filter Development
        %         % stability/slope/noise filter
        %         ParkingStruct.filtStruct = stableFilt_struct_init;

        switch testSettingsFlag
            case 1
                %%% custom settings test
                filtStruct.stableMethod = stableMethod;
                if State_count_thresh
                    ParkingStruct.State_count_thresh = State_count_thresh;
                    ParkingStruct.State_count_thresh_timeout = State_count_thresh;
                end
                if STD_threshDown
                    ParkingStruct.STD_threshDown = STD_threshDown;
                end
                if STD_threshUp
                    ParkingStruct.STD_threshUp = STD_threshUp;
                end
                if lsRecheckEnableFlag<0
                    ParkingStruct.lsRecheckEnable = int8(-1);
                end
            case -1
                %%% original r03 STD settings
                filtStruct.stableMethod = 0;
                ParkingStruct.State_count_thresh = 5;
                ParkingStruct.State_count_thresh_timeout = 5;
                ParkingStruct.STD_threshDown = 0.5;
                ParkingStruct.STD_threshUp = 1.5;
            otherwise % 0
                % default settings for current version - no changes here
        end

        %         %%% >>> Force Car State for testing
        %         ParkingStruct.car_present = uint8(3);
        %         ParkingStruct.car_present2 = uint8(3);
        %         ParkingStruct.car_present = uint8(1);
        %         ParkingStruct.car_present = uint8(1);
        %         ParkingStruct.car_present = uint8(1);





        %% Interp Missing Mag Data
        % fix unique time
        if ~isempty(dataInfo) && isfield(dataInfo,'time')
            Nlength = size(dataInfo.time,1);
            time0 = dataInfo.time;
            [time00,it0,it00] = unique(time0,'rows','stable');
            fldNames = fieldnames(dataInfo);
            for ifld=1:length(fldNames)
                if size(dataInfo.(fldNames{ifld}),1) == Nlength
                    dataInfo.(fldNames{ifld}) = dataInfo.(fldNames{ifld})(it0,:);
                end
            end
        end
        % fix unique mathching time
        if ~isempty(dataInfo) && ~isfield(dataInfo,'time')
            Nlength = size(dataStruct.time,1);
            time0 = dataStruct.time;
            [time00,it0,it00] = unique(time0,'rows','stable');
            fldNames = fieldnames(dataInfo);
            for ifld=1:length(fldNames)
                if size(dataInfo.(fldNames{ifld}),1) == Nlength
                    dataInfo.(fldNames{ifld}) = dataInfo.(fldNames{ifld})(it0,:);
                end
            end
        end
        % fix unique time
        if ~isempty(dataStruct) && isfield(dataStruct,'time')
            Nlength = size(dataStruct.time,1);
            time0 = dataStruct.time;
            [time00,it0,it00] = unique(time0,'rows','stable');
            fldNames = fieldnames(dataStruct);
            for ifld=1:length(fldNames)
                if size(dataStruct.(fldNames{ifld}),1) == Nlength
                    dataStruct.(fldNames{ifld}) = dataStruct.(fldNames{ifld})(it0,:);
                end
            end
        end

        timeSave = dataStruct.time;
        if fillMissingData
            [ParkingStruct0,filtStruct0,resultRecAy] = parkingLoopMeas(ParkingStruct,filtStruct,dataStruct,dataInfo);

            dtLim = 0.36; % gap ~ 3x HS mode
            tintMax = 7; % max number of seconds to add with interp
            interpMethod = 'fill'; % interp, fill
            dataStruct = fillMissingDataFcn(dataStruct,resultRecAy,filtStruct,dtLim,tintMax,interpMethod);
            dataInfo.fillMissingData = fillMissingData;

            % fix unique time
            if ~isempty(dataStruct) && isfield(dataStruct,'time')
                Nlength = size(dataStruct.time,1);
                time0 = dataStruct.time;
                [time00,it0,it00] = unique(time0,'rows','stable');
                fldNames = fieldnames(dataStruct);
                for ifld=1:length(fldNames)
                    if size(dataStruct.(fldNames{ifld}),1) == Nlength
                        dataStruct.(fldNames{ifld}) = dataStruct.(fldNames{ifld})(it0,:);
                    end
                end
            end
        end

        % check if previous truth_state field needs to be interpolated to the new times if any
        if ~isempty(dataInfo) && isfield(dataInfo,'time') && length(dataStruct.time) ~= length(dataInfo.time)
            truth_state = interp1(dataInfo.time, dataInfo.truth_state, dataStruct.time, 'linear', 'extrap');
            dataInfo.truth_state = round(truth_state);
            dataInfo.time = dataStruct.time;
        elseif ~isempty(dataInfo) && isfield(dataInfo,'truth_state')
            if size(dataInfo.truth_state,1) ==  size(timeSave,1)
                try
                    truth_state = interp1(timeSave, dataInfo.truth_state, dataStruct.time, 'linear', 'extrap');
                    dataInfo.truth_state = round(truth_state);
                    dataInfo.time = dataStruct.time;
                catch
                end

            elseif isfield(dataInfo,'time') && length(dataStruct.time) == length(dataInfo.time)
            else
                error('dataInfo length mismatch!!!');
            end
%             truth_state = interp1(dataInfo.time, dataInfo.truth_state, dataStruct.time, 'linear', 'extrap');
%             dataInfo.truth_state = round(truth_state);
%             dataInfo.time = dataStruct.time;
        end


        %% Process MagData
        mraw = dataStruct.magDataAy(:,2:4);
        timeRaw = dataStruct.time;
        SentralOutput = dataStruct.magDataAy(:,6:7);
        raw_rate = dataStruct.magRaw_rate;
        magSenTimestamp = dataStruct.magSenTimestamp;
        servTime = dataStruct.magDateTimeAy; % server time

        start_ind = 1;
        end_ind = size(mraw,1);    %%%% 1690;   %%%%size(mraw,1);  %%%625;
        magData       = mraw(start_ind:end_ind,:);
        time          = timeRaw(start_ind:end_ind,:);
        SentralOutput = SentralOutput(start_ind:end_ind,:);
        magSenTimestamp = magSenTimestamp(start_ind:end_ind,:);


        %%% MagData Check
        Ncal=30; % target minimum cal samples if all within limits - set shorter because of typical file behavior
        if size(magData,1) < Ncal
            continue
        end

        dataInfoExtra.servTime = servTime;
        HS_mode_triggerIND = [];


        time_rel = time - time(1);

        %%% Additive Signal Noise
        if testSignalFlag
            %%% add sine noise
            if magSineNoise(1)
                % generate sine wave at desired frequency at high time resolution
                magData = addSineSignalNoise(magSineNoise,time_rel,magData);
            end

            %%% add square noise
            if magSquareNoise(1)
                % generate sine wave at desired frequency at high time resolution
                magData = addSquareSignalNoise(magSquareNoise,time_rel,magData);
            end

            %%% add gaussian noise
            if magGaussNoise
                magData = magData + magGaussNoise*randn(length(magData),3);
            end
        end



        dt = [0; time(2:end) - time(1:end-1)];

        % time2: replace large time gaps
        tgapmax = 60;
        dtBigInds = find(dt>=tgapmax);
        tgapreplace = 10;
        % [time(dtBigInds-1) time(dtBigInds) time(dtBigInds+1)]

        dt2 = dt;
        tgapmeas = dt(dtBigInds);
        dt2(dtBigInds) = tgapreplace;
        time2 = time(1) + cumsum(dt2);
        dataInfoExtra.time2 = time2;


        %% Pre-Cal Loop
        % check initial data for cleanliness
        % on PP cal is 40 samples at HS rate
        % here we may have LS data in short bursts updated only occasionally
        % Start with 40 samples

        if ~isempty(preCalFixed_AVGInit2)
            % force fixed field cal values
            preCalLoop = 0;
            dataInfo.preCalLoop = preCalLoop;
            ParkingStruct.AVGInit2 = single(preCalFixed_AVGInit2);

            % cal simulation reset
            ParkingStruct.Calibration_FLAG            = uint8(1);   % calibration process finished
            ParkingStruct.Calibration_InitFLAG        = uint8(0);
            ParkingStruct.LS_Trigger_FLAG             = uint8(1);    % trigger the Alarm: back to low speed mode
            ParkingStruct.SecondSensor_Req_FLAG       = uint8(0);    %%% reset confidence level
            ParkingStruct.Context_Input               = uint8(0);
            ParkingStruct.Reset_FLAG                  = uint8(0);

            ParkingStruct.LS_StartValue               = ParkingStruct.AVGInit2;
            ParkingStruct.LS_StartValue_state1        = ParkingStruct.LS_StartValue;
            ParkingStruct.LS_StartValue_state3        = zeros(1,3,'single');

            % reset
            ParkingStruct = Parking_structure_HS_to_LS_reset(ParkingStruct) ;


            ParkingStruct.NumCars                           = uint16(0);
            ParkingStruct.NumCarsPre                        = uint16(0);
            ParkingStruct.multipleCarsFLAG                  = uint8(0);
            ParkingStruct.NumCars_DriveThru                 = uint16(0);
            ParkingStruct.NumCars_DriveThruPre              = uint16(0);
            ParkingStruct.multipleCarsFLAG_DriveThru        = uint8(0);

        else
            [ParkingStruct,filtStruct,dataInfo] = preCalLoopFcn(ParkingStruct,filtStruct,dataInfo,magData,time2,magSenTimestamp,[],Ncal);
        end

        calTime = dataInfo.calTime;


%         %%% hist buffer init
%             %%% Update persistent state tracker
%             if ParkingStruct.car_present ~= uint8(3)
%                 magCalInitData =  mean(magData(1:8,:),1);
%                 ParkingStruct.car_present = uint8(1);
%                 filtStruct.ihist1 = filtStruct.ihist1+1;
%                 filtStruct.mhiststate1(filtStruct.ihist1,:) = magCalInitData;
%                 filtStruct.mhisttime1(filtStruct.ihist1,:) = magSenTimestamp(8);
%                 ParkingStruct.car_presentPersist = ParkingStruct.car_present;
%             end



        %         %%% >>> Force Car State for testing
        %         ParkingStruct.car_present = uint8(3);
        %         ParkingStruct.car_present2 = uint8(3);
        %         ParkingStruct.car_presentCur = uint8(3);
        %         ParkingStruct.car_presentCur2 = uint8(3);
        %         ParkingStruct.car_presentPre = uint8(3);
        %         ParkingStruct.car_presentPre2 = uint8(3);
        %         ParkingStruct.Car_State_last_HS = uint8(3);




        %%
        magNdata = sqrt(sum(magData.^2,2));
        magNdata2 = sqrt(sum(magData(:,2:3).^2,2));

        range_X = max(magData(:,1)) - min(magData(:,1));
        range_Y = max(magData(:,2)) - min(magData(:,2));
        range_Z = max(magData(:,3)) - min(magData(:,3));

        disp('magXYZ ranges')
        disp([range_X range_Y range_Z])

        figN = 100;

        %%% plot deltas and vector deltas
        set(0,'DefaultFigureWindowStyle','normal') %docked figures


        global testState

        dt = [0; time(2:end) - time(1:end-1)];

        % time2: replace large time gaps
        tgapmax = 60;
        dtBigInds = find(dt>=tgapmax);
        tgapreplace = 10;
        % [time(dtBigInds-1) time(dtBigInds) time(dtBigInds+1)]

        dt2 = dt;
        tgapmeas = dt(dtBigInds);
        dt2(dtBigInds) = tgapreplace;
        time2 = time(1) + cumsum(dt2);
        dataInfoExtra.time2 = time2;


        % adapt time gaps for other sentral times
        % insert time gap at closest time
        tTempAy = dataStruct.dataTempAy(:,1);
        dtTemp = [0; tTempAy(2:end) - tTempAy(1:end-1)];
        for ii=1:length(dtBigInds)
            tfind = time(dtBigInds(ii));
            [minVal, minInd] = min(abs(tTempAy-tfind));
            dtTemp(minInd) = tgapreplace;
        end
        time2Temp = tTempAy(1) + cumsum(dtTemp);


        [pathstr,fNameTitle,ext] = fileparts(FileName);
        idlm1 = find(FileName == '_',1,'first');
        if ~isempty(idlm1)
            fNameTitle = FileName(1:idlm1-1);
        else
            fNameTitle = FileName;
        end
        if length(fNameTitle)>14
            fNameTitle = fNameTitle(1:14);
        end


        diffTime = [0; diff(time)];
        diffTime(1) = diffTime(2);
        HS_label = diffTime<0.5;

        N3 = length(magData);

        magNdata = zeros(N3,1);
        mag_diff = zeros(N3,1);
        phase_level = zeros(N3,1);
        detection_output = zeros(N3,1);

        car_state = zeros(N3,4);

        MEAN_value = zeros(N3,2);
        STD_value = zeros(N3,1);

        MEAN_value2 = zeros(N3,3);

        moving_avg = zeros(N3,1);

        MEAN_Baseline_value = zeros(N3,1);
        STD_Baseline_value = zeros(N3,1);
        MEAN_Occupied_value = zeros(N3,1);
        STD_Occupied_value = zeros(N3,1);

        ALG2Level = zeros(N3,1);
        car_state_alg2 = zeros(N3,1);

        car_state_buffer =zeros(N3,1);

        Alarm_level = zeros(N3,1);
        LS_Trigger_FLAG_ay = zeros(N3,1);

        dataBuffer2Ay = zeros(size(ParkingStruct.dataBuffer2,1),size(ParkingStruct.dataBuffer2,2),N3);


        % stability filter track
        mmn_ay = []; mmnCln_ay = [];
        mstd_ay = []; mstdCln_ay = [];
        mstdDelta_ay = []; mstdDeltaCln_ay = [];
        mstdSlope_ay = []; mstdSlopeCln_ay = [];
        mslope_ay = []; mslopeCln_ay = [];
        mslopeMoveClnMn_ay = [];

        % add missing fields
        ParkingStruct.NUM = single(0);
        ParkingStruct.StartNUM = single(0);

        % flds to monitor
        % status fields
        parkFieldsStatusWatch = createParkStructStatusWatchList;
        parkStatusS = copyFields(ParkingStruct,parkFieldsStatusWatch);
        parkStatusAy = repmat(parkStatusS,N3,1);
        % meas fields

        parkFieldsMeasWatch = createParkStructMeasWatchList;
        parkMeasS = copyFields(ParkingStruct,parkFieldsMeasWatch);
        parkMeasAy = repmat(parkMeasS,N3,1);
        filtStructAy = repmat(filtStruct,N3,1);

%         baseFiltFieldsWatch = {...
%             'w'...
%             'data'...
%             'dfilt'...
%             'dfiltw'...
%             'dvarfilt'...
%             'dvarfiltw'...
%             'dslopefilt'...
%             'dslopevarfilt'...
%             'dslopew'...
%             'dslopewfilt'...
%             'dslopewvarfilt'...
%             };

         baseFiltFieldsWatch = {...
            'w'...
            'dfiltS'...
            'dfiltwS'...
            'dslopefiltwS'...
            'stableCnt'...
            'baseLineMeas'...
            };

%         baseFilt0 = filtStruct.baseFilt;
%         baseFiltS = copyFields(baseFilt0,baseFiltFieldsWatch);
%         baseFilt0Ay = repmat(baseFiltS,N3,1);

%         baseFilt1 = filtStruct.baseFilt;
%         baseFiltS = copyFields(baseFilt1,baseFiltFieldsWatch);
%         baseFilt1Ay = repmat(baseFiltS,N3,1);



        %% Data Loop
        testState = 0;

        %         startTime = 2200;
        if ~isempty(dataInfo.startTime)
            startInd = find(time2>=dataInfo.startTime,1,'first');
        else
            startInd = 1;
        end
        for i = startInd:length(magData)

            ParkingStruct.NUM               = single(i);

%             disp(time2(i))
            if time2(i)>= 8130.77
                testState=1;
            end

%             save('sideTest','ParkingStruct', 'filtStruct')

            %%% sampling rate adjustment
            % tfact is to account for timing noise
            tfact = 0.9;
            sampleFlag=1;
            if downSample && i>1
                if ParkingStruct.LS_Trigger_FLAG
                    if (time2(i)-tprev) < tfact*(1/single(ParkingStruct.LS_rate))
                        sampleFlag=0;
                    end
                else
                    if (time2(i)-tprev) < tfact*(1/single(ParkingStruct.HS_rate))
                        sampleFlag=0;
                    end
                end
            end
            

            %% main call to algorithm
            if sampleFlag
                [ParkingStruct, filtStruct, numcarprev, car_state, parkStatusAy] = Parking_AlgorithmWrapWrap(ParkingStruct, filtStruct, magData(i,:), magSenTimestamp(i), time(i), time2(i), HS_mode_triggerIND, numcarprev, i, car_state, parkStatusAy, triggertwoevent);
                tprev = time2(i);
            end
            
            


            %%% Track ParkingStruct field data
            parkStatusAy(i) = copyFields(ParkingStruct,parkFieldsStatusWatch);
            parkMeasAy(i) = copyFields(ParkingStruct,parkFieldsMeasWatch);
            filtStructAy(i) = filtStruct;

%             baseFilt1Ay(i) = copyFields(filtStruct.baseFilt,baseFiltFieldsWatch);
%             baseFilt0Ay(i) = copyFields(filtStruct.baseStruct.baseFilt0,baseFiltFieldsWatch);


            %     % software alarm
            %     ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),magSenTimestamp(i),0);

            % track buffer
            dataBuffer2Ay(:,:,i) = ParkingStruct.dataBuffer2;

            magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
            %    MEAN_value(i,1) = ParkingStruct.AVG;
            STD_value(i,1)  = ParkingStruct.STD;

            %    STD_value(i,2)  = ParkingStruct.STDz;

            MEAN_value2(i,:) = ParkingStruct.AVG2;

            MEAN_value(i,1) = ParkingStruct.moving_avg;

            moving_avg(i,1)=ParkingStruct.moving_avg;


            car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2 ParkingStruct.car_present ParkingStruct.car_present2];
            Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG;

            %    RMS(i,1) = ParkingStruct.RMS;

            SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;

            LS_Trigger_FLAG_ay(i,:) = ParkingStruct.LS_Trigger_FLAG;

        end



        % add magData field to parkMeasAy
        for i = 1:size(magData,1)
            parkMeasAy(i).magData = magData(i,:); % latest data
        end


        %%% process run dependent variables
        % load dataInfo state file if present
        if ~isempty(dataInfo_load) && isfield(dataInfo_load,'truth_state')  && isfield(dataInfo,'truth_state') % && ~fillMissingData
            % % %                 dataInfo = dataInfo_load;
%             truth_state = dataInfo_load.truth_state;
            truth_state = dataInfo.truth_state;
%         elseif ~isempty(dataInfo) && isfield(dataInfo,'truth_state') && fillMissingData
%             % case of resampling with fillMissingData
%             truth_state = dataInfo.truth_state;
        else
            truth_state = car_state;
        end

        if fillDataFront && length(time2) ~= length(truth_state)
            truth_state = [repmat(truth_state(1,:),fillDataFront,1); truth_state];
        end


        dataInfo.truth_state = truth_state;
        dataInfo.truth_state_load = truth_state;

        % use new (recalculated) car and sen_states
        dataInfo.car_state = car_state;
        dataInfo.sen_state = SentralOutput;
        dataInfo.time = dataStruct.time;



        %%% Plotting
        N = size(magData,1);
        %         iRefInds = 1:4;
        if ~dataInfo.preCalLoop
            % cal section defined by 'Calibration_FLAG'
            dataCalFlags = single([parkStatusAy.('Calibration_FLAG')]');
            if ~isempty(dataInfo.startTime)
                runFlags = time2>=dataInfo.startTime;
                tcalRangeInds = find(runFlags & ~dataCalFlags);
            else
                tcalRangeInds = find(~dataCalFlags);
            end
            if ~isempty(tcalRangeInds)
                calTime = [time2(tcalRangeInds(1)) time2(tcalRangeInds(end))];
            end
        else
            tcalRangeInds = find(time2>=calTime(1) & time2<=calTime(2));
        end
        %         iRefInds = tcalRangeInds;


        dataInfo.preCalLoop = preCalLoop;
        dataInfo.calTime = calTime;
        tcalRangeInds = find(time2>=calTime(1) & time2<=calTime(2));
        magDataCal = magData(tcalRangeInds,:);


        %         magDataRef = mean(magData(iRefInds,:),1);
        magDataRef = ParkingStruct.AVGInit2; % use park algor cal as reference
        magDataDelta = magData - repmat(magDataRef,N,1);
        magDataDeltaR = sqrt(sum(magDataDelta.^2,2));

        magDataDeltaDiff = [0 0 0; diff(magDataDelta)];
        magDataDeltaDiffR = sqrt(sum(magDataDeltaDiff.^2,2));

        magDataR = sqrt(sum(magData.^2,2));

        mmnCln = reshape([filtStructAy.mmnCln],3,N)';
        mstdCln = reshape([filtStructAy.mstdCln],3,N)';
        mslopeCln = reshape([filtStructAy.mslopeCln],3,N)';
        mslopeMoveClnStd = reshape([filtStructAy.mslopeMoveClnStd],3,N)';
        mslopeMoveClnMn = reshape([filtStructAy.mslopeMoveClnMn],3,N)';
        magStableMeas = [sqrt(sum(mstdCln.^2,2))  sqrt(sum(mslopeMoveClnMn.^2,2))];

        dataStruct.magDataRef = magDataRef;
        dataStruct.magDataCal = magDataCal;
        dataStruct.magDataCalStd = std(magDataCal,0,1);
        dataStruct.parkStatusAy = parkStatusAy;
        dataStruct.parkMeasAy = parkMeasAy;


        %%% Plotting
        if plotDataFlag
            plotData.fNameTitle = fNameTitle;
            plotData.timeRaw = timeRaw;
            plotData.time2 = time2;
            plotData.dt = dt;
            plotData.servTime = servTime;
            plotData.tgapmeas = tgapmeas;
            plotData.dtBigInds = dtBigInds;
            plotData.LS_Trigger_FLAG_ay = LS_Trigger_FLAG_ay;
            plotData.parkStatusAy = parkStatusAy;
            plotData.parkMeasAy = parkMeasAy;
            plotData.startInd = startInd;
            plotData.time2Temp = time2Temp;
            plotData.car_state = car_state;
            plotData.truth_state = truth_state;
            plotData.SentralOutput = SentralOutput;
            plotData.tcalRangeInds = tcalRangeInds;
            plotData.magData = magData;
            plotData.magDataRef = magDataRef;
            plotData.magDataDelta = magDataDelta;
            plotData.magDataDeltaR = magDataDeltaR;
            plotData.magDataDeltaDiff = magDataDeltaDiff;
            plotData.magDataDeltaDiffR = magDataDeltaDiffR;
            plotData.magDataR = magDataR;
            plotData.mmnCln = mmnCln;
            plotData.mstdCln = mstdCln;
            plotData.mslopeCln = mslopeCln;
            plotData.mslopeMoveClnStd = mslopeMoveClnStd;
            plotData.mslopeMoveClnMn = mslopeMoveClnMn;
            plotData.magStableMeas = magStableMeas;

            [plotInfo,figPlotS,cntrlInfo,haxS] = parkingDataPlot(plotData,dataStruct,dataInfo,cntrlInfo,parkImageShow,plotInfo,figPlotS,haxS);

            if 0% isfield(dataStruct,'dataDiagAy')
                dataDiagAy = dataStruct.dataDiagAy;
                figure(999999); clf
                hax1 = axes;
                %             xclr = 'b'; yclr = 'g'; zclr = 'r';

                % hdr.iDiag = {'maxAxis', 'minAxis', 'dataMax', 'dataMin', 'std', 'stdMax'};
                plot(hax1,time2,dataDiagAy(:,1),'-','LineWidth',1.5,'MarkerSize',14,'Color',[1 0 0]); hold all
                plot(hax1,time2,dataDiagAy(:,2),'-','LineWidth',1.5,'MarkerSize',14,'Color',[0 0 1]); hold all
                plot(hax1,time2,dataDiagAy(:,3),'p-','LineWidth',2,'MarkerSize',8,'Color',[0.8 0 0]); hold all
                plot(hax1,time2,dataDiagAy(:,4),'p-','LineWidth',2,'MarkerSize',8,'Color',[0 0 0.8]); hold all
                plot(hax1,time2,dataDiagAy(:,5),'.-','LineWidth',1.5,'MarkerSize',14,'Color',[0 0.8 0]); hold all
                plot(hax1,time2,dataDiagAy(:,6),'.-','LineWidth',1.5,'MarkerSize',14,'Color',[0 1 0]); hold all
                grid on
                title('Diag Values')
                legend('maxAxis', 'minAxis', 'dataMax', 'dataMin', 'std', 'stdMax');
            end


        end

        %         if length(dataInfo.calTime)>1
        %             cntrlInfo.calTimesEdit.String = [num2str(dataInfo.calTime(1)) ', ' num2str(dataInfo.calTime(2))];
        %         end


        %%% docking
        if plotDataFlag
            plotflds = fieldnames(figPlotS);
            for ifld = 1:length(plotflds)
                try
                    if figPlotS.(plotflds{ifld})(1)
                        if figPlotS.(plotflds{ifld})(2)
                            set(figPlotS.(plotflds{ifld})(1),'WindowStyle','docked')
                        else
                            set(figPlotS.(plotflds{ifld})(1),'WindowStyle','normal')
                        end
                    end
                catch
                    disp('Figure Docking Error!!!\n');
                end
            end

            %%% link plots
            %     linkaxes([hax1 hax2 hax4 hax3q],'x')
            %         linkprop([hax0 hax1 hax2 hax4 hax5 hax3q],'xlim');
            %         linkprop([hax hax hax hax],'xlim');

            plotInfo.haxS = haxS;
            linkflds = fieldnames(haxS);
            haxAy = [];
            for ifld=1:length(linkflds)
                figFld = linkflds{ifld};
                figFldMain = strtok(figFld,'_');
                if ~isempty(haxS.(linkflds{ifld})) && figPlotS.(figFldMain)(3)
                    haxAy = [haxAy haxS.(linkflds{ifld})];

                    % add server time to datatip display
                    % create custom data cursor display
                    try
                        if ~strcmp(linkflds{ifld},'parkStatus') && ~strcmp(linkflds{ifld},'parkMeas')
                            dcm_obj3 = datacursormode(figPlotS.(linkflds{ifld})(1));
                            set(dcm_obj3,'UpdateFcn',@dispMkrTimeFcn);
                        end
                    catch
                    end
                end
            end
            plotInfo.haxAy = haxAy;

            haxDebug = [];
            if ~isempty(haxAy)
                haxList = [haxAy haxDebug];
                haxList = haxList(isvalid(haxList));
                linkprop(haxList,'xlim');
                %             linkParkPlots;
            end

            %%% >>> load parking camera images
            if parkImagesFlagInit
                camDir = [PathName 'cameraLogs\'];
                parkImageShow = loadMatchingParkingImagesAll(parkImageShow,camDir,servTime);
            end
            if parkImageShow.on && isfield(parkImageShow,'dateTimeAyAy') && ~isempty(parkImageShow.dateTimeAyAy)
                parkImageShow = parkImagesUpdate2File(figPlotS,plotInfo,dataInfoExtra,parkImageShow);
            end
            %%% >>> load parking camera images
        end

        %%% Display noise
        disp('Mag Calibration Noise (uT): ')
        disp(dataStruct.magDataCalStd)

        %%% Save Data
        % this file will be overwritten by a truth eidt file if the truth file is saved.
        [pathstr,fileName,ext] = fileparts(dataInfo.fileName);
        save([dataInfo.pathName fileName fsuffix '.mat'],'dataInfo','dataStruct')


    else
        disp('No Valid Data...')


    end
    if file_index>=numfiles
        % continue...
    elseif numfiles>1 && waitTime
        pause(waitTime)
    elseif numfiles>1 && plotDataFlag
        disp('Hit any key to continue...');
        pause % hit key to continue
    end

end


%% show metrics
% needs path for metrics repo
try
    plotDataFig = 0; % 0=off; # = fig number
    waitTime = 0.01; % seconds to pause after each file
    % if 0, pause indefinitley

    fileList0 = alldatfiles';
    fileList = [];
    for ii = 1:length(fileList0)
        fileList = [fileList; {[PathName fileList0{ii}]}];
    end
    statSS = truthMetricCalcFileList(fileList,waitTime,plotDataFig);

    if ~isempty(statSS)
        format short g
        fprintf('\n')
        disp('ML Accuracy Table')
        disp(statSS.Tmeas(:,1:6));
        disp('Overall Meas Accuracy Table')
        disp(statSS.TmeasCombine);

        fprintf('\n')
        disp('Sen Accuracy Table')
        format short g
        disp(statSS.Tsen(:,1:6));
        disp('Overall Accuracy Table')
        disp(statSS.TsenCombine);
    end
    % statSS = [];


    %%% Save Metrics
    pathMetrics = [PathName 'metrics\'];
    if ~isdir(pathMetrics)
        mkdir(pathMetrics)
    end
    save([pathMetrics 'statSS_' datestr(now,'yyyy-mmm-dd_hh_MM')], 'statSS')
catch
end

return







%%% >>> for saving a screenshot with multiple figures
screenImages = captureScreen; % images of all monitor screens

iscreen = 2;
imwrite(screenImages{iscreen},['carStates4' '.png']);
%%% >>> for saving a screenshot with multiple figures





