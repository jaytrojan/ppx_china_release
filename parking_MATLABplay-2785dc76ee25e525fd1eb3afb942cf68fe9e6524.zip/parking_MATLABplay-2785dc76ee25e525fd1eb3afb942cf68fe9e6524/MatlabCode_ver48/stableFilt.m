function filtStruct = stableFilt(filtStruct,mdata)
% slope/noise stability filter
% I/O
% filtStruct - filter structure for stabilty buffer and results
% mdata - mag data [ x y z] (single)

nrows = size(filtStruct.mbuf,1);

validFlags = zeros(nrows,1,'uint8');
if filtStruct.ibuf<filtStruct.Nbuf
    filtStruct.ibuf = filtStruct.ibuf+1;
    filtStruct.mbuf(filtStruct.ibuf,:) = mdata;
else
    filtStruct.mbuf = [filtStruct.mbuf(2:end,:); mdata]; % drop oldest, add new at end
end
validFlags(1:filtStruct.ibuf,:) = 1;

%%% stats including outliers
[filtStruct.mmn, filtStruct.mstd] = Parking_MnStd(filtStruct.mbuf,validFlags);



%%%%% rem limited number of outliers
%%% base on magnitude (R of xyz deltas) of deviations
nmax0 = single(round(filtStruct.outRatio*single(filtStruct.ibuf)));
% reset mtempbuf1 to [0]
filtStruct.mtempbuf1 = zeros(size(filtStruct.mtempbuf1),'single');
for ii=1:filtStruct.ibuf
    if validFlags(ii)
        mdelta = (filtStruct.mbuf(ii,:) - filtStruct.mmn);
        filtStruct.mtempbuf1(ii,:) = sqrt(sum(mdelta.^2,2));
    end    
end


[filtStruct.mtempbuf1, indsSort] = sort(filtStruct.mtempbuf1,'descend'); % indsSort is original index sorting
nOutCnt = uint8(0);
for ii=1:filtStruct.Nbuf
    if filtStruct.mtempbuf1(ii) > filtStruct.outLimit(1) && filtStruct.mtempbuf1(ii) < filtStruct.outLimit(2)
        validFlags(indsSort(ii)) = uint8(0);
        nOutCnt = nOutCnt+1;
    end
    if nOutCnt>=nmax0
        break
    end
end


%%% stats with outliers removed (clean)
[filtStruct.mmnCln, filtStruct.mstdCln] = Parking_MnStd(filtStruct.mbuf,validFlags);


mslopeCln = single([0 0 0]);
iprev = uint8(0);
for ii=1:filtStruct.ibuf
    if iprev && ii>iprev && validFlags(ii)
        mslopeCln = mslopeCln + (filtStruct.mbuf(ii,:) - filtStruct.mbuf(iprev,:));
    end    
    if validFlags(ii)
        iprev = uint8(ii);
    end
end
filtStruct.mslopeCln = mslopeCln;


% moving slope Cln Buffer Measurements
if filtStruct.ibuf<filtStruct.Nbuf
    filtStruct.mslopeClnbuf(filtStruct.ibuf,:) = mslopeCln;
else
    filtStruct.mslopeClnbuf = [filtStruct.mslopeClnbuf(2:end,:); mslopeCln]; % drop oldest, add new at end
end
[filtStruct.mslopeMoveClnMn, filtStruct.mslopeMoveClnStd] = Parking_MnStd(filtStruct.mslopeClnbuf,validFlags);
% aaa=999;



