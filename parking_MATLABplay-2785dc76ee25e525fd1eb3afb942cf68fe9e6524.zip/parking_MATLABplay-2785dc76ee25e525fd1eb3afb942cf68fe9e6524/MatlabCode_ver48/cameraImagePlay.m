
% for aligning time data to images...
camDir = '..\..\Data\cameraLogs'

fnameTime = 'FrontParkingImages171221-095836_time';
filename = 'FrontParkingImages171221-095836';

% fnameTime = 'FrontParkingImages171219-164049_time';

fmt = 'tif';

timeAyLoad = load([camDir '\' fnameTime],'timeAy');
timeAyLoad = timeAyLoad.timeAy;
timeAy = timeAyLoad(1:end);
% save([camDir '\' fnameTime],'timeAy');

% load images
tic
imageAy = loadImageArray([camDir '\' filename],fmt);
% infoImage=imfinfo([filename '.' fmt]);
% Nimages=length(infoImage);
% mwidth=InfoImage(1).Width;
% nheight=InfoImage(1).Height;
% 
% toc
% imageAy = zeros(nheight,mwidth,3,Nimages,'uint8');
% for im = 1:Nimages
%     imageAy(:,:,:,im) = imread([filename '.' fmt],im);
% end
toc

dateTimeAy = datetime(timeAy,'ConvertFrom','datenum');



figure(1); clf

iii = 1;
parkImage = imageAy(:,:,:,iii);
image(parkImage);
disp(dateTimeAy(iii));

    
% display images
figure(2); clf
% tic
itoff = 300;
timeAy = [];
for im = 1:Nimages
    parkImage = imageAy(:,:,:,im);
    image(parkImage);
    
    it = im+itoff;
    t = timeAyLoad(it);
    disp(datestr(t));
    timeAy(im) = t;
    drawnow
    pause(0.0)
end
% toc

return

% save updated timeAy
save([filename '_time'],'timeAy');




aaa=999;
