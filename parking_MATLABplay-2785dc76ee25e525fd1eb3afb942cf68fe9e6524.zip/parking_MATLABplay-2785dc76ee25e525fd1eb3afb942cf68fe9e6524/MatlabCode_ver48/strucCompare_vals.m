
function [scomp_match, scomp, stype_match, stype, fldMissList, fldMatchList] = strucCompare_vals(strucName,S1,S2,fldMissList,fldMatchList,strucLevel0,printInfo)
% Struct Comparison S1 vs. S2
% Possible not all S1 fields are in S2, and not all S2 fields in S1
%
% OUTPUT:
% scomp_match - all match flag
% scomp - struct specifying which fields match
% fldMissList - s1 fields not present in s2
% fldMatchList - all present s1 fields and match status with s2

S_flds1 = fieldnames(S1);
% S_flds2 = fieldnames(S2);

% if all(all(char(S_flds1) ~= char(S_flds2)))
%     scomp_match = [];
%     scomp = [];
%     return
% end

scomp_flags = zeros(length(S_flds1),1);
stype_flags = zeros(length(S_flds1),1);
scomp = [];
stype = [];
strucLevel = strucLevel0;
for ifld = 1:size(S_flds1)
%     if isstruct(S1.(S_flds1{ifld}))
%     scomp_vals1(ifld,:) = {S1.(S_flds1{ifld})};
%     scomp_vals2(ifld,:) = {S2.(S_flds1{ifld})};
    sfield = S_flds1{ifld};
    if isfield(S1, sfield) && isstruct(S2) && isfield(S2, sfield)
        if  ~isstruct(S1.(sfield)) && ~isstruct(S2.(sfield))
            if all(size(S1.(sfield)) == size(S2.(sfield)))
                scomp_flags(ifld) = all(all(S1.(sfield) == S2.(sfield)));
            else
                scomp_flags(ifld) = 0;
            end
            scomp.(sfield) = scomp_flags(ifld);
            stype_flags(ifld) = all(strcmp(class(S1.(sfield)),class(S2.(sfield))));
            stype.(sfield) = stype_flags(ifld);
            
            if printInfo==1
                if ~scomp_flags(ifld)
                    fprintf([strucName '.' sfield '\n']);
                    fprintf('1: '); disp(S1.(sfield)); %fprintf('\n');
                    fprintf('2: '); disp(S2.(sfield)); %fprintf('\n');
                    aaa=999;
                end
            elseif printInfo==2
                fprintf(sfield); disp([scomp_flags(ifld)*ones(size(S1.(sfield),1),1)  S1.(sfield)  S2.(sfield)])
            end
            
            fldMatchList = [fldMatchList; {strucLevel strucName  sfield  scomp_flags(ifld)  stype_flags(ifld)}];
            
        else
            strucLevel = strucLevel0+1;
            [scomp_matchSub, scompSub, stype_matchSub, stypeSub, fldMissList, fldMatchList] = strucCompare_vals(sfield,S1.(sfield),S2.(sfield),fldMissList,fldMatchList,strucLevel,printInfo);
            scomp_flags(ifld) = all(scomp_matchSub);
            scomp.(sfield) = scompSub;
            stype_flags(ifld) = all(stype_matchSub);
            scomp.(sfield) = stypeSub;
        end
    elseif isfield(S1, sfield) && (~isstruct(S2) || ~isfield(S2, sfield))
        % track s1 fields not present in s2
            fldMissList = [fldMissList; {strucLevel strucName  sfield  0}];        
    end
end

scomp_match = all(scomp_flags);
stype_match = all(stype_flags);
