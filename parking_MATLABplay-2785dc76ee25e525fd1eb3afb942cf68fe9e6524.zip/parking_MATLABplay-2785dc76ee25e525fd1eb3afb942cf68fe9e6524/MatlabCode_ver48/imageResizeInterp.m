function imageData = imageResizeInterp(imageData,m)

sXYZ = size(imageData);
gInt = sXYZ(1)/((sXYZ(1)*m));
Xq = round(1:gInt:sXYZ(1));
gInt = sXYZ(2)/(sXYZ(2)*m);
Yq = round(1:gInt:sXYZ(2));
[Xq,Yq] = meshgrid(Yq,Xq);

parkImageResize = [];
parkImageResize(:,:,1) = (interp2(double(imageData(:,:,1)),Xq,Yq,'spline'));
parkImageResize(:,:,2) = (interp2(double(imageData(:,:,2)),Xq,Yq,'spline'));
parkImageResize(:,:,3) = (interp2(double(imageData(:,:,3)),Xq,Yq,'spline'));
imageData = uint8(parkImageResize);