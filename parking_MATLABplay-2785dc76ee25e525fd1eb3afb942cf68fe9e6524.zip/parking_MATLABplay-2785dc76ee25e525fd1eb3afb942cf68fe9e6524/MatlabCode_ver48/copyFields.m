function Scopy = copyFields(S,fldNames)

for ifld = 1:length(fldNames)
    fld = fldNames{ifld};
    Scopy.(fld) = S.(fld);
end
