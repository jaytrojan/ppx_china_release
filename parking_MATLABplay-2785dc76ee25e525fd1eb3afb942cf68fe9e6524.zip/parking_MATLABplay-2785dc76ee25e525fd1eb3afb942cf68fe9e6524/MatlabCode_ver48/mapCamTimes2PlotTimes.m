function [time2Match, camTimeMatch, camIndsMatch] = mapCamTimes2PlotTimes(time2,servTime,camTime)

% time2 = dataInfoExtra.time2;
% servTime = dataInfoExtra.servTime;
% camTime =  parkImageShow.dateTimeAyAy;


% find closest tserv before tcam within tpad
% tpad = 120; % seconds of padding for time matching
% tserv = dataInfoExtra.servTime(index);
% inds = find(dataInfoExtra.servTime >= (tcam-seconds(tpad)) & dataInfoExtra.servTime <= tcam+0*seconds(tpad));

% camTimeMatch = zeros(length(servTime),1,'datetime');
camTimeMatch = repmat(datetime(0,0,0),length(servTime),1);
camIndsMatch = zeros(length(servTime),1);
for ii=1:length(servTime)
    imatch = find(camTime >=servTime(ii),1,'first');
    if ~isempty(imatch)
        camIndsMatch(ii) = imatch;
        camTimeMatch(ii) = camTime(imatch);
    end
end

% find all cam index breaks and fill with inbetween images with
% interpolated time2 values
% camIndsMatchref = camIndsMatch;
% camTimeMatchref = camTimeMatch;
time2Match = time2;
whileCheck = 1;
while whileCheck
    dcamIndsMatch = [0; camIndsMatch(2:end,:) - camIndsMatch(1:end-1,:)];
    ibreak = find(dcamIndsMatch > 1,1,'first');
    if ~isempty(ibreak)
%         dcamIndsMatch(ibreak)
        camInds0 = camIndsMatch(ibreak-1,:);
        camInds1 = camIndsMatch(ibreak,:);
        
        insertCamInds = ((camInds0+1):(camInds1-1))';
        insertCamTimes = camTime(insertCamInds,:);
        camIndsMatch = [camIndsMatch(1:(ibreak-1)); insertCamInds;  camIndsMatch(ibreak:end) ] ;
        camTimeMatch = [camTimeMatch(1:(ibreak-1)); insertCamTimes;  camTimeMatch(ibreak:end) ] ;
        
        % time2 insert interp
        ntimes = camInds1-camInds0-1;
        t0 = time2Match(ibreak-1,:);
        t1 = time2Match(ibreak,:);
        dt = (t1-t0)/(ntimes+1);
        insertTimes = (t0+(dt:dt:(ntimes)*dt))';
        time2Match = [time2Match(1:(ibreak-1)); insertTimes;  time2Match(ibreak:end)] ;
    else
        whileCheck = 0;
    end
end

[camIndsMatch,ia,ic] = unique(camIndsMatch,'stable');
time2Match = time2Match(ia,:);
camTimeMatch = camTimeMatch(ia,:);


%         camTime0 = camTimeMatch(ibreak-1,:);
%         camTime1 = camTimeMatch(ibreak,:);


