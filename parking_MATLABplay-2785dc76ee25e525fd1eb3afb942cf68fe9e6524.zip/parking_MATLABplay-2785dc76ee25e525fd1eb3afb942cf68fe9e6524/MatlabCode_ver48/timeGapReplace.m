function [time2,dtBigInds,tgapmeas] = timeGapReplace(time,tgapmax,tgapreplace)

dt = [0; time(2:end) - time(1:end-1)];

% time2: replace large time gaps
% tgapmax = 60;
dtBigInds = find(dt>=tgapmax);
% tgapreplace = 10;
% [time(dtBigInds-1) time(dtBigInds) time(dtBigInds+1)]

dt2 = dt;
tgapmeas = dt(dtBigInds);
dt2(dtBigInds) = tgapreplace;
time2 = time(1) + cumsum(dt2);