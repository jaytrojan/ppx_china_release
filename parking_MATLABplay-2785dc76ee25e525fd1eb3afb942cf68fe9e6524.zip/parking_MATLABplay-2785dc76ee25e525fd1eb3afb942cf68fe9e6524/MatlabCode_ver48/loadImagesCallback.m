function loadImagesCallback(src,event_data)
% src         handle to the figure that has been clicked
% event_data   object containing event data
%				    (same as the event data of the
%             'ActionPreCallback' callback)

% ActionPostCallback <function_handle> � Function to execute after brushing
% Use this callback to execute code when a brush operation ends. The function handle should reference a function with two implicit arguments:

global dataInfo dataInfoExtra cntrlInfo parkImageShow plotInfo figPlotS

% reset truth to truth_state_load state

% calTimesEdit = cntrlInfo.calTimesEdit.String;
% calTimesEdit = '24.5, 13.2';

parkImageShow.on = cntrlInfo.loadImagesCheck.Value;

if parkImageShow.on
    oldpointer = get(cntrlInfo.figCntrl, 'pointer');
    set(cntrlInfo.figCntrl, 'pointer', 'watch')
    drawnow;
    
    % your computation goes here
    camDir = [dataInfo.pathName 'cameraLogs\'];
    parkImageShow = loadMatchingParkingImagesAll(parkImageShow,camDir,dataInfoExtra.servTime);
    
    
    if isfield(parkImageShow,'dateTimeAyAy') && ~isempty(parkImageShow.dateTimeAyAy)
        %%% add line for id time and image tracking on truth states plot
%         Nimages = length(parkImageShow.dateTimeAyAy);
%         time2_images = dataInfoExtra.time2(1):((dataInfoExtra.time2(end)-dataInfoExtra.time2(1))/(Nimages-1)):dataInfoExtra.time2(end);
        
        parkImageShow = parkImagesUpdate2File(figPlotS,plotInfo,dataInfoExtra,parkImageShow);

% % %         [time2ImagesMatch, camTimeImagesMatch, camIndsImagesMatch] = mapCamTimes2PlotTimes(dataInfoExtra.time2,dataInfoExtra.servTime,parkImageShow.dateTimeAyAy);
% % %  
% % %         parkImageShow.time2ImagesMatch = time2ImagesMatch;
% % %         parkImageShow.camTimeImagesMatch = camTimeImagesMatch;
% % %         parkImageShow.camIndsImagesMatch = camIndsImagesMatch;
% % %         
% % %         figFld = 'carStatesTruth';
% % %         figN = figPlotS.(figFld)(1);
% % %         figure(figN);
% % %         plotInfo.hTimeTrackLine = plot(plotInfo.haxS.carStatesTruth,time2ImagesMatch,-0.25*ones(length(time2ImagesMatch),1),'-','LineWidth',3,'MarkerSize',20,'Color',0.7*[1 1 1]); hold all
% % %         
% % %         if parkImageShow.on
% % %             figure(parkImageShow.figN); clf
% % %             hax = axes('parent',parkImageShow.figN);
% % %             parkImageShow.hax = hax;
% % % 
% % %             for ifig = 1:length(parkImageShow.cursFigs)
% % %                 dcm_obj4 = datacursormode(parkImageShow.cursFigs(ifig));
% % %                 set(dcm_obj4,'UpdateFcn',@dispMkrTimeImage2Fcn);
% % %             end
% % %             
% % %             parkImage = parkImageShow.imageStructAy(1).imageAy(:,:,:,1);
% % %             image(parkImageShow.hax,parkImage);
% % %         end
        
%         for ifig = 1:length(parkImageShow.cursFigs)
%             dcm_obj4 = datacursormode(parkImageShow.cursFigs(ifig));
%             set(dcm_obj4,'UpdateFcn',@dispMkrTimeImage2Fcn);
%         end
    end
    
    set(cntrlInfo.figCntrl, 'pointer', oldpointer)
    drawnow;
end



% [token1, remain] = strtok(calTimesEdit, ' ,');
% [token2] = strtok(remain, ' ,');
% 
% dataInfo.calTime = [str2num(token1) str2num(token2)];
% 
% 
% dataInfo.preCalLoop = cntrlInfo.preCalCheck.Value;


% % update slider
% currentTruth = truth_state_load(logical(cntrlInfo.BrushData),1);
% setVal = currentTruth(1);
% setVal = round(setVal);
% cntrlInfo.sld.Value = setVal;
% cntrlInfo.sldText.String = num2str(setVal);
% 


% % adjust all current brush data to slider value
% currentTruth = dataInfo.truth_state(logical(cntrlInfo.BrushData),1);
% 
% if ~isempty(currentTruth)
%     
%     % set slider to first value
%     setVal = cntrlInfo.sld.Value;
%     
%     setVal = round(setVal);
%     cntrlInfo.sld.Value = setVal;
%     cntrlInfo.sldText.String = num2str(setVal);
%     
%     % make all selected truth match slider
%     hTruthStateLine.YData(logical(cntrlInfo.BrushData)) = setVal;
%     dataInfo.truth_state(logical(cntrlInfo.BrushData),1) = setVal;
% 
% end

