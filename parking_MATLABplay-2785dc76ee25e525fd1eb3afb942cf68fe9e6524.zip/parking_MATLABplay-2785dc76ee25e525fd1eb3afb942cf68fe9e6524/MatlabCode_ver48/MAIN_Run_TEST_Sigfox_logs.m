close all;
clear; clc;
dbstop if error



addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\Sigfox Test')

[FileName,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File -mag data');


delimiter = ',';
startRow = 2;   %10
formatSpec = '%f%s%s%f%f%f%f%f%f%[^\n\r]';
fileID = fopen([FileName],'r');
rawData1 = textscan(fileID, formatSpec, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines' ,startRow-1, 'ReturnOnError', false);

%     size(rawData{1,10},1)
fclose(fileID);

rawData = zeros(size(rawData1{1,9},1),9);


for i =4:9
    temp = rawData1{1,i};
    rawData(:,i) = temp(1:size(rawData1{1,9},1)); 
end


serverTime = rawData1{1,3};

for i = 1:size(rawData,1)

    temp =char(serverTime(i));
    
    hr = str2double(temp(12:13));
    mi = str2double(temp(15:16));
    sec = str2double(temp(18:19));
    
    time1 = hr*60*60+mi*60+sec;
    
    rawData(i,2) = time1; 
    
end


time = rawData(:,2);
time = time(length(time):-1:1);

time = time - time(1);


RSSIdata = rawData(:,7);
RSSIdata = RSSIdata(length(RSSIdata):-1:1);


diffTime = [0 ;diff(time)];


figure;

subplot(2,1,1); plot(time,RSSIdata); grid on;
xlabel('Server Time(seconds)');
ylabel('RSSI');
title('Server Time VS. RSSI');

subplot(2,1,2); plot(time,diffTime); grid on;
xlabel('Server Time(seconds)');
ylabel('delta time(seconds)');
title('delat Server Time');







% mraw = rawData(:,4:6);
% 
% timeRaw = rawData(:,9)+rawData(:,8)*65536;
% timeRaw = (timeRaw-timeRaw(1))/32000;
% 
% 
% figure; plot(timeRaw,mraw); grid on;
% title(FileName);
% xlabel('Time(seconds)');
% ylabel('raw mag data');
% legend('mag-x', 'mag-y', 'mag-z');
