function [cloud_feature] = cloud_feature_parking(mdata)


dataBuffer              = zeros(8,1,'single');
dataBuffer2             = zeros(8,3,'single');
local_avg               = single(0);
dx_history              = zeros(8,1,'single');

filter_alpha            = single(0.8);
filter_beta             = single(0.2);


STD_thresh              = single(2.5);
MA_detection_thresh     = single(2);


K2                      = uint8(0);
SUM                     = single(0) ;    % sum
SUMSq                   = single(0);     % sum square  

dataBufferSize          = uint8(8);



% mdata = mDataRaw1;



car_state = mdata(1,6);
total_time = mdata(end,1)-mdata(1,1);   %%% total time in the HS mode ( uint: second)


HS_startValue        = single(mdata(1,3:5)); 
% HS_endValue          = single(mdata(end,3:5)); 


HS_startValueN       = single(sqrt(mdata(:,3).*mdata(:,3)+...
    mdata(:,4).*mdata(:,4)+...
    mdata(:,5).*mdata(:,5)));   



% max-min mag data
[HS_DataNMax,ind1]           = max(HS_startValueN);
HS_DataNMaxT =mdata(ind1,1)-mdata(1,1); 


[HS_DataNMin,ind2]           = min(HS_startValueN); 
HS_DataNMinT =mdata(ind2,1)-mdata(1,1); 


HS_DataNdiff          = HS_DataNMax - HS_DataNMin ; 


% STD + Moving Avg
HS_STDmax             = single(0);
HS_MAmax              = single(0); 



% max and min mag data during transition period (car entering/ leaving)
HS_DataNmax2          = HS_startValueN(1);
HS_DataNmin2          = HS_startValueN(1); 



for i = 1: length(mdata(:,1))
    

    dataBuffer      = shifting_array(dataBuffer);
    dataBuffer(end) = HS_startValueN(i); 
    
    
    dataBuffer2                  = shifting_array(dataBuffer2);
    dataBuffer2(dataBufferSize,:)= single(mdata(i,3:5));
    


    %setup bias or calc avg.
    if(local_avg == single(0))
       local_avg = HS_startValueN(i);
    else
        %take local average
        local_avg = filter_alpha*local_avg + filter_beta*HS_startValueN(i);
    end

    % ****** FEATURE: DIFFERENCE between current mag and previous mag *********
    dx_history      = shifting_array(dx_history);
    % ParkingStruct.dx_history(end) = single((data1 - ParkingStruct.local_avg)*(data1 - ParkingStruct.local_avg));
    dx_history(end) = single(abs(HS_startValueN(i) - local_avg));

    %get new moving average, compare to last, set new
    if dx_history(1) > single(0)
        moving_avg = mean(dx_history);
    else
        moving_avg = dx_history(end);
    end

    if moving_avg > HS_MAmax
        HS_MAmax  = moving_avg;   
    end

    
    
 
    
    
    
    
    if K2 < dataBufferSize - uint8(1)

        K2 = K2 + uint8(1);
        SUM         = SUM   + HS_startValueN(i) ;             % sum
        SUMSq       = SUMSq + HS_startValueN(i) * HS_startValueN(i);      % sum square         

        if K2 == uint8(1)        
            STD1 = single(0);
        else        
            STD1 = sqrt(abs(SUMSq -SUM*SUM/single(K2))/(single(K2 - uint8(1))));         
        end
    else
        STD1 = Parking_std(dataBuffer,dataBufferSize);
    end    

    if STD1 > HS_STDmax
        HS_STDmax  = STD1;  
    end    
    
    
    
    if STD1 > STD_thresh || moving_avg > MA_detection_thresh
        
        if HS_startValueN(i) > HS_DataNmax2
            HS_DataNmax2          = HS_startValueN(i); 
        end         

        if HS_startValueN(i) < HS_DataNmin2
            HS_DataNmin2          = HS_startValueN(i);         
        end 
        
    end
        
        
    
end

HS_DataNdiff2          = HS_DataNmax2 - HS_DataNmin2 ; 



LS_StartValue    = mean(dataBuffer2);
LS_StartValueN   = mean(dataBuffer);
        

% RSSI = mean(mdata(end-3:end,2));
RSSI = mdata(end,2);


cloud_feature = [car_state RSSI total_time HS_startValue LS_StartValue ...
    HS_DataNMax HS_DataNMin HS_DataNdiff HS_DataNMaxT HS_DataNMinT HS_STDmax HS_MAmax HS_startValueN(1,:) LS_StartValueN HS_DataNmax2 HS_DataNmin2 HS_DataNdiff2];