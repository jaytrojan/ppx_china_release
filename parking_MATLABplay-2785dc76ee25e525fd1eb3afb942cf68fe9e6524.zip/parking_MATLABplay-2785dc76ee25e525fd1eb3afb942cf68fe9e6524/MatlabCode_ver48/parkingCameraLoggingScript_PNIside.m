% parking Camera Logging Script


clear camWatchS

camWatchS.logPath = '..\..\Data\cameraLogs\';
camWatchS.lotSaveDir = 'SideLot\';
camWatchS.filenameSave = 'parkImage';
camWatchS.fmtSave = 'tif';

camWatchS.dayLightCheck = 1; % log during daylight (1hr before and after)
camWatchS.tlogTimes = [6 24]; % only used if not daylight option

%%% date start stop
% times will be all daylight workday hours in this date range
camWatchS.tSchedList = {...
    '15-Jan-2018', '31-Jan-2018'
    };
camWatchS.long = -122.7;                                     % longitude
camWatchS.lat  = 38.4404;                                    % latitude
camWatchS.UTCoff = -8;                                       % UTC offset

% ftp image location
camWatchS.parkLotDir = '/share/AMC0006A_18P7RE'; % side
camWatchS.ftpObj = ftp('download.pnicorp.com','wdWYsnRPIB','CvjMMsjDlp');
camWatchS.camLocalStore = '..\..\Data\cameraLocal\';


camWatchS = parkingCameraWatchFcn(camWatchS)
