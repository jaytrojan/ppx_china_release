%% Algorithm using SSA and SSR with real-time functionality 
% No motion data


close all;
clear; clc;
dbstop if error


% choose and open data file
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\original')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\app_data')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors3')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data')
addpath('C:\Users\yzou\Documents\parking_MATLAB\Test_Vectors\Field_Test\cloud_data\issue_cases')


% [alldatfiles,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File', 'MultiSelect', 'on');
% numfiles=length(alldatfiles);
% 
% 
% for file_index=1:numfiles
% 
%     FileName=char(alldatfiles(file_index));



% % Load PPG and Accel data (need to select multiple data files)
[FileName,PathName] = uigetfile({'Data/;*.csv'},'Choose Log File -mag data');


[mraw,timeRaw,SentralOutput,raw_rate,RSSIdata, DataRaw,cloud_feature] = Read_Data_CloudLog(FileName);


% %sort data by timestamp
% [sortedTimes, sortedIndexes] = sort(timeRaw);
% mraw = mraw(sortedIndexes,:);
% timeRaw = sortedTimes;
% 
% [sortedTimes, sortedIndexes] = sort(SentralOutput(:,1));
% SentralOutput = SentralOutput(sortedIndexes,:);


% magN = sqrt(sum(mraw.^2,2));
% 
% 
% plotind1 = 1;
% plotind2 = length(timeRaw);
% 
% 
% % plot: mag data with markers
% figure;   
% subplot(3,1,1);plot(timeRaw(plotind1:plotind2,:),mraw(plotind1:plotind2,:)); grid on;
% xlabel('Time(seconds)');
% ylabel('raw mag data');
% legend('mag-x', 'mag-y', 'mag-z');
% 
% hold on; 
% y1=get(gca,'ylim');
% 
% 
% subplot(3,1,2); plot(timeRaw(plotind1:plotind2,:),RSSIdata(plotind1:plotind2,:)); grid on;
% subplot(3,1,3); plot(timeRaw(plotind1:plotind2,:),SentralOutput(plotind1:plotind2,:)); grid on;




% plot: mag data with markers
figure;   
subplot(3,1,1);plot(mraw); grid on;
xlabel('Time(seconds)');
ylabel('raw mag data');
legend('mag-x', 'mag-y', 'mag-z');

hold on; 
y1=get(gca,'ylim');


subplot(3,1,2); plot(RSSIdata); grid on;
subplot(3,1,3); plot(SentralOutput); grid on;











% % for i=1:length(markerTimes)
% %     plot([markerTimes(i),markerTimes(i)],y1);hold on;
% % end
% 
% 
% 
% subplot(3,1,2); plot(timeRaw(1:end),magN(1:end)); grid on;
% subplot(3,1,3); plot(timeRaw(1:end),SentralOutput); grid on;
% 
% % diffT= diff(timeRaw);
% % subplot(2,2,4);plot(timeRaw(9:end)/60,diffT(8:end)); grid on;





% magN = sqrt(sum(mraw.^2,2));
% 
% 
% figure;   
% subplot(3,1,1);plot(mraw(8:end,:)); grid on;
% xlabel('Time(seconds)');
% ylabel('raw mag data');
% legend('mag-x', 'mag-y', 'mag-z');
% 
% hold on; 
% y1=get(gca,'ylim');
% 
% % for i=1:length(markerTimes)
% %     plot([markerTimes(i),markerTimes(i)],y1);hold on;
% % end
% 
% 
% 
% subplot(3,1,2); plot(magN(8:end,:)); grid on;
% subplot(3,1,3); plot(SentralOutput(8:end,2)); grid on;



tic;



%% Setup data structures
ParkingStruct = Parking_struct_init;



% if raw_rate <= ParkingStruct.HS_rate
%     
%     warning('upsampling is not supported');
%     
% else
%    
%     factor = floor(raw_rate/ ParkingStruct.HS_rate);
%     sprintf('Down Sampling Factor: %f',factor);    
%     
%     magData       = downsample(mraw,factor);
%     time          = downsample(timeRaw,factor);
%     SentralOutput = downsample(SentralOutput,factor);
% end
    


magData       = mraw;
time          = timeRaw;
SentralOutput = SentralOutput;



N3 = length(magData);


magNdata = zeros(N3,1);
mag_diff = zeros(N3,1);
phase_level = zeros(N3,1);
detection_output = zeros(N3,1);

car_state = zeros(N3,4);

MEAN_value = zeros(N3,2);
STD_value = zeros(N3,1);

MEAN_value2 = zeros(N3,3);

moving_avg = zeros(N3,1);

MEAN_Baseline_value = zeros(N3,1);
STD_Baseline_value = zeros(N3,1);
MEAN_Occupied_value = zeros(N3,1);
STD_Occupied_value = zeros(N3,1);



ALG2Level = zeros(N3,1);
car_state_alg2 = zeros(N3,1);

car_state_buffer =zeros(N3,1);

Alarm_level = zeros(N3,1);

for i = 1:length(magData)
    
    
    if i == 200
        1;
    end
    
    
    if ((abs(magData(i,1)-ParkingStruct.LS_StartValue(1))> ParkingStruct.HS_Trigger_thresh) ...
        || (abs(magData(i,2)-ParkingStruct.LS_StartValue(2))> ParkingStruct.HS_Trigger_thresh) ...
        || (abs(magData(i,3)-ParkingStruct.LS_StartValue(3))> ParkingStruct.HS_Trigger_thresh) )...
        || ParkingStruct.LS_Trigger_FLAG  == uint8(0)
    

    
        % hardware alarm 
        ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),time(i),1);
        
    end



%     % software alarm 
%     ParkingStruct = Parking_AlgorithmWrap(ParkingStruct, magData(i,:),0);    
    
    

   magNdata(i,1) = sqrt(sum(magData(i,:).^2,2));
   MEAN_value(i,1) = ParkingStruct.AVG;
   STD_value(i,1)  = ParkingStruct.STD;
   
   MEAN_value2(i,:) = ParkingStruct.AVG2;
   
   MEAN_value(i,2) = ParkingStruct.moving_avg;
   
   moving_avg(i,1)=ParkingStruct.moving_avg;
   
   
   car_state(i,:) = [ParkingStruct.car_presentCur ParkingStruct.car_presentCur2 ParkingStruct.car_present ParkingStruct.car_present2]; 
   Alarm_level(i,1) = ParkingStruct.LS_Trigger_FLAG; 
   
   RMS(i,1) = ParkingStruct.RMS;
   
   SecondSensor_Req_FLAG(i,:) = ParkingStruct.SecondSensor_Req_FLAG;
    
end



static_state1 = [ParkingStruct.AVGInit2 single(1)];
static_state = [static_state1; ParkingStruct.LS_StartValue_stateALL];

for i = 1:size(static_state,1)
    static_state(i,5) = sum(abs(static_state(i,1:3) - static_state(1,1:3)));
    static_state(i,6) = sqrt(sum(static_state(i,1:3).^2)) - sqrt(sum(static_state(1,1:3).^2));
end




figure;
subplot(4,1,1); plot(time,magNdata),title('absolute mag'); grid on;
subplot(4,1,2); plot(time,MEAN_value(:,2)),title('Feature: Magnetic Counts Change'); grid on;
subplot(4,1,3); plot(time,STD_value),title('Feature: STD'); grid on;
subplot(4,1,4); plot(time,Alarm_level),title('Alarm Trigger Level'); grid on;



figure;
subplot(3,1,1); plot(time,moving_avg),title('Feature: Magnetic Counts Change');  grid on;
subplot(3,1,2); plot(time,car_state),title('Car States from MATLAB'); grid on; 
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
% xlabel('Time (Seconds)');



subplot(3,1,3); plot(time,car_state(:,1)),title('Car States from SENtral'); grid on;
set(gca,'YTick',1:4);
labels = {
        'Empty';
        'Car Entering';
        'Occupied';
        'Car Leaving';
        };
set(gca,'YTickLabel',labels)
xlabel('Time (Seconds)');