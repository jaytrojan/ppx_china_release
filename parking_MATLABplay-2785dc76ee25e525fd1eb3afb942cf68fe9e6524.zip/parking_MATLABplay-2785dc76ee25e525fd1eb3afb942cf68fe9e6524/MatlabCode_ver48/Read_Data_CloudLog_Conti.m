function [mraw,time,SentralOutput,raw_rate,RSSIdata,mDataRaw, sentralTimestamp] = Read_Data_CloudLog_Conti(FileName)

[rawData,~] = xlsread(FileName);

reverseIdx = size(rawData,1):-1:1;
rawData = rawData(reverseIdx,:);

rawData = rawData(rawData(:,2)~=0,:);


diffT = diff(rawData(:,2));
tind = find(diffT< -10^9);

if ~isempty(tind)
    if length(tind)>1
        1;
    end
    
    for i = 1:length(tind)
        rawData(tind(i)+1:end,2)=rawData(tind(i)+1:end,2)+rawData(tind(i),2);
    end
end

%sort data by timestamp
[~, sortedIndexes] = sort(rawData(:,2));
rawData = rawData(sortedIndexes,:);







% ****** load raw mag data
midx=find(~isnan(rawData(:,1)));
mDataRaw=rawData(midx,[2 9 10 11 7]); 

%sort data by timestamp
[~, sortedIndexes] = sort(mDataRaw(:,1));
mDataRaw = mDataRaw(sortedIndexes,:); 


%%%% removal of repeated data
[~,ia,~] = unique(mDataRaw(:,1));
mDataRaw = mDataRaw(ia,:); 


mDataRaw=[mDataRaw zeros(size(mDataRaw,1),3)];
mDataRaw(:,8) = 10;

% %%%%%% SENtral output
sidx1=find(~isnan(rawData(:,5)));
SentralOutputRaw1=rawData(sidx1,[5 2]);    
[~,ia,~] = unique(SentralOutputRaw1(:,2));

sidx = sidx1(ia);
SentralOutputRaw=rawData(sidx,[2 5 8]);

empty_record = [];
for i = 1:length(sidx)
    
    iind = find(mDataRaw(:,1)==SentralOutputRaw(i,1));
    
    if ~isempty(iind)
        mDataRaw(iind,6)=SentralOutputRaw(i,2);
        mDataRaw(iind,7)=SentralOutputRaw(i,3);
        

        %%% car state
        if mDataRaw(iind,6) == 0        
           mDataRaw(iind,6) = 1;
        elseif mDataRaw(iind,6) == 100        
            mDataRaw(iind,6) = 3;        
        elseif mDataRaw(iind,6) == 50        
            mDataRaw(iind,6) = 2;  
        elseif mDataRaw(iind,6) == -50        
            mDataRaw(iind,6) = 4;  
        end         
        
        
        
        
    else
        empty_record = [empty_record;i];
    end
end



for i = 2: size(mDataRaw,1)
    
    if mDataRaw(i,6) == 0 && mDataRaw(i,7) == 0 && mDataRaw(i-1,6) ~= 0 && mDataRaw(i-1,7) ~= 0
        
        mDataRaw(i,6) = mDataRaw(i-1,6);
        mDataRaw(i,7) = mDataRaw(i-1,7); 
        mDataRaw(i,8) = 20;
    end
end







% timestamp in seconds
tRaw = mDataRaw(:,1);
time = (tRaw - tRaw(1,:))/32000;  % time in seconds 

sentralTimestamp = mDataRaw(:,1);

% mag data
mraw = mDataRaw(:,2:4);     
    
RSSIdata = mDataRaw(:,5);


SentralOutput = mDataRaw(:,6:7);






% % ****** load output on from SENtral
% % sidx=find(~isnan(rawData(:,5)));
% % SentralOutputRaw=rawData(~isnan(rawData(:,5)),[5]);
% 
% 
% sidx1=find(~isnan(rawData(:,5)));
% SentralOutputRaw1=rawData(sidx1,[5 2]);    
% [~,ia,~] = unique(SentralOutputRaw1(:,2));
% 
% sidx = sidx1(ia);
% SentralOutputRaw=rawData(sidx,[5 8]);
% 
% 
% SentralOutput = zeros(size(time,1),2);
% 
% endpoint = 1;
% index = 1;
% 
% for i = 1:length(sidx)
%     
%     sentral_index = sidx(i);
%     
%     
%     %%% car state
%     if SentralOutputRaw(i,1) == 0        
%        SentralOutputRaw(i,1) = 1;
%     elseif SentralOutputRaw(i,1) == 100        
%         SentralOutputRaw(i,1) = 3;        
%     elseif SentralOutputRaw(i,1) == 50        
%         SentralOutputRaw(i,1) = 2;  
%     elseif SentralOutputRaw(i,1) == -50        
%         SentralOutputRaw(i,1) = 4;  
%     end    
%     
%     
%     
%     
%     for j = endpoint:length(time)
%         
%         mag_index = midx(j);                  
%         
%         if sentral_index > mag_index
%             
%             SentralOutput(index,:) = SentralOutputRaw(i,:);    
%             index = index + 1;
%             
%         else
%             
%            endpoint = j;
%            break;
%            
%         end
%         
%     end
%     
%     
% end
% 
% if (length(time) > (endpoint-1)) && (~isempty(SentralOutputRaw)) 
%     
%     for i = endpoint:length(time)
%        SentralOutput(i,:) = SentralOutputRaw(end,:); 
%     end
% end
% 



%compute the average rate of a single time axis. axis should be
%a column vector.

%compute delta-t vector
tDels = time(2:end)-time(1:end-1);
%compute frequency vector
tFqs = tDels.^(-1);
%compute mean rate in hz
% raw_rate = mean(tFqs);
% raw_rate = mean(tFqs(1:10));
raw_rate = tFqs(1);






